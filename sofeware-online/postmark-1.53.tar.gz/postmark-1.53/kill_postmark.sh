#!/bin/bash

echo "BEGIN....."
sleep 3600

kill -9 `pidof postmark`
kill -9 `pidof postmark`

echo "====================================" >> test_result
echo "result:" >> test_result
#ls -l /cluster2/test/bb/ | wc -l >> test_result
echo "====================================" >> test_result
echo "                      " >> test_result
echo "END......"
