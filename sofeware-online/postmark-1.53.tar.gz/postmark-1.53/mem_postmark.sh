#!/bin/bash

#PROCESS=`pidof digioceanfs`
PROCESS=7049

echo "Begin watch ${PROCESS}" 
echo "" >> mem_result.txt
echo "" >> mem_result.txt
echo "" >> mem_result.txt
echo "Begin PID=${PROCESS}" >> mem_result.txt

while ((1))
do
	sleep 5 
	echo `ps aux | grep ${PROCESS} | grep -v "grep" | awk '{print $5}'` >> mem_result.txt
done
