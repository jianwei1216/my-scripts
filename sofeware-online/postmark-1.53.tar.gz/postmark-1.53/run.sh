for((;;));do rm -rf /cluster2/test/a*;./postmark conf;done
