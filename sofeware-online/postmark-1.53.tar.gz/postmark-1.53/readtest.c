#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <pthread.h>

long long begin   = 1;
long long count   = 1;
pthread_mutex_t pt_lock;
#define PATH    "/mnt/test/aa"

void *file_count_per(void* argv)
{
	char tmpbuf[307500] = {0, };

	long long tmp_count;
        char tmpname[256] = {0, };
        FILE *fp;
        int ret = 0;
        while(1) {

	   	pthread_mutex_lock(&pt_lock);
	        count++;
		begin++;
		tmp_count = begin;
	        pthread_mutex_unlock(&pt_lock);

                sprintf(tmpname, "%s/%ld", PATH, tmp_count);
                fp = fopen(tmpname, "r+");
                if (!fp) {
                        fprintf(stderr, "fopen %s error, %s\n", tmpname, strerror(errno));
			exit(-2);
                }
                ret = fread(tmpbuf, 307200, 1, fp);
                if (ret < 0) {
                        fprintf(stderr, "fread %s error, %s\n", tmpname, strerror(errno));
			fclose(fp);
                        exit(-3);
                }
                
		fclose(fp);
                unlink(fp);
        }
}

int main(int argc, char *argv[])
{
        int interal = 2;
        long long count_t = 0;
        pthread_mutex_init(&pt_lock, NULL);
        pthread_t pt1;
        pthread_t pt2;
        pthread_t pt3;
        pthread_create(&pt1, NULL, file_count_per, NULL);
        pthread_create(&pt2, NULL, file_count_per, NULL);
        pthread_create(&pt3, NULL, file_count_per, NULL);
        time_t pre_t  = time(NULL);
        time_t next_t = 0;
        while(1) {
                 next_t = time(NULL);
                if ((next_t - pre_t) >= interal) {
                        printf("interal: %d, files: %ld, total: %ld\n", (next_t - pre_t), (count-count_t), count);
                        count_t = count;
                        pre_t   = next_t;
                        next_t  = 0;
                }
        }
        return 0;
}


