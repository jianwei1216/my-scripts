#!/usr/bin/python

import sys
from PIL import Image


def conv(c1, c2):
    global distortion
    c = 0
    alpha = 255

    if 255 + c1 - c2 != 0:
        c = round (255 * c1 / (255 + c1 - c2))

    if 255 + c1 - c2 <= 255:
        alpha = 255 + c1 - c2

    if 255 + c1 - c2 > 255:
        distortion += 1
    return (int(c), alpha)

def new_png_gen (dark_color_jpg, bright_color_jpg, new_name_jpg):
    global distortion

    dark = Image.open (dark_color_jpg, 'r').convert('LA').split()[0]
    bright = Image.open (bright_color_jpg, 'r').convert('LA').split()[0]
    assert dark.size == bright.size

    distortion = 0
    newdata = list (map(conv, dark.getdata(), bright.getdata()))

    img = Image.new ('LA', dark.size)
    img.putdata (newdata)
    img.save (new_name_jpg, "PNG")


if __name__ == '__main__':
    if len(sys.argv) != 4:
        print 'Usage: %s dark_color.jpg bright_color.jpg new_name.jpg' % (sys.argv[0])
        exit()
    
    new_png_gen (sys.argv[1], sys.argv[2], sys.argv[3])
