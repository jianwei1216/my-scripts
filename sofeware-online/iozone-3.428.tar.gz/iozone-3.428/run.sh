#!/bin/bash

if [ $# -lt 2 ];then
{       
echo -e "please input data size range.unit:(KB-MB)\n"
echo -e "example: sh ser_per.sh 4 16 \n"
exit
}
fi

cd /root/current/
var=$1
#size=$(($2*1024))
size=$2

mkdir -p /root/test-data/{log,xls}

until [ $var -gt $size ];do
	/root/current/iozone -C -b /root/test-data/xls/"$var"k.xls -s 3g -r "$var"k -i 0 -i 1 -+m  /root/current/client_list -t 240| tee -a /root/test-data/log/service2_default_"$var"k.log 
	var=$(($var* 2))
done
