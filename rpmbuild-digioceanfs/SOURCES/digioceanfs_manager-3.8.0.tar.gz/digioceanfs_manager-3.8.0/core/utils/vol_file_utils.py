##################################################################
#                                                                #
# This file used operate on vol file beside digioceanfs_manager. #
# It shuold synchronization with digioceanfs_volgen.             #
#                                                                #
##################################################################
# -*- coding: utf-8 -*-
from manager_utils import *

MIRROR_PREFIX = "volume mirror"
VOLUME_END    = "end-volume"
VOLUME_SUB    = "subvolumes"

def last_split(str, sep):
    first_seg  = ""
    second_seg = ""

    str_split = str.split(sep)
    if len(str_split) < 2:
        return None

    for s in str_split:
        if s == str_split[-1]:
            second_seg = s
            break
        if not first_seg:
            first_seg = "%s"%s
        else:
            first_seg = "%s-%s"%(first_seg, s)
    return [first_seg, second_seg]

def vol_afr_mirror(vol_file_path):
    mirror_all = {}
    mirror_single = []
    mirror_single_np = []
    mirror_num = 0

    vol_file = get_config_file(vol_file_path)
    vol_file.seek(0)

    a_line = vol_file.readline()
    while len(a_line) > 0:
        if len(a_line) < 13:
            a_line = vol_file.readline()
            continue

        #pharse one mirror section
        if a_line[0:13] == MIRROR_PREFIX:
            mir_name_l = a_line.split('\n')[0].split(' ', 1)
            if len(mir_name_l) != 2:
                continue
            mir_name = mir_name_l[1]

            mirror_single = []
            mirror_single_np = []

            a_line = vol_file.readline()
            while a_line[0:10] != VOLUME_END and len(a_line) > 0:
                a_split_line = a_line.split()
                if len(a_split_line) >= 2 and a_split_line[0] == VOLUME_SUB:
                    mirror_single = a_split_line[1:]
                a_line = vol_file.readline()

            #initial mirror_num at first arrival of here,
            #use this number to make sure all mirror has same amount of subvolume
            if mirror_num == 0:
                mirror_num = len(mirror_single)

            if mirror_num == len(mirror_single):
                for i in mirror_single:
                    mirror_single_np.append(last_split(i, '-'))
                mirror_all[mir_name] = mirror_single_np
            else:
                return None

        else:
            a_line = vol_file.readline()

    return mirror_all


if __name__ == "__main__":
    print vol_afr_mirror("/etc/digioceanfs_manager/services/test1/test1.vol")
