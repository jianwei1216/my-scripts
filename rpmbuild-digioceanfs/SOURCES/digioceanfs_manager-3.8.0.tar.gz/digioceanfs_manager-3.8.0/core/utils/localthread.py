import os, time
import threading, Queue
import traceback
import time

from manager_utils import digi_debug

class ClusterThread(threading.Thread):
    """
    This thread class inherit from top class threading.Thread, handling some
    complex problems which sometimes needs a little more time.
    """
    def __init__(self, ret_pool, targetObj, target_str, target_args=None, target_kwargs=None):
        super(ClusterThread, self).__init__()
        self.targetObj = targetObj
        self.__target = targetObj.__getattribute__(target_str)
        self.__args = target_args
        self.__kwargs = target_kwargs
        self.targetObj = targetObj
        self.ret_pool = ret_pool
        self.stoprequest = threading.Event()

    def run(self):
        #print "%s start at %s ... " % (self.getName(), str(time.time()))
        count = 0
        count += 1
        #print "loop %d" % count
        #print "%s start at %s" % (self.getName(),str(time.time()))
        #print "%s %s" % (self.getName(), self.stoprequest.isSet())
        self.handler()
        self.stoprequest.wait()
        #else:
            #print "%s ends at %s ..." % (self.getName(), str(time.time()))
        #    pass

    def join(self, timeout=None):
        """
        Overwrite superclass function to get control of lifecycle of instance.
        """
        #print "%s stop at %s" % (self.getName(),str(time.time()))
        self.stoprequest.set()
        threading.Thread.join(self, timeout)
	
	try:
            self.targetObj.disconnect()
	except Exception,e:
            digi_debug("Thread join error: %s" % e, 3)
        #digi_debug('%s job done ...' % self.targetObj)
        #super(ClusterThread, self).join(timeount)

    def wakeup(self):
        self.stoprequest.clear()

    def handler(self):
        """
        This function handle actual problems, could be overwriten by subclass.z
        """
        try:
            #print "%s is handling work ..." % (self.getName())
            if self.__target:
                # ret_pool must be a Queue object
                if self.__target.func_name == 'threadtest':
                    self.__target(self.targetObj.get_name())
                else:
                    self.ret_pool.put([self.targetObj, self.__target(*self.__args)])
        except Exception,e:
            digi_debug("Thread handler raise error: %s" % e, 3)
        #finally:
            # Avoid a refcycle if the thread is running a function with
            # an argument that has a member that points to the thread.
            #del self.__target, self.__args, self.__kwargs

class ClusterThreadPool:

    def __init__(self, thread_count):
        self.data = None#data
        self.data_pool = Queue.Queue()
        self.ret_pool = Queue.Queue()
        self.target_info = None#target_info
        self.target_str = ''
        self.target_args = list()
        self.target_kwargs = dict()
        self.thread_count = thread_count
        self.work_count = 0
        self.thread_list = list()
        self.result_list = list()

    def initPool(self, data=[], target_info=()):
        # self.thread_count = thread_count
        self.data = data
        self.target_info = target_info
        # init data pool
        self.init_data_pool()
        # init thread target args
        self.init_thread_args()
        # init threads
        self.init_threads()

    def init_thread_args(self):
        """
        Analysis target info from tumple target.
        Frist element is name string of target function, secend is args for target function. 
        """
        if self.target_info:
            self.target_str = self.target_info[0]
            self.target_args = self.target_info[1]
            self.target_kwargs = self.target_info[2]
            for d in self.data:
                self.target_kwargs[str(d)] = ''


    def init_threads(self):
        try:
            '''
            for i in range(self.thread_count):
                self.thread_list.append(ClusterThread( self.data_pool, self.ret_pool, target=self.doWork()))
            '''
            for i in range(self.thread_count):
                targetObj = self.data_pool.get_nowait()
                if self.target_str == 'service_online_extend':
                    disks = self.target_args[-1][targetObj]
                    tmp_target_args = self.target_args[:-1]
                    tmp_target_args.append(disks)
                    self.thread_list.append(ClusterThread(self.ret_pool, targetObj, self.target_str, tmp_target_args, self.target_kwargs))
                else:
                    self.thread_list.append(ClusterThread(self.ret_pool, targetObj, self.target_str, self.target_args, self.target_kwargs))
        except Exception, e:
            digi_debug("Thread init raise error: %s" % e, 3)

    def doWork(self):
        try:
            while not self.data_pool.empty():
                #targetObj = self.data_pool.get_nowait()
                targetObj = self.data_pool.get_nowait()
                if self.target_str == 'threadtest':
                    self.ret_pool.put((targetObj, targetObj.__getattribute__(self.target_str)(targetObj.get_name())))
                else:
                    self.ret_pool.put((targetObj, targetObj.__getattribute__(self.target_str)(*self.target_args)))
                targetObj.disconnect()
        except Queue.Empty:
            pass

    def init_data_pool(self):
        if not self.data:
            pass
            #print "No work to do ..."
        else:
            for d in self.data:
                if d:
                    self.work_count += 1
                    self.data_pool.put(d)

    def start_threads(self):
        try:
            for thread in self.thread_list:
                thread.setDaemon(True)
                thread.start()
            for thread in self.thread_list:
                thread.join()
        except Exception, e:
            digi_debug("Thread start raise error: %s" % e, 3)


    '''
    def watch_thread(self):
        while not self.work_count:
            ret = self.ret_pool.get()
            if not ret:
                print "one thread work out result ..."
            else:
                print "one thread work went wrong ..."
    '''

    def get_results(self):
        try:
            while not self.ret_pool.empty():
                yield self.ret_pool.get()
                #print r
        #        self.result_list.append(r)
        #    else:
        #        return self.result_list
        except Queue.Empty:
            pass
            #pass

    def wakeup_threads(self):
        for thread in self.thread_list:
            thread.wakeup()

    def clear_threads(self):
        del self.thread_list[:]

def threadtest(node_name):
    print "%s test start ..." % node_name
    os.system('dd if=/dev/zero of=/root/threadtest/%s bs=1M count=64' % (node_name))
    print "%s test ends ..." % node_name
    return 'test'

if __name__ == '__main__':
    nodes = ['node-1', 'node-2', 'node-3', 'node-4', 'node-5']
    thread_list = []
    Qin = Queue.Queue()
    Qout = Queue.Queue()
    for node in nodes:
        thread_list.append(ClusterThread(Qin, Qout, target=threadtest,args=[node,], kwargs={}))
        #threadtest(node)
    for thread in thread_list:
        thread.start()
    for thread in thread_list:
        thread.join()
    del thread_list[:]
