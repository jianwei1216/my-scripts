#!/usr/bin/python
#coding=utf-8

from mongo_utils import *
from monitor_report_log import digi_log

def usage_digioceanfs_write(data,action):
    match = {}
    result = []

    almcol = Digi_Collection('alarmcol')
    ret = almcol.connect()
    if ret == -1:
        exit(2)

    if action == 'disk_error':

        match = {'type':int(data['type']),'node':(data['node']),'message':'replace@'+data['device'],'servicename':data['servicename'],'handle':data['handle']}
        result = almcol.read(match)
        if len(result) > 0:
            update_match = {'$set':{'device':data['device'],'message':'disk_error'}}
            almcol.update(match,update_match)
            return
        if db_coalesced_choice(almcol,data) == 0:
            get_max_alarm_collection_id(almcol,data)

    if action == 'replace':

        match = {'type':int(data['type']),'node':data['node'],'servicename':data['servicename'],'device':data['device'],'handle':data['handle'],"message":"disk_error"}
        result = almcol.read(match)
        if len(result) > 0:
            update_match = {'$set':{'message':'replace'+'@'+data['message']}}
            almcol.update(match,update_match)
            return
        data["message"] = "replace@"+data["message"]
        if db_coalesced_choice(almcol,data) == 0:
            get_max_alarm_collection_id(almcol,data)


    if action == "brick_down" or action == "dht_down":
        if db_coalesced_choice(almcol,data) == 0:
            get_max_alarm_collection_id(almcol,data)

    if action == "brick_restore":
        match = {'type':600160002,'node':data['node'],'servicename':data['servicename'],'device':data['device'],'handle':'0','message':'brick_down'}
        result = almcol.read(match)
        if len(result) > 0:  
            up_data = {'$set':{'handle':'1','type':700160002}}
            almcol.update(match,up_data)
            return
        match = {'type':600070002,'node':data['node'],'servicename':data['servicename'],'handle':'0','message':"replace@"+data['device']}
        result = almcol.read(match)
        if len(result) > 0:
            up_data = {'$set':{'handle':"1",'type':700160003}}
            almcol.update(match,up_data,True)
            return
    if action == "dht_up":
        atype = data['type'] // 100000000
        if atype == 7:
            htype = int(str(data['type']).replace('7','6',1))
            matches = {'type':htype,'servicename':data['servicename'],'message':data['message'],'device':data['device'],'handle':'0'}
            up_data = {'$set':{'handle':'1','type':data['type']}}
            almcol.update(matches,up_data,True)


def usage_digioceanfs_read(data,action):
    match = {}
    result = []
    almcol = Digi_Collection('alarmcol')
    ret = almcol.connect()

    if ret == -1:
        exit(2)

    if action == "heal_full":
        match = {'type':600070001,'node':data['node'],'servicename':data['servicename'],'device':data['device'],'message':'brick_down','handle':'0'}
        result = almcol.read(match)
        if len(result) > 0:
            return True

        match = {'type':600160002,'node':data['node'],'servicename':data['servicename'],'message':"replace@"+data['device'],'handle':'0'}
        result = almcol.read(match)
        if len(result) > 0:
            return True

        return False
    if action == "dht_status":
        match = {'type':int(data['type']),'servicename':data['servicename'],'message':data['message'],'handle':'0'}
        return True
    return False

def usage_digioceanfs_conversion(disk_info):
    all_disk = disk_info.split(',')
    disk = []
    device = ''
    for i in range(0,len(all_disk)):
        device+=(all_disk[i][all_disk[i].find("wwn-0x"):])+','
        disk.append(all_disk[i][all_disk[i].find("wwn-0x"):])
        #Conversion drive
#    from manager import node_manager
#    import manager_utils 
#    system_disk = node_manager.get_system_disks()
#    len1 = len(system_disk)
#    len2 = len(device)
#    for i in range(0,len1):
##       for j in range(0,len2):
#           if system_disk[i][0] == disk[j]:
#               device += get_position_by_dev(system_disk[i][1])+','
    if len(device) > 0:
        device = device[0:len(device)-1]
    return device

if __name__ == '__main__':
    ### 磁盘挂载点到盘位信息的转换
    #python mongo_utils.py write alarmcol type#600160003 servicename#ec-vol  node#node-1  device#/digioceanfs/wwn-0x6666exb222576333622  message#disk_error   handle#0  action#disk_error
    if len(sys.argv) >= 3:
        if sys.argv[1] == 'write':
            data = {}
            action = sys.argv[-1]
            colname = sys.argv[2]
            for line in sys.argv[3:-1]:
                if line.find('#') >= 0:
                    if line.split('#')[0] == "device":
                        data[line.split('#')[0]] = usage_digioceanfs_conversion(line.split('#')[1])
                        continue
                    if line.split('#')[0] == "type":
                        data[line.split('#')[0]] = int(line.split('#')[1])
                        continue
                    if line.split('#')[0] == "message" and line.split('#')[1][0] == '@':
                        data[line.split('#')[0]] = usage_digioceanfs_conversion(line.split('#')[1][1:])
                        continue
                        
                    data[line.split('#')[0]] = line.split('#')[1]
                else:
                    print 'argv errors'
                    exit(2)
            if data:
                if colname == 'alarmcol':
                    usage_digioceanfs_write(data,action)
            else:
                print 'argv errors'
                exit(2)
        else:
            data = {}
            colname = sys.argv[2]
            for line in sys.argv[3:-1]:
                if line.find('#') >= 0:
#                    if line.split('#')[0] == "device":
#                        data[line.split('#')[0]] = usage_digioceanfs_conversion(line.split('#')[1])
#                        continue
                    if line.split('#')[0] == "type":
                        data[line.split('#')[0]] = int(line.split('#')[1])
                        continue
                    data[line.split('#')[0]] = line.split('#')[1]
                else:
                    print 'argv errors'
                    exit(2)
            if data:
                if colname == 'alarmcol':
                    if usage_digioceanfs_read(data,sys.argv[-1]):
                        exit(0);
                    else:
                        exit(2);
            else:
                pass
                exit(2)
    else:
        print 'argv errors'
        exit(2)
