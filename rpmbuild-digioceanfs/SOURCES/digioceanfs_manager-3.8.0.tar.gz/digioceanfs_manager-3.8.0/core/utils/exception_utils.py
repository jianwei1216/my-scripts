# -*- coding: utf-8 -*-
import os
import sys
import traceback

DEBUG=False

def uni_exception_handler(ex, fd = sys.stderr, limit = None):
    
    exc_type, exc_value, exc_traceback = sys.exc_info()
    
    if not issubclass(type(ex), Exception):
        return
    
    if not type(fd) == file:
        fd = sys.stderr
    
    fd.write("*** print_tb:")
    traceback.print_tb(exc_traceback, limit, fd)
    
    fd.write("*** print_exception:")
    traceback.print_exception(exc_type, exc_value, exc_traceback, limit, fd)
    
    fd.write("*** print_exc:")
    traceback.print_exc(limit, fd)

    if DEBUG:
        print "*** exception brief:"
        print ex
        
        print "*** format_exc, first and last line:"
        formatted_lines = traceback.format_exc().splitlines()
        print traceback.format_list(formatted_lines)
        
        print "*** format_exception:"
        print repr(traceback.format_exception(exc_type, exc_value,
                                              exc_traceback))
        
        print "*** extract_tb:"
        print repr(traceback.extract_tb(exc_traceback))
        
        print "*** format_tb:"
        print repr(traceback.format_tb(exc_traceback))
        
        print "*** tb_lineno:", exc_traceback.tb_lineno


class Normal_Logic_Ext(Exception):
    
    def __init__(self, value):
        self.value = value
        
    def __str__(self):
        return repr(self.value)
    
'''
def __se_examine__():
    
    try:
        a = []
        b = a[10]
        print b
        
    except Exception, ex:
        print issubclass(type(ex), Exception)
        uni_exception_handler(ex)
        
'''