#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
from manager_utils import *
import tempfile
import time

import settings

#NFS_CONF = "/etc/exports"
NFS_CONF = settings.NFSCONF
#NFS_RMTAB = "/var/lib/nfs/rmtab"
NFS_RMTAB = settings.NFSRMTAB 

def nfs_service_list():
    cmd = []
    cmd.append("/sbin/showmount")
    cmd.append("-e")
    cmd.append("--no-headers")
    cmd.append("127.0.0.1")
    img = tempfile.TemporaryFile()
    ret = execute(cmd, std=img)
    lines = img.readlines()
    service_list = []
    for a_line in lines:
        service_list.append(a_line.split()[0])
    return service_list

def nfs_service_in_use_list():
    cmd = []
    cmd.append("/sbin/showmount")
    cmd.append("--no-headers")
    cmd.append("-d")
    cmd.append("127.0.0.1")
    img = tempfile.TemporaryFile()
    ret = execute(cmd, std=img)
    lines = img.readlines()
    service_inuse_list = []
    for a_line in lines:
        service_inuse_list.append(a_line.split('\n')[0])
    return service_inuse_list

def nfs_config_add(service_name):
    handle = os.popen("get_fsid %s"%(service_name))
    fsid = handle.read()
    digi_debug("Service %s set fsid in nfs configure file with %s" % (service_name, fsid), 7)
    while(fsid[-1] == '\n'):
        fsid = fsid[:-1]
    if(fsid.isdigit() == False):
        return False
    fd = file(NFS_CONF, "r")
    lines = fd.readlines()
    fd.close()
    for a_line in lines:
        if a_line.strip():
            a_service = a_line.split()[0]
            if a_service == service_name:
                return True
    fd = file(NFS_CONF, "a")
    fd.write("%s 127.0.0.1(ro,no_root_squash,no_subtree_check,fsid=%s)\n"%(service_name, fsid))
    fd.close()
    return True

def nfs_config_list_user(service_name):
    fd = file(NFS_CONF, "r")
    lines = fd.readlines()
    fd.close()
    for aline in lines:
        a_service = aline.split()[0]
        if a_service == service_name:
            user_list = aline.split()[1:]
            break
    user_ip_list = []
    if len(user_list) < 1:
        digi_debug("No user for nfs export found", 3)
        return ['nouser']
    elif len(user_list) >= 1:
        for user in user_list:
            user_ip = user.split("(")[0]
            if user_ip != "127.0.0.1":
                user_ip_list.append(user_ip)
            else:
                if len(user_list) == 1:
                    user_ip_list.append('nouser')
        else:
            return user_ip_list        

def nfs_config_add_user(service_name, user_ip):
    handle = os.popen("get_fsid %s"%(service_name))
    fsid = handle.read()
    digi_debug("Service %s set fsid in nfs configure file with %s" % (service_name, fsid), 7)
    while(fsid[-1] == '\n'):
        fsid = fsid[:-1]
    if(fsid.isdigit() == False):
        return 3
    fd = file(NFS_CONF, "r")
    lines = fd.readlines()
    fd.close()
    for aline in lines:
        a_service = aline.split()[0]
        if a_service == service_name:
            flag = lines.index(aline)
            user_list = aline.split()[1:]
            break
    if user_list:
        for user in user_list:
            if user.find(user_ip) >= 0:
                return 2
        else:
            user_list.insert(0, "%s(rw,no_root_squash,no_subtree_check,fsid=%s)" % (user_ip, fsid))
    user_data = ' '.join(user_list)
    lines[flag] = "%s %s" % (service_name, user_data) + "\n"
    lines_data = ''.join(lines)
    fd = file(NFS_CONF, "w")
    fd.write(lines_data)
    fd.close()
    digi_debug("nfs add user ip:%s succeed" % (user_ip),5)
    nfs_reload_config()
    return 1

def nfs_config_del_user(service_name, user_ip):
    fd = file(NFS_CONF, "r")
    lines = fd.readlines()
    fd.close()
    for aline in lines:
        a_service = aline.split()[0]
        if a_service == service_name:
            flag = lines.index(aline)
            user_list = aline.split()[1:]
    if user_list:
        for user in user_list:
            if user.find(user_ip) >= 0:
                user_list.remove(user)
                break
        else:
            return 2
    lines[flag] = "%s %s\n" % (service_name, ' '.join(user_list))
    fd = file(NFS_CONF, "w")
    lines_data = ''.join(lines)
    fd.write(''.join(lines))
    fd.close()
    digi_debug("nfs del user ip:%s succeed" % (user_ip),5)
    nfs_reload_config()
    return 1


def nfs_config_del(service_name):
    fd = file(NFS_CONF, "r")
    lines = fd.readlines()
    fd.close()
    for a_line in lines:
        a_service = a_line.split()[0]
        if a_service == service_name:
            lines.remove(a_line)
            break
    else:
        return False
    fd = file(NFS_CONF, "w")
    for a_line in lines:
        fd.write(a_line)
    fd.close()
    return True

def nfs_reload_config():
    cmd = []
    cmd.append("/usr/bin/killall")
    cmd.append("-s")
    cmd.append("SIGHUP")
    cmd.append("unfsd")
    ret = execute(cmd)
    digi_debug("nfs:reload config return:%d"%(ret),5)
    time.sleep(1)    

def nfs_restart():
    nfs_stop()
    nfs_start()
    '''
    cmd = []
    cmd.append("/etc/init.d/nfs-kernel-server")
    cmd.append("restart")
    ret = execute(cmd)
    digi_debug("nfs:restart nfs-kernel-server return %d"%(ret))
    '''
    
def nfs_start():
    cmd = []
    cmd.append("/usr/local/sbin/unfsd")
    ret = execute(cmd)
    digi_debug("nfs:start return %d"%(ret),5)
    '''
    cmd = []
    cmd.append("/etc/init.d/nfs-kernel-server")
    cmd.append("start")
    ret = execute(cmd)
    digi_debug("nfs:start nfs-kernel-server return %d"%(ret))
    '''
    
def nfs_stop():
    cmd = []
    cmd.append("/usr/bin/killall")
    #cmd.append("-9")
    cmd.append("unfsd")
    cmd.append("2>/dev/null")
    ret = execute(cmd)
    digi_debug("nfs:stop return %d"%(ret),5)
    '''
    cmd = []
    cmd.append("/etc/init.d/nfs-kernel-server")
    cmd.append("stop")
    ret = execute(cmd)
    digi_debug("nfs:stop nfs-kernel-server return %d"%(ret))
    '''

def nfs_status():
    """
        True:    nfs service start
        False:   nfs service stop
    """
    cmd = []
    cmd.append("/sbin/showmount")
    cmd.append("-e")
    cmd.append("--no-headers")
    cmd.append("127.0.0.1")
    img = tempfile.TemporaryFile()
    ret = execute(cmd, std=img)
    if ret == 0:
        return True
    if img.readlines():
        digi_debug("Service check nfs status with showmount return: %s" % img.readlines(), 7)
    else:
        digi_debug("Service check nfs status with showmount return: None", 3)
    return False

def nfs_add_service(service_name):
    """
        True:    nfs service start
        False:   nfs service stop
    """
    if not nfs_status():
        nfs_start()

    ret = nfs_config_add(service_name)

    nfs_reload_config()

    return ret

def nfs_del_service(service_name):
    """
        True:    nfs service start
        False:   nfs service stop
    """
    if not nfs_status():
        nfs_start()

    ret = nfs_config_del(service_name)
    digi_debug("Service nfs del service config return : %s" % (ret), 7)
    nfs_reload_config()

    return ret

def nfs_status_service(service_name):
    """
        1:    nfs service start, not used
        2:    nfs service start, used
        3:    nfs service stop
    """
    service_list = nfs_service_list()
    digi_debug("search in service list:%s"%(service_list),5)
    for a_service in service_list:
        if a_service == service_name:
            break
    else:
        return 3
    service_inuse_list = nfs_service_in_use_list()
    for a_service in service_inuse_list:
        if a_service == service_name:
            break
    else:
        return 1
    return 2

def get_all_nfs_links(service_name):
    nfs_links = []
    cmd = []
    cmd.append('showmount')
    cmd.append('-a')
    cmd.append('--no-header')
    cmd.append('0.0.0.0')
    img = tempfile.TemporaryFile()
    ret = execute(cmd, img)
    img.seek(0)
    lines = img.readlines()
    if lines:
        for line in lines:
            data = line.strip().split(':')
            if len(data) > 1:
                ip_data = data[0]
                name_data = data[1]
            if name_data.find(service_name) >= 0:
                nfs_links.append(ip_data)
        else:
            return nfs_links
    else:
        return nfs_links
    
def force_del_nfs_link(service_name, tar_ip=''):
    fd = file(NFS_RMTAB, "r")
    lines = fd.readlines()
    fd.close()
    new_lines = []
    if lines:
        for line in lines:
            if tar_ip:
                if line.find(tar_ip) < 0:
                    new_lines.append(line)
            else:    
                if line.find(service_name) < 0:
                    new_lines.append(line)
        else:
            new_fd = file(NFS_RMTAB, "w")
            new_fd.write(''.join(new_lines))
            new_fd.close()
    else:
        return False
    return True
        

if __name__ == "__main__":
    print get_all_nfs_links('/cluster2/tet')
    print force_del_nfs_link('/cluster2/tet')
    print get_all_nfs_links('/cluster2/tet')
    
