#!/usr/bin/python
#coding=utf-8

from monitor_report_log import digi_log

def connect_mongodb():
    mongo_dict = {}
    mongo_dict['monitorcol'] = Digi_Collection ('monitorcol')
    ret = mongo_dict['monitorcol'].connect ()
    if ret == -1:
        digi_log.error("Error connecting to the database  monogodb  monitircol")
        return None
    mongo_dict['alarmcol'] = Digi_Collection ('alarmcol')
    ret = mongo_dict['alarmcol'].connect ()
    if ret == -1:
        digi_log.error("Error connecting to the database  monogodb  alarmcol")
        return None
    mongo_dict['thresholdcol'] = Digi_Collection ('thresholdcol')
    ret = mongo_dict['thresholdcol'].connect ()
    if ret == -1:
        digi_log.error("Error connecting to the database  monogodb  thresholdcol")
        return None
    return mongo_dict

def reconnect_mongodb (collection = '', mongo_dict = {}):
    if not collection:
        digi_log.error ("reconnect which collection ???")
        return -1
    i = 0
    while i < 10:
        if collection == 'monitorcol':
            mongo_dict['monitorcol'] = Digi_Collection('monitorcol')
            ret = mncol.connect ()
            if ret == -1:
                if i == 10:
                    digi_log.error ("reconnect mongodb failed and exit()")
                    exit()
            else:
                break
        if collection == 'alarmcol':
            mongo_dict['alarmcol'] = Digi_Collection('alarmcol')
            ret = mncol.connect ()
            if ret == -1:
                if i == 10:
                    digi_log.error ("reconnect mongodb failed and exit()")
                    exit()
            else:
                break
        if collection == 'thresholdcol':
            mongo_dict['thresholdcol'] = Digi_Collection('thresholdcol')
            ret = mncol.connect ()
            if ret == -1:
                if i == 10:
                    digi_log.error ("reconnect mongodb failed and exit()")
                    exit()
            else:
                break
        i += 1

def get_max_alarm_collection_id(alarmcol,write_data):

    result = []
    id = 0
    ret = -1
    match = {'type':400160001,'message':'save the biggest id','device':'alarmcol'}
    all_db = {}
    if isinstance(alarmcol,Digi_Collection):
        result = alarmcol.read(match)
        if len(result) == 1:
            id = result[0]['save_max_id']
            id += 1
        elif len(result) > 1:
            digi_error("Save the maximum id value database has more than two")
        elif len(result) == 0:
            digi_error("No save the maximum id data entry")
            all_db = alarmcol.read()
            id = len(all_db)
            id += 1
            match['save_max_id'] = id
            ret = alarmcol.write(match)
            digi_debug("Create id number entry, begin  :"+id)
            if ret == -1:
                digi_error("Create id number entry FALSE")
                return  -1
        else:
            pass
        write_data['id'] = id
        ret = alarmcol.write(write_data)
        if ret == -1:
            digi_error("write data false :"+write_data)
            return  -1
        up_data = {'$set':{'save_max_id':id}}
        ret = alarmcol.update(match,up_data,True)
        if ret == -1:
            return -1
        return 0
    else:
        return -1

class Digi_Collection():
    # monitorcol: 监控集合
    # alarmcol：报警集合
    # thresholdcol：阈值集合

    def __init__(self,name):
        self.name = name
        self.wclient = None        # write
        self.rclient = None        # read
        self.db_sharding = False
        self.db_health = False

        self.sort_conds = []
        self.limit_conds = 0

        self.probe_database_process_health()

    def probe_database_process_health(self):
        mongos_cmd = "ps aux | grep mongos | grep 20000 | grep -v 'grep'"            #是否有mongos进程
        config_cmd = "ps aux | grep mongod | grep 21000 | grep -v 'grep'"            #是否有mongod配置服务器进程
        repl_cmd = "ps aux | grep mongod | grep 27017 | grep -v 'grep'"              #是否有mongod副本集进程
        mongos_ret = os.system(mongos_cmd)
        config_ret = os.system(config_cmd)
        repl_ret = os.system(repl_cmd)
        if mongos_ret == 0 and config_ret == 0 and repl_ret == 0:
            self.db_health = True
            self.db_sharding = True
        elif mongos_ret == 256 and config_ret == 256 and repl_ret == 0:
            self.db_health = True
            self.db_sharding = False
        else:
            self.db_health = False
            self.db_sharding = False

    def connect(self):
        # init write client and read client
        if self.db_health and self.db_sharding:          # sharding and replica set
            mpath = 'mongodb://127.0.0.1:20000'
            client = pymongo.MongoClient(mpath)
            self.rclient = self.wclient = client
        elif self.db_health:                             # only replica set
            mpath = 'mongodb://127.0.0.1:27017'
            self.rclient = pymongo.MongoClient(mpath)    # read from local        

            primary = self.rclient.clusterdb.command('isMaster')['primary']
            mpath = 'mongodb://' + primary                
            self.wclient = pymongo.MongoClient(mpath)    # write to primary
        else:
            return -1

        return 0

    #def close(self):
        #self.client.close()

    def write(self,data):
        # data: dict;
        #       写入该集合的数据
        # 如果副本集模式，写数据需要连接到主节点
        global ACOLID
        try:
            col = self.wclient.clusterdb.get_collection(self.name)
            col.insert_one(data)
        except Exception,e:
            if self.name == 'alarmcol':
                ACOLID = ACOLID - 1
            digi_log.error(e)
            return -1

    def read(self,matches={}):
        # matches: dict;
        #          查询条件
        # 返回值为list
        ### matches 需要完善，字段筛选查询的情况
        ### col.find_one({'author':'Mike'},{'author':1})
        read_list = []
        try:
            col = self.rclient.clusterdb.get_collection(self.name)
            result = col.find(matches)
            if self.sort_conds:
                result = result.sort(self.sort_conds)
            if self.limit_conds:
                result = result.limit(self.limit_conds)
            for line in result:
                read_list.append(line)
        except Exception,e:
            return -1
        return read_list

    def update(self,matches,data,many=False):
        # matches: dict;
        #          更新条件
        # data: dict;
        #       需要更新的字段及内容
        #       ex: data = {'$set':{'handled':True}
        #           表示更新指定字段
        #           data = {'date':'2016-03-09 17:00:00','type':'600010001','severity':'WARNING','servicename':'test','message':'High CPU usage','node':'node-1.cluster-1'}
        #           表示更新所有字段
        # 如果副本集模式，写数据需要连接到主节点
        try:
            col = self.wclient.clusterdb.get_collection(self.name)
            if many:
                ret = col.update_many(matches,data)
            else:
                ret = col.update(matches,data)
        except Exception,e:
            digi_log.error("update Failed")
            return -1

    def sort(self,matches):
        # matches: list;
        #          排序键和排序方式组成的序列，可以为一个或多个元素
        #          ex：[('id',pymongo.DESCENDING)] 或 [("id",pymongo.DESCENDING),("node",pymongo.ASCENDING)]
        self.sort_conds = matches

    def limit(self,lmt):
        # lmt: int;
        #      筛选要获取的数量
        self.limit_conds = lmt
