import logging
import logging.config

log_conf = "/usr/local/digioceanfs_manager/log.conf"

try:
    os.mkdir('/var/log/digioceanfs_manager')
    os.system('touch /var/log/digioceanfs_manager/monitor_report.log')
except:
    pass
logging.config.fileConfig(log_conf)
digi_log = logging.getLogger('monitorReport')

def test():
    digi_log.info('This is info message')
    digi_log.debug('This is DEBUG message')
    digi_log.warn('This is Warning message')
    digi_log.error('This is Error message')
    digi_log.critical('This is critical message')

if __name__ == "__main__":
    test()
