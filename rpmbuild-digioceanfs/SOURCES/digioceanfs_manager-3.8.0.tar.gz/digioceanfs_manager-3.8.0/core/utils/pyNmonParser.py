#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Copyright (c) 2015-? Ballma Luo
Parse nmon result
'''
import os
import re
import logging as log
#import settings
import datetime

from xml.dom.minidom import Document
#from manager_utils import *

class pyNmonParser:
    
    def __init__(self, inputStr, outdir='./data', debug=False):
        # TODO: check input vars or "die"
        self.inputStr = inputStr
        self.outdir = outdir
        self.outputStr = ''
        self.debug = debug
        
        # Holds final 2D arrays of each stat
        self.processedData = {}
        # Holds System Info gathered by nmon
        self.sysInfo = []
        self.bbbInfo = []
        # Holds timestamps for later lookup
        self.tStamp = {}
        
        
    def outputCSV(self, stat):
        outFile = open(os.path.join(self.outdir,stat+".csv"),"w")
        line=""
        if len(self.processedData[stat]) > 0:
            # Iterate over each row
            for n in range(len(self.processedData[stat][0])):
                line=""
                # Iterate over each column
                for col in self.processedData[stat]:
                    if line == "":
                        # expecting first column to be date times
                        if n == 0:
                            # skip headings
                            line+=col[n]
                        else:
                            tstamp = datetime.datetime.strptime(col[n], "%d-%b-%Y %H:%M:%S")
                            line += tstamp.strftime("%Y-%m-%d %H:%M:%S")
                    else:
                        line+=","+col[n]
                outFile.write(line+"\n")
                
    def outputXML(self):
        xmlStr = ''
        dom = Document()
        root = dom.createElement('tns:pythonsysinfo')
        dom.appendChild(root)
        root.setAttribute('xmlns:tns', 'http://www.perabytes.com/')
        for key,value in self.processedData.iteritems():
            #print key,value
            if key:
                if key.find('CPU') >= 0:
                    if key == 'CPU_ALL':
                        cpu = dom.getElementsByTagName('CPU')
                        if not cpu:
                            cpu = dom.createElement('CPU')
                            root = dom.getElementsByTagName('tns:pythonsysinfo')[0]
                            root.appendChild(cpu)
                            for v in value:
                                if v[0].find(' ') >= 0:
                                    continue
                                cpu.setAttribute(v[0].replace('%',''), v[1])
                        else:
                            for v in value:
                                if v[0].find(' ') >= 0:
                                    continue
                                cpu[0].setAttribute(v[0].replace('%',''), v[1])
                    else:
                        cpu = dom.getElementsByTagName('CPU')
                        if not cpu:
                            cpu = dom.createElement('CPU')
                            root = dom.getElementsByTagName('tns:pythonsysinfo')[0]
                            root.appendChild(cpu)
                            sub_cpu = dom.createElement(key)
                            for v in value:
                                if v[0].find(' ') >= 0:
                                    continue
                                sub_cpu.setAttribute(v[0].replace('%',''), v[1])
                            else:
                                cpu.appendChild(sub_cpu)
                        else:
                            sub_cpu = dom.createElement(key)
                            for v in value:
                                if v[0].find(' ') >= 0:
                                    continue
                                sub_cpu.setAttribute(v[0].replace('%',''), v[1])
                            else:
                                cpu[0].appendChild(sub_cpu)
                if key == 'NETPACKET':
                    netpacket = dom.createElement('NETPACKET')
                    root = dom.getElementsByTagName('tns:pythonsysinfo')[0]
                    root.appendChild(netpacket)
                    try:
                        for v in value:
                            if v[0].find(' ') >= 0:
                                continue
                            h_dev,h_op = v[0].replace('/s','').split('-')
                            h_value = v[1]
                            h_dev_dom = netpacket.getElementsByTagName(h_dev)
                            if not h_dev_dom:
                                h_dev_dom = dom.createElement(h_dev)
                                h_dev_dom.setAttribute(h_op,h_value)
                                netpacket.appendChild(h_dev_dom)
                            else:
                                h_dev_dom[0].setAttribute(h_op,h_value)
                    except Exception,e:
                        #import traceback
                        #print traceback.print_exc(e)
                        pass
                if key == 'NET':
                    net = dom.createElement('NET')
                    root = dom.getElementsByTagName('tns:pythonsysinfo')[0]
                    root.appendChild(net)
                    try:
                        for v in value:
                            if v[0].find(' ') >= 0 or not v[0]:
                                continue
                            #print v[0].split('-')
                            h_dev,h_op,h_unit = v[0].split('-')
                            h_value = v[1]
                            h_dev_dom = net.getElementsByTagName(h_dev)
                            if not h_dev_dom:
                                h_dev_dom = dom.createElement(h_dev)
                                h_dev_dom.setAttribute(h_op,h_value)
                                net.appendChild(h_dev_dom)
                            else:
                                h_dev_dom[0].setAttribute(h_op,h_value)
                    except Exception,e:
                        import traceback
                        print traceback.print_exc(e)
                
                if key == 'MEM':
                    mem = dom.createElement('MEM')
                    root = dom.getElementsByTagName('tns:pythonsysinfo')[0]
                    root.appendChild(mem)
                    for v in value:
                        if v[0].find(' ') >= 0 or not v[0]:
                            continue
                        mem.setAttribute(v[0], v[1])
                if key == 'DISKBUSY' or key == 'DISKREAD' or key == 'DISKWRITE' or key =='DISKXFER':
                    disk = dom.getElementsByTagName('DISK')
                    if not disk:
                        disk = dom.createElement('DISK')
                        root = dom.getElementsByTagName('tns:pythonsysinfo')[0]
                        root.appendChild(disk)
                        for v in value:
                            try:
                                if v[0].find(' ') >= 0 or not v[0]:
                                        continue
                                h_dev = v[0]
                                h_value = v[1]
                                p = '^sd[a-z]$'
                                if re.match(p, h_dev):
                                    h_dev_dom = dom.createElement(h_dev)
                                    disk.appendChild(h_dev_dom)
                                    h_dev_dom.setAttribute(key, h_value)
                                else:
                                    continue
                            except Exception,e:
                                import traceback
                                print traceback.print_exc(e)
                    else:
                        disk = disk[0]
                        for v in value:
                            try:
                                if v[0].find(' ') >= 0 or not v[0]:
                                        continue
                                h_dev = v[0]
                                h_value = v[1]
                                p = '^sd[a-z]$'
                                if re.match(p, h_dev):
                                    h_dev_dom = disk.getElementsByTagName(h_dev)
                                else:
                                    continue
                                if not h_dev_dom:
                                    h_dev_dom = dom.createElement(h_dev)
                                else:
                                    h_dev_dom = h_dev_dom[0]
                                
                                disk.appendChild(h_dev_dom)
                                h_dev_dom.setAttribute(key, h_value)
                            except Exception,e:
                                import traceback
                                print traceback.print_exc(e)                
        return dom.toprettyxml()
    
    def processLine(self,header,line):
        if "AAA" in header:
            # we are looking at the basic System Specs
            self.sysInfo.append(line[1:])
        elif "BBB" in header:
            # more detailed System Spec
            # do more granular processing
            # refer to pg 11 of analyzer handbook
            self.bbbInfo.append(line)
        elif "ZZZZ" in header:
            self.tStamp[line[1]]=line[3]+" "+line[2]
        else:
            if "TOP" in line[0] and len(line) > 3:
                    # top lines are the only ones that do not have the timestamp
                    # as the second column, therefore we rearrange for parsing.
                    # kind of a hack, but so is the rest of this parsing
                    pid = line[1]
                    line[1] = line[2]
                    line[2] = pid
                    
            if line[0] in self.processedData.keys():
                table = self.processedData[line[0]]
                for n,col in enumerate(table):
                    # line[1] give you the T####
                    if n == 0 and line[n+1] in self.tStamp.keys():
                        # lookup the time stamp in tStamp
                        col.append(self.tStamp[line[n+1]])

                    elif n == 0 and line[n+1] not in self.tStamp.keys():
                        log.warn("Discarding line with missing Timestamp %s" % line)
                        break
                        
                    else:
                        # TODO: do parsing(str2float) here
                        if len(line) > n+1:
                            col.append(line[n+1])
                        else:
                            # somehow we are missing an entry here
                            # As in we have a heading, but no data
                            log.debug("We found more column titles than data for the category:"+line[0]+". This has been observed with some versions of NMON on AIX")
                            log.debug("This tends to happen with the LPAR readings, double check whether your data makes sense, if so you can ignore this.")
                            col.append("0")
                        # this should always be a float
                        #try:
                        #    col.append(float(line[n+1]))
                        #except:
                        #    print line[n+1]
                        #    col.append(line[n+1])
                    
            else:
                # new column, hoping these are headers
                # We are expecting a header row like:
                # CPU01,CPU 1 the-gibson,User%,Sys%,Wait%,Idle%
                header=[]
                if "TOP" in line[0] and len(line) < 3:
                    # For some reason Top has two header rows, the first with only
                    # two columns and then the real one therefore we skip the first row
                    pass
                else:
                    for h in line[1:]:
                        # make it an array
                        tmp=[]
                        tmp.append(h)
                        header.append(tmp)
                    self.processedData[line[0]]=header
            
    def parse(self):
        # TODO: check fname
        rawdata = self.inputStr.split('\n')
        for l in rawdata:
            l=l.strip()
            bits=l.split(',')
            self.processLine(bits[0],bits)

        return self.processedData
    
    def output(self,outType="csv"):
        
        if len(self.processedData) <= 0:
            # nothing has been parsed yet
            log.error("Output called before parsing")
            exit()
        
        # make output dir
        self.outdir = os.path.join(self.outdir,outType)
        if not (os.path.exists(self.outdir)):
            try:
                os.makedirs(self.outdir)
            except:
                log.error("Creating results dir:",self.outdir)
                exit()
                
        # switch for different output types    
        if outType.lower()=="csv":
            # Write out to multiple CSV files
            for l in self.processedData.keys():
                self.outputCSV(l)
        else:
            log.error("Output type: %s has not been implemented." % (outType))
            exit()
            
if __name__ == "__main__":
    inputStr = open("/usr/local/digioceanfs_manager/utils/test-1.nmon").read()
    pynmonParser = pyNmonParser(inputStr)
    print pynmonParser.parse()