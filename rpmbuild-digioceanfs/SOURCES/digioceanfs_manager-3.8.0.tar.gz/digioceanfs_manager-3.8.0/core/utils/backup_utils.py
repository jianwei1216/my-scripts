# -*- coding: utf-8 -*-
import os
import re
import sys
import threading
import traceback
import time
import subprocess
import commands
import socket
import hashlib
import pexpect
import fcntl

import net_utils
import settings
from manager_utils import digi_debug

currpath = os.path.join( os.getcwd(), os.path.dirname(__file__))

mgrpath = os.path.join(currpath[:currpath.rfind('utils')],'manager')

if not mgrpath in sys.path:
    sys.path.append(mgrpath)

# from digi_manager import command_lock_file, command_lock, command_unlock 
import digi_manager 

DEBUG=False

#BACKUP_DIR = "/usr/local/digioceanfs_backup"
BACKUP_DIR = "/usr/local/digioceanfs_gui"

MARK_FILE  = "/var/lock/backup_digioceanfs"

#BACKUP_TARGET = "/etc/digioceanfs_manager /etc/hosts"
#BACKUP_TARGET = "/etc/digioceanfs_manager /etc/digioceanfs/services %s" % settings.HOSTFILE
BACKUP_TARGET = "/usr/local/digioceanfs_gui/password"

BACKUP_MARK   = 'digimgrback'

def get_version_by_fname(fname):
    
    if DEBUG:
	    digi_debug("fname:%s" % fname,5)
    
    if not fname:
        return
        
    fn_arr = fname.split('-')
    
    if len(fn_arr) >= 5:
        if DEBUG:
            digi_debug("Get backup current version: [%s]" % (fn_arr[-3]), 7)
        try:
            return int(fn_arr[-3])
        
        except Exception, e:
            digi_debug("Get backup current version raise error", 3)
            return


def cmd_pack_backup_by_version(version, fcount, md5_sum):
    
    if ((type(fcount) is int) or (type(fcount) is long)) and ((type(version) is int) or (type(version) is long)) and ((type(md5_sum) is int) or (type(md5_sum) is long)):
        fname = "%s.tar.gz" % ("%s/%s-%s-%s-%s-%s" % (BACKUP_DIR, BACKUP_MARK, socket.gethostname(), str(version), str(fcount), str(md5_sum)))
        cmd = "tar -zcf %s %s" % (fname, BACKUP_TARGET)
    else:
        if DEBUG:    
            digi_debug("Pack backup by version found invalid parameter type", 3)
        return None 

    if DEBUG:    
        digi_debug("command:[%s]"%(cmd), 7)
        
    try:
        digi_manager.command_lock()
        (status, outpuut) = commands.getstatusoutput(cmd)
        digi_manager.command_unlock()

    except Exception, e:
        digi_debug("caught exception:%s" % e,3)
        digi_manager.command_unlock()
        return None 

    if status:
        return None
            
    return fname
    
def cmd_pack_backup_by_ts(fcount, md5_sum):
    
    fname = "%s.tar.gz" % ("%s/%s-%s-%s-%s-%s" % (BACKUP_DIR, BACKUP_MARK, socket.gethostname(), str(int(time.time())), str(fcount), str(md5_sum)))
    cmd = "tar -zcf %s %s" % (fname, BACKUP_TARGET)

    if DEBUG:    
        digi_debug("command:[%s]"%(cmd), 7)
        
    try: 
        # subprocess.Popen(cmd, shell=True)
        (status, outpuut) = commands.getstatusoutput(cmd)

    except Exception, e:
        digi_debug("caught exception:%s" % e,3)
        return None 

    if status:
        return None
            
    return fname
    
def cmd_backup_to_remote(fname, ipaddr, passwd='123456\n'):
    
    cmd = "scp -P22 %s root@%s:%s " % (fname, ipaddr, BACKUP_DIR)
    
    if DEBUG:
        digi_debug("fname:[%s]"%(fname),7)
        digi_debug("ipaddr:[%s]"%(ipaddr),7)
        digi_debug("command:[%s]"%(cmd),7)
        
    try:

        child = pexpect.spawn( cmd )
    
        while True:
            i = child.expect([pexpect.EOF, pexpect.TIMEOUT, ' password:', 'continue connecting (yes/no)?'])
            
            if i is 0:
                child.sendline(passwd)
                
            elif i is 1:
                if DEBUG:
                    digi_debug("Command TIMEOUT![%s]"%(cmd),3)
                
                child.close()
                return -1
            
            elif i is 2:
                child.sendline(passwd)
            
            elif i is 3:
                child.sendline('yes')
                continue

            child.close()
            break
    
    except Exception, e:
        digi_debug("caught exception:%s" % e,3)
        return -1

    return 0


def mark_conf_file_updated():
    
    cmd = "echo 1 > %s" % (MARK_FILE)
    
    if DEBUG:
        digi_debug("command:[%s]"%(cmd),5)
            
    try:
        # subprocess.Popen(cmd, shell=True)
        (status, outpuut) = commands.getstatusoutput(cmd)
        
    except Exception, e:
        digi_debug("caught exception:%s" % e,3)
        return -1

    if status:
        if DEBUG:
            digi_debug("command failed![%s]"%(cmd),3)
        return -1
        
    return 0 
    
def unmark_backup_done():
    
    cmd = "echo 0 > %s" % (MARK_FILE)
    
    if DEBUG:
        digi_debug("command:[%s]"%(cmd),5)
        
    try: 
        # subprocess.Popen(cmd, shell=True)
        (status, outpuut) = commands.getstatusoutput(cmd)
    
    except Exception, e:
        digi_debug("caught exception:%s" % e,3)
        return -1
    
    if status:
        if DEBUG:
            digi_debug("command failed![%s]"%(cmd),3)
        return None
        
    return 0

def get_mark_status():
    
    fd = None
    txt = []
    
    try: 
        if not os.path.isfile(MARK_FILE):
            return False
        
        fd  = open(MARK_FILE)
        txt = fd.readlines()
        fd.close()
        
        cle = []
        
        for line in txt:
            cle.append(line.strip())
        
        if DEBUG:
            digi_debug("txt: %s"%(txt),5)
            digi_debug("cle: %s"%(cle),5)
            
        if len(cle) != 1:
            if DEBUG:
                digi_debug("UN-vaild Status! [%s]"%(cle),5)
                
            return None
        
        if int(cle[0]) == 0:
            return False
        
        if int(cle[0]) == 1:
            return True
        
        return None
        
    except Exception, e:
        if not fd.closed:
            fd.close()
        digi_debug("caught exception:%s" % e,3)
        
        return None
    
def available_ssh(ipaddr, port):
    
    try:
        if not net_utils.host_is_reachable(ipaddr):
            return False
        
        ret = net_utils.execute_cmds_remote(ipaddr=ipaddr, port=port, cmds=["mkdir -p %s"%(BACKUP_DIR)])

    except Exception, e:
        digi_debug("caught exception:%s" % e,3)
        return False

    if ret:
        return False
    
    return True
    
def __hex_str_strip__(hstr):
    return hstr.replace("0x","").replace("L","").replace("l","")    

def reduce_sum_up(res1, res2):
    
    if DEBUG:
        digi_debug("%s" % res1,5)
        digi_debug("%s" % res2,5)
    
    if not type(res1) is list:
        if not len(res1) < 32 :
            res1 = [0, res1]
        else:
            res1 = [res1, 0]
            
    if not type(res2) is list:
        if not len(res2) < 32 :
            res2 = [0, res1]
        else:
            res2 = [res2, 0]
            
    return [res1[0] + res2[0], int(str(res1[1] + res2[1])[-32:])]
    

def directory_reduce(fname):
    
    if DEBUG:
        digi_debug("fname:%s" % fname,5)
    
    if not fname:
        return [0,0]
    
    if not os.path.isfile(fname):
        return [0,0]
    
    try:
        #m = md5.new()
        m = hashlib.md5('')
        fd = open(fname, 'r')
        m.update(fd.read())
        fd.close()
        return [1, int(m.hexdigest(),16)]
    
    except Exception, e:
        
        if not fd.closed:
            fd.close()
            
        digi_debug("caught exception:%s" % e,3)
        return [0,0]
        
def directory_map(dname):
    
    absdlst = []
    res = [0,0]
    
    if not dname:
        return [0,0]
    
    if os.path.isfile(dname):
        return directory_reduce(dname)
    
    if os.path.isdir(dname):
        dlist = os.listdir(dname)
        for dn in dlist:
            absdlst.append(dname+os.sep+dn) 

    for dn in absdlst:
        res = reduce_sum_up(res, directory_map(dn))
        
    return res

def latest_pack():
    
    flst = os.listdir(BACKUP_DIR)
    abslst = []
    mver = -1
    
    if DEBUG:
        digi_debug("[file list of %s]: " % (BACKUP_DIR),5)
        digi_debug("%s" % flst,5)
        
    for name in flst:
        
        abspath = BACKUP_DIR + os.sep + name
        
        if DEBUG:
            digi_debug("testing [%s] " % (abspath),5)
            
        try:
            if os.path.isfile(abspath):
                if not name[0] == '.': 
                    fn = name.split('.')
                    if len(fn) == 3:
                        if fn[1] == 'tar':
                            if fn[2] == 'gz':
                                if BACKUP_MARK in fn[0]:
                                    tver = int(get_version_by_fname(name))

                                    if DEBUG:
                                        digi_debug("finding [%s] version [%s], latest version is [%s]" % (name, str(tver), str(mver)),5)
                                            
                                    if tver > mver:
                                        mver = tver
                                        abslst.insert(0, BACKUP_DIR+os.sep+name)
                                            
                                    else:
                                        abslst.append(BACKUP_DIR+os.sep+name)
                                            
                                    continue

            if DEBUG:
                digi_debug('Ignore [%s]' % (abspath),5)
                           
        except Exception, e:
            
            digi_debug("caught exception:%s" % e,3)
            
            if DEBUG:
                digi_debug('Ignore [%s]' % (abspath),5)
            
    # abslst.sort()
    
    if DEBUG:
        digi_debug("%s" % abslst,5)
    
    if len(abslst):
        
        if DEBUG:
            digi_debug("%s" % len(abslst),5)
             
        return abslst[0]
    
    return None
    
def backup_files():

    ssh_avail = 0
    client_list = []
    [cnt, sum]  = [0, 0]
    ver = 0
    
    if not get_mark_status():
        return 0
    
    unmark_backup_done()
    
    for tgt in BACKUP_TARGET.split(' '):
        [c, s] = directory_map(tgt)
        [cnt, sum] = [cnt + c, sum + s]
    
    tlist = net_utils.get_client_list()
    
    if DEBUG:
        digi_debug("client list: %s"%(tlist),5)
         
    for ip in tlist:
        if net_utils.host_is_local(ip):
            continue
        
        if not available_ssh(ip, "22") :
            if DEBUG:
                digi_debug("client %s CANNOT access with ssh key! Please Check!",3)
                
            continue
        
        client_list.append(ip)

    if DEBUG:
        digi_debug("client list: %s"%(client_list),5)
        
    if len(client_list) == 0 :
        sum = sum + 1 # if no client, minus 1 and pack
    
    flatest = latest_pack()
    
    if flatest:
        ver     = get_version_by_fname(flatest) 
    
    if DEBUG:
        digi_debug("latest package: [%s]"%(flatest),5)
            
    if not ver:
        #digi_debug("Failed to get latest version No., Set as default 0",3)
        pass

    if flatest:
        if DEBUG:
            digi_debug("%s-%s"%(str(cnt), str(sum)),5)
                
        # if "%s-%s"%(str(cnt), str(sum)) in flatest:
        if "%s"%(str(sum)) in flatest:
            return 0
    
    fname = cmd_pack_backup_by_version(ver + 1, cnt, sum)
    
    if DEBUG:
        digi_debug("fname:[%s]" % (fname),5)
     
    if fname == None:
        if DEBUG:
            digi_debug("Packup Failed!",3)
        return -1
        
    for ip in client_list:
        cmd_backup_to_remote(fname, ip)
        
    return 0
    
            
def __test__():
    try:
        digi_debug("---- test directory_map() ----")
        [cnt, sum] = directory_map(BACKUP_TARGET)
        digi_debug("%s" % [cnt, sum],5)
        digi_debug("")
        
        digi_debug("---- test cmd_pack_backup() ----")
        digi_debug("%s" % cmd_pack_backup(cnt, sum),5)
        digi_debug("")
    
        digi_debug("---- test cmd_backup_to_remote() ----")    
        digi_debug("%s" % cmd_backup_to_remote( cmd_pack_backup(cnt, sum),"10.10.12.110"),5)
        digi_debug("")
        
        digi_debug("---- test unmark_backup_done() ----")
        digi_debug("%s" % unmark_backup_done(),5)
        digi_debug("")
    
        digi_debug("---- test mark_conf_file_updated() ----")
        digi_debug("%s" % mark_conf_file_updated(),5)
        digi_debug("")
    
        digi_debug("---- test get_mark_status() ----")
        digi_debug("%s" % get_mark_status(),5)
        digi_debug("")
        
        digi_debug("---- test available_ssh() ----")
        digi_debug("%s" % available_ssh("10.10.12.110","9999"),5)
        digi_debug("")
        
        digi_debug("---- test backup_files() ----")
        digi_debug("%s" % backup_files(),5)
        digi_debug("")
            
    except Exception, e:
        digi_debug("caught exception:%s" % e,3)
