import tempfile
import time
import Queue
import signal
import os
import socket
import traceback
import commands
import node_manager

from utils.singleton import Singleton
from utils.manager_utils import *

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)

manager_path = os.path.join(currpath[:currpath.rfind('utils')],'manager')
if not manager_path in sys.path:
    sys.path.append(manager_path)
    
P_ORI = 0
P_UPDATE = 1
P_NEW = 2

class NProcess:
    
    def __init__(self, cmd, service_name = ''):
        self.proc = None
        self.pid = -1
        self.user = ''
        self.cpu = -1
        self.mem = -1
        self.mem_u = 0
        self.name = ''
        self.stat = ''
        self.label = ''
        self.service_name = service_name
        self.cmd_str = cmd
        
    def initProcessInfo(self, pinfo = {}):
        self.pid = pinfo['pid']
        self.user = pinfo['user']
        self.cpu = pinfo['cpu']
        self.mem = pinfo['mem']
        
    def restart(self):
        pass
    
    def update(self):
        if self.pid:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append('ps auxef |grep %s | grep -v grep' % self.pid)
            ret = execute(cmd, tmp_img, shell=True)
            result = tmp_img.readlines()
            if ret:
                try:
                    p_info = result_str.split()
                    self.pid = int(p_info[1])
                    self.user = p_info[0]
                    self.mem = p_info[4]
                    self.cpu = p_info[2]
                    self.mem_u = p_info[3]
                    self.stat = p_info[7]
                    #self.cmd_str = p_info[-1]
                except Exception, e:
                    digi_debug("NProcess, update proc %s status failed" % self.pid)
                if self.stat.find('Z') >= 0:
                    self.free()
                    return False
                return True
            else:
                self.free()
                return False
        else:
            self.free()
            return False
        
    def execute(self):
        digi_debug("NProcess, execute cmd: %s" % self.cmd_str)
        tmp_img = tempfile.TemporaryFile()
        self.proc, self.pid = execute(self.cmd_str, tmp_img, shell=True, nowait=True)
        #NProcessManager().executing = True
        self.update()  
        try:
            NProcessManager().add(self.pid, self)
        except Exception, e:
            digi_debug("NProcess Manager, add proc to child process: %s" % traceback.print_exc(e)) 
        return self.proc, self.pid 
        
    def free(self):
        try:
            #os.kill(self.pid, signal.SIGTERM)
            #os.kill(self.pid, signal.SIGKILL)
            digi_debug('free processing ...')
            self.proc.poll()
            host_info = node_manager.get_all_nodes()
            hostname = commands.getoutput('hostname').strip()
            try:
                sip = socket.gethostbyaddr(hostname)[2][0]
            except:
                sip = '0.0.0.0'
            for host in host_info:
                if hostname == host[0]:
                    sip = host[1]
            #NProcessManager().notify('heal', {'heal':'HealComplete','SourceNode': hostname, 'ErrNode': hostname, 'ServiceName':self.service_name,'SourceIp': sip, 'Pid':self.pid})
            #if notice:
            #    node_manager.send_message(host_info, notice)
            print self.pid, ' ',self.label, ' terminated'
        except Exception,e:
            digi_debug("NProcess Manager, kill pid: %s caught exception: %s" % (self.pid,traceback.print_exc(e)))
            
class NProcessManager:
    
    __metaclass__ = Singleton
    
    def __init__(self, crontime=10):
        self._processes = {}
        self.crontime = crontime
        self.partten = []
        self.waitQueue = {}#Queue.Queue()
        self.executing = False
        # {'service_name': {'partten_1': Queue.Queue(), 'partten_2': Queue.Queue()}}
        
    def init(self, partten):
        digi_debug("NProcess Manager, %s" % self.partten)
        if partten not in self.partten:
            self.partten.append(partten)
        tmp_img = tempfile.TemporaryFile()
        #cmd.append('top -b -n1 |grep %s' % partten)
        #for partten in self.partten:
        for par in self.partten:
            cmd = []
            cmd.append('ps auxef |grep %s | grep -v grep' % par)
            ret = execute(cmd, tmp_img, shell=True)
            result = tmp_img.readlines()
            for result_str in result:
                p = NProcess()
                p.label = par
                try:
                    p_info = result_str.split()
                    p.pid = p_info[1]
                    p.user = p_info[0]
                    p.mem = p_info[4]
                    p.cpu = p_info[2]
                    p.mem_u = p_info[3]
                    
                except Exception, e:
                    pass
                self._processes[p.pid] = p        
            
    def add(self, pid, nProcess):
        if not pid in self._processes:
            self._processes[pid] = nProcess        
            
    def update(self):
        #check child proc
        #digi_debug("NProcess Manager, update proc info")
        try:
            for pid, p in self._processes.copy().iteritems():
                digi_debug("NProcess Manager, proc %s return %s" % (pid, p.proc.poll()))
                if not p.update():
                    self.executing = False
                    del self._processes[pid]
                    digi_debug("NProcess Manager, child proc terminate, del pid: %s" % pid)
        except Exception, e:
            digi_debug("NProcess Manager, update process manager caught exception: %s" % traceback.print_exc(e))
                
                
        for partten in self.partten:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append('ps auxef |grep %s | grep -v grep' % partten)
            ret = execute(cmd, tmp_img, shell=True,err_ignore=True)
            #if ret:
            #    del self.partten[self.partten.index(partten)]
            #    continue
            result = tmp_img.readlines()
            #if partten == 'trusted.ec.heal':
            #    print "NProcess Manager, find partten %s result: %s" % (partten, result)
            for pid, p in self._processes.iteritems():
                print p.pid, '\t', p.stat, '\t', p.service_name
            for k,v in dict(self._processes).iteritems():
                if not v.stat:
                    digi_debug("Node Manager, process %s removed" % v.pid)
                    del self._processes[k]
                else:
                    v.stat = P_ORI
                       
        for service_name in self.waitQueue.keys():
            for partten in self.partten:
                try:
                    # there is no executing partten cmd
                    if not self.executing:
                    #if not self.getProcessByLabel(partten):
                        # there is some partten cmds in queue
                        if not self.waitQueue[service_name][partten].empty():
                            nProcess = self.waitQueue[service_name][partten].get()
                            digi_debug("NProcess Manager, execute wait queue cmd: %s "% cmd)
                            nProcess.execute()
                            
                        else:
                            self.executing = False
                            digi_debug("NProcess Manager, wait queue %s removed" % service_name)
                            del self.waitQueue[service_name][partten]
                    else:
                        digi_debug("NProcess Manager, cmd found executing")#, pid: %s" % [ pid for p in self.getProcessByLabel(partten)])
                except Exception,e:
                    print '----------------'
                    traceback.print_exc(e)
                    print '----------------'
            if not self.waitQueue[service_name]:
                del self.waitQueue[service_name]
        '''        
        digi_debug("NProcess Manager, %s" % self.waitQueue)
        try:
            for service_name in self.waitQueue.keys():
                for partten, q in self.waitQueue[service_name].iteritems():
                    digi_debug("NProcess Manager, %s has %s in queue" % (partten, q.qsize()))
        except Exeption,e:
            digi_debug("NProcess Manager, caught exception: %s" % traceback.print_exc(e))
        '''
                    
    def getProcessByPid(self, pid):
        if pid in self._processes:
            
            return self._processes[pid]
        else:
            return None
        
    def getProcessByLabel(self, partten):
        return self.executing
        p_list = []
        if partten not in self.partten:
            self.init(partten)
        for k,v in self._processes.iteritems():
            print k, v.label, partten
            if v.label.find(partten) >= 0:
                p_list.append(v)
        else:
            digi_debug("NProcess Manager, partten >>> %s <<< filter found %s in process manager" % (partten,[p.pid for p in p_list if p]))
            return p_list
        
    def addWait(self, cmd, service_name, partten):
        nProcess = NProcess(cmd, service_name)
        if service_name in self.waitQueue:
            if partten in self.waitQueue[service_name]:
                self.waitQueue[service_name][partten].put_nowait(nProcess)
                digi_debug("NProcess Manager, add cmd: %s to %s's %s wait queue"% (cmd,service_name, partten))
            else:
                self.waitQueue[service_name][partten] = Queue.Queue()
                digi_debug("NProcess Manager, %s's %s wait queue not init, initing it"% (service_name, partten))
                self.waitQueue[service_name][partten].put_nowait(nProcess)
                digi_debug("NProcess Manager, add cmd: %s to %s's %s wait queue"% (cmd,service_name, partten))
        else:
            self.waitQueue[service_name] = {}
            digi_debug("NProcess Manager, %s's wait dict not init, initing it"% (service_name))
            self.waitQueue[service_name][partten] = Queue.Queue()
            digi_debug("NProcess Manager, %s's %s wait queue not init, initing it"% (service_name, partten))
            self.waitQueue[service_name][partten].put_nowait(nProcess)
            digi_debug("NProcess Manager, add cmd: %s to %s's %s wait queue"% (cmd,service_name, partten))
        self.update()
        
    def execute(self, cmd):
        import signal
        '''
        try:
            signal.signal(signal.SIGCHLD, signal.SIG_IGN)
        except Excpetion, e:
            if e.errno == 10:
                pass
            else:
                digi_debug("NProcess Manager, caught exception: %s" % traceback.print_exc(e))
        '''
        digi_debug("NProcess Manager, execute cmd: %s" % cmd)
        tmp_img = tempfile.TemporaryFile()
        proc, pid = execute(cmd, tmp_img, shell=True, nowait=True)
        self.update()  
        try:
            print self._processes.keys()
            print proc, pid
            self._processes[pid].proc = proc  
        except Exception, e:
            digi_debug("NProcess Manager, add proc to child process: %s" % traceback.print_exc(e))   
        return proc, pid    

    def cron(self):
        try:
            digi_debug("NProcess Manager, %s still incharge " % self._processes.keys())
            while True:
                self.update()
                self.check()
                time.sleep(self.crontime)
        except Exception,e:
            traceback.print_exc(e)
            
    def checkMax(self):
        mem_list = []
        sorted_value_list = sorted(self._processes.items(), lambda x, y: cmp(x[1], y[1]), reverse=True)
            
    def check(self):
        for k,v in self._processes.iteritems():
            #print "%10s %5s %10s" % (p.pid, ' --> ',p.mem)
            #print v.mem, v.stat
            if int(v.mem) >= 3*1024*1024:#*1024*1024:
                #print v.mem
                digi_debug("Node Manager, process %s take %s MB mem, %s" % (k, int(v.mem)/1024, v.label), 3)
            else:
                #digi_debug("Node Manager, process %s take %s MB mem, %s" % (k, int(v.mem)/1024, v.label), 7)
                pass
        else:
            pass #print '--------------------------------------------'
        
    def get(self):
        digi_debug(self._processes.values(), 7)
        
    def notify(self, op, message):
        if op == 'heal':    
            notice = {}       
            notice['CTime'] = time.time()
            notice['OP'] = 'FileSystemEvent'
            notice['FileEvent'] = message['heal']
            notice['SourceNode'] = message['SourceNode']
            notice['ErrNode'] = message['ErrNode']
            notice['ServiceName'] = message['ServiceName']
            notice['SourceIp'] = message['SourceIp']
            notice['Pid'] = message['Pid']
        else:
            pass
        if notice:
            node_manager.send_message(node_manager.get_all_nodes(), notice)
