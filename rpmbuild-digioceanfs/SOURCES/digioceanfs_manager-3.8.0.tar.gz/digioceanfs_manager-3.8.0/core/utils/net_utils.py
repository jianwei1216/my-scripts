#-*- coding: utf-8 -*-

import os
import sys
import re
import string
import subprocess
import socket
import fcntl
import struct
import pexpect
import tempfile

import settings

#currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
#if currpath not in sys.path:
#    sys.path.append(currpath)
#
#homepath = currpath[:currpath.find('libcommon')]
#if not homepath in sys.path:
#    sys.path.append(homepath)
import net_utils_tool
from manager_utils import digi_debug
from manager_utils import *

#ETHFILE = '/etc/network/interfaces'
#ETHFILE = settings.ETHFILE 
NETWORKCONFDIR = settings.NETWORKCONFDIR  #/etc/sysconfig/network-scripts/
#COMMANDS['ifconfig'] = '/sbin/ifconfig'
IFCONFIG = settings.COMMANDS['ifconfig'] 

DEBUG = False

#ipv4
width = 32
max_int = 2 ** width - 1
def iptoint(ip):
    return struct.unpack('!I',socket.inet_aton(ip))[0]

def inttoip(ipint):
    return socket.inet_ntoa(struct.pack('!I',ipint))

def isnetmask(ip):
    intip = iptoint(ip)
    a = ( intip ^ max_int ) + 1
    b = a - 1
    return a & b == 0

def netmaskbits(ip):
    if not isnetmask(ip):
        return width
    numbits = 0
    intip = iptoint(ip)
    while intip > 0:
        if intip & 1 == 1:
            break
        numbits += 1
        intip >>= 1
    masklength = width - numbits
    if 0 <= masklength <= width:
        return masklength
    else:
        raise ValueError('Unexpect mask length %d for address type' % masklength)

def broadcast(ip,netmask):
    ipint = iptoint(ip)
    hostmask = (1 << (width - netmaskbits(netmask))) - 1
    return inttoip(ipint | hostmask)

def bootInterfaces():
    """
    return a list of interfaces brought up at boot time
    """
    rv = []
    conflist = []
    b = {}
    conflist = net_utils_tool.read_env_file(ETHFILE)
    for conf in conflist:
        b['fullname'] = conf['DEVICE']
        m = re.match("(\S+):(\d+)",b['fullname'])
        if 'MAC' in conf and conf['MAC']:
            b['mac'] = conf['MAC']
        else:
            b['mac'] = ''
        if m:
            b['name'] = m.group(1)
            b['virtual'] = m.group(2)
        else:
            b['name'] = b['fullname']
            b['virtual'] = ''
        if conf['ONBOOT'] == 'yes':
            b['up'] = 'yes'
        else:
            b['up'] = ''
        if 'BOOTPROTO' not in conf:
            conf['BOOTPROTO'] = ''
        if 'GATEWAY' not in conf:
            conf['GATEWAY'] = ''
        if conf['DHCP'] == 'dhcp':
            b['dhcp'] = 'yes'
            b['address'] = conf['IPADDR']
            b['netmask'] = conf['NETMASK']
            b['broadcast'] = conf['BROADCAST']
            b['gateway'] = ''
        else:
            b['dhcp'] = ''
            b['address'] = conf['IPADDR']
            b['netmask'] = conf['NETMASK']
            b['broadcast'] = conf['BROADCAST']
            b['gateway'] = conf['GATEWAY']
        b['link'] = conf['LINK']
        b['mode'] = conf['MODE']
        if conf['BOOTPROTO'] == 'bootp':
            b['bootp'] = 'yes'
        else:
            b['bootp'] = ''
        if re.search('^ppp',b['name']):
            b['edit'] = ''
        else:
            b['edit'] = 'yes'
        if 'MTU' in conf and conf['MTU']:
            b['mtu'] = conf['MTU']
        b['index'] = len(rv)
        rv.append(b)
        b = {}
    return rv

def ifaceType(name):
    """
    return a human-readable interface type name
    """
    if re.search("^ppp",name):
        return 'PPP'
    if re.search("^sl",name):
        return 'SLIP'
    if re.search("^plip",name):
        return 'PLIP'
    if re.search("^(eth)",name):
        return 'Ethernet'
    if re.search("^bond",name):
        return 'BOND'
    if re.search("^arc",name):
        return 'Arcnet'
    if re.search("^tr",name):
        return 'Token Ring'
    if re.search("^atp",name):
        return 'Pocket/ATP'
    if re.search("^lo",name):
        return 'Loopback'
    return 'Unknown'

def ipType(ipaddr):
    type = ''
    a = int(ipaddr.split('.')[0])
    if a >= 0 and a <= 126:
        type = 'A'
    elif a >= 128 and a <= 191:
        type = 'B'
    elif a >= 192 and a <= 223:
        type = 'C'
    return type

def canEdit(what):
    #if what not in ['mtu']:
    #    return True
    #return False
    return True

def deleteInterface(interface):
    """
    delete the boot-time interface
    """
    name = ""
    if interface['virtual']:
        name = "%s:%s" % (interface['name'],interface['virtual'])
    else:
        name = interface['name']
    ETHFILE = NETWORKCONFDIR + 'ifcfg-' + name   
    #matchstr = 'auto %s\n' % name
    #f = open(ETHFILE,'r+')
    #line = f.readline()
    #while line:
    #    if re.search(matchstr,line):
    #        addr = f.tell() - len(line)
    #        for i in range(5):
    #            line = f.readline()
    #        temp = f.read()
    #        f.seek(addr)
    #        f.truncate()
    #        f.write(temp)
    #        break
    #    line = f.readline()
    #f.close()
    os.system('%s %s down &>/dev/null' % (IFCONFIG,name))


def saveInterface(interface):
    """
        create or update a boot-time interface
        input para specify:
        interface['virtual']
        interface['name']
        interface['static']
        interface['address']
        interface['netmask']
        interface['gateway']
        interface['broadcast']
        interface['mtu']
        interface['up']
        interface['dhcp']
        interface['bootp']
    """
    conf = {}
    name = ""
    if interface['virtual'] != '':
        name = '%s:%s' % (interface['name'],interface['virtual'])
    else:
        name = interface['name']
    ETHFILE = NETWORKCONFDIR + 'ifcfg-' + name
    conf['BOOTPROTO'] = interface['static']
    conf['DEVICE'] = name
    if interface['static'] != 'dhcp':
        conf['IPADDR'] = interface['address']
        ip = interface['address'].split('.')
        conf['NETMASK'] = interface['netmask']
        if interface['virtual'] == '':
            conf['GATEWAY'] = interface['gateway']
        else:
            conf['GATEWAY'] = ''
        nm = interface['netmask'].split('.')
        if interface['address'] and interface['netmask']:
            l1 = string.atoi(ip[0]) & string.atoi(nm[0]) & 0xff
            l2 = int(ip[1]) & int(nm[1]) & 0xff
            l3 = int(ip[2]) & int(nm[2]) & 0xff
            l4 = string.atoi(ip[3]) & string.atoi(nm[3]) & 0xff
            conf['NETWORK'] = "%d.%d.%d.%d" % (l1,l2,l3,l4)
        else:
            conf['NETWORK'] = ''
        conf['BROADCAST'] = interface['broadcast']
    if 'mtu' in interface and interface['mtu']:
        conf['MTU'] = interface['mtu']
    if 'ipv6' in interface and interface['ipv6']:
        conf['IPV6INIT'] = interface['ipv6']
    if interface['up'] == 'yes':
        conf['ONBOOT'] = 'yes'
    else:
        conf['ONBOOT'] = 'no'
    net_utils_tool.write_eth_file(ETHFILE,conf)

def activeInterface(interface):
    """
    create or modify an interface
    """
    cmd_up =  "%s %s up" % (IFCONFIG,interface['name'].split(':')[0])
    digi_debug('net_utils activeInterface command:%s' % cmd_up,5)
    proc = subprocess.Popen(cmd_up,shell=True,stdout=subprocess.PIPE,close_fds=True)
    retcode = proc.wait()

    if interface['virtual']:
        interface['name'] += ":%s" % interface['virtual']
    cmd = "%s %s " % (IFCONFIG,interface['name'])
    cmd += interface['address']
    if 'netmask' in interface and interface['netmask']:
        cmd += "    netmask    %s" % interface['netmask']
    if 'broadcast' in interface and interface['broadcast']:
        cmd += "    broadcast    %s" % interface['broadcast']
    if 'mtu' in interface and interface['mtu']:
        cmd += "    mtu    %s" % interface['mtu']
    if 'up' in interface and interface['up'] == 'yes':
        cmd += "    up"
    else:
        cmd += "    down"
    cmd += " 2>&1"
    digi_debug('net_utils activeInterface command:%s' % cmd,5)
    proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,close_fds=True)
    retcode = proc.wait()

def getAnInterface():
    interface = dict()
    interface['virtual']   = ''
    interface['name']      = ""
    interface['static']    = "" #"dhcp" or "static"
    interface['address']   = ""
    interface['netmask']   = ""
    interface['gateway']   = ""
    interface['broadcast'] = ""
    interface['mtu']       = ""
    interface['up']        = "" #"yes" or "no"
    interface['dhcp']      = bool
    interface['bootp']     = bool
    return interface

def getFakeInterface(interface):
    i_fake = getAnInterface()
    i_fake['name']      = interface['name'] + ':9999'
    i_fake['address']   = interface['address']
    i_fake['netmask']   = interface['netmask']
    i_fake['gateway']   = interface['gateway']
    i_fake['broadcast'] = interface['broadcast']
    i_fake['up']        = "yes"
    #i_fake['dhcp']      = False
    return i_fake

def setAnInterface(nic_name, new_ip, new_mask, new_gate, new_bcast):
    i = getAnInterface()
    i['name']      = nic_name
    i['static']    = "static"
    i['address']   = new_ip
    i['netmask']   = new_mask
    i['gateway']   = new_gate
    i['broadcast'] = new_bcast
    i['up']        = "yes"
    i['ipv6']      = "yes"
    i['mtu']       = "1500"
    i['virtual']   = ""
    #i['dhcp']      = False
    return i

def set_ip_addr(nic_name, new_ip, new_mask, new_gate, new_bcast):
    ETHFILE = NETWORKCONFDIR + 'ifcfg-' + nic_name
    if not os.path.exists(ETHFILE):
        return False
    i = setAnInterface(nic_name, new_ip, new_mask, new_gate, new_bcast)
    i_fake = getFakeInterface(i)
    deleteInterface(i_fake)
    saveInterface(i)
    activeInterface(i)

def set_fake_ip_addr(nic_name, new_ip, new_mask, new_gate, new_bcast):
    i = setAnInterface(nic_name, new_ip, new_mask, new_gate, new_bcast)
    i_fake = getFakeInterface(i)
    activeInterface(i_fake)

def host_is_reachable(ipaddr):
    try:
        return net_utils_tool.PING(ipaddr)
        # ret = os.system("ping -c 1 -w 1 %s"%(ipaddr))
    except Exception, e:
        digi_debug("caught exception: %s" % e,3)
        return False
    '''
    if ret == 0:
        return True
    
    return False
    '''
    
def get_ip_address(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915,  # SIOCGIFADDR
        struct.pack('256s', ifname[:15])
    )[20:24])

def host_is_local(ipaddr):
    # TODO: This is week
    try: 
        command = "ip ad | grep '%s' | wc -l"%(ipaddr)
        ret = string.strip(os.popen(command).readline())
        if string.atoi(ret) == 1:
            return True
        
        haddr = get_ip_address('eth0')
        if cmp(ipaddr,haddr) == 0:
            return True
        
        haddr = get_ip_address('eth1')
        if cmp(ipaddr,haddr) == 0:
            return True
        
    except:
        return False  

    return False

def getAllIpAddress():
    ipList = []
    cmd = [settings.COMMANDS['ip'],'addr']
    tmp_img = tempfile.TemporaryFile()
    ret = execute(cmd, tmp_img)
    result = tmp_img.readlines()
    if result:
        for line in result:
            if line.find('inet ') >= 0:
                ip_info_list=line.split()
                if len(ip_info_list) >= 2:
                    ipWithPrefix = ip_info_list[1]
                    if len(ipWithPrefix.split('/')) >= 1:
                        ip = ipWithPrefix.split('/')[0]
                        ipList.append(ip)
        else:
            return ipList
    else:
        return []

def get_client_list():
    
    NODEMARK = "####DigioceanfsNode####"
    #fhosts   = "/etc/hosts"
    fhosts   = settings.HOSTFILE 
    ips      = []
    fd = open(fhosts, 'r')
    
    try: 
        lines = fd.readlines()
        
        for line in lines : 
            if NODEMARK in line :
                arr = line.split()
                ips.append(arr[0])
            
        fd.close()
        return ips 
    
    except:
        if not fd.closed:
            fd.close()
            
        return None
    
    return None

def execute_cmds_remote(ipaddr, cmds, passwd='123456', user='root', port='22'):
    
    child = pexpect.spawn( 'ssh -l %s -p %s %s' % (user, port, ipaddr))
    
    while True:
        i = child.expect([pexpect.EOF, pexpect.TIMEOUT, 'password: ', 'continue connecting (yes/no)?', '#'])
        
        if i is 0:
            print "SSH Unsuccessful Terminated"
            return -1
            
        elif i is 1:
            print "SSH TIMEOUT"
            return -1
        
        elif i is 2:
            child.sendline(passwd)
        
        elif i is 3:
            child.sendline('yes')

        elif i is 4:
            child.sendline('cd')
            break

    for c in cmds:
        i = child.expect([pexpect.EOF, pexpect.TIMEOUT, '#'])
        
        if i is 0:
            print "SSH Unsuccessful Terminated"
            return -1
            
        elif i is 1:
            print "SSH TIMEOUT"
            return -1
        
        elif i is 2:
            if DEBUG:
                print c

            child.sendline(c)
            
    child.expect([pexpect.EOF, pexpect.TIMEOUT, '#'])
    child.sendline('exit')
    child.close()
    
    return 0
