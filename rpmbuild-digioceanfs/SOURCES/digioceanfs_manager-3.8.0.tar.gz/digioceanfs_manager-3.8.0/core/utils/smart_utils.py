# -*- coding: utf-8 -*-
import time
import re
import os
import subprocess
import tempfile

import settings

from manager_utils import *

DISK_DEV_PATH="/dev/"

def update_disk_smart():
    execute(['/usr/sbin/update-smartctl-cache'])

def SmartDisable(diskname):
    try:
        flag = False
        devpath = DISK_DEV_PATH + diskname
        cmd = []
        cmd.append(settings.COMMANDS['smartctl'])
        cmd.append('-s')
        cmd.append('off')
        cmd.append(devpath)
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, std=tmp_img)
        result = tmp_img.readlines()
        for line in result:
            if line.find('SMART Disabled') != -1 or line.find('(SMART) disabled') != -1:
                flag = True
        if flag:
            update_disk_smart()
            return 1
        return -1
    except Exception, e:
        digi_debug("Smart Disable error: %s" % e, 3)
        return -1

def SmartEnable(diskname):
    try:
        flag = False
        devpath = DISK_DEV_PATH + diskname
        cmd = []
        cmd.append(settings.COMMANDS['smartctl'])
        cmd.append('-s')
        cmd.append('on')
        cmd.append(devpath)
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, std=tmp_img)
        result = tmp_img.readlines()
        for line in result:
            if line.find('SMART Enabled') != -1 or line.find('(SMART) enabled') != -1:
                flag = True
        if flag:
            update_disk_smart()
            return 1
        return -1
    except Exception, e:
        digi_debug("Smart Enable error: %s" % e, 3)
        return -1

def SmartStatus(diskname):
    try:
        retval = 0
        devpath = DISK_DEV_PATH + diskname
        cmd = []
        cmd.append(settings.COMMANDS['smartctl'])
        cmd.append('-i')
        cmd.append(devpath)
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, std=tmp_img)
        result = tmp_img.readlines()
        for line in result:
            if line.find("SMART support is: Enabled") >= 0:
                retval = 1
                break
            elif line.find("SMART support is: Disabled") >= 0:
                retval = 2
                break 
        return retval
    except Exception, e:
        digi_debug("Smart Enable error: %s" % e, 3)
        return -1

def SmartStart(diskname,smarttype):
    '''
        retcode:
	1 : smart start success
	2 : smart in progress
        3 : smart disabled
        -1: unknown error
    '''
    try:
        prog = SmartProgress(diskname)
        if prog != '0%':
            return 2
        devpath = DISK_DEV_PATH + diskname
        cmd = []
        cmd.append(settings.COMMANDS['smartctl'])
        cmd.append('-t')
        cmd.append(smarttype)
        cmd.append(devpath)
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, std=tmp_img)
        result = tmp_img.readlines()
        for line in result:
	    if line.find('Testing has begun') >= 0:
                return 1
            elif line.find('SMART Disabled') >= 0:
                return 3
        return -1
    except Exception, e:
        digi_debug("Smart Start error: %s" % e, 3)
        return -1

def SmartStop(diskname):
    '''
        retcode:
	1 : smart stop success
	2 : smart not in progress
        -1: unknown error
    '''
    try:
        prog = SmartProgress(diskname)
        if prog == '0%':
            return 2
        devpath = DISK_DEV_PATH + diskname
        cmd = []
        cmd.append(settings.COMMANDS['smartctl'])
        cmd.append('-X')
        cmd.append(devpath)
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, std=tmp_img)
        result = tmp_img.readlines()
        for line in result:
	    if line.find('Self-testing aborted') >= 0:
                return 1
        return -1
    except Exception, e:
        digi_debug("Smart Stop error: %s" % e, 3)
        return -1

def SmartInfo(disk_list):
    try:
        split_line = '--------------------------------------------------------------------------------------------------------\n'
        smart_img = StringIO.StringIO()
        for diskname in disk_list:
            devpath = DISK_DEV_PATH + diskname
            cmd = []
            cmd.append(settings.COMMANDS['smartctl'])
            cmd.append('-a')
            cmd.append(devpath)
            tmp_img = tempfile.TemporaryFile()
            ret = execute(cmd, std=tmp_img)
            result = tmp_img.readlines()
	    smart_img.write('Diskname: %s\n' % diskname)
            for i in range(len(result)):
                if result[i].find('Device Model') >= 0:
                    smart_img.write(result[i])
                elif result[i].find('Serial Number') >= 0:
                    smart_img.write(result[i])
                elif result[i].find('SMART support is') >= 0:
                    smart_img.write('SMART Status: %s' % result[i].split(':')[1])
                elif result[i].find('SMART overall-health self-assessment test result') >= 0:
                    smart_img.write('SMART Overall-Health: %s' % result[i].split(':')[1])
                elif result[i].find('Self-test execution status:') >= 0:
                    prog = SmartProgress(diskname)
                    smart_img.write('Selftest Execution Status: %s\n' % prog)
                elif result[i].find('SMART Attributes Data Structure revision number') >= 0:
                    j = 0
                    smart_img.write('\n')
                    while result[i+j].find('SMART Error Log Version') < 0:
                        smart_img.write(result[i+j])
                        j += 1
	        #elif result[i].find('SMART Self-test log structure revision number') >= 0:
                #    k = 0
                #    while result[i+k].find('SMART Selective self-test log data structure revision number') < 0:
                #        smart_img.write(result[i+k])
                #        k += 1
	        else:
                    pass
            smart_img.write(split_line);
        smart_img.seek(0)
        return smart_img.read()
    except Exception, e:
        digi_debug("Smart Enable error: %s" % e, 3)
        return -1
    

def SmartProgress(diskname):
    try:
        Prog = '0%'
        devpath = DISK_DEV_PATH + diskname
        cmd = []
        cmd.append(settings.COMMANDS['smartctl'])
        cmd.append('-c')
        cmd.append(devpath)
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, std=tmp_img)
        result = tmp_img.readlines()
	for i in range(len(result)):
            if result[i].find('Self-test execution status:') >= 0 and result[i].find('Self-test routine in progress...') >= 0:
                Prog = result[i+1].split()[0]
                break
        return Prog
    except Exception, e:
        digi_debug("Smart Progress error: %s" % e, 3)
        return -1                
