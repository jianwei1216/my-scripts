# -*- coding: utf-8 -*-
import sys
import os
import string
import re
import subprocess
import simplejson
import sysinfo
import net_utils
from xml.dom.minidom import Document

import settings

ALLNETINFO = settings.ALLNETINFO
CPUINFO = settings.CPUINFO
NETWORKCONFDIR = settings.NETWORKCONFDIR

def getDiskinfo():
    pass
# Get nic information
# Return a list of netdevice that has been configuraed
def getNICinfo():
    nic_up = []
    bond_net_card = []
    base_net_card = []
    tmp_list = []
# Get allnicinfo from /sys/class/net/
    op = subprocess.Popen('ls %s' % ALLNETINFO, stdout=subprocess.PIPE,
            shell=True)
    str_all= op.stdout.readlines()
# delete str_all '\n'
    for net_card in str_all:
        tmp_list.append(net_card.strip())
    str_all = tmp_list
    tmp_list = []
    str_all.remove('lo')
    for net_card in str_all:
        if net_card.find('bond') != -1 or net_card.find('br') != -1:
            if net_card.find('bond') != -1:
                if net_card.find('bonding_masters') != -1:
                    continue
                bond_net_card.append(net_card)
        else:
            base_net_card.append(net_card)
    if len(bond_net_card) == 0:
        for net_card in str_all:
            net_info = getinfo(net_card,str_all,1)
            if len(net_info) == 0:
                continue
            nic_up.append(net_info)
            net_info = []
        return simplejson.dumps(nic_up)
    else:
        for bond_card in range(0,len(bond_net_card)):
            op = subprocess.Popen('ls %s/bond%s/' % (ALLNETINFO,str(i)),
                    stdout=subprocess.PIPE, shell=True)
            str_bond_slave = op.stdout.readlines()
            # delete '\n'
            tmp_list = []
            for bond_slave in str_bond_slave:
                tmp_list.append(bond_slave.strip())
            str_bond_slave = tmp_list
            tmp_list = []
            for bond_slave in str_bond_slave:
                for base in base_net:
                    if bond_slave.find(base) != -1:
                        str_all.remove(base)
        for net_card in str_all:
            if net_card.find('br') != -1:
                net_info = getinfo(net_card,str_all,0)
            elif net_card.find('bond') != -1:
                net_info = getinfo(net_card,str_all,1)
            else:
                net_info = getinfo(net_card,str_all,2)
            if len(net_info) == 0:
                continue
            nic_up.append(net_info)
            net_info = []
        return simplejson.dumps(nic_up)
#        return res_toString(nic_up)

# convert result to type of string
#def res_toString(res_list):
#    str = string()
#    for item in res_list:
#        print item
#        print type(item)
#        string.join(item, ',')
# Get bond or eth info
# nic_type -> nic type, nic_list -> nic_bond or nic_eth, type ->flag that describe the kind of netdevice(bond or eth)
# Return a list about netdevice info
def getinfo(nic_type, nic_list, type):
    nic_conf_path = '%sifcfg-%s' % (NETWORKCONFDIR, nic_type)
    try:
        if os.path.exists(nic_conf_path):
            _list = [type,'NOCONFIG','NOCONFIG','NOCONFIG','NOCONFIG','NOCONFIG','NOCONFIG','NOCONFIG']
            fd = open(nic_conf_path,'r')
            result = fd.readlines()
            for line in result:
                if line.find('DEVICE') >= 0:
                    _list[1] = line.split('=')[1].replace('"','').strip()
                elif line.find('TYPE') >= 0:
                    _list[2] = line.split('=')[1].replace('"','').strip()
                elif line.find('HWADDR') >= 0:
                    _list[3] = line.split('=')[1].replace('"','').strip()
                elif line.find('IPADDR') >= 0:
                    _list[4] = line.split('=')[1].replace('"','').strip()
                elif line.find('BROADCAST') >= 0:
                    _list[5] = line.split('=')[1].replace('"','').strip()
                elif line.find('NETMASK') >= 0:
                    _list[6] = line.split('=')[1].replace('"','').strip()
                elif line.find('GATEWAY') >= 0:
                    _list[7] = line.split('=')[1].replace('"','').strip()
                else:
                    pass
            if _list[5] == 'NOCONFIG' and _list[4] != 'NOCONFIG' and _list[6] != 'NOCONFIG':
                _list[5] = net_utils.broadcast(_list[4], _list[6])
            if _list[3] == 'NOCONFIG':
                op = subprocess.Popen('ifconfig |sed -n ' + "'/" + nic_type + "/',+p", stdout=subprocess.PIPE, shell=True)
                _up = op.stdout.read()
                m = re.search('.*encap:\s*(\S+)\s+HWaddr\s+(\S+).*',_up)
                if m:
                    _list[3] = m.group(2)                
            return _list
        else:
            op = subprocess.Popen('ifconfig |sed -n ' + "'/" + nic_type + "/',+1p", stdout=subprocess.PIPE, shell=True)
            _up = op.stdout.readlines()
            _list = []
            p = nic_type + '\s'
            match = re.search(p, ''.join(_up))
            if match:
                info = p + '.*encap:\s*(\S+)\s+HWaddr\s+(\S+).*'
                info_ex = p + '.*encap:\s*(\S+)\s+HWaddr\s+(\S+)\s+inet\s+addr:(\S+)\s+Bcast:(\S+)\s+Mask:(\S+).*'
                if re.search(info, ''.join(_up)):
                    if re.search(info_ex, ''.join(_up)):
                        _list = list(re.findall(info_ex, ''.join(_up))[0])
                    else:
                        _list = list(re.findall(info, ''.join(_up))[0])
                        _list.extend(['NOCONFIG', 'NOCONFIG', 'NOCONFIG'])
                _list.insert(0 ,type)
                _list.insert(1, nic_type)
                _list.append('NOCONFIG')   #gateway
            return _list
    except Exception,e:
        return _list

def getCPUinfo():
    cpu_info = []
    #op = subprocess.Popen('cat /proc/cpuinfo |sed -n "/processor/",+4p', stdout=subprocess.PIPE, shell=True )
    op = subprocess.Popen('cat %s |sed -n "/processor/",+4p' % CPUINFO, stdout=subprocess.PIPE, shell=True )
    str_cpu = op.stdout.readlines()
    p_cpu = '@\s+(\S+)\s'
    cpu_info = re.findall(p_cpu, ''.join(str_cpu))
    return simplejson.dumps(str(len(cpu_info)) + ',' + cpu_info[0])

def getStaticSYSinfo():
    sys_dom = sysinfo.XML()
    result = sys_dom._buildXml('static')
    ret_str = result.toprettyxml()
    return ret_str
def getDynamicSYSinfo():
    sys_dom = sysinfo.XML()
    result = sys_dom._buildXml('dynamic')
    ret_str = result.toprettyxml()
    return ret_str
