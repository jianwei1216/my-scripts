#-*- encoding: UTF-8 -*-
import re
import os
import math
import time
import subprocess
import socket
from xml.dom.minidom import Document
from settings import *
from net_utils_tool import checkIP

 # PSI Config File
 #
 #
 # @category  PHP
 # @package   PSI
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: $Id: config.php.new 412 2010-12-29 09:45:53Z Jacky672 $
 # @link      http://phpsysinfo.sourceforge.net
 #/

 #*******************************
 #       MAIN PARAMETERS
 #*******************************

 # Turn on debugging of some functions and include errors and warnings in xml and provide a popup for displaying errors
 # - False : no debug information are stored in xml or displayed
 # - True : debug information stored in xml and displayed *be careful if set this to True, may include sensitive information from your pc*

global PSI_DEBUG
PSI_DEBUG = False

 # Turn on/off compression for JavaScript file
 # - False : desactivate JavaScript compression (recommended with slow processor)
 # - True : activate JavaScript compression

global PSI_JS_COMPRESSION_ENABLE
PSI_JS_COMPRESSION_ENABLE = True
 # Additional paths where to look for installed programs
 # Example : global PSI_ADD_PATHS', '/opt/bin,/opt/sbin');

global PSI_ADD_PATHS
PSI_ADD_PATHS = False

 # Plugins that should be included in xml and output (!!!plugin names are case-sensitive!!!)
 # List of plugins should look like "plugin,plugin,plugin". See /plugins directory
 # - global PSI_PLUGINS', 'MDStatus,PS'); // list of plugins
 # - global PSI_PLUGINS', False); //no plugins
 # included plugins:
 # - MDStatus       - show the raid status and whats currently going on
 # - PS             - show a process tree of all running processes
 # - PSStatus       - show a graphical representation if a process is running or not
 # - Quotas         - show a table with all quotas that are active and there current state
 # - SMART          - show S.M.A.R.T. information from drives that support it
 # - BAT            - show battery state on a laptop
 # - ipmi           - show IPMI status
 # - UpdateNotifier - show update notifications (only for Ubuntu server)

global PSI_PLUGINS
PSI_PLUGINS = False


 #*******************************
 #      DISPLAY PARAMETERS
 #*******************************

 # Define the default display mode
 # auto: let user browser choose the mode
 # dynamic: use javascript to refresh data
 # static: static page (use metatag to reload page)

global PSI_DEFAULT_DISPLAY_MODE
PSI_DEFAULT_DISPLAY_MODE = 'auto'

 # Define the default language

global PSI_DEFAULT_LANG
PSI_DEFAULT_LANG = 'en'

 # Define the default template

global PSI_DEFAULT_TEMPLATE
PSI_DEFAULT_TEMPLATE = 'phpsysinfo'

 # Show or hide language picklist

global PSI_SHOW_PICKLIST_LANG
PSI_SHOW_PICKLIST_LANG = True

 # Show or hide template picklist

global PSI_SHOW_PICKLIST_TEMPLATE
PSI_SHOW_PICKLIST_TEMPLATE = True

 # Define the interval for refreshing data in ms
 # - 0 = disabled
 # - 1000 = 1 second
 # - Default is 60 seconds

global PSI_REFRESH
PSI_REFRESH = 60000

 # Show a graph for current cpuload
 # - True = displayed, but it's a performance hit (because we have to wait to get a value, 1 second)
 # - False = will not be displayed

global PSI_LOAD_BAR
PSI_LOAD_BAR = False

 # Display the virtual host name and address
 # - Default is canonical host name and address
 # - Use global PSI_USE_VHOST', True); to display virtual host name.

global PSI_USE_VHOST
PSI_USE_VHOST = False

 # Controls the units & format for network, memory and filesystem
 # - 1 KiB = 2^10 bytes = 1,024 bytes
 # - 1 KB = 10^3 bytes = 1,000 bytes
 # - 'PiB'    everything is in PeBiByte
 # - 'TiB'    everything is in TeBiByte
 # - 'GiB'    everything is in GiBiByte
 # - 'MiB'    everything is in MeBiByte
 # - 'KiB'    everything is in KiBiByte
 # - 'auto_binary' everything is automatic done if value is to big for, e.g MiB then it will be in GiB
 # - 'PB'    everything is in PetaByte
 # - 'TB'    everything is in TeraByte
 # - 'GB'    everything is in GigaByte
 # - 'MB'    everything is in MegaByte
 # - 'KB'    everything is in KiloByte
 # - 'auto_decimal' everything is automatic done if value is to big for, e.g MB then it will be in GB

global PSI_BYTE_FORMAT
PSI_BYTE_FORMAT = 'auto_binary'

 # Format in which temperature is displayed
 # - 'c'    shown in celsius
 # - 'f'    shown in fahrenheit
 # - 'c-f'  both shown first celsius and fahrenheit in braces
 # - 'f-c'  both shown first fahrenheit and celsius in braces

global PSI_TEMP_FORMAT
PSI_TEMP_FORMAT = 'c'


 #*******************************
 #      SENSORS PARAMETERS
 #*******************************

 # Define the motherboard monitoring program (!!!names are case-sensitive!!!)
 # We support the following programs so far
 # - LMSensors  http://www.lm-sensors.org/
 # - Healthd    http://healthd.thehousleys.net/
 # - HWSensors  http://www.openbsd.org/
 # - MBMon      http://www.nt.phys.kyushu-u.ac.jp/shimizu/download/download.html
 # - MBM5       http://mbm.livewiredev.com/
 # - Coretemp
 # - IPMI       http://openipmi.sourceforge.net/
 # - K8Temp     http://hur.st/k8temp/
 # Example: If you want to use lmsensors : global PSI_SENSOR_PROGRAM', 'LMSensors');

global PSI_SENSOR_PROGRAM
PSI_SENSOR_PROGRAM = False

 # Define how to access the monitor program
 # Available methods for the above list are in the following list
 # default method 'command' should be fine for everybody
 # !!! tcp connections are only made local and on the default port !!!
 # - LMSensors  command, file
 # - Healthd    command
 # - HWSensors  command
 # - MBMon      command, tcp
 # - MBM5       file
 # - Coretemp   command
 # - IPMI       command
 # - K8Temp     command

global PSI_SENSOR_ACCESS
PSI_SENSOR_ACCESS = 'command'

 # Hddtemp program
 # If the hddtemp program is available we can read the temperature, if hdd is smart capable
 # !!ATTENTION!! hddtemp might be a security issue
 # - global PSI_HDD_TEMP', 'tcp');	     // read data from hddtemp deamon (localhost:7634)
 # - global PSI_HDD_TEMP', 'command');  // read data from hddtemp programm (must be set suid)

global PSI_HDD_TEMP
PSI_HDD_TEMP = False


 #*******************************
 #     FILESYSTEM PARAMETERS
 #*******************************

 # Show mount point
 # - True = show mount point
 # - False = do not show mount point

global PSI_SHOW_MOUNT_POINT
PSI_SHOW_MOUNT_POINT = True

 # Show mount option
 # - True = show mount option
 # - False = do not show mount option

global PSI_SHOW_MOUNT_OPTION
PSI_SHOW_MOUNT_OPTION = True

 # Show inode usage
 # - True = display used inodes in percent
 # - False = hide them

global PSI_SHOW_INODES
PSI_SHOW_INODES = True

 # Hide mounts
 # Example : global PSI_HIDE_MOUNTS', '/home,/usr');

global PSI_HIDE_MOUNTS
PSI_HIDE_MOUNTS = ''

 # Hide filesystem types
 # Example : global PSI_HIDE_FS_TYPES', 'tmpfs,usbfs');

global PSI_HIDE_FS_TYPES
PSI_HIDE_FS_TYPES = ''

 # Hide partitions
 # Example : global PSI_HIDE_DISKS', 'rootfs');

global PSI_HIDE_DISKS
PSI_HIDE_DISKS = ''


 #*******************************
 #     NETWORK PARAMETERS
 #*******************************

 # Hide network interfaces
 # Example : global PSI_HIDE_NETWORK_INTERFACE', 'eth0,sit0');

global PSI_HIDE_NETWORK_INTERFACE
PSI_HIDE_NETWORK_INTERFACE = ''


 #*******************************
 #       UPS PARAMETERS
 #*******************************

 # Define the ups monitoring program (!!!names are case-sensitive!!!)
 # We support the following programs so far
 # - 1. Apcupsd  http://www.apcupsd.com/
 # - 2. Nut      http://www.networkupstools.org/
 # Example: If you want to use Apcupsd : global PSI_UPS_PROGRAM', 'Apcupsd');

global PSI_UPS_PROGRAM
PSI_UPS_PROGRAM = False

 # Apcupsd supports multiple UPSes
 # You can specify comma delimited list in the form <hostname>:<port> or <ip>:<port>. The defaults are: 127.0.0.1:3551
 # See the following parameters in apcupsd.conf: NETSERVER, NISIP, NISPORT

global PSI_UPS_APCUPSD_LIST
PSI_UPS_APCUPSD_LIST = '127.0.0.1:3551'



 # common Functions class
 #
 # PHP version 5
 #
 # @category  PHP
 # @package   PSI
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: $Id: class.CommonFunctions.inc.php 394 2010-11-12 14:22:42Z jacky672 $
 # @link      http://phpsysinfo.sourceforge.net
 #/
 # class with common functions used in all places
 #
 # @category  PHP
 # @package   PSI
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net

class CommonFunctions():
    def __init__(self):
        pass
     # phpSysInfo version
     #
     # @var string
     #/
    #const PSI_VERSION = '3.0.8'

     # Find a system program, do also path checking when not running on WINNT
     # on WINNT we simply return the name with the exe extension to the program name
     #
     # @param string $strProgram name of the program
     #
     # @return string complete path and name of the program
     #/
    def  _findProgram(strProgram):

        arrPath = list()
        if PHP_OS == 'WINNT':
            strProgram += '.exe'
            arrPath = re.split(';', os.environ["PATH"])
        else:
            arrPath = re.split(':', os.environ["PATH"])

        if PSI_ADD_PATHS != False:
            addpaths = re.split(',', PSI_ADD_PATHS)
            arrPath = addpaths + arrPath # In this order so $addpaths is before $arrPath when looking for a program

        #add some default paths if we still have no paths here
        if len(arrPath) == 0 and PHP_OS != 'WINNT':
            arrPath.append( '/bin')
            arrPath.append( '/sbin')
            arrPath.append( '/usr/bin')
            arrPath.append( '/usr/sbin')
            arrPath.append( '/usr/local/bin')
            arrPath.append( '/usr/local/sbin')

            strProgrammpath = strPath+"/"+strProgram
            if os.access(strProgrammpath, os.X_OK):
                return strProgrammpath


     # Execute a system program. return a trim():'d result.
     # does very crude pipe checking.  you need ' | ' for it to work
     # ie $program = CommonFunctions::executeProgram('netstat', '-anp | grep LIST'):
     # NOT $program = CommonFunctions::executeProgram('netstat', '-anp|grep LIST'):
     #
     # @param string  $strProgramname name of the program
     # @param string  $strArgs        arguments to the program
     # @param string  &$strBuffer     output of the command
     # @param boolean $booErrorRep    en- or disables the reporting of errors which should be logged
     #
     # @return boolean command successfull or not

    def executeProgram(self, strProgramname, args):

        cmd = strProgramname + ' ' + args
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        proc.wait()
        result = proc.stdout.readlines()
        return result
    """
        strProgram = self._findProgram(strProgramname)
        error = Error.singleton()
        if not strProgram
            if booErrorRep:
                error.addError('find_program('+strProgramname+')', 'program not found on the machine')

            return False

        # see if we've gotten a |, if we have we need to do path checking on the cmd
        if (strArgs):
            arrArgs = preg_split(' ', strArgs)
            for (i = 0, cnt_args = count(arrArgs): i < cnt_args i++):
            for i in arrArgs.length:
                if arrArgs[i] == '|':
                    strCmd = arrArgs[i + 1]
                    strNewcmd = self._findProgram(strCmd)
                    strArgs = strArgs.replace("/\| ".strCmd.'/', "| ".strNewcmd)



        descriptorspec = array(0=>array("pipe", "r"):, 1=>array("pipe", "w"):, 2=>array("pipe", "w"):):
        $process = proc_open($strProgram." ".$strArgs, $descriptorspec, $pipes):
        if (is_resource($process):):
            $strBuffer .= self::_timeoutfgets($pipes, $strBuffer, $strError):
            $return_value = proc_close($process):

        $strError = trim($strError):
        $strBuffer = trim($strBuffer):
        if (! empty($strError): && $return_value <> 0):
            if ($booErrorRep):
                $error->addError($strProgram, $strError."\nReturn value: ".$return_value):

            return False

        if (! empty($strError):):
            if ($booErrorRep):
                $error->addError($strProgram, $strError."\nReturn value: ".$return_value):

            return True

        return True

    """
     # read a file and return the content as a string
     #
     # @param string  $strFileName name of the file which should be read
     # @param string  &$strRet     content of the file (reference):
     # @param integer $intLines    control how many lines should be read
     # @param integer $intBytes    control how many bytes of each line should be read
     # @param boolean $booErrorRep en- or disables the reporting of errors which should be logged
     #
     # @return boolean command successfull or not

    def rfts(self, strFileName, intLines = 0, intBytes = 4096, booErrorRep = True):
        strFile = ""
        intCurLine = 1
        if os.path.exists(strFileName):
            fd = open(strFileName, 'r')
            if fd:
                strFile = ''.join(fd.readlines())
                fd.close()
                return strFile
            else:
                if booErrorRep:
                    error.addError('fopen(' + strFileName + ')' , 'file can not read by phpsysinfo')
                return False
        else:
            if booErrorRep:
                error.addError('file_exists(' + strFileName + ')', 'the file does not exist on your machine')
            return False
        return True
    """
     # reads a directory and return the name of the files and directorys in it
     #
     # @param string  $strPath     path of the directory which should be read
     # @param boolean $booErrorRep en- or disables the reporting of errors which should be logged
     #
     # @return array content of the directory excluding . and ..
     #/
    def  gdc(strPath, booErrorRep = True):

        arrDirectoryContent = array()
        #error = Error::singleton():
        if (is_dir($strPath):):
            if ($handle = opendir($strPath):):
                while (($strFile = readdir($handle):): !== False):
                    if ($strFile != "." && $strFile != ".."):
                        $arrDirectoryContent[] = $strFile


                closedir($handle):
             else
                if ($booErrorRep):
                    $error->addError('opendir('.$strPath.'):', 'directory can not be read by phpsysinfo'):


         else
            if ($booErrorRep):
                $error->addError('is_dir('.$strPath.'):', 'directory does not exist on your machine'):


        return $arrDirectoryContent

    /##
     # Check for needed php extensions
     #
     # We need that extensions for almost everything
     # This function will return a hard coded
     # XML string (with headers): if the SimpleXML extension isn't loaded.
     # Then it will terminate the script.
     # See bug #1787137
     #
     # @param array $arrExt additional extensions for which a check should run
     #
     # @return void
     #/
    def  checkForExtensions($arrExt = array():):

        $arrReq = array('simplexml', 'pcre', 'xml', 'mbstring'):
        $extensions = array_merge($arrExt, $arrReq):
        $text = ""
        $error = False
        $text .= "<?xml version='1.0'?>\n"
        $text .= "<phpsysinfo>\n"
        $text .= "  <Error>\n"
        foreach ($extensions as $extension):
            if (!extension_loaded($extension):):
                $text .= "    <Function>checkForExtensions</Function>\n"
                $text .= "    <Message>phpSysInfo requires the ".$extension." extension to php in order to work properly.</Message>\n"
                $error = True


        $text .= "  </Error>\n"
        $text .= "</phpsysinfo>"
        if ($error):
            header("Content-Type: text/xml\n\n"):
            echo $text
            die():




     # get the content of stdout/stderr with the option to set a timeout for reading
     #
     # @param array   $pipes array of file pointers for stdin, stdout, stderr (proc_open():):
     # @param string  &$out  target string for the output message (reference):
     # @param string  &$err  target string for the error message (reference):
     # @param integer $sek   timeout value in seconds
     #
     # @return void

    def  _timeoutfgets($pipes, &$out, &$err, $sek = 10):

        // fill output string
        $time = $sek
        $w = null
        $e = null

        while ($time >= 0):
            $read = array($pipes[1]):
            while (!feof($read[0]): && ($n = stream_select($read, $w, $e, $time):): !== False && $n > 0 && strlen($c = fgetc($read[0]):): > 0):
                $out .= $c

            --$time

        // fill error string
        $time = $sek
        while ($time >= 0):
            $read = array($pipes[2])
            while !feof($read[0]): && ($n = stream_select($read, $w, $e, $time):): !== False && $n > 0 && strlen($c = fgetc($read[0]):): > 0):
                $err .= $c

            --$time



     # get all configured plugins from config.php (file must be included before calling this function):
     #
     # @return array

    def  getPlugins(self):
        plugins = preg_split("/[\s]?,[\s]?/", PSI_PLUGINS, -1, PREG_SPLIT_NO_EMPTY):
        return $plugins
    """

 # parser Class
 #
 # @category  PHP
 # @package   PSI
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: Id: class.Parser.inc.php 392 2010-11-12 13:06:16Z jacky672
 # @link      http://phpsysinfo.sourceforge.net
 #/
 # parser class with common used parsing metods
 #
 # @category  PHP
 # @package   PSI
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net
 #/

class Parser():

     # parsing the output of lspci command
     #
     # @return Array
     #/
    def lspci(self):

        arrResults = list()
        if CommonFunctions().executeProgram("lspci", ""):
            result = ''.join(CommonFunctions().executeProgram("lspci", ""))
            arrLines = re.split("\n", result)
            arrLines.pop()
            for strLine in arrLines:
                strAddr = re.split(' ', strLine.strip(), 1)[0]
                strName = re.split(' ', strLine.strip(), 1)[1]
                strName = re.sub('\(.*\)', '', strName)
                dev = HWDevice()
                dev.setName(strName)
                arrResults.append(dev)

        return arrResults

     # parsing the output of pciconf command
     #
     # @return Array
     #/

     # parsing the output of df command
     #
     # @param string df_param additional parameter for df command
     #
     # @return array
     #/
    def df(self, df_param = ""):

        arrResult = list()
        if CommonFunctions().executeProgram('df', '-k ' + df_param):
            result = ''.join(CommonFunctions().executeProgram('df', '-k ' + df_param))
            df = re.split("\n", result)
            if CommonFunctions().executeProgram('df', '-i ' + df_param, ):
                result2 = ''.join(CommonFunctions().executeProgram('df', '-i ' + df_param))
                df2 = re.split("\n", result2)
                #Store inode use% in an associative array (df_inodes) for later use
                for df2_line in df2:
                    if re.match("^(\S+).*\s([0-9]+)%", df2_line):
                        inode_buf = re.split('\s+',re.match("^(\S+).*\s([0-9]+)%", df2_line).group())
                        df_inodes = {}
                        df_inodes[inode_buf[0]] = inode_buf[1]


            if CommonFunctions().executeProgram('mount', ''):
                result = ''.join(CommonFunctions().executeProgram('mount', ''))
                mount = re.split("\n", result)
                for mount_line in mount:
                    if re.match("\S+ on (\S+) type (.*) \((.*)\)", mount_line):
                        mount_buf = re.split('\s+',re.match("\S+ on (\S+) type (.*) \((.*)\)", mount_line).group())
                        mount_parm = {}
                        mount_parm[mount_buf[2]] = {}
                        mount_parm[mount_buf[2]]['fstype'] = mount_buf[4]
                        mount_parm[mount_buf[2]]['options'] = mount_buf[5]
                    elif re.match("\S+ (.*) on (\S+) \((.*)\)", mount_line):
                        mount_buf = re.split('\s+',re.match("\S+ (.*) on (\S+) \((.*)\/", mount_line).group())
                        mount_parm = {}
                        mount_parm[mount_buf[3]] = {}
                        mount_parm[mount_buf[3]]['fstype'] = mount_buf[5]
                        mount_parm[mount_buf[3]]['options'] = mount_buf[6]
                    elif re.match("\S+ on ([\S ]+) \((\S+)(,\s(.#))?\)", mount_line):
                        mount_buf = re.split('\s+',re.match("\S+ on ([\S ]+) \((\S+)(,\s(.*))?\)", mount_line).group())
                        mount_parm = {}
                        mount_parm[mount_buf[2]] = {}
                        mount_parm[mount_buf[2]]['fstype'] = mount_buf[4]
                        try:
                            mount_parm[mount_buf[2]]['options'] = mount_buf[5]
                        except NameError:
                            mount_parm[mount_buf[2]]['options'] = ''

                df.pop()
                for df_line in df[1:]:
                    df_buf1 = re.split("(\%\s)", df_line, 1)

                    if re.match("(.*)(\s+)(([0-9]+)(\s+)([0-9]+)(\s+)([0-9]+)(\s+)([0-9]+))", df_buf1[0]):
                        df_buf2 = re.split('\s+',re.match("(.*)(\s+)(([0-9]+)(\s+)([0-9]+)(\s+)([0-9]+)(\s+)([0-9]+))", df_buf1[0]).group())
                        df_buf = [df_buf2[0], df_buf2[1], df_buf2[2], df_buf2[3], df_buf2[4], df_buf1[2]]
                        if len(df_buf) == 6:
                            df_buf[5] = df_buf[5].strip()
                            dev = DiskDevice()
                            dev.setName(df_buf[0].strip())
                            if df_buf[2] < 0:
                                dev.setTotal(int(df_buf[3]) * 1024)
                                dev.setUsed(int(df_buf[3]) * 1024)
                            else:
                                dev.setTotal(int(df_buf[1]) * 1024)
                                dev.setUsed(int(df_buf[2]) * 1024)
                                dev.setFree(int(df_buf[3]) * 1024)
                                dev.setPercentInodesUsed(int(df_buf[4]))
                            dev.setMountPoint(df_buf[5])
                            arrResult.append(dev)

        return arrResult


class System():
    def __init__(self):
        self._hostname = "localhost"
        self._ip = "127.0.0.1"
        self._kernel = "Unknown"
        self._distribution = "Unknown"
        self._distributionIcon = "unknown.png"
        self._uptime = 0
        self._users = 0
        self._load = ""
        self._loadPercent = None
        self._cpus = list()         #CpuDevice.CpuDevice()
        self._netDevices = list()
        self._scsiDevices = list()
        self._pciDevices = list()
        self._usbDevices = list()
        self._ideDevices = list()
        self._diskDevices = list()
        self._memFree = 0
        self._memTotal = 0
        self._memUsed = 0
        self._memApplication = None
        self._memBuffer = None
        self._memCache = None
        self._swapDevices = list()

    def removeDupsAndCount(self, arrDev):
        result = list()
        for dev in arrDev:
            if len(result) == 0:
                result.append(dev)
            else:
                found = False
                for tmp in result:
                    if dev.equals(tmp):
                        tmp.setCount(tmp.getCount() + 1)
                        found = True
                        break
                if not found:
                    result.append(dev)
        return result

    def getMemPercentUsed(self):
        if self._memTotal > 0:
            return math.ceil(float(self._memUsed) / float(self._memTotal) * 100)
        else:
            return 0

    ##
     # return percent of used memory for applications
     #
     # @see System::_memApplication
     # @see System::_memTotal
     #
     # @return Integer
    def getMemPercentApplication(self):
        if self._memApplication != None:
            if self._memApplication > 0:
                return math.ceil(float(self._memApplication) / float(self._memTotal) * 100)
            else:
                return 0
        else:
            return None

    ##
     # return percent of used memory for cache
     #
     # @see System::_memCache
     # @see System::_memTotal
     #
     # @return Integer
     #
    def getMemPercentCache(self):
        if self._memCache != None:
            if self._memCache > 0:
                return math.ceil(float(self._memCache) / float(self._memTotal) * 100)
            else:
                return 0
        else:
            return None

    ##
     # return percent of used memory for buffer
     #
     # @see System::_memBuffer
     # @see System::_memTotal
     #
     # @return Integer
     #
    def getMemPercentBuffer(self):
        if self._memBuffer != None:
            if self._memBuffer > 0:
                return math.ceil(float(self._memBuffer) / float(self._memTotal) * 100)
            else:
                return 0
        else:
            return None

    ##
     # Returns total free swap space
     #
     # @see System::_swapDevices
     # @see DiskDevice::getFree()
     #
     # @return Integer
     #
    def getSwapFree(self):
        if len(self._swapDevices)> 0:
            free = 0
            for dev in self._swapDevices:
                free += dev.getFree()
            return free
        return None

    ##
     # Returns total swap space
     #
     # @see System::_swapDevices
     # @see DiskDevice::getTotal()
     #
     # @return Integer
     #
    def getSwapTotal(self):
        if len(self._swapDevices) > 0:
            total = 0
            for dev in self._swapDevices:
                total += dev.getTotal()
            return total
        else:
            return None

    ##
     # Returns total used swap space
     #
     # @see System::_swapDevices
     # @see DiskDevice::getUsed()
     #
     # @return Integer
     #
    def getSwapUsed(self):
        if len(self._swapDevices) > 0:
            used = 0
            for dev in self._swapDevices:
                used += dev.getUsed()
            return used
        else:
            return None

    ##
     # return percent of total swap space used
     #
     # @see System::getSwapUsed()
     # @see System::getSwapTotal()
     #
     # @return Integer
     #
    def getSwapPercentUsed(self):
        if self.getSwapTotal() != None:
            if self.getSwapTotal() > 0:
                return math.ceil(float(self.getSwapUsed()) / float(self.getSwapTotal()) * 100)
            else:
                return 0
        else:
            return None

    ##
     # Returns _distribution.
     #
     # @see System::_distribution
     #
     # @return String
     #
    def getDistribution(self):
        return self._distribution

    ##
     # Sets _distribution.
     #
     # @param String distribution distributionname
     #
     # @see System::_distribution
     #
     # @return Void
     #
    def setDistribution(self, distribution):
        self._distribution = distribution

    ##
     # Returns _distributionIcon.
     #
     # @see System::_distributionIcon
     #
     # @return String
     #
    def getDistributionIcon(self):
        return self._distributionIcon

    ##
     # Sets _distributionIcon.
     #
     # @param String distributionIcon distribution icon
     #
     # @see System::_distributionIcon
     #
     # @return Void
     #
    def setDistributionIcon(self, distributionIcon):
        self._distributionIcon = distributionIcon

    ##
     # Returns _hostname.
     #
     # @see System::_hostname
     #
     # @return String
     #
    def getHostname(self):
        return self._hostname

    ##
     # Sets _hostname.
     #
     # @param String hostname hostname
     #
     # @see System::_hostname
     #
     # @return Void
     #
    def setHostname(self, hostname):
        self._hostname = hostname

    ##
     # Returns _ip.
     #
     # @see System::_ip
     #
     # @return String
     #
    def getIp(self):
        return self._ip

    ##
     # Sets _ip.
     #
     # @param String ip IP
     #
     # @see System::_ip
     #
     # @return Void
     #
    def setIp(self, ip):
        self._ip = ip

    ##
     # Returns _kernel.
     #
     # @see System::_kernel
     #
     # @return String
     #
    def getKernel(self):
        return self._kernel

    ##
     # Sets _kernel.
     #
     # @param String kernel kernelname
     #
     # @see System::_kernel
     #
     # @return Void
     #
    def setKernel(self, kernel):
        self._kernel = kernel

    ##
     # Returns _load.
     #
     # @see System::_load
     #
     # @return String
     #
    def getLoad(self):
        return self._load

    ##
     # Sets _load.
     #
     # @param String load current system load
     #
     # @see System::_load
     #
     # @return Void
     #
    def setLoad(self, load):
        self._load = load

    ##
     # Returns _loadPercent.
     #
     # @see System::_loadPercent
     #
     # @return Integer
     #
    def getLoadPercent(self):
        return self._loadPercent

    ##
     # Sets _loadPercent.
     #
     # @param Integer loadPercent load percent
     #
     # @see System::_loadPercent
     #
     # @return Void
     #
    def setLoadPercent(self, loadPercent):
        self._loadPercent = loadPercent

    ##
     # Returns _uptime.
     #
     # @see System::_uptime
     #
     # @return Integer
     #
    def getUptime(self):
        return self._uptime

    ##
     # Sets _uptime.
     #
     # @param Interger uptime uptime
     #
     # @see System::_uptime
     #
     # @return Void
     #
    def setUptime(self, uptime):
        self._uptime = uptime

    ##
     # Returns _users.
     #
     # @see System::_users
     #
     # @return Integer
     #
    def getUsers(self):
        return self._users

    ##
     # Sets _users.
     #
     # @param Integer users user count
     #
     # @see System::_users
     #
     # @return Void
     #
    def setUsers(self, users):
        self._users = users

    ##
     # Returns _cpus.
     #
     # @see System::_cpus
     #
     # @return Array
     #
    def getCpus(self):
        return self._cpus

    ##
     # Sets _cpus.
     #
     # @param Cpu cpus cpu device
     #
     # @see System::_cpus
     # @see CpuDevice
     #
     # @return Void
     #
    def setCpus(self, cpus):
        self._cpus.append(cpus)


    ##
     # Returns _pciDevices.
     #
     # @see System::_pciDevices
     #
     # @return Array
     #
    def getPciDevices(self):
        return self._pciDevices

    ##
     # Sets _pciDevices.
     #
     # @param HWDevice pciDevices pci device
     #
     # @see System::_pciDevices
     # @see HWDevice
     #
     # @return Void
     #
    def setPciDevices(self, pciDevices):
        self._pciDevices.append(pciDevices)


    ##
     # Returns _netDevices.
     #
     # @see System::_netDevices
     #
     # @return Array
     #
    def getNetDevices(self):
        return self._netDevices

    ##
     # Sets _netDevices.
     #
     # @param NetDevice netDevices network device
     #
     # @see System::_netDevices
     # @see NetDevice
     #
     # @return Void
     #
    def setNetDevices(self, netDevices):
        self._netDevices.append(netDevices)


    ##
     # Returns _ideDevices.
     #
     # @see System::_ideDevices
     #
     # @return Array
     #
    def getIdeDevices(self):
        return self._ideDevices

    ##
     # Sets _ideDevices.
     #
     # @param HWDevice ideDevices ide device
     #
     # @see System::_ideDevices
     # @see HWDevice
     #
     # @return Void
     #
    def setIdeDevices(self, ideDevices):
        self._ideDevices.append(ideDevices)

    ##
     # Returns _scsiDevices.
     #
     # @see System::_scsiDevices
     #
     # @return Array
     #
    def getScsiDevices(self):
        return self._scsiDevices

    ##
     # Sets _scsiDevices.
     #
     # @param HWDevice scsiDevices scsi devices
     #
     # @see System::_scsiDevices
     # @see HWDevice
     #
     # @return Void
     #
    def setScsiDevices(self, scsiDevices):
        self._scsiDevices.append(scsiDevices)

    ##
     # Returns _usbDevices.
     #
     # @see System::_usbDevices
     #
     # @return Array
     #
    def getUsbDevices(self):
        return self._usbDevices

    ##
     # Sets _usbDevices.
     #
     # @param HWDevice usbDevices usb device
     #
     # @see System::_usbDevices
     # @see HWDevice
     #
     # @return Void
     #
    def setUsbDevices(self, usbDevices):
        self._usbDevices.append(usbDevices)


    ##
     # Returns _diskDevices.
     #
     # @see System::_diskDevices
     #
     # @return Array
     #
    def getDiskDevices(self):
        return self._diskDevices

    ##
     # Sets _diskDevices.
     #
     # @param DiskDevice diskDevices disk device
     #
     # @see System::_diskDevices
     # @see DiskDevice
     #
     # @return void
     #
    def setDiskDevices(self, diskDevices):
        self._diskDevices.append(diskDevices)


    ##
     # Returns _memApplication.
     #
     # @see System::_memApplication
     #
     # @return Integer
     #
    def getMemApplication(self):
        return self._memApplication

    ##
     # Sets _memApplication.
     #
     # @param Integer memApplication application memory
     #
     # @see System::_memApplication
     #
     # @return Void
     #
    def setMemApplication(self, memApplication):
        self._memApplication = memApplication

    ##
     # Returns _memBuffer.
     #
     # @see System::_memBuffer
     #
     # @return Integer
     #
    def getMemBuffer(self):
        return self._memBuffer

    ##
     # Sets _memBuffer.
     #
     # @param Integer memBuffer buffer memory
     #
     # @see System::_memBuffer
     #
     # @return Void
     #
    def setMemBuffer(self, memBuffer):
        self._memBuffer = memBuffer

    ##
     # Returns _memCache.
     #
     # @see System::_memCache
     #
     # @return Integer
     #
    def getMemCache(self):
        return self._memCache

    ##
     # Sets _memCache.
     #
     # @param Integer memCache cache memory
     #
     # @see System::_memCache
     #
     # @return Void
     #
    def setMemCache(self, memCache):
        self._memCache = memCache

    ##
     # Returns _memFree.
     #
     # @see System::_memFree
     #
     # @return Integer
     #
    def getMemFree(self):
        return self._memFree

    ##
     # Sets _memFree.
     #
     # @param Integer memFree free memory
     #
     # @see System::_memFree
     #
     # @return Void
     #
    def setMemFree(self, memFree):
        self._memFree = memFree

    ##
     # Returns _memTotal.
     #
     # @see System::_memTotal
     #
     # @return Integer
     #
    def getMemTotal(self):
        return self._memTotal

    ##
     # Sets _memTotal.
     #
     # @param Integer memTotal total memory
     #
     # @see System::_memTotal
     #
     # @return Void
     #
    def setMemTotal(self, memTotal):
        self._memTotal = memTotal

    ##
     # Returns _memUsed.
     #
     # @see System::_memUsed
     #
     # @return Integer
     #
    def getMemUsed(self):
        return self._memUsed

    ##
     # Sets _memUsed.
     #
     # @param Integer memUsed used memory
     #
     # @see System::_memUsed
     #
     # @return Void
     #
    def setMemUsed(self, memUsed):
        self._memUsed = memUsed

    ##
     # Returns _swapDevices.
     #
     # @see System::_swapDevices
     #
     # @return Array
     #
    def getSwapDevices(self):
        return self._swapDevices

    ##
     # Sets _swapDevices.
     #
     # @param DiskDevice swapDevices swap devices
     #
     # @see System::_swapDevices
     # @see DiskDevice
     #
     # @return Void
     #
    def setSwapDevices(self, swapDevices):
        self._swapDevices.append(swapDevices)


 # Linux System Class
 #
 #
 # @category  PHP
 # @package   PSI_OS
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: Id: class.Linux.inc.php 411 2010-12-28 22:32:52Z Jacky672
 # @link      http://phpsysinfo.sourceforge.net

 # Linux sysinfo class
 # get all the required information from Linux system
 #
 # @category  PHP
 # @package   PSI_OS
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net
 #/
class Linux():

    def __init__(self,type):
	if type == "static":
            self.sys = System()
            self.build_static()
	elif type == "dynamic":
	    self.sys = System()
	    self.build_dynamic()
     # Hostname
     #
     # @return void
     #/
    def _hostname(self):
        import node_utils
        import simplejson
     #   if PSI_USE_VHOST == True:
     #       self.sys.setHostname(getenv('SERVER_NAME'))
     #   else:
        #ip_list = simplejson.loads(node_utils.getNICinfo())
        #for ip in ip_list:
        #    try:
        #        if checkIP(ip[4]):
        #           ipaddr = socket.gethostbyaddr(ip[4])[2][0]
        #        else:
        #            continue
        #    except:
        #        continue
        #    self.sys.setHostname(socket.gethostbyaddr(ipaddr)[0])
        #if CommonFunctions().rfts('/proc/sys/kernel/hostname', 1):
        #    result = CommonFunctions().rfts('/proc/sys/kernel/hostname', 1).replace('\n','')
        #    ip = socket.gethostbyname(result)
        #    if ip != result:
        #        self.sys.setHostname(socket.gethostbyaddr(ip)[1][0])
        self.sys.setHostname(''.join(CommonFunctions().executeProgram('hostname','-f')).replace('\n',''))
        return self.sys._hostname
     # IP
     #
     # @return void
     #/
    def _ip(self):

     #   if PSI_USE_VHOST == True:
     #       self.sys.setIp(gethostbyname(self._hostname()))
     #   else:
     #       result = _SERVER['SERVER_ADDR']
     #       if not result:
         self.sys.setIp(socket.gethostbyname(self._hostname()))
         return self.sys._ip
     #       else:
     #           self.sys.setIp(result)


     # Kernel Version
     #
     # @return void
     #/
    def _kernel(self):

        if CommonFunctions().executeProgram('uname', '-r'):
            result = ''.join(CommonFunctions().executeProgram('uname', '-r')).replace('\n','')
            if CommonFunctions().executeProgram('uname', '-v'):
                if re.search('SMP', ''.join(CommonFunctions().executeProgram('uname', '-v'))):
                    result += ' (SMP)'


            if CommonFunctions().executeProgram('uname', '-m'):
                result += ' '.join(CommonFunctions().executeProgram('uname', '-m'))
            self.sys.setKernel(result.strip())
        else:
            if CommonFunctions().rfts('/proc/version', strBuf, 1):
                if re.search('/version (.#?) /', strBuf, ar_buf):
                    result = ar_buf[1]
                    if re.search('/SMP/', strBuf):
                        result += ' (SMP)'
                    self.sys.setKernel(result)
        return self.sys._kernel


     # UpTime
     # time the system is running
     #
     # @return void
     #/
    def _uptime(self):

        buf = CommonFunctions().rfts('/proc/uptime', 1)
        ar_buf = re.split(' ', buf)
        self.sys.setUptime(float(ar_buf[0]))
        return self.sys._uptime

     # Number of Users
     #
     # @return void
     #/
    def _users(self):

        if CommonFunctions().executeProgram('who', '-q'):
            result = ''.join(CommonFunctions().executeProgram('who', '-q')).strip()
            arrWho = re.split('=', result)
            self.sys.setUsers(arrWho[1])
        return self.sys._users

     # Processor Load
     # optionally create a loadbar
     #
     # @return void
     #/
    def _loadavg(self):

        if CommonFunctions().rfts('/proc/stat', 1):
            result = re.split("\s", CommonFunctions().rfts('/proc/stat', 1))
     #       // don't need the extra values, only first three
            del result[9:]
            
            #self.sys.setLoad(' '.join(result))
            self.sys.setLoad(str(self._parseProcStat('cpu')))
        return self.sys._load

     # fill the load for a individual cpu, through parsing /proc/stat for the specified cpu
     #
     # @param String cpuline cpu for which load should be meassured
     #
     # @return Integer
     #/
    def _parseProcStat(self, cpuline):

        load = 0
        load2 = 0
        total = 0
        total2 = 0
        if CommonFunctions().rfts('/proc/stat', 1):
            buf = CommonFunctions().rfts('/proc/stat', 1)
            lines = re.split("\n", buf)
            for line in lines:
                if re.match('^' + cpuline + ' (.*)', line):
                    result = re.match('^' + cpuline + ' (.*)', line).group(1).split()
                    load = float(result[0]) + float(result[1]) + float(result[2])                    # cpu.user + cpu.sys
                    total = float(result[0]) + float(result[1]) + float(result[2]) + float(result[3])        #cpu.total
                    break



        # we need a second value, wait 1 second befor getting (< 1 second no good value will occour)
        time.sleep(1)
        if CommonFunctions().rfts('/proc/stat', 1):
            buf = CommonFunctions().rfts('/proc/stat', 1)
            lines = re.split("\n", buf)
            for line in lines:
                if re.match('^' + cpuline + ' (.*)', line):
                    result = re.match('^' + cpuline + ' (.*)', line).group(1).split()
                    load2 = float(result[0]) + float(result[1]) + float(result[2])                    # cpu.user + cpu.sys
                    total2 = float(result[0]) + float(result[1]) + float(result[2]) + float(result[3])        #cpu.total
                    break



        if total > 0 and total2 > 0 and load > 0 and load2 > 0 and total2 != total and load2 != load:
            return (100 * (load2 - load)) / (total2 - total)

        return 0

     # CPU information
     # All of the tags here are highly architecture dependant.
     #
     # @return void
     #/
    def _cpuinfo(self):

        #if CommonFunctions().rfts('/proc/cpuinfo', 1):
        if CommonFunctions().rfts(CPUINFO, 1):
            #result = ''.join(CommonFunctions().rfts('/proc/cpuinfo', 1))
            result = ''.join(CommonFunctions().rfts(CPUINFO, 1))
            processors = re.split('\s?\n\s?\n', result)
            processors.pop()
            for processor in processors:
                dev = CpuDevice()
                details = re.split("\n", processor)
                for detail in details:
                    arrBuff = re.split('\s+:\s+', detail)
                    if len(arrBuff) == 2:
                        if arrBuff[0] == 'processor':
                            #dev.setLoad(self._parseProcStat('cpu' + arrBuff[1]))
                            pass
                        elif arrBuff[0] == 'model name' or arrBuff[0] == 'cpu':
                            dev.setModel(arrBuff[1])
                        elif arrBuff[0] == 'cpu mhz' or arrBuff[0] == 'clock':
                            dev.setCpuSpeed(arrBuff[1])
                        elif arrBuff[0] == 'cycle frequency [hz]':
                            dev.setCpuSpeed(int(arrBuff[1]) / 1000000)
                        elif arrBuff[0] == 'cpu0clktck':
                            dev.setCpuSpeed(int(arrBuff[1], 16) / 1000000) # Linux sparc64
                        elif arrBuff[0] == 'l2 cache' or arrBuff[0] == 'cache size':
                            dev.setCache(int(re.sub("[a-zA-Z]", "", arrBuff[1])) * 1024)
                        elif arrBuff[0] == 'bogomips' or arrBuff[0] == 'cpu0bogo':
                            dev.setBogomips(arrBuff[1])
                        elif arrBuff[0] == 'flags':
                            if re.match("vmx",arrBuff[1]):
                                dev.setVirt("vmx")
                            elif re.match("smv",arrBuff[1]):
                                dev.setVirt("smv")
                self.sys.setCpus(dev)

     # PCI devices
     #
     # @return void
     #/
    def _pci(self):

        if Parser().lspci():
            arrResults = Parser().lspci()
            for dev in arrResults:
                self.sys.setPciDevices(dev)

     # SCSI devices
     #
     # @return void
     #/
    def _scsi(self):

        get_type = False
        device = None
        if CommonFunctions().rfts('/proc/scsi/scsi', 1):
            bufr = ''.join(CommonFunctions().rfts('/proc/scsi/scsi', 1))
            bufe = re.split("\n", bufr)
            bufe.pop()
            for buf in bufe:
                if re.match('\s+Vendor: (\S+)\s+ Model: (.*) Rev: (.*)', buf):
                    devices = re.match('\s+Vendor: (\S+)\s+ Model: (.*) Rev: (.*)', buf).groups()
                    get_type = True
                    device = devices
                    continue

                if get_type:
                    dev_type = re.match('\s+Type:\s+(\S+)', buf).groups()
                    dev = HWDevice()
                    dev.setName(device[0] + ' ' + device[1] + ' (' + dev_type[0] + ')')
                    self.sys.setScsiDevices(dev)
                    get_type = False




     # USB devices
     #
     # @return array
     #/
    def _usb(self):

        #devnum = -1
        #print CommonFunctions().executeProgram('lsusb', '')
        #if CommonFunctions().executeProgram('lsusb', '') == '':
        #    if CommonFunctions().rfts('/proc/bus/usb/devices', 1):
        #        bufr = ''.join(CommonFunctions().rfts('/proc/bus/usb/devices', 1))
        #        bufe = re.split("\n", bufr)
        #        for buf in bufe:
        #            if re.match('^T', buf):
        #                devnum += 1
        #                results[devnum] = ""
        #            elif re.match('^S:', buf):
        #                list(key, value) = re.split('/: /', buf, 2)
        #                list(key, value2) = re.split('/=/', value, 2)
        #                if key.strip != "SerialNumber":
        #                    results[devnum] += " ".trim(value2)
        #
        #        for var in results:
        #            dev = HWDevice.HWDevice()
        #            dev.setName(var)
        #            self.sys.setUsbDevices(dev)

        if CommonFunctions().executeProgram('lsusb', ''):
            bufr = ''.join(CommonFunctions().executeProgram('lsusb', '' ))
            bufe = re.split("\n", bufr)
            bufe.pop()
            for buf in bufe:
                device = re.split(' ', buf, 6)
                if device[6].strip() != '':
                    dev = HWDevice()
                    dev.setName(device[6].strip())
                    self.sys.setUsbDevices(dev)




     # Network devices
     # includes also rx/tx bytes
     #
     # @return void
     #/
    def _network(self):

        if CommonFunctions().rfts('/proc/net/dev', 1):
            bufr = ''.join(CommonFunctions().rfts('/proc/net/dev', 1))
            bufe = re.split("\n", bufr)
            bufe.pop()
            for buf in bufe[2:]:
                if re.match('\s*\S+:', buf):
                    dev_name = re.split(':', buf ,1)[0]
                    stats_list = re.split(':', buf ,1)[1]
                    #list(dev_name, stats_list) = re.split('/:/', buf, 2)
                    stats = re.split('\s+', stats_list.strip())
                    dev = NetDevice()
                    dev.setName(dev_name.strip())
                    dev.setRxBytes(stats[0])
                    dev.setTxBytes(stats[8])
                    dev.setErrors(stats[2] + stats[10])
                    dev.setDrops(stats[3] + stats[11])
                    self.sys.setNetDevices(dev)

    def _blockdev(self):
        
        if CommonFunctions().rfts('iostat', 1):
            bufr = ''.join(CommonFunctions().rfts('iostat', 1))
            bufe = re.split("\n", bufr)
            bufe.pop()
            


     # Physical memory information and Swap Space information
     #
     # @return void
     #/
    def _memory(self):

        if CommonFunctions().rfts('/proc/meminfo', 1):
            bufr = ''.join(CommonFunctions().rfts('/proc/meminfo', 1))
            bufe = re.split("\n", bufr)
            for buf in bufe:
                if re.match('^MemTotal:\s+(.*)\s*kB', buf):
                    ar_buf = re.split('^MemTotal:\s+(.*)\s*kB', buf)
                    self.sys.setMemTotal(int(ar_buf[1]) * 1024)
                elif re.match('^MemFree:\s+(.*)\s*kB', buf):
                    ar_buf = re.split('^MemFree:\s+(.*)\s*kB', buf)
                    self.sys.setMemFree(int(ar_buf[1]) * 1024)
                elif re.match('^Cached:\s+(.*)\s*kB', buf):
                    ar_buf = re.split('^Cached:\s+(.*)\s*kB', buf)
                    self.sys.setMemCache(int(ar_buf[1]) * 1024)
                elif re.match('^Buffers:\s+(.*)\s*kB', buf):
                    ar_buf = re.split('^Buffers:\s+(.*)\s*kB', buf)
                    self.sys.setMemBuffer(int(ar_buf[1]) * 1024)


            self.sys.setMemUsed(self.sys.getMemTotal() - self.sys.getMemFree())
            # values for splitting memory usage
            if self.sys.getMemCache() != None and self.sys.getMemBuffer() != None:
                self.sys.setMemApplication(self.sys.getMemUsed() - self.sys.getMemCache() - self.sys.getMemBuffer())

            if CommonFunctions().rfts('/proc/swaps', 1):
                bufr = ''.join(CommonFunctions().rfts('/proc/swaps', 1))
                swaps = re.split("\n", bufr)
                swaps.pop()
                del swaps[0]
                for swap in swaps:
                    ar_buf = re.split('\s+', swap, 5)
                    dev = DiskDevice()
                    dev.setMountPoint(ar_buf[0])
                    dev.setName("SWAP")
                    dev.setTotal(int(ar_buf[2]) * 1024)
                    dev.setUsed(int(ar_buf[3]) * 1024)
                    dev.setFree(dev.getTotal() - dev.getUsed())
                    self.sys.setSwapDevices(dev)




     # filesystem information
     #
     # @return void
     #/
    def _filesystems(self):

        arrResult = Parser().df("-P")
        for dev in arrResult:
            self.sys.setDiskDevices(dev)
            self.sys.getDiskDevices()


     # Distribution
     #
     # @return void
     #/
    def _distro(self):

        #list = @parse_ini_file(APP_ROOT."/data/distros.ini", True)
        #if (!list)
        #    return

        # We have the '2> /dev/None' because Ubuntu gives an error on self.command which causes the distro to be unknown
        if CommonFunctions().rfts('/etc/issue', 1):
            bufr = ''.join(CommonFunctions().rfts('/etc/issue', 1))
            try:
                description = re.split("\n", bufr)[0]
            except:
                description = ''
            try:
                distributorid = description.split()[0]
            except:
                distributorid = ''
            if description:
                self.sys.setDistribution(description)
            if distributorid:
                self.sys.setDistributionIcon(distributorid)
           
        #else
        #    # Fall back in case 'lsb_release' does not exist )
        #    foreach (list as section=>distribution)
        #        if (!isset(distribution["Files"]))
        #            continue
        #         else
        #            foreach (re.split("//", distribution["Files"], -1, PREG_SPLIT_NO_EMPTY) as filename)
        #                if (file_exists(filename))
        #                    CommonFunctions::rfts(filename, buf)
        #                    if (isset(distribution["Image"]))
        #                        self.sys.setDistributionIcon(distribution["Image"])
        #
        #                    if (isset(distribution["Name"]))
        #                        if (distribution["Name"] == 'Synology')
        #                            self.sys.setDistribution(distribution["Name"])
        #                         else
        #                            self.sys.setDistribution(distribution["Name"]." ".trim(buf))
        #
        #                     else
        #                        self.sys.setDistribution(trim(buf))
        #
        #                    return
        #
        #




     # get the information
     #
     # @see PSI_Interface_OS::build()
     #
     # @return Void
     #/
    def build_static(self):

        self._distro()
        self._ip()
        self._hostname()
        self._kernel()
        self._uptime()
        self._users()
        self._cpuinfo()
        self._pci()
        #self._ide()
        self._scsi()
        self._usb()
        self._loadavg()
        self._filesystems()
    def build_dynamic(self):

        self._distro()
        self._ip()
        self._hostname()
        self._kernel()
        self._uptime()
        self._users()
        self._loadavg()
        self._network()
        self._memory()
 # Basic OS Class
 #
 #
 # @category  PHP
 # @package   PSI_OS
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: $Id: class.Sensors.inc.php 263 2009-06-22 13:01:52Z bigmichi1 $
 # @link      http://phpsysinfo.sourceforge.net
 #/
 # Basic OS functions for all OS classes
 #
 # @category  PHP
 # @package   PSI_OS
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net
 #/
class Sensors():


     # object for error handling
     #
     # @var Error
     #/
    #protected $error

     # object for the information
     #
     # @var MBInfo
     #/

     # build the global Error object
     #/
    def __init__(self):

        #self.error = Error.singleton()
        self.mbinfo = MBInfo()


     # get the filled or unfilled (with default values) MBInfo object
     #
     # @see PSI_Interface_Sensor::getMBInfo()
     #
     # @return MBInfo
     #/
    def getMBInfo(self):

        self.build()
        return self.mbinfo



class XML():
    def __init__(self):
        self._sysinfo = ''         #undefine
        self._sys = ''
        self._xml = Document()
        self._errors = list()                   #undefine
        self._plugins = ""
        self._plugin = ""
        self._plugin_request = False
        self._complete_request = False
    def _construct(self, type, complete = False, pluginname = ""):
        #self._errors = Error.singleton()
        if pluginname == "":
            self._plugin_request = False
            self._plugin = ""
        else:
            self._plugin_request = True
        if complete:
            self._complete_request  = True
        else:
            self._complete_request  = False

        #os = PYTHON_OS
        self._sysinfo = Linux(type)
        self._sys = self._sysinfo.sys
        #self._plugins  = CommonFunctions.getPlugins()
    def _xmlbody(self):
        dom = Document()
        root = dom.createElement('tns:pythonsysinfo')
        dom.appendChild(root)
        root.setAttribute('xmlns:tns', 'http://www.perabytes.com/')
        #root.setAttribute('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance')
        #root.setAttribute('xsi:schemaLocation', 'http://phpsysinfo.sourceforge.net/ phpsysinfo3.xsd')
        #self._xml = SimpleXMLExtended(simplexml_import_dom(dom), self._sysinfo.getEncoding())
        self._xml = dom
        #generation = self._xml.createElement('Generation')
        #root.appendChild(generation)
        #generation.setAttribute('version', CommonFunctions().PSI_VERSION)
        #generation.setAttribute('timestamp', time())
        #plug = self._xml.createElement('UsedPlugins')
        #root.appendChild(plug)
        #if self._complete_request and self._plugins.length > 0:
        #    for plugin in self._plugins:
        #        plug.createElement('Plugin').setAttribute('name', plugin)
        #elif self._plugin_request and self._plugins.length >0:
        #    plug.createElement('Plugin').setAttribute('name', plugin)

    def _buildVitals(self):
        vitals = self._xml.createElement('Vitals')
        root = self._xml.getElementsByTagName('tns:pythonsysinfo')[0]
        root.appendChild(vitals)
        vitals.setAttribute('Hostname', self._sys.getHostname())
        vitals.setAttribute('IPAddr', self._sys.getIp())
        vitals.setAttribute('Kernel', self._sys.getKernel())
        vitals.setAttribute('Distro', self._sys.getDistribution())
        vitals.setAttribute('Districon', self._sys.getDistributionIcon())
        vitals.setAttribute('Uptime', str(self._sys.getUptime()))
        vitals.setAttribute('Users', self._sys.getUsers())
        vitals.setAttribute('LoadAvg', self._sys.getLoad())
        if self._sys.getLoadPercent() != None:
            vitals.setAttribute('CPULoad', self._sys.getLoadPercent())

    def _buildNetwork(self):
        network = self._xml.createElement('Network')
        root = self._xml.getElementsByTagName('tns:pythonsysinfo')[0]
        root.appendChild(network)
        #self._xmlroot.appendChild(network)
        hideDevices = re.split("[\s]?,[\s]?", PSI_HIDE_NETWORK_INTERFACE)              #return a list
        for dev in self._sys.getNetDevices():
            if dev.getName() not in hideDevices:
                device = self._xml.createElement('NetDevice')
                network.appendChild(device)
                device.setAttribute('Name', dev.getName())
                device.setAttribute('RxBytes', dev.getRxBytes())
                device.setAttribute('TxBytes', dev.getTxBytes())
                device.setAttribute('Errors', dev.getErrors())
                device.setAttribute('Drops', dev.getDrops())

    def _buildHardware(self):
        dev = HWDevice()            #Define in class HWDevice
        hardware = self._xml.createElement('Hardware')
        root = self._xml.getElementsByTagName('tns:pythonsysinfo')[0]
        root.appendChild(hardware)
        #self._xmlroot.appendChild(hardware)
        pci = self._xml.createElement('PCI')
        hardware.appendChild(pci)
        for dev in System().removeDupsAndCount(self._sys.getPciDevices()):
            tmp = self._xml.createElement('Device')
            pci.appendChild(tmp)
            tmp.setAttribute('Name', dev.getName())
            tmp.setAttribute('Count', str(dev.getCount()))

        ide = self._xml.createElement('IDE')
        hardware.appendChild(ide)
        for dev in System().removeDupsAndCount(self._sys.getIdeDevices()):
            tmp = self._xml.createElement('Device')
            ide.appendChild(tmp)
            tmp.setAttribute('Name', dev.getName())
            tmp.setAttribute('Count', str(dev.getCount()))
            if dev.getCapacity() != None:
                tmp.setAttribute('Capacity', dev.getCapacity())

        scsi = self._xml.createElement('SCSI')
        hardware.appendChild(scsi)
        for dev in System().removeDupsAndCount(self._sys.getScsiDevices()):
            tmp = self._xml.createElement('Device')
            scsi.appendChild(tmp)
            tmp.setAttribute('Name', dev.getName())
            tmp.setAttribute('Count', str(dev.getCount()))
            if dev.getCapacity() != None:
                tmp.setAttribute('Capacity', dev.getCapacity())

        cpu = self._xml.createElement('CPU')
        hardware.appendChild(cpu)
        for dev in self._sys.getCpus():
            tmp = self._xml.createElement('CpuCore')
            cpu.appendChild(tmp)
            tmp.setAttribute('Model', dev.getModel())
            if dev.getCpuSpeed() != 0:
                tmp.setAttribute('CpuSpeed', str(dev.getCpuSpeed()))
            if dev.getTemp() != 0:
                tmp.setAttribute('CpuTemp', str(dev.getTemp()))
            if dev.getBusSpeed() != 0:
                tmp.setAttribute('BusSpeed', str(dev.getBusSpeed()))
            if dev.getCache() != 0:
                tmp.setAttribute('Cache', str(dev.getCache()))
            if dev.getVirt() != 0:
                tmp.setAttribute('Virt', str(dev.getVirt()))
            if dev.getBogomips() != 0:
                tmp.setAttribute('Bogomips', str(dev.getBogomips()))
            if dev.getLoad() != 0:
                tmp.setAttribute('Load', str(dev.getLoad()))

    def _buildMemory(self):
        memory = self._xml.createElement('Memory')
        root = self._xml.getElementsByTagName('tns:pythonsysinfo')[0]
        root.appendChild(memory)
        memory.setAttribute('Free', str(self._sys.getMemFree()))
        memory.setAttribute('Used', str(self._sys.getMemUsed()))
        memory.setAttribute('Total', str(self._sys.getMemTotal()))
        memory.setAttribute('Percent', str(self._sys.getMemPercentUsed()))

        details = self._xml.createElement('Details')
        memory.appendChild(details)
        if self._sys.getMemApplication() != None:
            details.setAttribute('App', str(self._sys.getMemApplication()))
            details.setAttribute('AppPercent', str(self._sys.getMemPercentApplication()))
        if self._sys.getMemBuffer() != None:
            details.setAttribute('Buffers', str(self._sys.getMemBuffer()))
            details.setAttribute('BuffersPercent', str(self._sys.getMemPercentBuffer()))
        if self._sys.getMemCache() != None:
            details.setAttribute('Cached', str(self._sys.getMemCache()))
            details.setAttribute('CachedPercent', str(self._sys.getMemPercentCache()))
        if len(self._sys.getSwapDevices()) > 0:
            swap = self._xml.createElement('Swap')
            memory.appendChild(swap)

            swap.setAttribute('Free', str(self._sys.getSwapFree()))
            swap.setAttribute('Used', str(self._sys.getSwapUsed()))
            swap.setAttribute('Total', str(self._sys.getSwapTotal()))
            swap.setAttribute('Percent', str(self._sys.getSwapPercentUsed()))

            i = 1
            for dev in self._sys.getSwapDevices():
                swapMount = self._xml.createElement('Mount')
                swap.appendChild(swapMount)
                i += 1
                self._fillDevice(swapMount, dev, i)


    def _fillDevice(self, mount, dev, i):
        mount.setAttribute('MountPointID', str(i))
        mount.setAttribute('FSType', str(dev.getFsType()))
        mount.setAttribute('Name', str(dev.getName()))
        mount.setAttribute('Free', str(dev.getFree()))
        mount.setAttribute('Used', str(dev.getUsed()))
        mount.setAttribute('Total', str(dev.getTotal()))
        mount.setAttribute('Percent', str(dev.getPercentInodesUsed()))

        if PSI_SHOW_MOUNT_OPTION == True:
            if dev.getOptions() != None:
                mount.setAttribute('MountOptions',str(dev.getOptions()))
        if dev.getPercentInodesUsed() != None:
            mount.setAttribute('Inodes', str(dev.getPercentInodesUsed()))
        if PSI_SHOW_MOUNT_POINT == True:
            mount.setAttribute('MountPoint', str(dev.getMountPoint()))

    def _buildFilesystems(self):
        hideMounts = hideFstypes = hideDisks = list()
        i = 1
        if PSI_HIDE_MOUNTS != "":
            hideMounts = PSI_HIDE_MOUNTS.split(',')
        if PSI_HIDE_FS_TYPES != "":
            hideFstype = PSI_HIDE_FS_TYPE.split(',')
        if PSI_HIDE_DISKS != "":
            hideDisks = PSI_HIDE_DISKS.split(',')

        fs = self._xml.createElement('FileSystem')
        root = self._xml.getElementsByTagName('tns:pythonsysinfo')[0]
        root.appendChild(fs)
        for disk in self._sys.getDiskDevices():
            mount = self._xml.createElement('Mount')
            fs.appendChild(mount)
            i += 1
            self._fillDevice(mount, disk, i)

    def _buildMbinfo(self):
        mbinfo = self._xml.createElement('MBInfo')
        root = self._xml.getElementsByTagName('tns:pythonsysinfo')[0]
        root.appendChild(mbinfo)
        #if PSI_MBINFO or PSI_HDDTEMP:
        temp = self._xml.createElement('TemperaTrue')
        #    if PSI_MBINFO:
        mbinfo.appendChild(temp)
        #mbinfoclass = PSI_SENSOR_PROGRAM
        mbinfo_data = LMSensors()           #mbinfoclass()
        mbinfo_detail = mbinfo_data.getMBInfo()
        for dev in mbinfo_detail.getMbTemp():
            item = self._xml.createElement('Item')
            temp.appendChild(item)
            item.setAttribute('Label', dev.getName())
            item.setAttribute('Value', str(dev.getValue()))
            item.setAttribute('Max', str(dev.getMax()))
        #    if PSI_HDDTEMP:
        """
        hddtemp = HDDTemp()
        hddtemp = hddtemp.getMBInfo()
        for dev in hddtemp.getMBTemp():
            item = self._xml.createElement('Item')
            temp.appendChild(item)
            item.setAttribute('Label', dev.getName())
            item.setAttribute('Value', dev.getValue())
            item.setAttribute('Max', dev.getMax())
        """
        #if PSI_MBINFO:
        fan = self._xml.createElement('Fans')
        for dev in mbinfo_detail.getMbFan():
            item = self._xml.createElement('Item')
            temp.appendChild(item)
            item.setAttribute('Label', dev.getName())
            item.setAttribute('Value', str(dev.getValue()))
            item.setAttribute('Max', str(dev.getMax()))

        #if PSI_MBINFO:
        volt = self._xml.createElement('Voltage')
        for dev in mbinfo_detail.getMbVolt():
            item = self._xml.createElement('Item')
            temp.appendChild(item)
            item.setAttribute('Label', dev.getName())
            item.setAttribute('Value', str(dev.getValue()))
            item.setAttribute('Min', str(dev.getMin()))
            item.setAttribute('Max', str(dev.getMax()))

    def _buildUpsinfo(self):
        upsinfo = self._xml.createElement('UPSInfo')
        if PSI_UPSINFO:
            upsinfoclass = PSI_UPS_PROGRAM
            upsinfo_data = upsinfoclass()
            upsinfo_detail = upsinfo_data.getUPSInfo()
            for ups in upsinfo_detail.getUpsDeivces():
                item = self._xml.createElement('Item')
                upsinfo.appendChild(item)
                item.setAttribute('Name', dev.getName())
                item.setAttribute('Model', dev.getModel())
                item.setAttribute('Mode', dev.getMode())
                item.setAttribute('StartTime', dev.getStartTime())
                item.setAttribute('Status', dev.getStatus())
                if ups.getTemperatur() != None:
                    item.setAttribute('TemperaTrue', ups.getTemperatue())
                if ups.getOutages() != None:
                    item.setAttribute('OuteagesCount', ups.getOutages())
                if ups.getLastOutage() != None:
                    item.setAttribute('LastOutage', ups.getLastOutage())
                if ups.getLastOutageFinish() != None:
                    item.setAttribute('LastOutageFinish', ups.getLastOutageFinish())
                if ups.getLineVoltage() != None:
                    item.setAttribute('LineVoltage', ups.getLineVoltage())
                if ups.getLoad() != None:
                    item.setAttribute('LoadPercent', ups.getLoad())
                if ups.getBatteryVoltage() != None:
                    item.setAttribute('BatteryVoltage', ups.getBatteryVoltage())
                if ups.getBatteryCharge() != None:
                    item.setAttribute('BatteryChargePercent', ups.getBatteryCharge())
                if ups.getTimeLeft() != None:
                    item.setAttribute('TimeLeftMinutes', ups.getTimeLeft())

    def _buildXml(self,type):
        #if !self._plugin_request or self._complete_request:
        #if self._complete_request:
        #    if self._sys == None:
        #        self._sys = self._sysinfo.getSys()
        self._xmlbody()
	if type == "static":
            self._construct(type)
            self._buildVitals()
            self._buildHardware()
            self._buildFilesystems()
	elif type == "dynamic":
            self._construct(type)
            self._buildVitals()
            self._buildNetwork()
            self._buildMemory()
            self._buildMbinfo()

        #    self._buildUpsinfo()
        return self._xml

    #def getXml(self):
    #    self._buildXml()
    #    return self._xml.getSimpleXmlElement()

    #def _buildPlugins(self):
    #    pluginroot = self._xml.createElement('Plugins')
    #    if self._plugin_request or self._complete_request and self._plugins.length > 0:
    #        plugins = list()
    #        if self._complete_request:
    #            plugins = list(self._plugin)
    #        for plugin in plugins:
    #            object = plugin(self._sysfinfo.getEncoding())
    #            object.execute()

 # CpuDevice TO class
 #
 # PHP version 5
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: Id: class.CpuDevice.inc.php 411 2010-12-28 22:32:52Z Jacky672
 # @link      http://phpsysinfo.sourceforge.net

 # CpuDevice TO class
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net

class CpuDevice():

    def __init__(self):
        self._model = ""
        self._cpuSpeed = 0
        self._cache = None
        self._virt = None
        self._busSpeed = None
        self._temp = None
        self._bogomips = None
        self._load = None

    def getBogomips(self):

        return self._bogomips


     # Sets _bogomips.
     #
     # @param Integer bogomips bogompis
     #
     # @see Cpu::_bogomips
     #
     # @return Void
     #/
    def setBogomips(self, bogomips):

        self._bogomips = bogomips


     # Returns _busSpeed.
     #
     # @see Cpu::_busSpeed
     #
     # @return Integer
     #/
    def getBusSpeed(self):

        return self._busSpeed


     # Sets _busSpeed.
     #
     # @param Integer busSpeed busspeed
     #
     # @see Cpu::_busSpeed
     #
     # @return Void
     #/
    def setBusSpeed(self, busSpeed):

        self._busSpeed = busSpeed


     # Returns _cache.
     #
     # @see Cpu::_cache
     #
     # @return Integer
     #/
    def getCache(self):

        return self._cache


     # Sets _cache.
     #
     # @param Integer cache cache size
     #
     # @see Cpu::_cache
     #
     # @return Void
     #/
    def setCache(self, cache):

        self._cache = cache


     # Returns _virt.
     #
     # @see Cpu::_virt
     #
     # @return String
     #/
    def getVirt(self):

        return self._virt


     # Sets _virt.
     #
     # @param String _virt
     #
     # @see Cpu::_virt
     #
     # @return Void
     #/
    def setVirt(self, virt):

        self._virt = virt


     # Returns _cpuSpeed.
     #
     # @see Cpu::_cpuSpeed
     #
     # @return Integer
     #/
    def getCpuSpeed(self):

        return self._cpuSpeed


     # Sets _cpuSpeed.
     #
     # @param Integer cpuSpeed cpuspeed
     #
     # @see Cpu::_cpuSpeed
     #
     # @return Void
     #/
    def setCpuSpeed(self, cpuSpeed):

        self._cpuSpeed = cpuSpeed


     # Returns _model.
     #
     # @see Cpu::_model
     #
     # @return String
     #/
    def getModel(self):

        return self._model


     # Sets _model.
     #
     # @param String model cpumodel
     #
     # @see Cpu::_model
     #
     # @return Void
     #/
    def setModel(self, model):

        self._model = model


     # Returns _temp.
     #
     # @see Cpu::_temp
     #
     # @return Integer
     #/
    def getTemp(self):

        return self._temp


     # Sets _temp.
     #
     # @param Integer temp temperature
     #
     # @see Cpu::_temp
     #
     # @return Void
     #/
    def setTemp(self, temp):

        self._temp = temp


     # Returns _load.
     #
     # @see CpuDevice::_load
     #
     # @return Integer
     #/
    def getLoad(self):

        return self._load


     # Sets _load.
     #
     # @param Integer load load percent
     #
     # @see CpuDevice::_load
     #
     # @return Void
     #/
    def setLoad(self, load):

        self._load = load

 # DiskDevice TO class
 #
 # PHP version 5
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: Id: class.DiskDevice.inc.php 252 2009-06-17 13:06:44Z bigmichi1
 # @link      http://phpsysinfo.sourceforge.net

 # DiskDevice TO class
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @versio   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net
class DiskDevice():

    def __init__(self):
        self._name = ""
        self._fsType = ""
        self._free = 0
        self._used = 0
        self._total = 0
        self._mountPoint = None
        self._options = None
        self._percentInodesUsed = None

     # Returns PercentUsed calculated when function is called from internal values
     #
     # @see DiskDevice::_total
     # @see DiskDevice::_used
     #
     # @return Integer

    def getPercentUsed(self):

        if  self._total > 0:
            return math.ceil( self._used / self._total * 100)
        else:
            return 0

     # Returns _PercentInodesUsed.
     #
     # @see DiskDevice::_PercentInodesUsed
     #
     # @return Integer

    def getPercentInodesUsed(self):

        return self._percentInodesUsed

     # Sets _PercentInodesUsed.
     #
     # @param Integer percentInodesUsed inodes percent
     #
     # @see DiskDevice::_PercentInodesUsed
     #
     # @return Void

    def setPercentInodesUsed(self, percentInodesUsed):

        self._percentInodesUsed = percentInodesUsed


     # Returns _free.
     #
     # @see DiskDevice::_free
     #
     # @return Integer

    def getFree(self):

        return self._free

     # Sets _free.
     #
     # @param Integer free free bytes
     #
     # @see DiskDevice::_free
     #
     # @return Void

    def setFree(self, free):

        self._free = free

     # Returns _fsType.
     #
     # @see DiskDevice::_fsType
     #
     # @return String

    def getFsType(self):

        return self._fsType

     # Sets _fsType.
     #
     # @param String fsType filesystemtype
     #
     # @see DiskDevice::_fsType
     #
     # @return Void

    def setFsType(self, fsType):

        self._fsType = fsType

     # Returns _mountPoint.
     #
     # @see DiskDevice::_mountPoint
     #
     # @return String

    def getMountPoint(self):

        return self._mountPoint

     # Sets _mountPoint.
     #
     # @param String mountPoint mountpoint
     #
     # @see DiskDevice::_mountPoint
     #
     # @return Void

    def setMountPoint(self, mountPoint):

        self._mountPoint = mountPoint

     # Returns _name.
     #
     # @see DiskDevice::_name
     #
     # @return String

    def getName(self):

        return self._name

     # Sets _name.
     #
     # @param String name device name
     #
     # @see DiskDevice::_name
     #
     # @return Void

    def setName(self, name):

        self._name = name


     # Returns _options.
     #
     # @see DiskDevice::_options
     #
     # @return String

    def getOptions(self):

        return self._options

     # Sets _options.
     #
     # @param String options additional options
     #
     # @see DiskDevice::_options
     #
     # @return Void

    def setOptions(self, options):

        self._options = options


     # Returns _total.
     #
     # @see DiskDevice::_total
     #
     # @return Integer

    def getTotal(self):

        return self._total

     # Sets _total.
     #
     # @param Integer total total bytes
     #
     # @see DiskDevice::_total
     #
     # @return Void

    def setTotal(self, total):

        self._total = total

     # Returns _used.
     #
     # @see DiskDevice::_used
     #
     # @return Integer

    def getUsed(self):

        return self._used

     # Sets _used.
     #
     # @param Integer used used bytes
     #
     # @see DiskDevice::_used
     #
     # @return Void

    def setUsed(self, used):

        self._used = used

 # HWDevice TO class
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: Id: class.HWDevice.inc.php 255 2009-06-17 13:39:41Z bigmichi1
 # @link      http://phpsysinfo.sourceforge.net
 # HWDevice TO class
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net
class HWDevice():

    def __init__(self):
        self._name = ""
        self._capacity = None
        self._count = 1

     # compare a given device with the internal one
     #
     # @param HWDevice dev device that should be compared
     #
     # @return boolean

    def equals(self, dev):

        if dev.getName() == self._name and dev.getCapacity() == self._capacity:
            return True
        else:
            return False

     # Returns _capacity.
     #
     # @see HWDevice::_capacity
     #
     # @return Integer

    def getCapacity(self):

        return self._capacity

     # Sets _capacity.
     #
     # @param Integer capacity device capacity
     #
     # @see HWDevice::_capacity
     #
     # @return Void

    def setCapacity(self, capacity):

        self._capacity = capacity

     # Returns _name.
     #
     # @see HWDevice::_name
     #
     # @return String

    def getName(self):

        return self._name

     # Sets _name.
     #
     # @param String name device name
     #
     # @see HWDevice::_name
     #
     # @return Void

    def setName(self, name):

        self._name = name

     # Returns _count.
     #
     # @see HWDevice::_count
     #
     # @return Integer

    def getCount(self):

        return self._count

     # Sets _count.
     #
     # @param Integer count device count
     #
     # @see HWDevice::_count
     #
     # @return Void

    def setCount(self, count):

        self._count = count

 # SensorDevice TO class
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: Id: class.SensorDevice.inc.php 252 2009-06-17 13:06:44Z bigmichi1
 # @link      http://phpsysinfo.sourceforge.net

 # SensorDevice TO class
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net

class SensorDevice():

    def __init__(self):
        self._name = ""
        self._value = 0
        self._max = 0
        self._min = 0

     # Returns _max.
     #
     # @see Sensor::_max
     #
     # @return Integer

    def getMax(self):

        return self._max

     # Sets _max.
     #
     # @param Integer max maximum value
     #
     # @see Sensor::_max
     #
     # @return Void

    def setMax(self, max):

        self._max = max

     # Returns _min.
     #
     # @see Sensor::_min
     #
     # @return Integer

    def getMin(self):

        return self._min

     # Sets _min.
     #
     # @param Integer min minimum value
     #
     # @see Sensor::_min
     #
     # @return Void

    def setMin(self, min):

        self._min = min

     # Returns _name.
     #
     # @see Sensor::_name
     #
     # @return String

    def getName(self):

        return self._name

     # Sets _name.
     #
     # @param String name sensor name
     #
     # @see Sensor::_name
     #
     # @return Void

    def setName(self, name):

        self._name = name

     # Returns _value.
     #
     # @see Sensor::_value
     #
     # @return Integer

    def getValue(self):

        return self._value

     # Sets _value.
     #
     # @param Integer value current value
     #
     # @see Sensor::_value
     #
     # @return Void

    def setValue(self, value):

        self._value = value


 # NetDevice TO class
 #
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: Id: class.NetDevice.inc.php 252 2009-06-17 13:06:44Z bigmichi1
 # @link      http://phpsysinfo.sourceforge.net
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net

class NetDevice():

    def __init__(self):
        self._name = ""
        self._txBytes = 0
        self._rxBytes = 0
        self._errors = 0
        self._drops = 0

    def getDrops(self):

        return self._drops

     # Sets _drops.
     #
     # @param Integer drops dropped packages
     #
     # @see NetDevice::_drops
     #
     # @return Void

    def setDrops(self, drops):

        self._drops = drops

     # Returns _errors.
     #
     # @see NetDevice::_errors
     #
     # @return Integer

    def getErrors(self):

        return self._errors

     # Sets _errors.
     #
     # @param Integer errors error packages
     #
     # @see NetDevice::_errors
     #
     # @return Void

    def setErrors(self, errors):

        self._errors = errors

     # Returns _name.
     #
     # @see NetDevice::_name
     #
     # @return String

    def getName(self):

        return self._name

     # Sets _name.
     #
     # @param String name device name
     #
     # @see NetDevice::_name
     #
     # @return Void

    def setName(self, name):

        self._name = name

     # Returns _rxBytes.
     #
     # @see NetDevice::_rxBytes
     #
     # @return Integer

    def getRxBytes(self):

        return self._rxBytes

     # Sets _rxBytes.
     #
     # @param Integer rxBytes received bytes
     #
     # @see NetDevice::_rxBytes
     #
     # @return Void

    def setRxBytes(self, rxBytes):

        self._rxBytes = rxBytes

     # Returns _txBytes.
     #
     # @see NetDevice::_txBytes
     #
     # @return Integer

    def getTxBytes(self):

        return self._txBytes

     # Sets _txBytes.
     #
     # @param Integer txBytes transmitted bytes
     #
     # @see NetDevice::_txBytes
     #
     # @return Void

    def setTxBytes(self, txBytes):

        self._txBytes = txBytes


 # UPSDevice TO class
 #
 # PHP version 5
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: Id: class.UPSDevice.inc.php 262 2009-06-22 10:48:33Z bigmichi1
 # @link      http://phpsysinfo.sourceforge.net
 #/
 # UPSDevice TO class
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net
 #/
class UPSDevice():

    def __init__(self):
        self._name = ""
        self._model = ""
        self._mode = ""
        self._startTime = ""
        self._status = ""
        self._temperatur = null
        self._outages = null
        self._lastOutage = null
        self._lastOutageFinish = null
        self._lineVoltage = null
        self._load = null
        self._batteryVoltage = null
        self._batterCharge = null
        self._timeLeft = null

     # Returns _batterCharge.
     #
     # @see UPSDevice::_batterCharge
     #
     # @return integer

    def getBatterCharge(self):

        return self._batterCharge

     # Sets _batterCharge.
     #
     # @param Integer batterCharge battery charge
     #
     # @see UPSDevice::_batterCharge
     #
     # @return void

    def setBatterCharge(self, batterCharge):

        self._batterCharge = batterCharge

     # Returns _batteryVoltage.
     #
     # @see UPSDevice::_batteryVoltage
     #
     # @return Integer

    def getBatteryVoltage(self):

        return self._batteryVoltage

     # Sets _batteryVoltage.
     #
     # @param object batteryVoltage battery volt
     #
     # @see UPSDevice::_batteryVoltage
     #
     # @return Void

    def setBatteryVoltage(self, batteryVoltage):

        self._batteryVoltage = batteryVoltage

     # Returns _lastOutage.
     #
     # @see UPSDevice::_lastOutage
     #
     # @return String

    def getLastOutage(self):

        return self._lastOutage

     # Sets _lastOutage.
     #
     # @param String lastOutage last Outage
     #
     # @see UPSDevice::lastOutage
     #
     # @return Void

    def setLastOutage(self, lastOutage):

        self._lastOutage = lastOutage

     # Returns _lastOutageFinish.
     #
     # @see UPSDevice::_lastOutageFinish
     #
     # @return String

    def getLastOutageFinish(self):

        return self._lastOutageFinish

     # Sets _lastOutageFinish.
     #
     # @param String lastOutageFinish last outage finish
     #
     # @see UPSDevice::_lastOutageFinish
     #
     # @return Void

    def setLastOutageFinish(self, lastOutageFinish):

        self._lastOutageFinish = lastOutageFinish

     # Returns _lineVoltage.
     #
     # @see UPSDevice::_lineVoltage
     #
     # @return Integer

    def getLineVoltage(self):

        return self._lineVoltage

     # Sets _lineVoltage.
     #
     # @param Integer lineVoltage line voltage
     #
     # @see UPSDevice::_lineVoltage
     #
     # @return Void

    def setLineVoltage(self, lineVoltage):

        self._lineVoltage = lineVoltage

     # Returns _load.
     #
     # @see UPSDevice::_load
     #
     # @return Integer

    def getLoad(self):

        return self._load

     # Sets _load.
     #
     # @param Integer load current load
     #
     # @see UPSDevice::_load
     #
     # @return Void

    def setLoad(self, load):

        self._load = load

     # Returns _mode.
     #
     # @see UPSDevice::_mode
     #
     # @return String

    def getMode(self):

        return self._mode

     # Sets _mode.
     #
     # @param String mode mode
     #
     # @see UPSDevice::_mode
     #
     # @return Void

    def setMode(self, mode):

        self._mode = mode

     # Returns _model.
     #
     # @see UPSDevice::_model
     #
     # @return String

    def getModel(self):

        return self._model

     # Sets _model.
     #
     # @param String model model
     #
     # @see UPSDevice::_model
     #
     # @return Void

    def setModel(self, model):

        self._model = model

     # Returns _name.
     #
     # @see UPSDevice::_name
     #
     # @return String

    def getName(self):

        return self._name

     # Sets _name.
     #
     # @param String name name
     #
     # @see UPSDevice::_name
     #
     # @return Void

    def setName(self, name):

        self._name = name

     # Returns _outages.
     #
     # @see UPSDevice::_outages
     #
     # @return Integer

    def getOutages(self):

        return self._outages

     # Sets _outages.
     #
     # @param Integer outages outages count
     #
     # @see UPSDevice::_outages
     #
     # @return Void

    def setOutages(self, outages):

        self._outages = outages

     # Returns _startTime.
     #
     # @see UPSDevice::_startTime
     #
     # @return String

    def getStartTime(self):

        return self._startTime

     # Sets _startTime.
     #
     # @param String startTime startTime
     #
     # @see UPSDevice::_startTime
     #
     # @return Void

    def setStartTime(self, startTime):

        self._startTime = startTime

     # Returns _status.
     #
     # @see UPSDevice::_status
     #
     # @return String

    def getStatus(self):

        return self._status

     # Sets _status.
     #
     # @param String status status
     #
     # @see UPSDevice::_status
     #
     # @return Void

    def setStatus(self, status):

        self._status = status

     # Returns _temperatur.
     #
     # @see UPSDevice::_temperatur
     #
     # @return Integer

    def getTemperatur(self):

        return self._temperatur

     # Sets _temperatur.
     #
     # @param Integer temperatur temperature
     #
     # @see UPSDevice::_temperatur
     #
     # @return Void

    def setTemperatur(self, temperatur):

        self._temperatur = temperatur

     # Returns _timeLeft.
     #
     # @see UPSDevice::_timeLeft
     #
     # @return String

    def getTimeLeft(self):

        return self._timeLeft

     # Sets _timeLeft.
     #
     # @param String timeLeft time left
     #
     # @see UPSDevice::_timeLeft
     #
     # @return Void

    def setTimeLeft(self, timeLeft):

        self._timeLeft = timeLeft

class MBInfo():
    def __init__(self):
        self._mbTemp = list()
        self._mbFan = list()
        self._mbVolt = list()

    def getMbFan(self):
        return self._mbFan

    def setMbFan(self, mbFan):
        self._mbFan.append(mbFan)

    def getMbTemp(self):
        return self._mbTemp

    def setMbTemp(self, mbTemp):
        self._mbTemp.append(mbTemp)

    def getMbVolt(self):
        return self._mbVolt

    def setMbVolt(self, mbVolt):
        self._mbVolt.append(mbVolt)


    """
 # MBInfo TO class
 #
 # PHP version 5
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: $Id: class.UPSInfo.inc.php 329 2009-09-07 11:21:44Z bigmichi1 $
 # @link      http://phpsysinfo.sourceforge.net
 #/
 # MBInfo TO class
 #
 # @category  PHP
 # @package   PSI_TO
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net
class UPSInfo
     # array with upsdivices
     #
     # @see UPSDevice
     #
     # @var Array
     #
    def __init__(self):
        self._upsDevices = list()

     # Returns $_upsDevices.
     #
     # @see UPSInfo::$_upsDevices
     #
     # @return Array
     #
    def getUpsDevices(self):
        return self._upsDevices

     # Sets $_upsDevices.
     #
     # @param UPSDevice $upsDevices upsdevice
     #
     # @see UPSInfo::$_upsDevices
     #
     # @return Void
     #
    def setUpsDevices(self, upsDevices):
        self._upsDevices(upsDevices)

 # ipmi sensor class
 #
 #
 # @category  PHP
 # @package   PSI_Sensor
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: Id: class.IPMI.inc.php 287 2009-06-26 12:11:59Z bigmichi1
 # @link      http://phpsysinfo.sourceforge.net
 #/
 # getting information from ipmitool
 #
 # @category  PHP
 # @package   PSI_Sensor
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net
class IPMI(Sensors):

     # content to parse
     #
     # @var array
     #/

     # fill the self.content var through tcp or file access
     #/
    def __init__(self):

        #switch (strtolower(PSI_SENSOR_ACCESS))
        #case 'command':
        lines = ''
        CommonFunctions().executeProgram('ipmitool', 'sensor')
        self._lines = re.split("\n", lines)
        #    break
        #default:
        #    self.error.addConfigError('__construct()', 'PSI_SENSOR_ACCESS')
        #    break



     # get temperature information
     #
     # @return void
     #/
    def _temp(self):

        for line in self._lines:
            buffer = re.split("[ ]+\|[ ]+", line)
            if buffer[2] == "degrees C" and buffer[5] != "na":
                dev = SensorDevice()
                dev.setName(buffer[0])
                dev.setValue(buffer[1])
                dev.setMax(buffer[8])
                self.mbinfo.setMbTemp(dev)



     # get voltage information
     #
     # @return void
     #/
    def _voltage(self):

        for line in self._lines:
            buffer = re.split("[ ]+\|[ ]+", line)
            if buffer[2] == "Volts" and buffer[5] != "na":
                dev = SensorDevice()
                dev.setName(buffer[0])
                dev.setValue(buffer[1])
                dev.setMin(buffer[5])
                dev.setMax(buffer[8])
                self.mbinfo.setMbVolt(dev)



     # get the information
     #
     # @see PSI_Interface_Sensor::build()
     #
     # @return Void
     #/
    def build(self):

        self._temp()
        self._voltage()

    """
 # Basic OS Class
 #
 #
 # @category  PHP
 # @package   PSI_OS
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: $Id: class.Sensors.inc.php 263 2009-06-22 13:01:52Z bigmichi1 $
 # @link      http://phpsysinfo.sourceforge.net
 #/
 # Basic OS functions for all OS classes
 #
 # @category  PHP
 # @package   PSI_OS
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net
 #/
class Sensors():


     # object for error handling
     #
     # @var Error
     #/
    #protected $error

     # object for the information
     #
     # @var MBInfo
     #/

     # build the global Error object
     #/
    def __init__(self):

        #self.error = Error.singleton()
        self.mbinfo = MBInfo()


     # get the filled or unfilled (with default values) MBInfo object
     #
     # @see PSI_Interface_Sensor::getMBInfo()
     #
     # @return MBInfo
     #/
    def getMBInfo(self):

        self.build()
        return self.mbinfo
 # lmsensor sensor class
 #
 #
 # @category  PHP
 # @package   PSI_Sensor
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   SVN: Id: class.LMSensors.inc.php 316 2009-09-03 08:09:18Z bigmichi1
 # @link      http://phpsysinfo.sourceforge.net
 #/
 # getting information from lmsensor
 #
 # @category  PHP
 # @package   PSI_Sensor
 # @author    Michael Cramer <BigMichi1@users.sourceforge.net>
 # @copyright 2009 phpSysInfo
 # @license   http://opensource.org/licenses/gpl-2.0.php GNU General Public License
 # @version   Release: 3.0
 # @link      http://phpsysinfo.sourceforge.net
 #/
class LMSensors(Sensors):

     # content to parse
     #
     # @var array
     #/

     # fill the private content var through tcp or file access
     #/
    def __init__(self):

        Sensors.__init__(self)
        self._lines = []
        self.mbinfo = Sensors().mbinfo

        if CommonFunctions().executeProgram("sensors", "" ):
            # Martijn Stolk: Dirty fix for misinterpreted output of sensors,
            # where info could come on next line when the label is too long.
            lines = ''.join(CommonFunctions().executeProgram("sensors", "" ))
            lines = lines.replace(":\n", ":")
            lines = lines.replace("\n\n", "\n")
            self._lines = re.split("\n", lines)

        #if CommonFunctions().rfts(APP_ROOT + '/data/lmsensors.txt', 1):
        #    lines = str_replace(":\n", ":", lines)
        #    lines = str_replace("\n\n", "\n", lines)
        #    this._lines = re.split("/\n/", lines, -1, PREG_SPLIT_NO_EMPTY)



     # get temperature information
     #
     # @return void
     #/
    def _temperature(self):

        ar_buf = list()
        for line in self._lines[2:]:
            if re.match("(.*):(.*)\((.*)=(.*),(.*)=(.*)\)(.*)", line):
                data = list(re.match("(.*):(.*)\((.*)=(.*),(.*)=(.*)\)(.*)", line).groups())
            elif re.match("(.*):(.*)\((.*)=(.*)\)(.*)", line):
                data = list(re.match("(.*):(.*)\((.*)=(.*)\)(.*)", line).groups())
            elif re.match("(.*):(.*)", line):
                data = list(re.match("(.*):(.*)", line).groups())
            if len(data) > 1:
                temp = data[1].strip()[-1:]
                if temp == "C" or temp == "F":
                    ar_buf.append(line)



        for line in ar_buf:
            data = list()
            if re.match("(.*):(.*).C[ ]*\((.*)=(.*).C,(.*)=(.*).C\)(.*)\)", line):
                data = list(re.match("(.*):(.*).C[ ]*\((.*)=(.*).C,(.*)=(.*).C\)(.*)\)", line).groups())
            elif re.match("(.*):(.*).C[ ]*\((.*)=(.*).C,(.*)=(.*).C\)(.*)", line):
                data = list(re.match("(.*):(.*).C[ ]*\((.*)=(.*).C,(.*)=(.*).C\)(.*)", line).groups())
            elif re.match("(.*):(.*).C[ ]*\((.*)=(.*).C\)(.*)", line):
                data = list(re.match("(.*):(.*).C[ ]*\((.*)=(.*).C\)(.*)", line).groups())
            elif re.match("(.*):(.*).C", line):
                data = list(re.match("(.*):(.*).C", line).groups())

            data_dict = {}
            for value in data:
                if re.match("^\+?([0-9\.]+).?", value.strip()):
                    newvalue = list(re.match("^\+?([0-9\.]+).?", value.strip()).groups())
                    data_dict[data.index(value)] = newvalue[0].strip()
                elif re.match("^(-?[0-9\.]+).?", value.strip()):
                    newvalue = list(re.match("^(-?[0-9\.]+).?", value.strip()).groups())
                    data_dict[data.index(value)] = newvalue[0].strip()
                else:
                    data_dict[data.index(value)] = value.strip()

            dev = SensorDevice()
            if data_dict:
                dev.setName(data_dict[0].strip())
                dev.setValue(data_dict[1].strip())
                limit = 0
                perce = 0
                if data_dict.has_key(5) and data_dict[1] > data_dict[5]:
                    limit = 75
                    perce = 75
                else:
                    if data_dict.has_key(3):
                        limit = data_dict[3]
                        perce = data_dict[5]
                    else:
                        limit = 75
                        perce = 75

                if limit < perce:
                    dev.setMax(perce)
                else:
                    dev.setMax(limit)
                self.mbinfo.setMbTemp(dev)


     # get fan information
     #
     # @return void
     #/
    def _fans(self):

        ar_buf = list()
        for line in self._lines:
            data = list()
            if re.match("(.*):(.*)\((.*)=(.*),(.*)=(.*)\)(.*)", line):
                data = list(re.match("(.*):(.*)\((.*)=(.*),(.*)=(.*)\)(.*)", line).groups())
            elif re.match("(.*):(.*)\((.*)=(.*)\)(.*)", line):
                data = list(re.match("(.*):(.*)\((.*)=(.*)\)(.*)", line).groups())
            elif re.match("(.*):(.*)", line):
                data = list(re.match("(.*):(.*)", line).groups())

            if len(data) > 1:
                temp = re.split(" ",data[1].strip())
                if len(temp) == 1:
                    temp = re.split("\xb0",data[1].strip())
                if len(temp) > 0:
                    if temp[0] != '' and temp[0] == "RPM":
                        ar_buf.append(line)




        for line in ar_buf:
            data = list()
            if re.match("(.*):(.*) RPM  \((.*)=(.*) RPM,(.*)=(.*)\)(.*)\)", line):
                data = list(re.match("(.*):(.*) RPM  \((.*)=(.*) RPM,(.*)=(.*)\)(.*)\)", line).groups())
            elif re.match("(.*):(.*) RPM  \((.*)=(.*) RPM,(.*)=(.*)\)(.*)", line):
                data = list(re.match("(.*):(.*) RPM  \((.*)=(.*) RPM,(.*)=(.*)\)(.*)", line).groups())
            elif re.match("(.*):(.*) RPM  \((.*)=(.*) RPM\)(.*)", line):
                data = list(re.match("(.*):(.*) RPM  \((.*)=(.*) RPM\)(.*)", line).groups())
            elif re.match("(.*):.*( RPM)"):
                data = list(re.match("(.*):(.*) RPM", line).groups())

            dev = SensorDevice()
            dev.setName(data[0].strip())
            dev.setValue(data[1].strip())
            if data[4] != '':
                dev.setMin(data[3].strip())

            self.mbinfo.setMbFan(dev)


     # get voltage information
     #
     # @return void
     #/
    def _voltage(self):

        ar_buf = list()
        for line in self._lines[2:]:
            data = list()
            if re.match("(.*):(.*)\((.*)=(.*),(.*)=(.*)\)(.*)", line):
                data = list(re.match("(.*):(.*)\((.*)=(.*),(.*)=(.*)\)(.*)", line).groups())
            elif re.match("(.*):(.*)", line):
                data = list(re.match("(.*):(.*)", line).groups())
            if len(data) > 1:
                temp = re.split(" ", data[1].strip())
                if len(temp) == 1:
                    temp = re.split("\xb0", data[1].strip())

                if temp[0] != '' and temp[0] == "V":
                    ar_buf.append(line)




        for line in ar_buf:
            data = list()
            if re.match("(.*)\:(.*) V  \((.*)=(.*) V,(.*)=(.*) V\)(.*)\)", line):
                data = list(re.match("(.*)\:(.*) V  \((.*)=(.*) V,(.*)=(.*) V\)(.*)\)", line).groups())
            elif re.match("(.*):(.*) V  \((.*)=(.*) V,(.*)=(.*) V\)(.*)", line):
                data = list(re.match("(.*):(.*) V  \((.*)=(.*) V,(.*)=(.*) V\)(.*)", line).groups())
            elif re.match("(.*):(.*) V", line):
                data = list(re.match("(.*):(.*) V", line).groups())


            data_dict = {}
            for value in data:
                if re.match("^\+?([0-9\.]+).?", value.strip()):
                    newvalue = list(re.match("^\+?([0-9\.]+).?", value.strip()).groups())
                    data_dict[data.index(value)] = newvalue[0].strip()
                else:
                    data_dict[data.index(value)] = value.strip()


            if data_dict.has_key(0):
                dev = SensorDevice()
                dev.setName(data[0].strip())
                dev.setValue(data[1].strip())
                if data_dict.has_key(3):
                    dev.setMin(data_dict[3])

                if data_dict.has_key(5):
                    dev.setMax(data_dict[5])

                self.mbinfo.setMbVolt(dev)




     # get the information
     #
     # @see PSI_Interface_Sensor::build()
     #
     # @return Void
     #/
    def build(self):

        self._temperature()
        self._voltage()
        self._fans()



