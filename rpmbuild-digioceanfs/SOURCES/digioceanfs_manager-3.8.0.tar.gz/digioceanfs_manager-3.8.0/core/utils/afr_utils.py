# -*- coding: utf-8 -*-
import os
import re
import sys
import copy
import dircache
import time
import threading
from findir import myFile
from operator import attrgetter,itemgetter
from manager_utils import *
from sysv_ipc import *

#global dep_dict
global file_total
global dir_total
global sort_time
PAHT = '/usr/local/digioceanfs_gui'

def parseinfo(path):
    result = get_config_file(path, lock=True).readlines()
    f_list = []
    mf = myFile()
    mf.__class__.fileAttr = tuple()
    p = "\/"
    for line in result:
        if len(line.split()) > 0:
            if len(line.split()[0].split("=")) > 1:
                r = line.split("=")
                if r[0] == "PATH":
                    mf.setPath(r[1].strip())
                    #mf.fileAttr = (len(re.findall(p, mf.PATH)), re.split(p, mf.PATH)[-1].strip())
                elif r[0] == "FILE":
                    mf.setFile(r[1].strip())
                elif r[0] == "TYPE":
                    mf.setType(r[1].strip())
                    if mf.TYPE == 'file':
                        mf.fileAttr = (len(re.findall(p, mf.PATH)), mf.PATH)
                        mf.initParent()
                        if mf.PARENT not in f_list:
                            f_list.append(mf.PARENT)
                    else:
                        mf.fileAttr = (len(re.findall(p, mf.PATH)), '/'.join(re.split(p, mf.PATH)[:-1]))
                        mf.initParent()
                        if mf.PARENT not in f_list:
                            f_list.append(mf.PARENT)
                elif r[0] == "STATUS":
                    mf.setStatus(r[1].strip())
                elif r[0] == "SRC":
                    mf.setSrc(r[1].strip())
                elif r[0] == "TGT":
                    mf.setTarget(r[1].strip())
                elif r[0] == "TSIZE":
                    mf.setTsize(r[1].strip())
                elif r[0] == "SPEED":
                    mf.setSpeed(r[1].strip())
        else:
            f_list.append(mf)
            mf = myFile()
    return f_list

def Dsort(_list):
    return sorted(_list, key = attrgetter('PATH'))

def createTree(root, f, dep_dict):
    if f.TYPE == 'dir':
        if not root.PATH:
            dep_dict[f.PATH] = root
            root.PATH = f.PATH
            return root
        else:
            if dep_dict.has_key(f.PATH):
                _parent = dep_dict[f.PATH]
            else:
                dep_dict[f.PATH] = f
            if f.PARENT.PATH == root.PATH:
                root.setCHILD(f)
                return root
            else:
                if f.PARENT.PATH in dep_dict.keys():
                    temp_f = dep_dict[f.PARENT.PATH]
                    temp_f.setCHILD(f)
                    return createTree(root, temp_f, dep_dict)#dep_dict[f.PARENT.PATH])
    else:
        if not root.PATH:          #f is file and root is null, set file'parent as root
            root.PATH = f.PATH
            root.setCHILD(f)
            return root
        else:                       #f is file and there is one root,find f'parent
            if f.PATH == root.PATH:
                root.setCHILD(f)
                return root
            else:
                if f.PARENT.PATH in dep_dict.keys():
                    if f.PARENT.PATH != root.PATH:
                        temp_f = dep_dict[f.PARENT.PATH]
                        temp_f.setCHILD(f)
                    return createTree(root, temp_f, dep_dict)#dep_dict[f.PARENT.PATH])
                else:
                    return createTree(root, f.PARENT, dep_dict)

def getTreeStr(root, indent=0, last=False, exceptions=[]):
    global s
    _last = last
    if indent == 0:
        s = u''
        #s += root.PATH
        s += root['PATH']
    else:
        s = u''
        s += u'\n'
        for i in range(indent-1):
            if i in exceptions:
                s += '│  '.decode('utf-8')
            else:
                s += '   '.decode('utf-8')
        if last:
            s += '└──'.decode('utf-8')
        else:
            s += '├──'.decode('utf-8')
        s += root['PATH'].split('/')[-1]
        if not _last:
            exceptions.append(indent-1)
        else:
            exceptions.append(-1)
    for f in root['childs']:
        if root['childs'].index(f) == len(root['childs']) - 1:
            _last = True
        else:
            _last = False
        if 'childs' not in f:
            s += u'\n'
            for i in range(indent):
                if i in exceptions:
                    s += '│  '.decode('utf-8')
                else:
                    s += '   '.decode('utf-8')
            if _last:
                s += '└──'.decode('utf-8')
            else:
                s += '├──'.decode('utf-8')
            if f['TYPE'] == u'file':
                if f['PROCEDURE'] == "OK":
                    dataline = u' ------->' + u' [ OK ] [ N/A ] [ None ] [ None ] [ N/A ]'
                    s += f['FILE'] + dataline
                else:
                    dataline = u' ------->' + u' [ SYNCING ]' + u'[ ' + f['SPEED'] + u' ]' + u'[ ' + f['TGT'] + u' ]' + u'[ ' + f['SRC'] + u' ]' + u'[ ' + f['SYNSIZE'] + u' ]'
                    s += f['FILE'] + dataline
            else:
                if f['PROCEDURE'] == "OK":
                    dataline = u' ------->' + u' [ OK ] [ N/A ] [ None ] [ None ] [ N/A ]'
                    s += f['FILE'] + dataline
                if f['PROCEDURE'] == "????":
                    dataline = u' ------->' + u' [ ?? ] [ N/A ] [ None ] [ None ] [ N/A ]'
                    s += f['FILE'] + dataline
                else:
                    dataline = u' ------->' + u' [ SYNCING ]' + u'[ ' + f['SPEED'] + u' ]' + u'[ ' + f['TGT'] + u' ]' + u'[ ' + f['SRC'] + u' ]' + u'[ ' + f['SYNSIZE'] + u' ]'
                    s += f['FILE'] + dataline
        else:
            s += getTreeStr(f, indent+1, _last, exceptions[:])
    else:
        return s

    """
    result = f.readlines()
    tmp_dict = {}
    tree_dict = {}
    for s in result:
        line = s.strip()
   """


def afr_info_tree(path):
    my_root = myFile()
    file_total = 0
    dir_total = 0
    dep_dict = {}
    f_list = parseinfo(path)
    for l in f_list:
        if l.TYPE == 'file':
            file_total += 1
        else:
            dir_total += 1
        my_root = createTree(my_root, l, dep_dict)
    return getTreeStr(my_root) + '\n' + 'Total files: %s   Total dirs: %s' % (file_total, dir_total)

def afr_info_tree_topage(path):
    my_root = myFile()
    f_list = Dsort(parseinfo(path))
    dep_dict = {}
    for l in f_list:
        my_root = createTree(my_root, l, dep_dict)
    return tree2ztree(my_root)

def lstree(path, mountdir, data, disks_dict, opendir=[], off=0):
    a = time.time()
    global offset
    offset = off
    d_dict = {}
    if os.path.isdir(path):
        _dict = {}
        _dict['name'] = path.split('/')[len(path.split('/')) -1]
        _dict['PATH'] = path
        _dict['fullName'] = path.split('/')[len(path.split('/')) -1]
        d = getCurrenData(offset, data, mountdir)
        if 'PATH' in d and d['PATH'].find(path) >= 0:
            _dict['PROCEDURE'] = '5'
        else:
            _dict['PROCEDURE'] = 'OK'
        if d and _dict['PATH'] == d['PATH']:
            _dict = copy.deepcopy(d)
            d_name = path.split('/')[len(path.split('/')) -1]
            _dict['fullName'] = d_name
            if len(d_name) > 35:
                d_name = d_name[:35] + u'...'
            _dict['name'] = d_name#path.split('/')[len(path.split('/')) -1]
            _dict['childs'] = []
            _dict['isParent'] = True
            _dict['open'] = True
            offset += len(d.keys()) + 1
        else:
            _dict['FILE']   = ''
            _dict['TYPE']   = 'dir'
            _dict['SRC']    = ''
            _dict['TGT']    = ''
            _dict['SYNSIZE']  = ''
            _dict['SPEED']  = ''
            _dict['childs'] = []
            _dict['isParent'] = True
            _dict['open'] = True
        #p_path = [(i.decode('utf-8')) for i in dircache.opendir(unquote(path))]
        p_path = dircache.opendir(unquote_str(path))
        uni_path = []
        for i in p_path:
            if type(i) == str:
                i = i.decode('utf-8')
            uni_path.append(i)
        p_path.sort()
        #t_path = copy.deepcopy(p_path)
        t_path = copy.deepcopy(uni_path)
        dircache.annotate(path, t_path)
        if d:
            for child in p_path:#os.(path):
                d = getCurrenData(offset, data, mountdir)
                if d:
                    for dchild in t_path:
                        d_path = os.path.join(path,dchild)[:-1]
                        c_dict = {}
                        c_dict['name'] = dchild
                        if d['TYPE'] == 'file' and dchild.find('/') < 0:#os.path.isfile(d_path):
                            if c_dict['name'] == d['FILE']:
                                c_dict = copy.deepcopy(d)
                                c_dict['fullName'] = dchild
                                if len(dchild) > 35:
                                    dchild = dchild[:35] + u'...'
                                c_dict['name'] = dchild
                                if 'SRC' in c_dict:
                                    if c_dict['SRC'] in disks_dict:
                                        c_dict['SRC'] = disks_dict[c_dict['SRC']]
                                else:
                                    c_dict['SRC'] = 'unknown'
                                if 'TGT' in c_dict:
                                    if c_dict['TGT'] in disks_dict:
                                        c_dict['TGT'] = disks_dict[c_dict['TGT']]
                                else:
                                    c_dict['SRC'] = 'unknown'
                                c_dict['PATH'] = d['PATH']# + '/' +d['FILE']
                                offset += len(d.keys()) + 1
                                _dict['childs'].append(c_dict)
                                t_path.remove(dchild)
                                break
                        if d['TYPE'] == 'dir' and dchild.find('/') >= 0:#os.path.isdir(d_path):
                            #c_dict = {}
                            #c_dict['name'] = dchild
                            if os.path.join(path, dchild) == d['PATH']:
                                #tmp_child.append(dchild)
                                if d_path in opendir:
                                    _dict['childs'].append(lstree(d_path, mountdir, data, disks_dict, opendir, offset))
                                    t_path.remove(dchild)
                                    break
                                '''
                                else:
                                    c_dict['name'] = dchild
                                    c_dict['PATH']   = path + '/' +dchild
                                    c_dict['FILE']   = dchild
                                    c_dict['TYPE']   = 'dir'
                                    c_dict['PROCEDURE'] = 'OK'
                                    c_dict['SRC']    = '--'
                                    c_dict['TGT']    = '--'
                                    c_dict['SYNSIZE']  = '--'
                                    c_dict['SPEED']  = '--'
                                    c_dict['isParent'] = True
                                    _dict['childs'].append(c_dict)
                                '''
        for child in t_path:
            d_path = os.path.join(path, child)[:-1]
            if child.find('/') < 0:#os.path.isfile(d_path):
            #if os.path.isfile(d_path):
                c_dict = {}
                c_dict['fullName'] = child
                if len(child) > 35:
                    child = child[:35] + u'...'
                c_dict['name'] = child
                c_dict['PATH']   = path + '/' +child
                c_dict['FILE']   = child
                c_dict['TYPE']   = 'file'
                c_dict['PROCEDURE'] = 'OK'
                c_dict['SRC']    = '--'
                c_dict['TGT']    = '--'
                c_dict['SYNSIZE']  = '--'
                c_dict['SPEED']  = '--'
                _dict['childs'].append(c_dict)
            if child.find('/') >= 0:#os.path.isdir(d_path):
            #if os.path.isdir(d_path):
                if d_path in opendir:
                    _dict['childs'].append(lstree(d_path, mountdir, data, disks_dict, opendir, offset))
                else:
                    c_dict = {}
                    c_dict['fullName'] = child
                    if len(child) > 35:
                        child = child[:35] + u'...'
                    c_dict['name'] = child
                    c_dict['PATH']   = path + '/' +child[:-1]
                    c_dict['FILE']   = child[:-1]
                    c_dict['TYPE']   = 'dir'
                    c_dict['PROCEDURE'] = '????'
                    c_dict['SRC']    = '--'
                    c_dict['TGT']    = '--'
                    c_dict['SYNSIZE']  = '--'
                    c_dict['SPEED']  = '--'
                    c_dict['isParent'] = True
                    _dict['childs'].append(c_dict)
        d_dict = _dict
    return d_dict

def unquote_list(jsescape):
    return [(''.join([(len(i) == 4 and unichr(int(i,16)) or i) for i in j.split('%u')])) for j in jsescape]
def unquote_str(jsescape):
    return ''.join([(len(i) == 4 and unichr(int(i,16)) or i) for i in jsescape.split('%u')])

def getCurrenData(offset, data, mountdir):
    #if len(tmpdata) > 1:
    #data = getData(key)
    datadict = {}
    tmpdata = data[offset:-1]
    if len(tmpdata) > 1:
        for data in tmpdata:
            if len(data.split('=')) > 1:
                key = data.split('=')[0].strip()
                value = data.split('=')[1].strip()
                if key == "PATH":
                    datadict['PATH'] = os.path.join(mountdir, value[1:])
                elif key == "FILE":
                    datadict['FILE'] = value
                elif key == "TYPE":
                    datadict['TYPE'] = value
                elif key == "SRC":
                    datadict['SRC'] = value
                elif key == "TGT":
                    datadict['TGT'] = value
                elif key == "SYNSIZE":
                    datadict['SYNSIZE'] = value
                elif key == "TSIZE":
                    datadict['TSIZE'] = value
                elif key == "SPEED":
                    datadict['SPEED'] = value
                elif key == "PROCEDURE":
                    datadict['PROCEDURE'] = value
                #elif key == "STATUS":
                #    datadict['status'] = value
                elif key == "TOTAL":
                    datadict['TOTAL'] = value
                elif key == "TIMESTAMP":
                    datadict['TIMESTAMP'] = value
                else:
                    pass
            else:
                break
    return datadict

def getData(key, th):
    result = ''
    while 1:#th.isAlive():
        try:
            sp_0 = Semaphore(key-10, 0, 0600)
            if sp_0.value:
                shm_0 = SharedMemory(key, 0, 0600)
                result += shm_0.read()
                sp_0.P()
            sp_1 = Semaphore(key-10+1, 0, 0600)
            if sp_1.value:
                shm_1 = SharedMemory(key+1, 0, 0600)
                result += shm_1.read()
                sp_1.P()
            if not th.isAlive():
                break
        except:
            raise DigioceanfsError
            break
    result_list = result.split('\n')
    return result_list

def tree2ztree(my_root):
    if my_root:
        my_dict = my_root.obj2dict()
        my_dict['name'] = my_root.PATH.split('/')[len(my_root.PATH.split('/')) -1]
        for child in my_root.CHILD:
            if len(child.CHILD) > 0:
                my_dict['childs'].append(tree2ztree(child))
            else:
                c_dict = child.obj2dict()
                if child.TYPE == 'dir':
                    c_dict['name'] = child.PATH.split('/')[len(child.PATH.split('/')) -1]
                else:
                    if c_dict.has_key('childs'):
                        del c_dict['childs']
                    c_dict['name'] = child.FILE
                my_dict['childs'].append(c_dict)
        else:
            return my_dict
    else:
        return None

def list_service_afr_num(service_name):
    afr_num = 0
    service_type = ''
    try:
        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append("volume")
        cmd.append("info")
        cmd.append(service_name)
        tmpfile = tempfile.TemporaryFile()
        execute(cmd, tmpfile)
        lines = tmpfile.readlines()
        for line in lines:
            m = re.match('Type:(.*)',line)
            if m:
                service_type = m.group(1).strip()
            n = re.match('Number of Bricks:(.*)',line)
            if n:
                bricks_num = n.group(1).split('=')[0]
                if bricks_num.count('x') >= 1 and service_type.find('Replicate') >= 0:
                    afr_num = bricks_num.split('x')[-1]
        return int(afr_num)
    except Exception, e:
        print e
        return int(afr_num)

def list_service_redu_num(service_name):
    redu_num = 0
    service_type = ''
    try:
        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append("volume")
        cmd.append("info")
        cmd.append(service_name)
        tmpfile = tempfile.TemporaryFile()
        execute(cmd, tmpfile)
        lines = tmpfile.readlines()
        for line in lines:
            m = re.match('Type:(.*)',line)
            if m:
                service_type = m.group(1).strip()
            n = re.match('Number of Bricks:(.*)',line)
            if n:
                bricks_num = n.group(1).split('=')[0]
                if bricks_num.count('x') >= 1 and service_type.find('Disperse') >= 0:
                    redu_num = eval(bricks_num.split('x')[-1])
        return int(redu_num)
    except Exception, e:
        print e
        return int(redu_num)

def disk_group_by_node(adisk_list):
    disks = {}
    for adisk in adisk_list:
        nodename = adisk.get_node().get_name()
        if nodename not in disks.keys():
            disks[nodename] = []
            disks[nodename].append(adisk)
        else:
            disks[nodename].append(adisk)  
    return disks

def disk_sort_by_size(node_disk_list):
    tmplist = []
    sorted_disk_list = []
    for disk in node_disk_list:
        tmplist.append((disk,disk.get_size()))
    tmplist.sort(key = lambda size : size[1],reverse=True)
    sorted_disk_list.extend(disk[0] for disk in tmplist)
    if sorted_disk_list:
        return sorted_disk_list 
    else:
        return node_disk_list

def afr_disk_auto_pair(adisk_list,afr_num):
    endlist = [] 

    if len(adisk_list)%afr_num != 0:
        return adisk_list

    disks_by_node = disk_group_by_node(adisk_list)
    # sort by size
    for node in disks_by_node:
        disks_by_node[node] = disk_sort_by_size(disks_by_node[node])
    while disks_by_node:
        disklendic = {}
        for node in disks_by_node.keys():
            disklendic[node] = len(disks_by_node[node])
        sortedlist = sorted(disklendic.iteritems(),key=itemgetter(1),reverse=True)
        for i in range(afr_num):
            if sortedlist:
                nodename = sortedlist.pop(0)[0]
                endlist.append(disks_by_node[nodename].pop(0))
            else:
                break
        for i in disks_by_node.keys():
            if not disks_by_node[i]:
                disks_by_node.pop(i)

    return endlist


if __name__ == "__main__":
#    from operator import attrgetter
#    print afr_info_tree_topage('test.txt')
    #data = getData(6901028037920)
    th = threading.Thread(target=execute, name='writemem', args=('get_asi -m %s %s -s %s %s -f %s' % (2147483620, 2147483621, 2147483610, 2147483611, "/etc/digioceanfs_manager/services/ssss/asi.conf",),None,True,False,))
    th.start()
    for th in threading.enumerate():
        if th.getName() == 'writemem':
            thd = th
    data = getData(2147483620, th)
    #d = lstree('/cluster2/ssss','/cluster2/ssss',data, ['/cluster2/ssss', '/cluster2/ssss/aa'], 0)
    opendir = ([(unquote_str(i)) for i in ['undefined', '/cluster2/ssss', '/cluster2/ssss/afrtest', '/cluster2/ssss/afrtest/%u65B0%u5EFA%u6587%u4EF6%u5939']])
    print opendir
    d = lstree('/cluster2/ssss','/cluster2/ssss',data, {'node-1-10004': 'node-1-sde', 'node-1-10002': 'node-1-sdc'}, opendir, 0)
    print getTreeStr(d)
    #print lstree(6901028037920,'/root/myget-0.1.2')
    #print lstree(6901028037920, '/usr/local/digioceanfs_gui')
#    getData('/root/luo/trunk/digioceanfs_gui/libcommon')
    '''
    my_root = myFile()
    tree_buffer = ''
    for i,l in enumerate(f_list):
        if l:
            my_root = createTree(my_root, l)
        if l.TYPE == 'file':
            file_total += 1
        else:
            dir_total += 1
    print getTreeStr(my_root)
    print 'Total files: %s   Total dirs: %s' % (file_total, dir_total)
    '''
