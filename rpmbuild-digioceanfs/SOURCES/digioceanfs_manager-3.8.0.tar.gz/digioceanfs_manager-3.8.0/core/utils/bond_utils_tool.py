#-*- coding: utf-8 -*-

import os
import sys
import subprocess
import re

import settings

#currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
#if currpath not in sys.path:
#    sys.path.append(currpath)

#homepath = currpath[:currpath.find('libcommon')]
#if not homepath in sys.path:
#    sys.path.append(homepath)
#import settings
#from libcommon import utils
import net_utils_tool

ETHFILE="/etc/network/interfaces"

#------------global--------------
#ethfile = settings.ethfile
#bond0path = settings.bond0path
#ethlist = None
#def loadglobal():
#    global ethlist
#    ethlist = utils.read_env_file(ethfile)
#loadglobal()

#def getEthNames():
#    ethnames = []
#    ethlist = net_utils_tool.read_env_file(ETHFILE)
#    for eth in ethlist:
#        name = eth['DEVICE']
#        if re.search('eth\d+$',name):
#            ethnames.append(name)
#    return ethnames
    
def getBondNames():
    bondnames = []
    ethlist = os.listdir(settings.NETWORKCONFDIR) 
    for eth in ethlist:
        if eth.find('ifcfg-bond') >= 0:
            bond = eth.split('-')[1]
            bondnames.append(bond)
    return bondnames

def getSlaveNames(bondname):
    slaves = []
    ethlist = os.listdir(settings.NETWORKCONFDIR)
    for eth in ethlist:
        if eth.find('ifcfg-') >= 0 and eth.find('bond') < 0 and eth.find('lo') < 0:
            ETHFILE = settings.NETWORKCONFDIR + eth
            ethinfo = net_utils_tool.read_eth_file(ETHFILE)
	    if 'MASTER' in ethinfo and ethinfo['MASTER'] == bondname:
                slaves.append(eth.split('-')[1])
    return slaves

#def getBondMode(bondname):
#    modelist = ['Balance Round-Robin','Active Backup','Balance - XOR','Broadcast','802.3ad','Balance-tlb','Balance-alb']
#    bondmode = None
#    if os.path.isfile(settings.bondmodefile % bondname):
#        retcode,proc = utils.cust_popen("cat %s | awk '{print $2}'" % (settings.bondmodefile % bondname))
#        result = proc.stdout.read().strip()
#        if retcode == 0:
#            bondmode = modelist[int(result)]
#    return bondmode

#def getUnslaveEthNames():
#    unslaves = []
#    ethnames = getEthNames()
#    for ethname in ethnames:
#        m = judgeSlave(ethname)
#        if not m:
#            unslaves.append(ethname)
#    return unslaves

def getEthAddr(ethname):
    ethaddr = ['','','','']
    ETHFILE = settings.NETWORKCONFDIR + 'ifcfg-' + ethname    
    if not os.path.exists(ETHFILE):
        return ethaddr
    ethinfo = net_utils_tool.read_eth_file(ETHFILE)
    if 'IPADDR' in ethinfo:
        ethaddr[0] = ethinfo['IPADDR']
    if 'NETMASK' in ethinfo:
        ethaddr[1] = ethinfo['NETMASK']
    if 'BROADCAST' in ethinfo:
        ethaddr[2] = ethinfo['BROADCAST']
    if 'GATEWAY' in ethinfo:
        ethaddr[3] = ethinfo['GATEWAY']
    return ethaddr

#def listBondMode():
#    tmplist = []
#    modelist = {'load balancing (round-robin)':0,'fault-tolerance (active-backup)':1,'load balancing (xor)':2,'fault-tolerance (broadcast)':3,'IEEE 802.3ad Dynamic link aggregation':4,'transmit load balancing':5,'adaptive load balancing':6}
#    if os.path.exists(bond0path):
#        f = open(bond0path,'r')
#        lines = f.readlines()
#        f.close()
#        for line in lines:
#            line = line.rstrip()
#            if re.search('Bonding Mode',line):
#                templist = line.split(':')
#                matstr = templist[1].lstrip()
#                return modelist[matstr]
#    return 6

#def judgeSlave(ethname):
#    #judge if the Ethernet is a slave
#    #if true return the master's name,else return None
#    #example:
#    #    ethname = 'eth0'
#    #    mastername = 'bond0'
#    f = open(ethfile,'r')
#    line = f.readline()
#    while line:
#        line = line[:-1]
#        m = re.match('auto\s+(bond\d+)',line)
#        if m:
#            mastername = m.group(1)
#            for i in range(6):
#                line = f.readline()
#            m = re.match('slaves\s+(\w)',line)
#            if m:
#                templist = line.split()
#                if ethname in templist:
#                    f.close()
#                    return mastername
#        line = f.readline()
#    f.close()
#    return None
    
def getNewBondName():
    i = 0
    bondnames = getBondNames()
    while True:
        name = 'bond%s' % i
        if bondnames.count(name) == 0:
            return name
        i += 1
    return None 
