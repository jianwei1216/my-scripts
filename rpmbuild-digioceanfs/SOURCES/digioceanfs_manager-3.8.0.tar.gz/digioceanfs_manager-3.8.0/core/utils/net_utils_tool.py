#!/usr/bin/python
#-*- coding: UTF-8 -*-

import re
import os
import sys
import string
import subprocess
import tempfile

import settings

#currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
#if currpath not in sys.path:
#    sys.path.append(currpath)

#homepath = currpath[:currpath.find('libcommon')]
#if not homepath in sys.path:
#    sys.path.append(homepath)

MIITOOL = settings.COMMANDS['mii-tool'] 

def read_file(*arg):
    #Fill an associative array with name=value pairs from a file
    lst = list(arg)
    length = len(lst)
    o = open(lst[0],"r")
    lines = o.readlines()
    o.close()
    for line in lines:
        line = line.rstrip()
        m = re.match("^([^=]+)=(.*)$",line)
        if not re.search("^#",line) and m:
            if length >= 4:
                str = m.group(1).lower()
            else:
                str = m.group(1)
            lst[1][str] = m.group(2)
            if length >= 3:
                lst[2].append(m.group(1))
    return lst

def check_ipaddress(ip):
    #check if ip address in right format
    m = re.match("^(\d+)\.(\d+)\.(\d+)\.(\d+)$",ip)
    if m:
        if 1 <= string.atoi(m.group(1)) <= 255 and 0 <= string.atoi(m.group(2)) <= 255 and 0 <= string.atoi(m.group(3)) <= 255 and 0 <= string.atoi(m.group(4)) <= 255:
            return ip
    return 0

def checkIP(ip):
    """
    check the ip address
    """
    p = re.compile(r"^(([1-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.)(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){2}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$")
    if ip == "255.255.255.255":
        return False
    elif p.match(ip):
        return True
    else:
        return False

def PING(ip):
    """
    check ipaddr is valid on net
    """
    p = subprocess.Popen('ping -w5 -c2 %s' % (ip), stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    result = p.stdout.read()
    ret = p.wait()
    p_str = '(\S+)% packet loss'
    percent = re.findall(p_str,result)
    if ret:
        return False
    if percent[0] != '100':
        return True
    return False


def read_file_lines(file):
    lines = []
    f = open(file,'r')
    line = f.readline()
    while line:
        lines.append(line.rstrip())
        line = f.readline()
    f.close()
    return lines

def flush_file_lines(file,lst):
    f = open(file,'w')
    for line in lst:
        f.write(line)
    f.write('\n')
    f.close()

def read_env_file(*arg):
    ahole = tempfile.TemporaryFile()
    modelist = ['Balance Round-Robin','Active Backup','Balance - XOR','Broadcast','802.3ad','Balance-tlb','Balance-alb']
    arglist = list(arg)
    ethlist = []
    conf = {}
    f = open(arglist[0],'r')
    line = f.readline()
    find = False
    while line:
        mstr = re.match('auto\s+(\S+)',line)
        mstr1 = re.match('^#auto\s+(\S+)',line)
        if mstr and mstr.group(1) != 'lo':
            conf['ONBOOT'] = 'yes'
            find = True
        if mstr1 and mstr1.group(1) != 'lo':
            conf['ONBOOT'] = 'no'
            find = True
        if find:
            line = f.readline()
            m = re.match('iface\s+(eth\S+)\s+inet\s+(\S+)\n',line)
            bond = re.match('iface\s+(bond\S+)\s+inet\s+(\S+)\n',line)
            if m:
                conf['DEVICE'] = m.group(1)
                proc = subprocess.Popen("%s %s | awk -F\link '/link/{print $2}'" % (MIITOOL,conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE, stderr=ahole)
                conf['LINK'] = proc.stdout.read().strip()
                proc.wait()
                if re.match("(\S+):(\d+)",conf['DEVICE']):
                    proc = subprocess.Popen("%s %s | awk -F\link '/link/{print $1}'| awk -F\: '{print $3}'" % (MIITOOL,conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE, stderr=ahole)
                else:
                    proc = subprocess.Popen("%s %s | awk -F\link '/link/{print $1}'| awk -F\: '{print $2}'" % (MIITOOL,conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE, stderr=ahole)
                conf['MODE'] = None
                result = proc.stdout.read().strip()[:-1]
                remode = re.match('[^\d]*(\d+\S+)(\s*\S*)',result)
                if remode:
                    conf['MODE'] = remode.group(1)
                proc.wait()
                proc = subprocess.Popen("ifconfig %s | awk '/%s/{print $5}'" % (conf['DEVICE'],conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE, stderr=ahole)
                conf['MAC'] = proc.stdout.read()
                proc.wait()
                conf['DHCP'] = m.group(2)
                if conf['DHCP'] == 'dhcp':
                    proc = subprocess.Popen('ifconfig %s | sed -n 1,2p' % conf['DEVICE'],shell=True,close_fds = True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                    result = ''.join(proc.stdout.readlines() + proc.stderr.readlines())
                    proc.wait()
                    mp = re.search('%s\s+Link encap:(\S+)\s+HWaddr\s+(\S+)\s+inet addr:(\S+)\s+Bcast:(\S+)\s+Mask:(\S+).*' % conf['DEVICE'],result)
                    if mp:
                        conf['IPADDR'] = mp.group(3)
                        conf['NETMASK'] = mp.group(5)
                        conf['BROADCAST'] = mp.group(4)
                        conf['GATEWAY'] = ''
                        conf['NETWORK'] = ''
                    line = f.readline()
                    while line:
                        mt = re.match('mtu\s+(\d+)',line)
                        if mt:
                            conf['MTU'] = mt.group(1)
                        else:
                            curraddr = f.tell() - len(line)
                            f.seek(curraddr)
                            break
                        line = f.readline()
                    ethlist.append(conf)
                    conf = {}
                    find = False
                    line = f.readline()
                    continue
                conf['IPADDR'] = ''
                conf['NETMASK'] = ''
                conf['BROADCAST'] = ''
                conf['GATEWAY'] = ''
                conf['NETWORK'] = ''
                netheadmatch = ['auto\s+(\S+)','^#auto\s+(\S+)']
                netdetailmatch = [('address\s+(\S+)','IPADDR'),('netmask\s+(\S+)','NETMASK'),('broadcast\s+(\S+)','BROADCAST'),('gateway\s+(\S+)','GATEWAY'),('network\s+(\S+)','NETWORK'),('mtu\s+(\d+)','MTU')]
                line = f.readline()
                while line:
                    dflag = False
                    for netdetail in netdetailmatch:
                        nd = re.match(netdetail[0],line)
                        if nd:
                            dflag = True
                            conf[netdetail[1]] = nd.group(1)
                    if not dflag:
                        curraddr = f.tell() - len(line)
                        f.seek(curraddr)
                        break
                    line = f.readline()
                """
                n = re.match('address\s+(\S+)',line)
                if n:
                    conf['IPADDR'] = n.group(1)
                line = f.readline()
                o = re.match('netmask\s+(\S+)',line)
                if o:
                    conf['NETMASK'] = o.group(1)
                line = f.readline()
                p = re.match('broadcast\s+(\S+)',line)
                if p:
                    conf['BROADCAST'] = p.group(1)
                if len(conf['DEVICE']) > 5:
                    ethlist.append(conf)
                    conf = {}
                    line = f.readline()
                    continue
                line = f.readline()
                q = re.match('gateway\s+(\S+)',line)
                if q:
                    conf['GATEWAY'] = q.group(1)
                """
                ethlist.append(conf)
                conf = {}
            if bond:
                bondsignal = 0
                for eth in ethlist:
                    if re.search('bond',eth['DEVICE']):
                        bondsignal = 1
                if bondsignal == 0:
                    ethlist = []
                conf['DEVICE'] = bond.group(1)
                conf['DHCP'] = bond.group(2)
                proc = subprocess.Popen("%s %s | awk -F\link '/link/{print $2}'" % (MIITOOL,conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE, stderr=ahole)
                conf['LINK'] = proc.stdout.read().strip()
                proc.stdout.close()
                proc.wait()
                #proc = subprocess.Popen("%s %s | awk -F\link '/link/{print $1}'| awk -F\: '{print $2}'" % (MIITOOL,conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE, stderr=ahole)
                conf['MODE'] = None
                #proc.stdout.close()
                #proc.wait()
                proc = subprocess.Popen("ifconfig %s | awk '/%s/{print $5}'" % (conf['DEVICE'],conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE, stderr=ahole)
                conf['MAC'] = proc.stdout.read()
                proc.stdout.close()
                proc.wait()
                if conf['DHCP'] == 'dhcp':
                    proc = subprocess.Popen('ifconfig %s | sed -n 1,2p' % conf['DEVICE'],shell=True,close_fds = True,stdout=subprocess.PIPE, stderr=ahole)
                    result = ''.join(proc.stdout.readlines())
                    proc.wait()
                    mp = re.search('%s\s+Link encap:(\S+)\s+HWaddr\s+(\S+)\s+inet addr:(\S+)\s+Bcast:(\S+)\s+Mask:(\S+).*' % conf['DEVICE'],result)
                    if mp:
                        conf['IPADDR'] = mp.group(3)
                        conf['NETMASK'] = mp.group(5)
                        conf['BROADCAST'] = mp.group(4)
                    line = f.readline()
                    while line:
                        mt = re.match('mtu\s+(\d+)',line)
                        if mt:
                            conf['MTU'] = mt.group(1)
                        else:
                            curraddr = f.tell() - len(line)
                            f.seek(curraddr)
                            break
                        line = f.readline()
                    ethlist.append(conf)
                    conf = {}
                    find = False
                    line = f.readline()
                    continue
                conf['IPADDR'] = ''
                conf['NETMASK'] = ''
                conf['BROADCAST'] = ''
                conf['GATEWAY'] = ''
                conf['NETWORK'] = ''
                netheadmatch = ['auto\s+(\S+)','^#auto\s+(\S+)']
                netdetailmatch = [('address\s+(\S+)','IPADDR'),('netmask\s+(\S+)','NETMASK'),('broadcast\s+(\S+)','BROADCAST'),('gateway\s+(\S+)','GATEWAY'),('network\s+(\S+)','NETWORK'),('mtu\s+(\d+)','MTU'),('slaves\s+(.*)','SLAVES'),('bond_mode\s+(\d+)','MODE')]
                line = f.readline()
                while line:
                    dflag = False
                    for netdetail in netdetailmatch:
                        nd = re.match(netdetail[0],line)
                        if nd:
                            dflag = True
                            if netdetail[1] == 'MODE':
                                conf[netdetail[1]] = modelist[int(nd.group(1))]
                            else:
                                conf[netdetail[1]] = nd.group(1)
                    if not dflag:
                        if re.match('iface\s+(\S+)\s+inet\s+(\S+)',line):
                            curraddr = f.tell() - len(line)
                            f.seek(curraddr)
                            break
                    line = f.readline()
                ethlist.append(conf)
                conf = {}
        find = False
        line = f.readline()
    f.close()
    ahole.close()
    return ethlist

def write_env_file(*arg):
    lst = list(arg)
    fstr = lst[0]
    conf = lst[1]
    if len(lst) > 2:
        f = open(fstr,'r+')
        line = f.readline()
        while line:
            if re.search('^up',line):
                addr = f.tell() - len(line)
                line = f.readline()
                temp = f.read()
                f.seek(addr)
                f.truncate()
                f.write(temp)
                f.seek(0)
            line = f.readline()
        for i in conf:
            f.write(i)
        f.close()
    else:
        ethlist = read_env_file(fstr)
        typestr = ''
        signal = 0
        bsignal = conf['ONBOOT']
        f = open(fstr,'r+')
        line = f.readline()
        matchstr1 = 'auto %s\n' % conf['DEVICE']
        matchstr2 = '#auto %s\n' % conf['DEVICE']
        for eth in ethlist:
            if conf['DEVICE'] == eth['DEVICE']:
                typestr = eth['DHCP']
                break
        if conf['DHCP'] == 'static':
            ifacestr = 'iface %s inet %s\n' % (conf['DEVICE'],conf['DHCP'])
            addrstr = 'address %s\n' % conf['IPADDR']
            netmaskstr = 'netmask %s\n' % conf['NETMASK']
            brostr = 'broadcast %s\n' % conf['BROADCAST']
            gatestr = 'gateway %s\n' % conf['GATEWAY']
            mtustr = None
            if 'MTU' in conf and conf['MTU']:
                mtustr = 'mtu %s\n' % conf['MTU']
            while line:
                if re.search(matchstr1,line):
                    signal = 1
                    addr = f.tell() - len(line)
                    if typestr == 'static':
                        for i in range(4):
                            line = f.readline()
                        if conf['GATEWAY'] != '':
                            line = f.readline()
                    else:
                        line = f.readline()
                    temp = f.read()
                    f.seek(addr)
                    f.truncate()
                    if bsignal == 'yes':
                        f.write(matchstr1)
                    else:
                        f.write(matchstr2)
                    f.write(ifacestr)
                    f.write(addrstr)
                    f.write(netmaskstr)
                    f.write(brostr)
                    if conf['GATEWAY'] != '':
                        f.write(gatestr)
                    if mtustr:
                        f.write(mtustr)
                    f.write(temp)
                    break
                line = f.readline()
            if signal == 0:
                f.write(matchstr1)
                f.write(ifacestr)
                f.write(addrstr)
                f.write(netmaskstr)
                f.write(brostr)
                if conf['GATEWAY'] != '':
                    f.write(gatestr)
                if mtustr:
                    f.write(mtustr)
        else:
            ifacestr = 'iface %s inet %s\n' % (conf['DEVICE'],conf['DHCP'])
            mtustr = None
            if 'MTU' in conf and conf['MTU']:
                mtustr = 'mtu %s\n' % conf['MTU']
            while line:
                if re.search(matchstr1,line):
                    signal = 1
                    addr = f.tell() - len(line)
                    if typestr == 'static':
                        for i in range(5):
                            line = f.readline()
                    else:
                        line = f.readline()
                    temp = f.read()
                    f.seek(addr)
                    f.truncate()
                    if bsignal == 'yes':
                        f.write(matchstr1)
                    else:
                        f.write(matchstr2)
                    f.write(ifacestr)
                    if mtustr:
                        f.write(mtustr)
                    f.write(temp)
                    break
                line = f.readline()
        f.close()

def write_eth_file(ETHFILE,conf):
    ethconf = {}
    f = open(ETHFILE,'r+')
    result = f.read()
    f.close()
    if 'DEVICE' in conf and conf['DEVICE']:
        if not re.search('DEVICE="%s"\n' % conf['DEVICE'],result):
            result += 'DEVICE="%s"\n' % conf['DEVICE']

    if 'IPV6INIT' in conf and conf['IPV6INIT']:
        if re.search('IPV6INIT=.*\n',result):
            result = re.sub('IPV6INIT=.*\n','IPV6INIT="%s"\n' % conf['IPV6INIT'],result)
        else:
            result += 'IPV6INIT="%s"\n' % conf['IPV6INIT']

    if 'MTU' in conf and conf['MTU']:
        if re.search('MTU=.*\n',result):
            result = re.sub('MTU=.*\n','MTU="%s"\n' % conf['MTU'],result)
        else:
            result += 'MTU="%s"\n' % conf['MTU']
    
    if not re.search('NM_CONTROLLED=',result):
        result += 'NM_CONTROLLED="yes"\n' 
    if not re.search('TYPE=',result):
        result += 'TYPE="Ethernet"\n' 

    if 'SLAVE' in conf:
        if conf['SLAVE']:
            if not re.search('SLAVE=',result):
                result += 'SLAVE="%s"\n' % conf['SLAVE']        
            if re.search('HWADDR=',result):
                result = re.sub('HWADDR','#HWADDR',result)
        else:
            if re.search('SLAVE=.*\n',result):
                result = re.sub('SLAVE=.*\n','',result)
            if re.search('#HWADDR=',result):
                result = re.sub('#HWADDR','HWADDR',result)
        
    if 'MASTER' in conf:
        if conf['MASTER']:
            if not re.search('MASTER=',result):
                result += 'MASTER="%s"\n' % conf['MASTER']        
        else:
            if re.search('MASTER=.*\n',result):
                result = re.sub('MASTER=.*\n','',result)

    if 'BOOTPROTO' in conf:
        if conf['BOOTPROTO'] == 'none':                    #set bond
            if re.search('BOOTPROTO=.*\n',result):
                result = re.sub('BOOTPROTO','#BOOTPROTO',result)
                result += 'BOOTPROTO="%s"\n' % conf['BOOTPROTO']
            else:
                result += 'BOOTPROTO="%s"\n' % conf['BOOTPROTO']
        else:
            if re.search('BOOTPROTO="none"\n',result):     #del bond,bootproto is 'static' or 'dhcp' or ''
                result = re.sub('BOOTPROTO="none"\n','',result)       
                if re.search('#BOOTPROTO=.*\n',result):
                    result = re.sub('#BOOTPROTO=.*\n','BOOTPROTO="%s"\n' % conf['BOOTPROTO'],result)
            else:                                          #set ip, bootproto is 'static'
                if re.search('BOOTPROTO=.*\n',result):
                    result = re.sub('BOOTPROTO=.*\n','BOOTPROTO="%s"\n' % conf['BOOTPROTO'],result)
                else:
                    result += 'BOOTPROTO="%s"\n' % conf['BOOTPROTO']
    if 'ONBOOT' in conf and conf['ONBOOT']:
        if re.search('ONBOOT=.*\n',result):
            result = re.sub('ONBOOT=.*\n','ONBOOT="%s"\n' % conf['ONBOOT'],result)
        else:
            result += 'ONBOOT="%s"\n' % conf['ONBOOT']
    if 'IPADDR' in conf and conf['IPADDR']:
        if re.search('IPADDR=.*\n',result):
            result = re.sub('IPADDR=.*\n','IPADDR="%s"\n' % conf['IPADDR'],result)
        else:
            result += 'IPADDR="%s"\n' % conf['IPADDR']
    if 'NETMASK' in conf and conf['NETMASK']:
        if re.search('NETMASK=.*\n',result):
            result = re.sub('NETMASK=.*\n','NETMASK="%s"\n' % conf['NETMASK'],result)
        else:
            result += 'NETMASK="%s"\n' % conf['NETMASK']
    if 'GATEWAY' in conf and conf['GATEWAY']:
        if re.search('GATEWAY=.*\n',result):
            result = re.sub('GATEWAY=.*\n','GATEWAY="%s"\n' % conf['GATEWAY'],result)
        else:
            result += 'GATEWAY="%s"\n' % conf['GATEWAY']
    if 'BROADCAST' in conf and conf['BROADCAST']:
        if re.search('BROADCAST=.*\n',result):
            result = re.sub('BROADCAST=.*\n','BROADCAST="%s"\n' % conf['BROADCAST'],result)
        else:
            result += 'BROADCAST="%s"\n' % conf['BROADCAST']

    f = open(ETHFILE,'w+')
    f.write(result)
    f.close()

def read_eth_file(ETHFILE):
    ethinfo = {}
    f = open(ETHFILE,'r')
    lines = f.readlines() 
    for line in lines:
        if line.find('=') >= 0:
            key = line.split('=')[0]
            value = line.split('=')[1]
            ethinfo[key] = value.strip().replace('"','')
    return ethinfo
