#!/usr/bin/python
import os
import sys
import time


def disk_sync(sync_disk, export_dir_prefix, mount_dir):
    time.sleep(20)
    file_list = lsdir(sync_disk, export_dir_prefix)
    for i in file_list:
        cluster_f = i.split(os.path.join(export_dir_prefix, sync_disk))[1]
        os.system("ls -la %s >/dev/null 2>&1" % (mount_dir + cluster_f))


def lsdir(sync_disk, export_dir_prefix):
    for root, dirs, files in os.walk(os.path.join(export_dir_prefix, sync_disk)):
        if files:
            for f in files:
                yield os.path.join(root, f)

if __name__ == "__main__":
    sync_disk = sys.argv[1]
    export_dir_prefix = sys.argv[2]
    mount_dir = sys.argv[3]
    disk_sync(sync_disk, export_dir_prefix, mount_dir)
