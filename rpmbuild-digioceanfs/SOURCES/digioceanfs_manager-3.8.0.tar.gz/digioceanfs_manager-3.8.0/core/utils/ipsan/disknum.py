#-*- coding: utf-8 -*-
#!/usr/bin/python
import os
import sys
import re
import platform
import subprocess
import traceback
#-----------------------
# global
#-----------------------
SASDEVICE = '/sys/class/sas_device/'
SYSBLOCK = '/sys/block/'
PARTITIONS = '/proc/partitions'
DISKDEVPATH = "/sys/block/%s/device"
#ODSP2.0,3.0
BASEPATH = '/etc/storage/'
SASJOBD = os.path.join(BASEPATH,'sasjobd')
SATAJOBD = os.path.join(BASEPATH,'satajobd')
SATASN = os.path.join(BASEPATH,'sata_sn.py')
SASSN = os.path.join(BASEPATH,'sas_sn.py')
NEWDEVICEFILE = os.path.join(BASEPATH,'newdevice')
if not os.path.exists(BASEPATH):
    os.makedirs(BASEPATH)
#-----------------------
#   system command
#-----------------------
DD = 'dd'
RM = 'rm'
LS = 'ls'
CAT = 'cat'
GREP = 'grep'
TOUCH = 'touch'
PVSCAN = 'pvscan'
DMIDECODE = 'dmidecode'
KILLDDCMD = "kill -9 `ps ax | grep dd | grep -v grep | grep -v winbindd | awk '{print $1;}'`"
#-----------------------
#
#-----------------------
def cust_popen(cmd, no_wait=False, close_fds=True):
    try:
        proc = None
        retcode = None
        if close_fds and platform.system().lower() == 'linux':
            if type(cmd) == list:
                proc = subprocess.Popen(cmd,shell=False,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True)
            else:
                proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True)
        else:
            proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if not no_wait:
            retcode = proc.wait()
        return retcode,proc
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
#-----------------------
#
#-----------------------
def exit_install():
    retcode,proc = cust_popen(KILLDDCMD)
    sys.exit(0)
#-----------------------
#
#-----------------------
def just_sysdisk():
    sysdisk = ''
    retcode,proc = cust_popen([PVSCAN,'-s'])
    result = proc.stdout.readlines()
    for line in result:
        m = re.match('\s+/dev/([s,h]d[a-z])\d+',line)
        if m:
            sysdisk = m.group(1)
            break
    return sysdisk
#-----------------------
#
#-----------------------
def get_pci_path():
    pci_path = 'phy_identifier'
    retcode,proc = cust_popen("%s -t2 | sed -n '/Product Name/,1p' | awk -F\: '{print $2}'" % DMIDECODE)
    result = proc.stdout.read().strip()
    if result in ["X8SIE","X8DTL","X9DR7/E-LN4F"]:
        pci_path = "sas_address"
    return pci_path
#-----------------------
#
#-----------------------
def get_all_disks():
    disks = []
    disksizeinfo = {}
    sysdisk = just_sysdisk()
    f = open(PARTITIONS,'r')
    result = f.readlines()
    f.close()
    for line in result:
        m = re.match("\s+\d+\s+\d+\s+\d+\s+(sd\w)\n", line)
        n = re.match("\s+\d+\s+\d+\s+\d+\s+(sd[a-z][a-z])\n",line)
        diskname = None
        if m:
            diskname = m.group(1)
        if n:
            diskname = n.group(1)
        if diskname:
            disks.append(diskname)
            disksize = '0G'
            try:
                disksizefile = os.path.join(SYSBLOCK,diskname,'size')
                if os.path.isfile(disksizefile):
                    retcode,proc = cust_popen([CAT,disksizefile])
                    disksize = proc.stdout.read().strip()
                    disksize = '%sG' % str(int(int(disksize) * 0.512 / 1000 / 10000) * 10)
            except:
                pass
            disksizeinfo[diskname] = disksize
    if sysdisk in disks:
        disks.remove(sysdisk)
        del disksizeinfo[sysdisk]
    return disks,disksizeinfo
#-----------------------
#
#-----------------------
def check_sata_or_sas():
    disktype = 'sas'
    if not os.path.exists(SASDEVICE) or len(os.listdir(SASDEVICE)) == 0:
        disktype = 'sata'
    else:
        disktype = 'sas'
    return disktype
#-----------------------
#
#-----------------------
def create_newdevice():
    if not os.path.isfile(NEWDEVICEFILE):
        retcode,proc = cust_popen("%s %s" % (TOUCH,NEWDEVICEFILE))
#-----------------------
#
#-----------------------
def remove_newdevice():
    if os.path.isfile(NEWDEVICEFILE):
        retcode,proc = cust_popen("%s %s" % (RM,NEWDEVICEFILE))
#-----------------------
#
#-----------------------
def remove_jobd(jobd=SASJOBD):
    if os.path.isfile(jobd):
        retcode,proc = cust_popen("%s %s" % (RM,jobd))
#-----------------------
#
#-----------------------
def disk_operation():
    print "-----------Operation-----------"
    print "1.Remove disk from the list(System disk in it).\n"
    print "2.Add disk(We lost some disk).\n"
    print "3.Confirm(Perfect work).\n"
    print "4.Back."
    print "-------------------------------"
#-----------------------
#
#-----------------------
def usage():
    print "-----------Operation-----------"
    print "1.Verify disk map(old expander).\n"
    print "2.Create flag(new expander flag).\n"
    print "3.Remove flag(new expander flag).\n"
    print "4.Quit."
    print "-------------------------------"
#-----------------------
#
#-----------------------
def print_disksizeinfo(disksizeinfo):
    count = len(disksizeinfo.keys())
    i = 0
    printlist = []
    for disk,disksize in disksizeinfo.iteritems():
        if i > 0 and i % 3 == 0:
            print '%s\n' % ((' ' * 3).join(printlist))
            printlist = []
        printlist.append('%s ===> %s' % (disk,disksize))
        i += 1
    if printlist:
        print '%s\n' % ((' ' * 3).join(printlist))
#-----------------------
#
#-----------------------    
def main():
    while True:
        usage()
        select = raw_input("Enter you choise: ").strip()
        if select == "1":
            remove_newdevice()
            diskmap = {}
            disknum = 16
            filename = SASSN
            jobdfile = SASJOBD
            disktype = check_sata_or_sas()
            if disktype == 'sata':
                print '#This is sata disks\n'
                remove_jobd(SASJOBD)
                filename = SATASN
                jobdfile = SATAJOBD
                disknum = 8
                while True:
                    count = raw_input('Please input the number of the sata jobd(8,16,etc): ')
                    m = re.match('(-?\d+)',count)
                    if m:
                        count = int(m.group(1))
                        disknum = count
                        break
                f = open(jobdfile,'w')
                f.write(str(count))
                f.close()
                while True:
                    disks,disksizeinfo = get_all_disks()
                    returnflag = False
                    while True:
                        disk_operation()
                        print_disksizeinfo(disksizeinfo)
                        operation = raw_input("Enter you choise: ").strip()
                        if operation == "1":
                            disk = raw_input("Which disk you want to remove(enter q do nothine): ").strip()
                            if disk == 'q':
                                continue
                            if disk in disks:
                                disks.remove(disk)
                                del disksizeinfo[disk]
                            else:
                                print 'Disk not exists'
                                continue
                        elif operation == "2":
                            disk = raw_input("Which disk you want to add(enter q do nothine): ").strip()
                            if disk == 'q':
                                continue
                            if disk in disks:
                                print "Disk already exists"
                            else:
                                retcode,proc = cust_popen("%s %s | %s %s" % (CAT,PARTITIONS,GREP,disk))
                                result = proc.stdout.read().strip()
                                if result:
                                    disks.append(disk)
                                    disksize = '0G'
                                    try:
                                        disksizefile = os.path.join(SYSBLOCK,diskname,'size')
                                        if os.path.isfile(disksizefile):
                                            retcode,proc = cust_popen([CAT,disksizefile])
                                            disksize = proc.stdout.read().strip()
                                            disksize = '%sG' % str(int(int(disksize) * 0.512 / 1000 / 10000) * 10)
                                    except:
                                        pass
                                    disksizeinfo[disks] = disksize
                                else:
                                    print "Disk not exists"
                                continue
                        elif operation == "3":
                            break
                        elif operation == "4":
                            returnflag = True
                            break
                    if returnflag:
                        break
                    for disk in disks:
                        while True:
                            retcode,proc = cust_popen("%s if=/dev/%s of=/dev/null & >/dev/null" % (DD,disk))
                            retcode,proc = cust_popen("%s -l %s" % (LS,DISKDEVPATH % disk))
                            result = proc.stdout.readline()
                            m = re.match(".*\/(\d+\:\d+\:\d+\:\d+)\n",result)
                            if m:
                                scsiid = m.group(1)
                            else:
                                print '#Error,please check the disk'
                                exit_install()
                                
                            number = raw_input('#Please input the disk number:')
                            m = re.match("(\d+)",number)
                            if m and int(m.group(1)) <= disknum:
                                diskmap[number] = scsiid
                                retcode,proc = cust_popen(KILLDDCMD)
                                break
                            elif number.lower() == 'q':
                                exit_install()
                            else:
                                retcode,proc = cust_popen(KILLDDCMD)
                    if len(diskmap.keys()) == disknum:
                        break
                    else:
                        print '#disk already in: ',diskmap.keys()
                        count = raw_input('#Press any key to continue:')
            else:
                print 'This is sas disks\n'
                remove_jobd(SATAJOBD)
                while True:
                    count = raw_input('Please input the number of the jobd: ')
                    m = re.match('(-?\d+)',count)
                    if m:
                        count = int(m.group(1))
                        break
                f = open(jobdfile,'w')
                f.write(str(count))
                f.close()
                if count == 48:
                    disknum = 48
                elif count == 24:
                    disknum = 24
                elif count == 8:
                    disknum = 8
                elif 1 < count < 5:
                    disknum = 16 * count
                elif count == 0:
                    disknum = 16
                elif count < 0:
                    disknum = -count
                pci_path = get_pci_path()
                while True:
                    disks,disksizeinfo = get_all_disks()
                    returnflag = False
                    while True:
                        disk_operation()
                        print_disksizeinfo(disksizeinfo)
                        operation = raw_input("Enter you choise: ").strip()
                        if operation == "1":
                            disk = raw_input("Which disk you want to remove(enter q do nothine): ").strip()
                            if disk == 'q':
                                continue
                            if disk in disks:
                                disks.remove(disk)
                                del disksizeinfo[disk]
                            else:
                                print 'Disk not exists'
                                continue
                        elif operation == "2":
                            disk = raw_input("Which disk you want to add(enter q do nothine): ").strip()
                            if disk == 'q':
                                continue
                            if disk in disks:
                                print "Disk already exists"
                            else:
                                retcode,proc = cust_popen("%s %s | %s %s" % (CAT,PARTITIONS,GREP,disk))
                                result = proc.stdout.read().strip()
                                if result:
                                    disks.append(disk)
                                    disksize = '0G'
                                    try:
                                        disksizefile = os.path.join(SYSBLOCK,diskname,'size')
                                        if os.path.isfile(disksizefile):
                                            retcode,proc = cust_popen([CAT,disksizefile])
                                            disksize = proc.stdout.read().strip()
                                            disksize = '%sG' % str(int(int(disksize) * 0.512 / 1000 / 10000) * 10)
                                    except:
                                        pass
                                    disksizeinfo[disks] = disksize
                                else:
                                    print "Disk not exists"
                                continue
                        elif operation == "3":
                            break
                        elif operation == "4":
                            returnflag = True
                            break
                    if returnflag:
                        break
                    retcode,proc = cust_popen('%s -l /sys/class/sas_device/end_device-*:*/device/target*:*:*/' % LS)
                    sasdirlist = proc.stdout.readlines()
                    sasdirlen = len(sasdirlist)
                    for disk in disks:
                        pciaddr = ''
                        while True:
                            #sasid
                            retcode,proc = cust_popen("%s if=/dev/%s of=/dev/null & >/dev/null" % (DD,disk))
                            retcode,proc = cust_popen("%s -l %s" % (LS,DISKDEVPATH % disk))
                            result = proc.stdout.readline()
                            m = re.match(".*\/(\d+\:\d+\:\d+\:\d+)\n",result)
                            if m:
                                scsiid =  m.group(1)
                            else:
                                print '#Error, please check the disk'
                                exit_install()
                            #sasdir
                            for i in range(sasdirlen):
                                m = re.match(".*(\d+\:\d+\:\d+\:\d+)\n", sasdirlist[i])
                                if m != None and m.group(1) == scsiid:
                                    sasdir = sasdirlist[i-2]
                            try:
                                #sasport
                                temp = re.split("\/device\/", sasdir)
                                sasfile = temp[0] + "/%s" % pci_path
                                portfile = open(sasfile, 'r')
                                sasport = portfile.readline()
                                sasport = sasport.strip()
                                portfile.close()

                                if pci_path != 'sas_address':
                                    m = re.match(".*(end_device-\S+)\:\d+",temp[0])
                                    pciaddr = m.group(1)
                            except:
                                retcode,proc = cust_popen(KILLDDCMD)
                                break
                            number = raw_input('Please input the disk number:')
                            if count in [2,3,4,48]:
                                m = re.match("(\d+)-(\d+)",number)
                                if m:
                                    if count == 48:
                                        if int(m.group(1)) < 2 and int(m.group(2)) < 25:
                                            if pci_path != 'sas_address':
                                                diskmap[number] = ":".join([pciaddr,sasport])
                                            else:
                                                diskmap[number] = sasport
                                            retcode,proc = cust_popen(KILLDDCMD)
                                            break
                                        else:
                                            retcode,proc = cust_popen(KILLDDCMD)
                                            continue
                                    else:
                                        if int(m.group(1)) < 4 and int(m.group(2)) < 17:
                                            if pci_path != 'sas_address':
                                                diskmap[number] = ":".join([pciaddr,sasport])
                                            else:
                                                diskmap[number] = sasport
                                            retcode,proc = cust_popen(KILLDDCMD)
                                            break
                                        else:
                                            retcode,proc = cust_popen(KILLDDCMD)
                                            continue
                                elif number.lower() == 'q':
                                    exit_install()
                                else:
                                    retcode,proc = cust_popen(KILLDDCMD)
                                    continue
                            else:
                                m = re.match("(\d+)",number)
                                if m and int(m.group(1)) <= disknum:
                                    if pci_path != 'sas_address':
                                        diskmap[number] = ":".join([pciaddr,sasport])
                                    else:
                                        diskmap[number] = sasport
                                    retcode,proc = cust_popen(KILLDDCMD)
                                    break
                                elif number.lower() == 'q':
                                    exit_install()
                                else:
                                    retcode,proc = cust_popen(KILLDDCMD)
                                    continue
                    if len(diskmap.keys()) == disknum:
                        break
                    else:
                        print 'disk already in: ',diskmap.keys()
                        count = raw_input('Press any key to continue:')
            #do somethine
            result = os.path.exists(jobdfile)
            # 24 + 24
            if result:
                if count == 48:
                    pass
                #24 disk
                elif count == 24:
                    pass
                #disk 8
                elif count == 8:
                    pass
                #expander
                elif 1 < count < 5:
                    pass
                #16 disk
                elif count == 0:
                    pass
                #other
                else:
                    pass
            else:
                pass
            #write to file
            reversediskmap = {}
            for key,value in diskmap.iteritems():
                reversediskmap[value] = key    
            if filename:
                f = open(filename,'w')
                print >> f,'PORTNUM =',diskmap
                print >> f,'DISKNUM =',reversediskmap
                f.close()
            print "Finished"
        elif select == "2":
            print "Create flag"
            create_newdevice()
        elif select == "3":
            print "Remove flag"
            remove_newdevice()
        elif select == "4":
            print "Quit"
            exit_install()
        else:
            continue
   
if __name__ == '__main__':
    main()
