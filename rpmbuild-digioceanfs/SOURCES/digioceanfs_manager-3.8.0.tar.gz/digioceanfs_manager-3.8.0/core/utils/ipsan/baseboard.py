#-*- coding: utf-8 -*-
#baseborad.py

import os
import sys
import re
import stat
import copy
import pickle
import platform
import traceback
import simplejson
import subprocess
#---------------------------------
#global
#---------------------------------
SASDEVICE = '/sys/class/sas_device/'
SASEXPANDER = '/sys/class/sas_expander/'
SYSDISKCACHE = '/tmp/digitools/sysdisk'
SYSBLOCK = '/sys/block/'
DISKDEVICE = '/sys/block/%s/device'
EXPANDERMATCH = 'expander-\d+:(\d+)'
SASADDRESS = 'sas_address'
PRODUCTID = 'product_id'
EXPANDERPHYMATCH = '\s*phy\s+(\d+):\S+:\S+:\[(\S+):\S+\s+([^\(\]]*).*\].*\s*'
SASDRIVER = ''
if os.path.exists('/dev/mpt2ctl'):
    SASDRIVER = '/dev/mpt2ctl'
elif os.path.exists('/dev/mptctl'):
    SASDRIVER = '/dev/mptctl'
RELEASE = '/RELEASE'
VERSION = 4
DISKLIBPATH = '/etc/storage/'
DISKMAPPATH = os.path.join(DISKLIBPATH,'diskmap')
NEWDEVICEFILE = os.path.join(DISKLIBPATH,'newdevice')
SASJOBD = os.path.join(DISKLIBPATH,'sasjobd')
SATAJOBD = os.path.join(DISKLIBPATH,'satajobd')
if not DISKLIBPATH in sys.path:
    sys.path.append(DISKLIBPATH)
EXPANDERDISKMAPFILEMATCH = '(\d+)-(\d+)-(\S+)'
SMPDEVICEID = '28' #set smp device id
#old expander
sas_sn = None
sata_sn = None
#phyid,position
DISKIDMAP16 = {
    '12': '1',
    '11': '2',
    '10': '3',
    '9' : '4',
    '13': '5',
    '8' : '6',
    '7' : '7',
    '6' : '8',
    '14': '9',
    '1' : '10',
    '5' : '11',
    '4' : '12',
    '15': '13',
    '0' : '14',
    '2' : '15',
    '3' : '16'
}
DISKIDMAP24 = {
    '18': '1',
    '17': '2',
    '16': '3',
    '15': '4',
    '19': '5',
    '13': '6',
    '12': '7',
    '14': '8',
    '20': '9', 
    '11': '10',
    '10': '11',
    '9' : '12',
    '21': '13',
    '8' : '14',
    '7' : '15',
    '6' : '16',
    '22': '17',
    '1' : '18',
    '5' : '19',
    '4' : '20',
    '23': '21',
    '0' : '22',
    '2' : '23',
    '3': '24'
}
#---------------------------------
# system command 
#---------------------------------
RM = 'rm'
CP = 'cp'
CAT = 'cat'
GREP = 'grep'
MKDIR = 'mkdir'
CHOWN = 'chown'
CHMOD = 'chmod'
PVSCAN = 'pvscan'
DMIDECODE = 'dmidecode'
SMPDISCOVER = 'smp_discover'
#----------------------------------------
# user defined execute command
#----------------------------------------
def cust_popen(cmd, no_wait=False, close_fds=True):
    try:
        proc = None
        retcode = None
        if close_fds and platform.system().lower() == 'linux':
            if type(cmd) == list:
                proc = subprocess.Popen(cmd,shell=False,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True)
            else:
                proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True)
        else:
            proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if not no_wait:
            retcode = proc.wait()
        return retcode,proc
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
#----------------------------------------
# user defined open file function
#----------------------------------------
def change_fstat(filepath):
    fstat = 755
    if os.path.exists(filepath):
        fstat = int(oct(stat.S_IMODE(os.stat(filepath).st_mode)))
        retcode,proc = cust_popen('chmod 777 %s' % filepath)
    return fstat

def recover_fstat(filepath,fstat):
    if os.path.exists(filepath):
        retcode,proc = cust_popen('chmod %d %s' % (int(fstat),filepath))
        
def cust_fopen(filepath,mode='r'):
    if os.path.exists(filepath):
        fstat = change_fstat(filepath)
        f = open(filepath,mode)
        return f,fstat
    else:
        if mode.startswith('a') or mode.startswith('w') or mode.startswith('r+'):
            parentdir = os.path.split(filepath)[0]
            if not os.path.exists(parentdir):
                retcode,proc = cust_popen(['mkdir','-p',parentdir])
            retcode,proc = cust_popen('touch %s' % filepath)
            fstat = change_fstat(filepath)
            f = open(filepath,mode)
            return f,fstat
        else:
            raise IOError,'%s not exists' % filepath

def cust_fclose(f,fstat):
    recover_fstat(f.name,fstat)
    f.close()
#-----------------------------------------
# check version
# default 4.0
#-----------------------------------------
def check_version():
    global VERSION
    global DISKLIBPATH
    global DISKMAPPATH
    global NEWDEVICEFILE
    global SASJOBD
    global SATAJOBD
    global DISKLIBPATH
    
    if os.path.isfile(RELEASE):
        retcode,proc = cust_popen("%s %s" % (CAT,RELEASE))
        result = proc.stdout.read().strip()
        if result.startswith('V3.0'):
            VERSION = 3
        elif result.startswith('V3.1'):
            VERSION = 3.1
        elif result.startswith('V4.0'):
            VERSION = 4
    if VERSION == 4:
        DISKLIBPATH = '/etc/storage/'
        DISKMAPPATH = os.path.join(DISKLIBPATH,'diskmap')
        NEWDEVICEFILE = os.path.join(DISKLIBPATH,'newdevice')
        SASJOBD = os.path.join(DISKLIBPATH,'sasjobd')
        SATAJOBD = os.path.join(DISKLIBPATH,'satajobd')
        SATAJOBD = os.path.join(DISKLIBPATH,'satajobd')
        DISKLIBPATH = '/etc/storage/'
        if not DISKLIBPATH in sys.path:
            sys.path.append(DISKLIBPATH)
        if not DISKLIBPATH in sys.path:
            sys.path.append(DISKLIBPATH)
    elif VERSION == 3.1:
        DISKLIBPATH = '/usr/local/digitools/'
        DISKMAPPATH = os.path.join(DISKLIBPATH,'conf','diskmap')
        NEWDEVICEFILE = os.path.join(DISKLIBPATH,'libcommon','raidlib','newdevice')
        SASJOBD = os.path.join(DISKLIBPATH,'libcommon','raidlib','jobd')
        SATAJOBD = os.path.join(DISKLIBPATH,'libcommon','raidlib','sata_jobd')
        DISKLIBPATH = os.path.join(DISKLIBPATH,'libcommon','raidlib')
        if not DISKLIBPATH in sys.path:
            sys.path.append(DISKLIBPATH)
        if not DISKLIBPATH in sys.path:
            sys.path.append(DISKLIBPATH)
    elif VERSION == 3:
        DISKLIBPATH = '/usr/local/digitools/'
        DISKMAPPATH = os.path.join(DISKLIBPATH,'conf','diskmap')
        NEWDEVICEFILE = os.path.join(DISKLIBPATH,'libcommon','raidlib','newdevice')
        SASJOBD = os.path.join(DISKLIBPATH,'libcommon','raidlib','jobd')
        SATAJOBD = None
        DISKLIBPATH = os.path.join(DISKLIBPATH,'libcommon','raidlib')
        if not DISKLIBPATH in sys.path:
            sys.path.append(DISKLIBPATH)
        if not DISKLIBPATH in sys.path:
            sys.path.append(DISKLIBPATH)
#-----------------------------------------
# check if new expander
#-----------------------------------------
def check_new_or_old():
    if os.path.isfile(NEWDEVICEFILE):
        return True
    else:
        return False
#-----------------------------------------
# reverse map (one key,one value)
#-----------------------------------------
def reverse_map(reversedict):
    returndict = {}
    for key,value in reversedict.iteritems():
        returndict[value] = key
    return returndict
#-----------------------------------------
# get all expander
#-----------------------------------------
def get_all_expanders():
    expanders = {}
    pathlist = os.listdir(SASEXPANDER)
    for path in pathlist:
        if re.match(EXPANDERMATCH,path):
            expandersasaddress = ''
            expandersasaddresspath = os.path.join(SASDEVICE,path,SASADDRESS)
            if os.path.exists(expandersasaddresspath):
                f,fstat = cust_fopen(expandersasaddresspath,'r')
                expandersasaddress = f.read().strip()
                cust_fclose(f,fstat)
            if expandersasaddress:
                expanders[path] = expandersasaddress
    return expanders
#------------------------------------------
# get expander smp device id
#------------------------------------------
def get_smp_device_id(expandername,expandersasaddress):
    smpdeviceid = ''
    cmdstr = '%s -s %s %s' % (SMPDISCOVER,expandersasaddress,SASDRIVER)
    retcode,proc = cust_popen(cmdstr)
    result = proc.stdout.readlines()
    for line in result:
        m = re.match(EXPANDERPHYMATCH,line)
        if m:
            phyid = m.group(1)
            disksasaddress = '0x%s' % m.group(2)
            flag = m.group(3)
            if flag.find('V') >= 0:
                smpdeviceid = phyid
                break
    return smpdeviceid
#------------------------------------------
# get expander smp device
#------------------------------------------
def get_smp_device(expandername,expandersasaddress):
    smpdevice = None
    smpdeviceid = SMPDEVICEID
    if smpdeviceid:
        try:
            expanderphdevicepath = os.path.join(SASDEVICE,expandername,'device')
            devicelist = os.listdir(expanderphdevicepath)
            vphydevice = None
            vphyenddevice = None
            vphyendtardevice = None
            vphyendtarscsidevice = None
            for device in devicelist:
                if device.find(smpdeviceid) >= 0:
                    vphydevice = device
                    break
            if vphydevice:
                vphydevicepath = os.path.join(expanderphdevicepath,vphydevice,'port')
                if os.path.exists(vphydevicepath):
                    devicelist = os.listdir(vphydevicepath)
                    for device in devicelist:
                        if device.find('end_device') >= 0:
                            vphyenddevice = device
                            break
                    if vphyenddevice:
                        vphyendtardevicepath = os.path.join(vphydevicepath,vphyenddevice)
                        if os.path.exists(vphyendtardevicepath):
                            devicelist = os.listdir(vphyendtardevicepath)
                            for device in devicelist:
                                if device.find('target') >= 0:
                                    vphyendtardevice = device
                                    break
                            if vphyendtardevice:
                                vphyendtarscsidevicepath = os.path.join(vphyendtardevicepath,vphyendtardevice)
                                if os.path.exists(vphyendtarscsidevicepath):
                                    devicelist = os.listdir(vphyendtarscsidevicepath)
                                    for device in devicelist:
                                        if re.match('\d+:\d+:\d+:\d+',device):
                                            vphyendtarscsidevice = device
                                            break
                                    if vphyendtarscsidevice:
                                        smpdevicepath = os.path.join(vphyendtarscsidevicepath,vphyendtarscsidevice,'scsi_generic')
                                        if os.path.exists(smpdevicepath):
                                            devicelist = os.listdir(smpdevicepath)
                                            for device in devicelist:
                                                if device.find('sg') >= 0:
                                                    smpdevice = device
                                                    break
        except Exception,e:
            print >> sys.stderr,traceback.print_exc()
    return smpdevice
#-----------------------------------------
# get expander disk
#-----------------------------------------
def get_expander_disk(expandername):
    expanderdisks = {}
    expanderphdevicepath = os.path.join(SASDEVICE,expandername,'device')
    if os.path.exists(expanderphdevicepath):
        devicelist = os.listdir(expanderphdevicepath)
        i = 0
        for device in devicelist:
            try:
                vphydevice = None
                vphydeviceid = None
                vphyenddevice = None
                vphyendtardevice = None
                diskdevice = None
                if device.find('phy-') >= 0:
                    vphydevice = device
                    if vphydevice:
                        vphydevicephydevicepath = os.path.join(expanderphdevicepath,vphydevice,'sas_phy')
                        vphydevicephydevice = None
                        if os.path.exists(vphydevicephydevicepath):
                            devicelist = os.listdir(vphydevicephydevicepath)
                            for device in devicelist:
                                if device.find('phy-') >= 0:
                                    vphydevicephydevice = device
                                    break
                            if vphydevicephydevice:
                                vphydevicephydevicephyidnetpath = os.path.join(vphydevicephydevicepath,vphydevicephydevice,'phy_identifier')
                                if os.path.exists(vphydevicephydevicephyidnetpath):
                                    f,fstat = cust_fopen(vphydevicephydevicephyidnetpath,'r')
                                    vphydeviceid = f.read().strip()
                                    cust_fclose(f,fstat)
                        #disk name
                        vphydevicepath = os.path.join(expanderphdevicepath,vphydevice,'port')
                        if os.path.exists(vphydevicepath):
                            devicelist = os.listdir(vphydevicepath)
                            for device in devicelist:
                                if device.find('end_device') >= 0:
                                    vphyenddevice = device
                                    break
                            if vphyenddevice:
                                vphyendtardevicepath = os.path.join(vphydevicepath,vphyenddevice)
                                if os.path.exists(vphyendtardevicepath):
                                    devicelist = os.listdir(vphyendtardevicepath)
                                    for device in devicelist:
                                        if device.find('target') >= 0:
                                            vphyendtardevice = device
                                            break
                                    if vphyendtardevice:
                                        vphyendtarscsidevicepath = os.path.join(vphyendtardevicepath,vphyendtardevice)
                                        if os.path.exists(vphyendtarscsidevicepath):
                                            devicelist = os.listdir(vphyendtarscsidevicepath)
                                            for device in devicelist:
                                                if re.match('\d+:\d+:\d+:\d+',device):
                                                    vphyendtarscsidevice = device
                                                    break
                                            if vphyendtarscsidevice:
                                                diskdevicepath = os.path.join(vphyendtarscsidevicepath,vphyendtarscsidevice,'block')
                                                if os.path.exists(diskdevicepath):
                                                    devicelist = os.listdir(diskdevicepath)
                                                    if devicelist:
                                                        diskdevice = devicelist[0]
                i += 1
                if vphydeviceid and diskdevice:
                    expanderdisks[vphydeviceid] = diskdevice
            except:
                print >> sys.stderr,traceback.print_exc()
    return expanderdisks
#-----------------------------------------
# get all expander disk
#-----------------------------------------
def get_all_expander_disk():
    allexpanderdisks = {}
    expanders = get_all_expanders()
    for expandername,expandersasaddress in expanders.iteritems():
        allexpanderdisks[expandersasaddress] = get_expander_disk(expandername)
    return allexpanderdisks
#-----------------------------------------
# get cabinet count
#-----------------------------------------
def get_cabinet_info():
    expanderidmap = {}
    expanderdisks = {}
    if os.path.exists(DISKMAPPATH) and os.listdir(DISKMAPPATH):
        expanderdisks = get_all_expander_disk()
        filelist = os.listdir(DISKMAPPATH)
        for mapfile in filelist:
            m = re.match(EXPANDERDISKMAPFILEMATCH,mapfile)
            if m:
                expanderid = m.group(1)
                diskcounttype = int(m.group(2))
                expandersasaddress = m.group(3)
                if expandersasaddress in expanderdisks:
                    expanderidmap[int(expanderid)] = {
                        'sasaddress':expandersasaddress,
                        'diskcounttype':diskcounttype
                    }
    else:
        autocabinetnum()
        if os.path.exists(DISKMAPPATH) and os.listdir(DISKMAPPATH):
            return get_cabinet_info()
    return len(expanderidmap.keys()),expanderidmap,expanderdisks
#----------------------------------------
# get expander phy id
#----------------------------------------
def get_expander_phyids(expandername):
    expanderphyids = []
    expanderphdevicepath = os.path.join(SASDEVICE,expandername,'device')
    if os.path.exists(expanderphdevicepath):
        devicelist = os.listdir(expanderphdevicepath)
        i = 0
        for device in devicelist:
            try:
                vphydevice = None
                vphydeviceid = None
                vphyenddevice = None
                vphyendtardevice = None
                diskdevice = None
                if device.find('phy-') >= 0:
                    vphydevice = device
                    if vphydevice:
                        vphydevicephydevicepath = os.path.join(expanderphdevicepath,vphydevice,'sas_phy')
                        vphydevicephydevice = None
                        if os.path.exists(vphydevicephydevicepath):
                            devicelist = os.listdir(vphydevicephydevicepath)
                            for device in devicelist:
                                if device.find('phy-') >= 0:
                                    vphydevicephydevice = device
                                    break
                            if vphydevicephydevice:
                                vphydevicephydevicephyidnetpath = os.path.join(vphydevicephydevicepath,vphydevicephydevice,'phy_identifier')
                                if os.path.exists(vphydevicephydevicephyidnetpath):
                                    f,fstat = cust_fopen(vphydevicephydevicephyidnetpath,'r')
                                    vphydeviceid = f.read().strip()
                                    cust_fclose(f,fstat)
                if vphydeviceid and int(vphydeviceid) < 24:
                    expanderphyids.append(vphydeviceid)
            except:
                print >> sys.stderr,traceback.print_exc()
    return expanderphyids
#-----------------------------------------
# auto expander
#-----------------------------------------   
def autocabinetnum():
    expanderidmap = {}
    expanderfiles = {}
    try:
        pathlist = os.listdir(SASEXPANDER)
        for path in pathlist:
            m = re.match(EXPANDERMATCH,path)
            if m:
                expanderid = int(m.group(1))
                expandersasaddress = ''
                diskcounttype = 16
                expandersasaddresspath = os.path.join(SASDEVICE,path,SASADDRESS)
                if os.path.exists(expandersasaddresspath):
                    f,fstat = cust_fopen(expandersasaddresspath,'r')
                    expandersasaddress = f.read().strip()
                    cust_fclose(f,fstat)
                expanderdiskcountpath = os.path.join(SASEXPANDER,path,PRODUCTID)
                if os.path.exists(expanderdiskcountpath):
                    f,fstat = cust_fopen(expanderdiskcountpath,'r')
                    result = f.read().strip()
                    cust_fclose(f,fstat)
                    n = re.match("\s*[^-]+-(\d+)",result)
                    if n:
                        diskcounttype = int(n.group(1))
                if expandersasaddress and diskcounttype:
                    expanderfiles[expanderid] = {
                         'sasaddress':expandersasaddress,
                         'diskcounttype':diskcounttype
                    }
        if expanderfiles:
            expanderorder = sorted(expanderfiles.keys())
            i = 0
            for expanderid in expanderorder:
                expanderidmap[i] = copy.deepcopy(expanderfiles[expanderid])
                i += 1
        if expanderidmap:
            cust_popen([RM,'-rf',DISKMAPPATH])
            cust_popen([MKDIR,'-p',DISKMAPPATH])
            for expanderid,expanderinfo in expanderidmap.iteritems():
                diskmapfile = os.path.join(DISKMAPPATH,'%d-%d-%s' % (expanderid,expanderinfo['diskcounttype'],expanderinfo['sasaddress']))
                f,fstat = cust_fopen(diskmapfile,'w')
                pickle.dump(eval('DISKIDMAP%d' % expanderinfo['diskcounttype']),f)
                cust_fclose(f,fstat)
            cust_popen([CHMOD, '755', '-R', DISKMAPPATH])
            cust_popen([CHOWN, 'www-data:www-data', '-R', DISKMAPPATH])
    except:
        print >> sys.stderr,traceback.print_exc()
#----------------------------------------
# get diskname set
#----------------------------------------
def get_diskmap(json=False):
    check_version()
    if check_new_or_old():
        disks = []
        diskcount = []
        disknameset = set([])
        diskidmap = {}
        disknamemap = {}
        cabinetcount,expanderidmap,expanderdisks = get_cabinet_info()
        if cabinetcount > 0:
            for expanderid,expanderinfo in expanderidmap.iteritems():
                expanderdiskfile = os.path.join(DISKMAPPATH,'%d-%d-%s' % (expanderid,expanderinfo['diskcounttype'],expanderinfo['sasaddress']))
                diskcount.insert(expanderid,expanderinfo['diskcounttype'])
                if os.path.exists(expanderdiskfile):
                    f = open(expanderdiskfile,'r')
                    expanderdiskidmap = pickle.load(f)
                    f.close()
                    if cabinetcount > 1:
                        for phyid,locateid in expanderdiskidmap.iteritems():
                            if phyid in expanderdisks[expanderinfo['sasaddress']]:
                                diskid = '%d-%s' % (expanderid,locateid)
                                diskname = expanderdisks[expanderinfo['sasaddress']][phyid]
                                disks.append(diskname)
                                diskidmap[diskid] = diskname
                                disknamemap[diskname] = diskid
                    else:
                        for phyid,locateid in expanderdiskidmap.iteritems():
                            if phyid in expanderdisks[expanderinfo['sasaddress']]:
                                diskid = locateid
                                diskname = expanderdisks[expanderinfo['sasaddress']][phyid]
                                disks.append(diskname)
                                diskidmap[diskid] = diskname
                                disknamemap[diskname] = diskid
        disknameset = set(disks)
        if json:
            return simplejson.dumps([disknamemap,diskcount])
        else:
            return disks,disknameset,diskidmap,disknamemap,expanderidmap
    else:
        global sas_sn
        global sata_sn
        expanderidmap = {}
        diskidmap = {}
        disknamemap = {}
        disks,disknameset = get_disknameset()
        disktype = check_sata_or_sas()
        diskcount = get_old_diskcount()
        try:
            if disktype == 'sata':
                try:
                    reload(sata_sn)
                except:
                    import sata_sn                
            else:
                try:
                    reload(sas_sn)
                except:
                    import sas_sn
            for disk in disknameset: 
                diskslot = get_disk_slot_from_dev(disk)
                if diskslot:
                    diskid = convert_disk_slot_to_disk_id(diskcount,diskslot)
                    if diskid:
                        diskid = str(diskid)
                        diskidmap[diskid] = disk
                        disknamemap[disk] = diskid
        except:
            pass
        if json:
            return simplejson.dumps([disknamemap,diskcount])
        else:
            return disks,disknameset,diskidmap,disknamemap,expanderidmap
#old expander
#-----------------------------------------
# check the system disk
#-----------------------------------------    
def just_sys_disk():
    sysdisk = ''
    if os.path.isfile(SYSDISKCACHE):
        retcode,proc = cust_popen([CAT,SYSDISKCACHE])
        sysdisk = proc.stdout.read().strip()
    else:
        sysdiskmatch = '\s+/dev/([s,h]d[a-z])\d+'
        retcode,proc = cust_popen([PVSCAN,'-s'])
        if retcode == 0:
            result = proc.stdout.readlines()
            for line in result:
                m = re.search(sysdiskmatch,line)
                if m:
                    sysdisk = '/dev/%s' % m.group(1)
                    parentpath = os.path.split(SYSDISKCACHE)[0]
                    if not os.path.exists(parentpath):
                        os.makedirs(parentpath)
                    f = open(SYSDISKCACHE,'w')
                    f.write(sysdisk)
                    f.close()
                    break
    return sysdisk
#----------------------------------------
# get diskname set
#----------------------------------------
def get_disknameset():
    diskmatch = "sd\D+"
    disknameset = set([])
    disks = []
    sysdisk = just_sys_disk()
    sysdiskname = ''
    if sysdisk:
        sysdiskname = sysdisk.replace('/dev/','')
    sysblocks = os.listdir(SYSBLOCK)
    for sysblock in sysblocks:
        if re.match(diskmatch,sysblock) and sysblock != sysdiskname:
            disknameset.add(sysblock)
            disks.append(sysblock)
    return disks,disknameset
#-----------------------
#
#-----------------------
def get_pci_path():
    pci_path = 'phy_identifier'
    retcode,proc = cust_popen("%s -t2 | sed -n '/Product Name/,1p' | awk -F\: '{print $2}'" % DMIDECODE)
    result = proc.stdout.read().strip()
    if result in ["X8SIE","X8DTL","X9DR7/E-LN4F"]:
        pci_path = "sas_address"
    return pci_path
#-----------------------
#
#-----------------------
def check_sata_or_sas():
    disktype = 'sas'
    if not os.path.exists(SASDEVICE) or len(os.listdir(SASDEVICE)) == 0:
        disktype = 'sata'
    else:
        disktype = 'sas'
    return disktype
#-----------------------
#
#-----------------------
def get_old_diskcount():
    diskcount = []
    count = None
    filename = None
    disktype = check_sata_or_sas()
    if disktype == 'sas':
        filename = SASJOBD
    elif disktype == 'sata':
        filename = SATAJOBD
    if filename:
        if os.path.isfile(filename):
            retcode,proc = cust_popen([CAT,filename])
            try:
                count = int(proc.stdout.read().strip())
            except:
                count = None
    if not count is None:
        if count == 48:
            diskcount = [24,24]
        elif count == 24:
            diskcount = [24]
        elif count == 16:
            diskcount = [16]
        elif count == 8:
            diskcount = [8]
        elif count == 0:
            diskcount = [16]
        elif 1 < count < 5:
            diskcount = [16] * count
        elif count < 0:
            diskcount = [-count]
    return diskcount
#-----------------------
#
#-----------------------
def check_jobd():
    status = 0 #satadisk
    count = 0
    disktype = check_sata_or_sas()
    if disktype == 'sas':
        filename = SASJOBD
        if os.path.isfile(filename):
            retcode,proc = cust_popen([CAT,filename])
            try:
                count = int(proc.stdout.read().strip())
            except:
                count = None
            if count == 0:
                status = 1 #16 disk
            elif count == 24:
                status = 3 #24 disk
            elif count == 8:
                status = 0 #8 disk
            elif count < 0:
                count = 0 - count
                status = 4 # (0 - count) * 4 disk
            elif count == 48:
                status = 5 #48 disk
            else:
                status = 2 #dusk
    elif disktype == 'sata':
        filename = SATAJOBD
        if os.path.isfile(filename):
            retcode,proc = cust_popen([CAT,filename])
            try:
                count = int(proc.stdout.read().strip())
            except:
                count = None
            if count == 8:
                status = 0
            elif count == 16:
                status = 6 #satadisk 16 disk
        else:
             count = 8
             status = 0
    return status,count
#-----------------------------------------
# covert slot to portaddr
# slot      : 6:0:2:0
# portAddr  : end_device-7:6
#-----------------------------------------
def convert_disk_slot_to_port_addr(diskslot):
    portaddr = None
    pciaddr = ''
    find = False
    portfile = None
    portfilestr = get_pci_path()
    devicelist = os.listdir(SASDEVICE)
    for eachdev in devicelist:
        devsubdir = "%s%s/device" %(SASDEVICE,eachdev)
        targetlist = os.listdir(devsubdir)
        for eachtarget in targetlist:
            if re.match("target\d+\:\d+\:\d+",eachtarget):
                targetsubdir = '%s/%s' % (devsubdir,eachtarget)
                slotlist = os.listdir(targetsubdir)
                for eachslot in slotlist:
                    if eachslot == diskslot:
                        pciaddr = eachdev[:eachdev.rindex(':')]
                        portfile = '%s%s/%s' % (SASDEVICE,eachdev,portfilestr)
                        find = True
                        break
                if find:
                    break
        if find:
            break
    if find:
        f = open(portfile,'r')
        result = f.read().strip()
        f.close()
        if result:
            if portfilestr == 'phy_identifier':
                portaddr = '%s:%s' %(pciaddr,result)
            else:
                portaddr = result
    return portaddr
#-----------------------------------------
# conver disk dev to disk slot
# dev   : /dev/sdq
# return: 6:0:0:0
#-----------------------------------------
def get_disk_slot_from_dev(diskdev):
    diskslot = None
    if diskdev:
        diskname = diskdev.replace('/dev/','')
        diskslotmatch = ".*\/(\d+:\d+:\d+:\d+)"
        if os.path.exists(DISKDEVICE % diskname):
            if os.path.islink(DISKDEVICE % diskname):
                result = os.readlink(DISKDEVICE % diskname)
                m = re.match(diskslotmatch,result)
                if m:
                    diskslot = m.group(1)
    return diskslot
#-----------------------------------------
# split diskslot
# slot   : 6:0:0:0
# return : 2:0:0:0
#-----------------------------------------
def analysisslot1(diskslot):
    slot = diskslot
    if re.match('\d+:\d+:\d+:\d+',diskslot):
        tmp = [int(item) for item in diskslot.split(':')]
        maxid = max(tmp)
        maxpos = tmp.index(maxid)
        if maxid >= 6:
            maxid = maxid - 6
        else:
            maxid = maxid + 4
        tmp[maxpos] = maxid
        slot = ':'.join([str(item) for item in tmp])
    return slot
def analysisslot2(diskslot):
    slot = diskslot
    if re.match('\d+:\d+:\d+:\d+',diskslot):
        tmp = [int(item) for item in diskslot.split(':')]
        maxid = max(tmp)
        maxpos = tmp.index(maxid)
        if maxid >= 5:
            maxid = maxid - 4
        else:
            maxid = maxid + 5
        tmp[maxpos] = maxid
        slot = ':'.join([str(item) for item in tmp])
    return slot
def analysissysslot(diskslot):
    maxid = 0
    if re.match('\d+:\d+:\d+:\d+',diskslot):
        tmp = [int(item) for item in diskslot.split(':')]
        maxid = max(tmp)
    return maxid
#-----------------------------------------
# conver slot to disk id
# slot   : 6:0:0:0
# return: 13
#-----------------------------------------
def convert_disk_slot_to_disk_id(diskcount,diskslot):
    diskid = None
    retcode,proc = cust_popen('ls -al %s%s' % (SASDEVICE,'end*'))
    reslen = len(proc.stdout.readlines())
    if reslen > 0:
        portaddr = convert_disk_slot_to_port_addr(diskslot)
        if diskcount in [24,48]:
            m = re.match('^end\S+-\d+:(\d+)$',portaddr)
            n = re.match('^end\S+-\d+:(\d+:\d+)$',portaddr)
            portaddrkey = None
            if m:
                portaddrkey = m.group(1)
            elif n:
                portaddrkey = n.group(1)
            if portaddrkey:
                for key in sas_sn.DISKNUM.keys():
                    if re.match('^end\S+-\d+:%s$' % portaddrkey,key):
                        diskid = sas_sn.DISKNUM[key]
                        break
        else:
            if portaddr and portaddr in sas_sn.DISKNUM:
                diskid = sas_sn.DISKNUM[portaddr]
    else:
        sysdisk = just_sys_disk()
        sysdiskslot = get_disk_slot_from_dev(sysdisk)
        if sysdiskslot in sata_sn.DISKNUM:
            maxid = analysissysslot(sysdiskslot)
            if maxid < 4:
                diskslot = analysisslot1(diskslot)
                if diskslot in sata_sn.DISKNUM:
                    diskid = sata_sn.DISKNUM[diskslot]
            else:
                diskslot = analysisslot2(diskslot)
                if diskslot in sata_sn.DISKNUM:
                    diskid = sata_sn.DISKNUM[diskslot]
        else:
            if diskslot in sata_sn.DISKNUM:
                diskid = sata_sn.DISKNUM[diskslot]
    return diskid
#-----------------------------------------
# main function
#-----------------------------------------
if __name__ == '__main__':
    expanders = get_all_expanders()
    for expandername,expandersasaddress in expanders.iteritems():
        print expandername
        print expandersasaddress
        print '*********************************'
        print get_smp_device(expandername,expandersasaddress)
        print '*********************************'
        print get_expander_phyids(expandername)
        print '*********************************'
    print get_diskmap(True)
