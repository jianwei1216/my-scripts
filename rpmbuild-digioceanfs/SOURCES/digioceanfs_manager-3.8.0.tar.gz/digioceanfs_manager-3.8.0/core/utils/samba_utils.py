# -*- coding: utf-8 -*-
import StringIO
import ConfigParser
import tempfile
import copy
from manager_utils import * 

import settings

#SMB_CONF = "/etc/samba/smb.conf"
SMB_CONF = settings.SMBCONF 
#SHADOW = '/etc/shadow'
SHADOW = settings.SHADOW 
#PASSWD = '/etc/passwd'
PASSWD = settings.PASSWD 
#SMBPASSWD = '/usr/bin/smbpasswd'
SMBPASSWD = settings.COMMANDS['smbpasswd'] 
#SMBSTATUS = '/usr/bin/smbstatus'
SMBSTATUS = settings.COMMANDS['smbstatus'] 
#USERADD = '/usr/sbin/useradd'
USERADD = settings.COMMANDS['useradd'] 
#USERDEL = '/usr/sbin/userdel'
USERDEL = settings.COMMANDS['userdel'] 
#USERMOD = '/usr/sbin/usermod'
USERMOD = settings.COMMANDS['usermod'] 
#USERNAME_PREFIX = 'digioceanfs_smb_'
USERNAME_PREFIX = settings.USERNAMEPREFIX 
#SMB_CONF_PREFIX = '/etc/digioceanfs/services/'
SMB_CONF_PREFIX = settings.SMBCONFPREFIX 
#NETSTAT = '/bin/netstat'
NETSTAT = settings.COMMANDS['netstat'] 
#SMBSERVICENAME = 'smbd'
SMBSERVICENAME = settings.COMMANDS['smbd'] 

MINUID = 1001
MAXUID = 2000
MINGID = 2001
MAXGID = 3000

samba_config_template                 = """
[%s]
comment                       = Public Directory
path                          = %s/%%S/%%U
browseable                    = yes
writable                      = no
guest ok                      = no
level2 oplocks                = no
blocking locks                = no
follow symlinks               = no
strict locking                = NO
posix locking                 = NO
oplocks                       = no
fake oplocks                  = yes
directory mask                = 0000
force directory mode          = 0700
create mask                   = 0000
force create mode             = 0700
force security mode           = 2770
force directory security mode = 2770
write list =
valid users = 
# performance feature
follow symlinks = no
wide links = no
aio read size = 65536 #16384
aio write size = 65536 #16384
aio write behind = true
write cache size = 2097152
max xmit = 65536
large readwrite = yes
read raw = Yes
write raw = Yes
socket options = TCP_NODELAY IPTOS_LOWDELAY SO_RCVBUF=131072 SO_SNDBUF=131072
[homes]
comment = Home Directories
browseable = no
writable = no
path = /home/%%U
"""
SYSUSER = ['root','daemon','bin','sys','sync','games',
          'man','lp','mail','news','uucp','proxy','www-data',
          'backup','list','irc','gnats','nobody','libuuid',
          'Debian-exim','statd','sshd','ftp','mysql']
def samba_add_include(include_path):
    smb_conf_img = get_config_file(SMB_CONF)
    smb_conf_lines = smb_conf_img.readlines()
    if not smb_conf_lines:
        digi_debug("Parse samba config file failed", 5)
        return False
    for a_line in smb_conf_lines:
        if len(a_line) < 2:
            continue
        if a_line[0] == "#":
            continue
        if a_line[0] == ";":
            continue
        if a_line[:7] == "include":
            path = a_line[8:-1]
            digi_debug("compare %s with %s"%(path, include_path),5)
            if path == include_path:
                break
    else:
        if len(smb_conf_lines[-1][-1]) != '\n':
            smb_conf_lines.append('\n')
        smb_conf_lines.append("include=%s\n"%(include_path))

        smb_conf_img_new = StringIO.StringIO()
        for a_line in smb_conf_lines:
            smb_conf_img_new.write(a_line)

        set_config_file(SMB_CONF, smb_conf_img_new)
        return True
    digi_debug("Samba add include return False", 3)
    return False

def samba_del_include(include_path):
    smb_conf_img = get_config_file(SMB_CONF)
    smb_conf_lines = smb_conf_img.readlines()
    for a_line in smb_conf_lines:
        if len(a_line) < 2:
            continue
        if a_line[0] == "#":
            continue
        if a_line[0] == ";":
            continue
        if a_line[:7] == "include":
            path = a_line[8:-1]
            digi_debug("compare %s with %s"%(path, include_path),5)
            if path == include_path:
                smb_conf_lines.remove(a_line)
                break
    else:
        digi_debug("Samba del include return False", 3)
        return False

    smb_conf_img_new = StringIO.StringIO()
    for a_line in smb_conf_lines:
        smb_conf_img_new.write(a_line)
    set_config_file(SMB_CONF, smb_conf_img_new)
    return True

def samba_check_include(include_path):
    smb_conf_img = get_config_file(SMB_CONF)
    smb_conf_lines = smb_conf_img.readlines()
    for a_line in smb_conf_lines:
        if len(a_line) < 2:
            continue
        if a_line[0] == "#":
            continue
        if a_line[0] == ";":
            continue
        if a_line[:7] == "include":
            path = a_line[8:-1]
            digi_debug("compare %s with %s"%(path, include_path),5)
            if path == include_path:
                break
    else:
        digi_debug("Samba check include return False", 3)
        return False
    return True

def samba_status():
    arrive_service = False
    start_push = False
    service_list = []

    cmd = []
    cmd.append("/usr/bin/smbstatus")
    img = tempfile.TemporaryFile()
    ret = execute(cmd, std=img)
    img.seek(0)
    lines = img.readlines()

    for a_line in lines:
        if arrive_service:
            arrive_service = False
            start_push = True
            continue
        if start_push:
            if len(a_line) < 2:
                break
            service_list.append(a_line.split()[0])
            continue
        if len(a_line) < 2:
            continue
        elif a_line.split()[0] == "Service":
            arrive_service= True

    digi_debug("Got samba service list:%s"%(service_list), 7)

    return service_list

def samba_reload_config():
    cmd = []
    cmd.append("/usr/bin/smbcontrol")
    cmd.append("smbd")
    cmd.append("reload-config")
    ret = execute(cmd)

def samba_gen_config_file(export_dir_prefix, service_name):
    if export_dir_prefix[-1] == '/':
        export_dir_prefix = export_dir_prefix[:-1]
    config_file_img = samba_config_template%(service_name, export_dir_prefix)#), service_name)
    return StringIO.StringIO(config_file_img)

def samba_add_service(include_path):
    if not samba_add_include(include_path):
        return False
    samba_reload_config()
    return True

def samba_del_service(include_path):
    if not samba_del_include(include_path):
        return False
    samba_reload_config()
    return True

def samba_check_service(include_path):
    if not samba_check_include(include_path):
        return False
    return True

def samba_status_service(service_name):
    service_list = samba_status()
    if find_in_list(service_list, service_name):
        digi_debug("Get samba status service return True", 7)
        return True
    digi_debug("Get samba status service return False", 3)
    return False
def samba_status_process():
    sambastatus = False
    ret, tmpimg = systemctl('status', 'smb')
    result = tmpimg.readline()
    re_p = '\s+Active:\s(\S+)\s+'
    statusRe = re.match(re_p, result)
    if statusRe:
        result = statusRe.groups[0]
    if result == 'active':
        sambastatus = True
    else:
        samba_start()
        sambastatus = True
    digi_debug("Get samba status process return %s" % (sambastatus), 7)
    return sambastatus

def samba_stop():
    ret, tmpfile = systemctl('stop', 'smb')

def samba_start():
    ret, tmpfile = systemctl('start', 'smb')

def samba_restart():
    ret, tmpfile = systemctl('restart', 'smb')
    return ret

###### user utils #######

def get_user_info(user_name=''):
    cmd = []
    cmd.append("cat %s | awk -F\: '{print $5}'" % (PASSWD))
    tmp_img = tempfile.TemporaryFile()
    ret = execute(cmd, tmp_img, shell=True)
    tmp_img.seek(0)
    user_list = tmp_img.readlines()
    digi_debug("get user list return: %s" % (user_list),5)
    if user_list:
        cluster_smb_user_list = []
        if user_name:
            p = USERNAME_PREFIX + user_name
            for user in user_list:
                if user.find(p) >= 0:
                    return True
            else:
                digi_debug("Get user info return False", 3)
                return False
        else:
            p = USERNAME_PREFIX
            for user in user_list:
                if user.find(p) >= 0:
                    cluster_smb_user_list.append(user[len(USERNAME_PREFIX):].strip())
            else:
                digi_debug("Get user info return: %s" % cluster_smb_user_list, 7)
                return cluster_smb_user_list

def get_smb_user_info(service_name):
    config = ConfigParser.ConfigParser()
    if config.read(settings.SMBCONFPREFIX+ '/' + service_name + '/smb.conf'):
        smb_user_list = []
        smb_user_list = config.get(service_name, "write list").split()
    return smb_user_list

def check_user_links(user_name):
    all_links_info = get_all_samba_links()
    for link in all_links_info:
        if user_name in link:
            return False
    else:
        return True
###### user action ######
#-------------------------------------------
# create user
#-------------------------------------------
def add_user(user_name, password='',uid=''):
    cmd = []
    cmd.append(USERADD)
    cmd.append('-N')
    cmd.append(user_name)
    cmd.append('-u')
    cmd.append(str(uid))
    cmd.append('-g')
    cmd.append('100')
    cmd.append('-c')
    cmd.append(USERNAME_PREFIX + user_name)
    ret = execute(cmd)
    if ret == 9:
        digi_debug("User : %s has already exist" % (USERNAME_PREFIX + user_name), 5)
        cmd = []
        cmd.append(USERMOD)
        cmd.append('-c')
        cmd.append(USERNAME_PREFIX + user_name)
        cmd.append(user_name)
        ret = execute(cmd)
    elif ret == 0:
        digi_debug("Add user to system succeed", 7)
    else:
        return False
    if not password:
        return True
    cmd = []
    cmd.append(SMBPASSWD)
    cmd.append('-s')
    cmd.append('-a')
    cmd.append(user_name)
    #ret = execute(cmd, None, False, False, password+'\n'+password)
    tmp_img = tempfile.TemporaryFile()
    #ret = execute(cmd, std=tmp_img, stdi=sys.stdin, communicate='%s\n%s' % (password,password))
    ret = execute(cmd, std=tmp_img, stdi=subprocess.PIPE, communicate='%s\n%s\n' % (password,password))
    if ret:
        digi_debug("Set passwd failed return %s" %(ret), 3)
        return False
    return True

def add_user2smbconf(service_name, user_name):
    config = ConfigParser.ConfigParser()
    smb_user_list = []
    #check user_name is in system
    user_list = get_user_info()
    if user_name not in user_list:
        digi_debug("%s not fount in system, add first" % (user_name), 3)
        return False
    if config.read(settings.SMBCONFPREFIX+ '/' + service_name + '/smb.conf'):
        smb_user_list = config.get(service_name, "write list").split()
        digi_debug("Read service smb config file return: %s" % (smb_user_list), 7)
        for user in smb_user_list:
            if user == user_name:
                return False
            else:
                continue
        else:
            smb_user_list.append(user_name)
            smb_user_str = ' '.join(smb_user_list)
            config.set(service_name, 'write list', smb_user_str)
            config.set(service_name, 'valid users', smb_user_str)
            digi_debug("Set service smb config file with: %s" % (smb_user_str), 7)
            configfile = open(settings.SMBCONFPREFIX+  '/' + service_name + '/smb.conf', 'wb')
            config.write(configfile)
            configfile.close()
            samba_reload_config()
            digi_debug("Add user to write list succeed" , 7)
            try:
                os.mkdir('/cluster2/%s/%s' % (service_name, user_name), 0700)
                os.system('chown %s /cluster2/%s/%s' % (user_name, service_name, user_name))
                os.system('chgrp users /cluster2/%s/%s' % (service_name, user_name))
                #os.system('chown'+' '+user_name+':'+'users'+' '+'/cluster2/'+service_name+'/'+user_name)
                #modified by zys
                #os.system('mkdir /cluster2/%s/%s' % (service_name, user_name))
            except:
                pass
            return True

def del_user(service_name, user_name):
    user_list = get_user_info()
    smb_user_list = get_smb_user_info(service_name)
    smb_links = get_all_samba_links()
    for link in smb_links:
        if link['username'] == user_name:
            return 3
    if user_name in SYSUSER:
        cmd = []
        cmd.append(USERMOD)
        cmd.append('-c')
        cmd.append(user_name)
        cmd.append(user_name)
        ret = execute(cmd)
        cmd = []
        cmd.append(SMBPASSWD)
        cmd.append('-d')
        cmd.append(user_name)
        ret = execute(cmd)        
        return 1
    else:
        cmd = []
        cmd.append(USERDEL)
        cmd.append(user_name)
        for user in user_list:
            if user == user_name:
                if user not in smb_user_list:
                    ret = execute(cmd)
                    if ret == 0:
                        cmd = []
                        cmd.append(SMBPASSWD)
                        cmd.append('-d')
                        cmd.append(user_name)
                        ret = execute(cmd) 
                        return 1
                    else:
                        return 2
                else:
                    digi_debug("Samba del user %s is used by smb" % (user_name), 3)
                    return 3
        else:
            digi_debug("Samba del user %s not found in system" % (user_name), 3)
            return 4

def del_user_force(service_name, user_name):
    user_list = get_user_info()
    smb_user_list = get_smb_user_info(service_name)
    cmd = []
    cmd.append(USERDEL)
    cmd.append(user_name)
    for user in user_list:
        if user == user_name:
            ret = execute(cmd)
    else:
        digi_debug("Samba del user %s not found in system" % (user_name), 3)
        return 4
    
def del_userfromsmbconf(service_name, user_name):
    config = ConfigParser.ConfigParser()
    smb_user_list = []
    digi_debug(settings.SMBCONFPREFIX, 3)
    smb_conf_path = settings.SMBCONFPREFIX+'/'+service_name+'/smb.conf'
    if config.read(smb_conf_path):
        smb_user_list = config.get(service_name, "write list").split()
        digi_debug("read >> %s << smb config file return: %s" % (service_name, smb_user_list),7)
        for user in smb_user_list:
            if user == user_name:
                smb_user_list.remove(user_name)
                smb_user_str = ' '.join(smb_user_list)
                config.set(service_name, 'write list', smb_user_str)
                digi_debug("read >> %s << smb config file return: %s" % (service_name, smb_user_list),7)
                digi_debug("set service smb config file with: %s" % (smb_user_str),7)
                configfile = open(smb_conf_path, 'wb')
                config.write(configfile)
                configfile.close()
                samba_reload_config()
                return True
            else:
                continue
        else:
            return False
        
def get_all_samba_links():
    tsambalinkinfos = []
    sambalinkinfos = []
    cmd = []
    cmd.append(SMBSTATUS)
    cmd.append('-p')
    tmp_img_0 = tempfile.TemporaryFile()
    ret = execute(cmd, tmp_img_0)
    tmp_img_0.seek(0)
    lines = tmp_img_0.readlines()
    for line in lines:
        m = re.match("\s*(\d+)\s+([\S]+)\s+([\S]+)\s+(.+)\n",line)
        if m:
            sambalinkinfo = {
                'pid':m.group(1),
                'username':m.group(2),
                'group':m.group(3),
                'comefrom':m.group(4),
                'sharename':'',
                'logintime':'',
            }
            tsambalinkinfos.append(sambalinkinfo)
    cmd = []
    cmd.append(SMBSTATUS)
    cmd.append('-S')
    tmp_img_1 = tempfile.TemporaryFile()
    ret = execute(cmd, tmp_img_1)
    tmp_img_1.seek(0)
    lines = tmp_img_1.readlines()
    for line in lines:
        m = re.match("(\S+)\s+(\d+)\s+(\S+)\s+(.+)\n",line)
        if m:
            for sambalinkinfo in tsambalinkinfos:
                if sambalinkinfo['pid'] == m.group(2) and m.group(1) != 'IPC$':
                    tsambalinkinfo = copy.deepcopy(sambalinkinfo)
                    tsambalinkinfo['sharename'] = m.group(1)
                    tsambalinkinfo['logintime'] = m.group(4)
                    sambalinkinfos.append(tsambalinkinfo)
    return sambalinkinfos
                
def force_del_samba_links(pid):
    cmd = []
    cmd.append('kill')
    cmd.append('-9')
    cmd.append(pid)
    ret = execute(cmd)
    if not ret:
        return True
    else:
        return False

if __name__ == "__main__":
    #print samba_gen_config_file("/cluster2/", "test1").read()
    #print samba_del_service("/etc/samba/cluster/test2.conf")
    print get_all_samba_links()
    print get_user_info()
