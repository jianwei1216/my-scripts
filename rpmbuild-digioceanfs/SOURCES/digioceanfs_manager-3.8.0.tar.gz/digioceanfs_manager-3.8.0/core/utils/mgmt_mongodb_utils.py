#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import sys
import time
import pymongo
import re
import types

#import settings

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)
manager_path = os.path.join(currpath[:currpath.rfind('utils')])
if not manager_path in sys.path:
    sys.path.append(manager_path)
ACOLID = None

sys.path.append("/usr/local/digioceanfs_manager/monitor_report")
from get_info import *
from monitor_report_log import digi_log
from mongo_utils import *

#####################################################
    # write collection data to mongo database
    # such as cpu/memory/fan/battery/process...
#####################################################
rex_mongo = re.compile('.*', re.IGNORECASE)

def ocol_db_init(instance):

    '''
    disk_size_monitor  = {600070006:80.0,700070005: 90.0}
    disk_inode_monitor = {600070008:90.0,700070008: 95.5}
    cpu_usage_monitor  = {600010001:90.0,700010001: 180.5}
    mem_usage_monitor  = {600020001:90.0,600020001: 95.5} 
    '''
    disk_size  = {'600070006':80.0,'700070006':90.0}
    disk_inode = {'600070008':90.0,'700070008':95.5}
    cpu_usage  = {'600010001':90.0,'700010001':180.5}
    mem_usage  = {'600020001':90.0,'700020001':95.5}

    if isinstance(instance, Digi_Collection) is False or instance.name != "thresholdcol":
        return  -1
    ret = instance.write(disk_size)
    if ret == -1:
        return -1
    instance.write(disk_inode)
    if ret == -1:
        return -1
    instance.write(cpu_usage)
    if ret == -1:
        return -1
    instance.write(mem_usage)
    if ret == -1:
        return -1
    return 0

def update_probe_threshold_key(col_key , col):

    dicts = {'disk_size_monitor':{600070006:80.0,700070006: 90.0},'disk_inode_monitor':{600070008:90.0,700070008: 95.5},
             'cpu_usage_monitor':{600010001:90.0,700010001: 180.5},'mem_usage_monitor':{600020001:90.0,700020001: 95.5}}

    if isinstance(col, Digi_Collection) is False or col.name != "thresholdcol":
        return  -1

    match = dicts[col_key]
    result = col.read(match)
    if ret == -1:
        return {}
    return  result

########## alarm information of battary ##########
def alarm_information_of_battary(data, data_old, alarm_info):
    ########## The battery from full or charging to discharge state ##########
    if (data['battery_status'] == 'Discharge' and data_old['battery_status'] == 'Full') or (data['battery_status'] == 'Discharge' and data_old['battery_status'] == 'Charging'):
        alarm_info['type'] = '600060001'
        alarm_info['data'] = data['monitor_time']
        alarm_info['severity'] = 'ERROR'
        alarm_info['node'] = data['node']
        alarm_info['message'] = 'The battery power is too low'
    ########## The battery from discharge to full or discharge state ##########
    if (data['battery_status'] == 'Full' and data_old['battery_status'] == 'Discharge') or (data['battery_status'] == 'Charging' and data_old['battery_status'] == 'Discharge'):
        alarm_info['type'] = '700060001'
        alarm_info['data'] = data['monitor_time']
        alarm_info['severity'] = 'INFO'
        alarm_info['node'] = data['node']
        alarm_info['message'] = 'The battery power recovery'

########## alarm information of digioceanfs_gui ##########
def alarm_information_of_digioceanfs_gui(data, data_old, alarm_info):
    ########## digioceand_gui, startup failure ##########
    if data['process_status'] == 'Off' and data_old['process_status'] == 'Off':
        data['alarm_flag'] = 'True'
        alarm_info['type'] = '600140018'
        alarm_info['data'] = data['monitor_time']
        alarm_info['severity'] = 'ERROR'
        alarm_info['node'] = data['node']
        alarm_info['message'] = 'Digioceanfs_gui process startup failure'
        os.system('/usr/bin/digioceanfs-gui start')
    ########## digioceand_gui, abnormal death ##########
    if data['process_status'] == 'Off' and data_old['process_status'] == 'On':
        data['alarm_flag'] = 'True'
        alarm_info['type'] = '600140017'
        alarm_info['data'] = data['monitor_time']
        alarm_info['severity'] = 'WARNING'
        alarm_info['node'] = data['node']
        alarm_info['message'] = 'Digioceanfs_gui process of abnormal death'
        os.system('/usr/bin/digioceanfs-gui start')
    ########## digioceand_gui, started sucessfully ##########
    if data['process_status'] == 'On' and data_old['process_status'] == 'Off':
        if data_old['alarm_flag'] == 'True':
            alarm_info['type'] = '700140009'
            alarm_info['data'] = data['monitor_time']
            alarm_info['severity'] = 'INFO'
            alarm_info['node'] = data['node']
            alarm_info['message'] = 'Digioceanfs_gui process has been started sucessfully'

########## alarm information of digioceand ##########
def alarm_information_of_digioceand(data, data_old, alarm_info):
    ########## digiocean, startup failure ##########
    if data['process_status'] == 'Off' and data_old['process_status'] == 'Off':
        data['alarm_flag'] = 'True'
        alarm_info['type'] = '6000140002'
        alarm_info['data'] = data['monitor_time']
        alarm_info['severity'] = 'ERROR'
        alarm_info['node'] = data['node']
        alarm_info['message'] = 'Digioceand process startup failure'
        os.system('/usr/bin/node-manager start')
    ########## digiocean, abnormal death ##########
    if data['process_status'] == 'Off' and data_old['process_status'] == 'On':
        data['alarm_flag'] = 'True'
        alarm_info['type'] = '6000140001'
        alarm_info['data'] = data['monitor_time']
        alarm_info['severity'] = 'WARNING'
        alarm_info['node'] = data['node']
        alarm_info['message'] = 'Digioceand process of abnormal death'
        os.system('/usr/bin/node-manager start')
    ########## digiocean, started sucessfully ##########
    if data['process_status'] == 'On' and data_old['process_status'] == 'Off':
        if data_old['alarm_flag'] == 'True':
            alarm_info['type'] = '7000140001'
            alarm_info['data'] = data['monitor_time']
            alarm_info['severity'] = 'INFO'
            alarm_info['node'] = data['node']
            alarm_info['message'] = 'Digioceand process has been started sucessfully'

########## alarm information of node_manager ##########
def alarm_information_of_node_manager(data, data_old, alarm_info):
    ########## node_manager, startup failure ##########
    if data['process_status'] == 'Off' and data_old['process_status'] == 'Off':
        data['alarm_flag'] = 'True'
        alarm_info['type'] = '600140016'
        alarm_info['data'] = data['monitor_time']
        alarm_info['severity'] = 'ERROR'
        alarm_info['message'] = 'Node_manager process startup failure'
        alarm_info['node'] = data['node']
        os.system('/usr/bin/node-manager start')
    ########## node_manager, abnormal death ##########
    if data['process_status'] == 'Off' and data_old['process_status'] == 'On':
        data['alarm_flag'] = 'True'
        alarm_info['type'] = '600140015'
        alarm_info['data'] = data['monitor_time']
        alarm_info['severity'] = 'WARNING'
        alarm_info['message'] = 'Node_manager process of abnormal death'
        alarm_info['node'] = data['node']
        os.system('/usr/bin/node-manager start')
    ########## node_manager, started sucessfully ##########
    if data['process_status'] == 'On' and data_old['process_status'] == 'Off':
        if data_old['alarm_flag'] == 'True':
            alarm_info['type'] = '700140008'
            alarm_info['data'] = data['monitor_time']
            alarm_info['severity'] = 'INFO'
            alarm_info['node'] = data['node']
            alarm_info['message'] = 'Node_manager process has been started sucessfully'

########## alarm information of Cifs ##########
def alarm_information_of_Cifs(data, data_old, alarm_info):
    ########## Cifs, startup failure ##########
    if data['process_status'] == 'Off' and data_old['process_status'] == 'Off':
        data['alarm_flag'] = 'True'
        alarm_info['type'] = '600140012'
        alarm_info['data'] = data['monitor_time']
        alarm_info['severity'] = 'ERROR'
        alarm_info['node'] = data['node']
        alarm_info['message'] = 'Cifs process startup failure'
        os.system('systemctl start smb')
    ########## Cifs, abnormal death ##########
    if data['process_status'] == 'Off' and data_old['process_status'] == 'On':
        data['alarm_flag'] = 'True'
        alarm_info['type'] = '600140011'
        alarm_info['data'] = data['monitor_time']
        alarm_info['severity'] = 'WARNING'
        alarm_info['node'] = data['node']
        alarm_info['message'] = 'Cifs process of abnormal death'
        os.system('systemctl start smb')
    ########## Cifs, started sucessfully ##########
    if data['process_status'] == 'On' and data_old['process_status'] == 'Off':
        if data_old['alarm_flag'] == 'True':
            alarm_info['type'] = '700140006'
            alarm_info['data'] = data['monitor_time']
            alarm_info['severity'] = 'INFO'
            alarm_info['node'] = data['node']
            alarm_info['message'] = 'Cifs process has been started sucessfully'

########## alarm information of Nfs ##########
def alarm_information_of_Nfs(data, data_old, alarm_info):
    ########## is start service ##########
    service_start_flag = 0
    for index in xrange(len(service_name)):
        if service_status[service_name[index]] == 'On':
            service_start_flag = 1
            break
    ########## Nfs, startup failure ##########
    try:
        if data['process_status'] == 'Off' and data_old['process_status'] == 'Off' and service_start_flag == 1:
            data['alarm_flag'] = 'True'
            alarm_info['type'] = '600140010'
            alarm_info['data'] = data['monitor_time']
            alarm_info['severity'] = 'ERROR'
            alarm_info['node'] = data['node']
            alarm_info['message'] = 'Nfs process startup failure'
            os.system('digiocean vol start %s force'%service_name[index])
        ########## Nfs, abnormal death ##########
        if data['process_status'] == 'Off' and data_old['process_status'] == 'On' and service_start_flag == 1:
            data['alarm_flag'] = 'True'
            alarm_info['type'] = '600140009'
            alarm_info['data'] = data['monitor_time']
            alarm_info['severity'] = 'WARNING'
            alarm_info['node'] = data['node']
            alarm_info['message'] = 'Nfs process of abnormal death'
            os.system('digiocean vol start %s force'%service_name[index])
    except Exception,e:
        digi_log.error("Alarm information, alarm_information_of_Nfs(), caught exception: %s" % traceback.print_exc(e))
    ########## Nfs, started sucessfully ##########
    if data['process_status'] == 'On' and data_old['process_status'] == 'Off':
        if data_old['alarm_flag'] == 'True':
            alarm_info['type'] = '700140005'
            alarm_info['data'] = data['monitor_time']
            alarm_info['severity'] = 'INFO'
            alarm_info['node'] = data['node']
            alarm_info['message'] = 'Nfs process has been started sucessfully'

########## alarm information of service mount ##########
def alarm_information_of_service_mount(data, data_old, alarm_info):
    service_name = get_service_list()
    if not service_name:
        digi_log.warn("get_service_list() is None")
        return None
    service_status = get_status_of_service(service_name)
    for index in xrange(len(service_name)):
    	try:
    	    ########## service mount, startup failure ##########
            if data['process_status'] == 'Off' and data_old['process_status'] == 'Off' and service_status['%s'%service_name[index]] == 'On':
                data['alarm_flag'] = 'True'
            	alarm_info['type'] = '600140006'
            	alarm_info['data'] = data['monitor_time']
            	alarm_info['severity'] = 'ERROR'
                alarm_info['node'] = data['node']
                alarm_info['servicename'] = service_name[index]
                alarm_info['message'] = '%s process startup failure'%data['process_name']
            	info = os.popen("mount").read()
            	if data['process_name'] in info:
                    os.system("umount %s"%data['process_name'])
                    os.system("mount.digioceanfs 127.0.0.1:/%s %s"%(service_name[index], data['process_name']))
            	else:
                    os.system("mount.digioceanfs 127.0.0.1:/%s %s"%(service_name[index], data['process_name']))
            ########## service mount, abnormal death ##########
            if data['process_status'] == 'Off' and data_old['process_status'] == 'On' and service_status['%s'%service_name[index]] == 'On':
                data['alarm_flag'] = 'True'
            	alarm_info['type'] = '600140005'
            	alarm_info['data'] = data['monitor_time']
            	alarm_info['severity'] = 'WARNING'
            	alarm_info['node'] = data['node']
            	alarm_info['servicename'] = service_name[index]
            	alarm_info['message'] = '%s process of abnormal death'%data['process_name']
            	info = os.popen("mount").read()
            	if data['process_name'] in info:
                    os.system("umount %s"%data['process_name'])
                    os.system("mount.digioceanfs 127.0.0.1:/%s %s"%(service_name[index], data['process_name']))
            	else:
                    os.system("mount.digioceanfs 127.0.0.1:/%s %s"%(service_name[index], data['process_name']))
    	    ########## service mount, started sucessfully ##########
    	    if data['process_status'] == 'On' and data_old['process_status'] == 'Off':
                if data_old['alarm_flag'] == 'True':
            	    alarm_info['type'] = '700140003'
            	    alarm_info['data'] = data['monitor_time']
            	    alarm_info['severity'] = 'INFO'
            	    alarm_info['node'] = data['node']
            	    alarm_info['servicename'] = service_name[index]
            	    alarm_info['message'] = '%s process has been started sucessfully'%data['process_name']
        except Exception,e:
            digi_log.error("Alarm information, alarm_information_of_service_mount(), caught exception: %s" % traceback.print_exc(e))

########## alarm information of service quota ##########
def alarm_information_of_service_quota(data, data_old, alarm_info):
    service_name = get_service_list()
    if not service_name:
        digi_log.warn("get_service_list() is None")
        return None
    service_status = get_status_of_service(service_name)
    quota_info = get_quota_status_of_service(service_name)
    for index in xrange(len(service_name)):
    	try:
            ########## service quota, startup failure ##########
            if data['process_status'] == 'Off' and data_old['process_status'] == 'Off' :
            	if service_status['%s'%service_name[index]] == 'On' and quota_info['%s'%service_name[index]] == 'On':
                    data['alarm_flag'] = 'True'
                    alarm_info['type'] = '600140014'
                    alarm_info['data'] = data['monitor_time']
                    alarm_info['severity'] = 'ERROR'
                    alarm_info['node'] = data['node']
                    alarm_info['servicename'] = service_name[index]
                    alarm_info['message'] = 'quota-mount-%s process startup failure'%service_name[index]
                    info = os.popen("ls /var/run/digiocean/").read()
                    if '%s.pid'%service_name[index] in info:
                    	os.system("umount /var/run/digiocean/%s"%service_name[index])
                    	os.system("digiocean vol quota %s enable"%service_name[index])
                    else:
                        os.system("digiocean vol quota %s enable"%service_name[index])
            ########## service quota, abnormal death ##########
            if data['process_status'] == 'Off' and data_old['process_status'] == 'On':
            	if service_status['%s'%service_name[index]] == 'On' and quota_info['%s'%service_name[index]] == 'On':
                    data['alarm_flag'] = 'True'
                    alarm_info['type'] = '600140013'
                    alarm_info['data'] = data['monitor_time']
                    alarm_info['severity'] = 'WARNING'
                    alarm_info['node'] = data['node']
                    alarm_info['servicename'] = service_name[index]
                    alarm_info['message'] = 'quota-mount-%s process of abnormal death'%service_name[index]
                    info = os.popen("ls /var/run/digiocean/").read()
                    if '%s.pid'%service_name[index] in info:
                    	os.system("umount /var/run/digiocean/%s"%service_name[index])
                    	os.system("digiocean vol quota %s enable"%service_name[index])
                    else:
                    	os.system("digiocean vol quota %s enable"%service_name[index])
            ########## service quota, started sucessfully ##########
    	    if data['process_status'] == 'On' and data_old['process_status'] == 'Off':
                if data_old['alarm_flag'] == 'True':
            	    alarm_info['type'] = '700140007'
            	    alarm_info['data'] = data['monitor_time']
            	    alarm_info['severity'] = 'INFO'
            	    alarm_info['node'] = data['node']
            	    alarm_info['servicename'] = service_name[index]
            	    alarm_info['message'] = 'quota-mount-%s process has been started sucessfully'%service_name[index]
    	except Exception,e:
            digi_log.error("Alarm information, alarm_information_of_service_quota() , caught exception: %s" % traceback.print_exc(e))

########## alarm information of digioceanshd ##########
def alarm_information_of_digioceanshd(data, data_old, alarm_info):
    service_name = get_service_list()
    if not service_name:
        digi_log.warn("get_service_list() is None")
        return None
    service_type = get_type_of_service(service_name)
    service_status = get_status_of_service(service_name)
    ########## digioceanshd, startup failure ##########
    try:
        if data['process_status'] == 'Off' and data_old['process_status'] == 'Off':
            for index in xrange(len(service_name)):
                if (service_type[service_name[index]] == '2' or service_type[service_name[index]] == '4') and service_status[service_name[index]] == 'On':
                    data['alarm_flag'] = 'True'
                    alarm_info['type'] = '600140008'
                    alarm_info['data'] = data['monitor_time']
                    alarm_info['severity'] = 'ERROR'
                    alarm_info['node'] = data['node']
                    alarm_info['message'] = 'Digioceanshd process startup failure'
                    os.system('digiocean vol start %s force'%service_type[service_name[index]])
        ########## digioceanshd, abnormal death ##########
        if data['process_status'] == 'Off' and data_old['process_status'] == 'On':
            for index in xrange(len(service_name)):
                if (service_type[service_name[index]] == '2' or service_type[service_name[index]] == '4') and service_status[service_name[index]] == 'On':
                    data['alarm_flag'] = 'True'
                    alarm_info['type'] = '600140007'
                    alarm_info['data'] = data['monitor_time']
                    alarm_info['severity'] = 'WARNING'
                    alarm_info['node'] = data['node']
                    alarm_info['message'] = 'Digioceanshd process of abnormal death'
                    os.system('digiocean vol start %s force'%service_type[service_name[index]])
    except Exception,e:
        digi_log.error("Alarm information, alarm_information_of_digioceanshd() , caught exception: %s" % traceback.print_exc(e)) 
    ########## digioceanshd, started sucessfully  ##########
    if data['process_status'] == 'On' and data_old['process_status'] == 'Off':
        if data_old['alarm_flag'] == 'True':
            alarm_info['type'] = '700140004'
            alarm_info['data'] = data['monitor_time']
            alarm_info['severity'] = 'INFO'
            alarm_info['node'] = data['node']
            alarm_info['message'] = 'Digioceanshd process has been started sucessfully'

########## alarm information of disk mount ##########
def alarm_information_of_disk_mount(data, data_old, alarm_info):
    service_name = get_service_list()
    if not service_name:
        digi_log.warn("get_service_list() is None")
        return None
    service_status = get_status_of_service(service_name)
    name = data['process_name'].split("/")[1]+ '-'+ data['process_name'].split("/")[2]
    for index in xrange(len(service_name)):
    	try:
    	    ########## disk mount, startup failure ##########
            if data['process_status'] == 'Off' and data_old['process_status'] == 'Off':
            	info = os.popen("ls /var/lib/digioceand/vols/%s"%service_name[index]).read()
            	if name in info and service_status[service_name[index]] == 'On':
                    data['alarm_flag'] = 'True'
                    alarm_info['type'] = '600140010'
                    alarm_info['data'] = data['monitor_time']
                    alarm_info['severity'] = 'ERROR'
                    alarm_info['node'] = data['node']
                    alarm_info['servicename'] = service_name[index]
                    alarm_info['message'] = '%s process startup failure'%data['process_name']
                    sleep(1)
                    os.system('digiocean vol start %s force'%service_name[index])
            ########## disk mount, abnormal death ##########
            if data['process_status'] == 'Off' and data_old['process_status'] == 'On':
                info = os.popen("ls /var/lib/digioceand/vols/%s"%service_name[index]).read()
            	if name in info and service_status[service_name[index]] == 'On':
                    data['alarm_flag'] = 'True'
                    alarm_info['type'] = '600140009'
                    alarm_info['data'] = data['monitor_time']
                    alarm_info['severity'] = 'WARNING'
                    alarm_info['node'] = data['node']
                    alarm_info['servicename'] = service_name[index]
                    alarm_info['message'] = '%s process of abnormal death'%data['process_name']
                    sleep(1)
                    os.system('digiocean vol start %s force'%service_name[index])
    	    ########## disk mpunt, started sucessfully ##########
    	    if data['process_status'] == 'On' and data_old['process_status'] == 'Off':
                if data_old['alarm_flag'] == 'True':
             	    alarm_info['type'] = '700140005'
            	    alarm_info['data'] = data['monitor_time']
            	    alarm_info['severity'] = 'INFO'
            	    alarm_info['node'] = data['node']
            	    alarm_info['servicename'] = service_name[index]
            	    alarm_info['message'] = '%s process has been started sucessfully'%data['process_name']
    	except Exception,e:
            digi_log.error("Alarm information, alarm_information_of_disk_mount() , caught exception: %s" % traceback.print_exc(e))

########## alarm information of quotad ##########
def alarm_information_of_quotad(data, data_old,alarm_info):
    service_name = get_service_list()
    if not service_name:
        digi_log.warn("get_service_list() is None")
        return None
    service_status = get_status_of_service(service_name)
    ########## quotad, startup failure ##########
    try:
        if data['process_status'] == 'Off' and data_old['process_status'] == 'Off' :
           for index in xrange(len(service_name)):
                if service_status[service_name[index]] == 'On':
                    data['alarm_flag'] = 'True'
                    alarm_info['type'] = '600140014'
                    alarm_info['data'] = data['monitor_time']
                    alarm_info['severity'] = 'ERROR'
                    alarm_info['node'] = data['node']
                    alarm_info['message'] = 'quotad process startup failure'
                    os.system('digiocean vol start %s force'%service_name[index])
        ########## quotad, abnormal death ##########
        if data['process_status'] == 'Off' and data_old['process_status'] == 'On':
            for index in xrange(len(service_name)):
                if service_status[service_name[index]] == 'On':
                    data['alarm_flag'] = 'True'
                    alarm_info['type'] = '600140013'
                    alarm_info['data'] = data['monitor_time']
                    alarm_info['severity'] = 'WARNING'
                    alarm_info['node'] = data['node']
                    alarm_info['message'] = 'quotad process of abnormal death'
                    os.system('digiocean vol start %s force'%service_name[index])
    except Exception,e:
        digi_log.error("Alarm information, alarm_information_of_quotad() , caught exception: %s" % traceback.print_exc(e))
    ########## quotad, started sucessfully ##########
    if data['process_status'] == 'On' and data_old['process_status'] == 'Off':
        if data_old['alarm_flag'] == 'True':
            alarm_info['type'] = '700140007'
            alarm_info['data'] = data['monitor_time']
            alarm_info['severity'] = 'INFO'
            alarm_info['node'] = data['node']
            alarm_info['message'] = 'quotad process has been started sucessfully'

def deal_check_system_disk_data(data):
    message_dict = {}
    if data['system_disk_status'] == "ok":
        return None
    elif data['system_disk_status'] == "broke":
        message_dict['date'] = data['monitor_time']
        message_dict['type'] = "600070005"
        message_dict['severity'] = "CRITICAL"
        message_dict['message'] = "System disk was breakedown"
        message_dict['node'] = data['node_name']
        return message_dict

def deal_fan_speed_monitor_data(data, mongo_dict):
    message_dict = {}
#    threshold = {'600030001': 600.0, '700030001': 800.0,
#    '600030002': 25400.0, '700030002': 25300.0}
    if data['current_value'] >= threshold['600030002']:
        message_dict['type'] = "600030002"
        message_dict['severity'] = "ERROR"
        message_dict['message'] = "High Fan rotate speed"
    elif data['current_value'] <= threshold['600030001']:
        message_dict['type'] = "600030001"
        message_dict['severity'] = "ERROR"
        message_dict['message'] = "Low Fan rotate speed"
    elif (data['current_value'] > threshold['700030001'] and
            data['current_value'] > threshold['700030002']):
        type_list = ['600030001', '600030002', '700030001', '700030002']
        message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
        if not message:
            return None
        else:
            if message['severity'] == "ERROR":
                if message['message'] == "High Fan rotate speed":
                    message_dict['message'] = "High Fan rotate speed recorvered"
                    message_dict['severity'] = "INFO"
                    message_dict['type'] = "700030002"
                elif message['message'] == "Low Fan rotate speed":
                    message_dict['message'] = "Low Fan rotate speed recorvered"
                    message_dict['severity'] = "INFO"
                    message_dict['type'] = "700030001"
            else:
                return None
    message_dict['date'] = data['monitor_time']
    message_dict['node'] = data['node_name']
    message_dict['device'] = data['device_name']
    return message_dict

def deal_disk_size_monitor_data(data, mongo_dict, threshold):
    message_dict = {}
    zone_flag = 0
#    threshold = {'600070004': 80.0, '700070004': 70.0,
#    '600070006': 95.0, '700070005': 90.0}
    if data['device_name'] == "system_disk":
        if len(data) == 8:
            zone_flag += 1
            device_name = ("{0}-{1}".format(data['device_name'],
                                           data['zone_name']))
        else:
            device_name = data['device_name']
        if data['size_usage'] >= threshold['600070004']:
            message_dict['type'] = "600070004"
            message_dict['severity'] = "ERROR"
            if zone_flag == 0:
                message_dict['message'] = "High System_disk size usage"
            else:
                message_dict['message'] = "High System_disk Zone size usage"
        elif data['size_usage'] < threshold['700070004']:
            type_list = ['600070004', '700070004']
            message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
            if not message:
                return None
            else:
                if message['severity'] == "ERROR":
                    if zone_flag == 0:
                        message_dict['message'] = ("High System_disk "
                                                   "size usage recorvered")
                    else:
                        message_dict['message'] = ("High System_disk Zone "
                                                   "size usage recorvered")
                    message_dict['severity'] = "INFO"
                    message_dict['type'] = "700070004"
                else:
                    return None
        message_dict['node'] = device_name
    else:
        if data['size_usage'] >= threshold['600070006']:
            message_dict['type'] = "600070006"
            message_dict['severity'] = "ERROR"
            message_dict['message'] = "High Data_disk size usage"
        elif data['size_usage'] < threshold['700070005']:
            type_list = ['600070006', '700070005']
            message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
            if not message:
                return None
            else:
                if message['severity'] == "ERROR":
                    message_dict['message'] = ("High Data_disk size"
                                               " usage recorvered")
                    message_dict['severity'] = "INFO"
                    message_dict['type'] = "700070005"
                else:
                    return None
        message_dict['node'] = data['device_name']
    message_dict['date'] = data['monitor_time']
    return message_dict

def deal_disk_inode_monitor_data(data, mongo_dict, threshold):
    message_dict = {}
    zone_flag = 0
#    threshold = {'600070007': 90.0, '700070006': 80.0,
#                 '600070008': 90.0, '700070007': 80.0}
    if data['device_name'] == "system_disk":
        if len(data) == 8:
            zone_flag += 1
            device_name = ("{0}-{1}".format(data['device_name'], 
                                            data['zone_name']))
        else:
            device_name = data['device_name']
        if data['inode_usage'] >= threshold['600070007']:
            message_dict['type'] = "600070007"
            message_dict['severity'] = "ERROR"
            if zone_flag == 0:
                message_dict['message'] = "High System_disk inode usage"
            else:
                message_dict['message'] = "High System_disk Zone inode usage"
        elif data['inode_usage'] < threshold['700070006']:
            type_list = ['600070007', '700070006']
            message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
            if not message:
                return None
            else:
                if message['severity'] == "ERROR":
                    if zone_flag == 0:
                        message_dict['message'] = ("High System_disk inode "
                                                   "usage recorvered")
                    else:
                        message_dict['message'] = ("High System_disk Zone "
                                                   "inode usage recorvered")
                    message_dict['type'] = "700070006"
                    message_dict['severity'] = "INFO"
                else:
                    return None
        message_dict['node'] = device_name
    else:
        if data['inode_usage'] >= threshold['600070008']:
            message_dict['type'] = "600070008"
            message_dict['severity'] = "ERROR"
            message_dict['message'] = "High Data_disk inode usage"
        elif data['inode_usage'] < threshold['700070007']:
            type_list = ['600070008', '700070007']
            message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
            if not message:
                return None
            else:
                if message['severity'] == "ERROR":
                    message_dict['message'] = ("High Data_disk inode "
                                               "usage recorvered")
                    message_dict['severity'] = "INFO"
                    message_dict['type'] = "700070007"
                else:
                    return None
        message_dict['node'] = data['device_name']
    message_dict['date'] = data['monitor_time']
    return message_dict

def deal_power_monitor_data(data, mongo_dict):
    message_dict = {}
#    threshold = {'600040002': 13.224, '700040002': 12.918,
#                 '600040003': 10.521, '700040003': 10.776}
    if data['current_value'] >= threshold['600040002']:
        message_dict['type'] = "600040002"
        message_dict['severity'] = "ERROR"
        message_dict['message'] = "High Power volts"
    elif data['current_value'] <= threshold['600040003']:
        message_dict['type'] = '600040003'
        message_dict['severity'] = "ERROR"
        message_dict['message'] = "Low Power volts"
    elif (data['current_value'] > threshold['700040003'] and
         data['current_value'] < threshold['700040002']):
        type_list = ['600040002', '700040002' ,'600040003', '700040003']
        message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
        if not message:
            return None
        else:
            if message['severity'] == "ERROR":
                if message['message'] == "High Power volts":
                    message_dict['message'] = "High Power volts recorvered"
                    message_dict['severity'] = "INFO"
                    message_dict['type'] = "700040002"
                elif message['message'] == "Low Power volts":
                    message_dict['message'] = "Low Power volts recorvered"
                    message_dict['severity'] = "INFO"
                    message_dict['type'] = "700040003"
            else:
                return None
    message_dict['date'] = data['monitor_time']
    message_dict['node'] = data['node_name']
    message_dict['device'] = data['device_name']
    return message_dict

def deal_cpu_temp_monitor_data(data, mongo_dict):
    message_dict = {}
#    threshold = {'600010002': 98.0, '700010002': 95.0}
    if data['current_value'] >= threshold['600010002']:
        message_dict['type'] = "600010002"
        message_dict['severity'] = "ERROR"
        message_dict['message'] = "High Cpu temp"
    elif data['current_value'] < threshold['700010002']:
        type_list = ['600010002', '700010002']
        message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
        if not message:
            return None
        else:
            if message['severity'] == "ERROR":
                message_dict['message'] = "High Cpu temp recorvered"
                message_dict['severity'] = "INFO"
                message_dict['type'] = "700040002"
            else:
                return None
    message_dict['date'] = data['monitor_time']
    message_dict['node'] = data['node_name']
    message_dict['device'] = data['device_name']
    return message_dict

def deal_netcard_bond_monitor_data(data, mongo_dict):
    message_dict = {}
    up_list = []
    down_list = []
    up_number = 0
    if data['bond_status'] == "up":
        for netcard_info in data['netcard_info']:
            if netcard_info['netcard_status'] == "up":
                up_list.append(netcard_info['netcard_name'])
                up_number += 1
            else:
                down_list.append(netcard_info['netcard_name'])
        type_list = ['600080002', '700080002']
        message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
        if not message:
            return None
        else:
            bond_rank = int(message['message'][0])
            if len(data['netcard_info']) == up_number:
                if bond_rank < up_number:
                    message_dict['severity'] = "INFO"
                    message_dict['type'] = "700080003"
                    message_dict['message'] = ("{0} bond demotion recorvered, "
                                               "all netcard up."
                                               .format(up_number))
                elif bond_rank == up_number:
                    return None
            elif len(data['netcard_info']) > up_number:
                if up_number > bond_rank:
                    message_dict['severity'] = "INFO"
                    message_dict['type'] = "700080002"
                    message_dict['message'] = ("{0} bond demotion part "
                                               "recorvered, up:{1}; down:{2}."
                                               .format(up_number,
                                                       up_list, down_list))
                elif up_number <= bond_rank:
                    message_dict['severity'] = "ERROR"
                    message_dict['type'] = "600080002"
                    message_dict['message'] = ("{0} bond demotion, up:{1};"
                                               " down:{2}."
                                               .format(up_number,
                                                       up_list, down_list))
    else:
        message_dict['severity'] = "ERROR"
        message_dict['type'] = "600080002"
        message_dict['message'] = "0 bond demotion, all netcard down."
    message_dict['date'] = data['monitor_time']
    message_dict['node'] = data['node_name']
    message_dict['device'] = data['device_name']
    return message_dict

def deal_netcard_speed_monitor_data(data, mongo_dict):
    message_dict = {}
    if data['current_speed'] < data['theoretical_value']:
        message_dict['severity'] = "ERROR"
        message_dict['type'] = "600080003"
        message_dict['message'] = "Network bandwidth demotion"
    else:
        type_list = ['600080003', '700080004']
        message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
        if not message:
            return None
        if message['severity'] == "ERROR":
            message_dict['severity'] = "INFO"
            message_dict['type'] = "700080004"
            message_dict['message'] = "Network bandwidth demotion recorvered"
        else:
            return None
    message_dict['date'] = data['monitor_time']
    message_dict['node'] = data['node_name']
    message_dict['device'] = data['device_name']
    return message_dict

def deal_disk_smart_detection_data(data):
    message_dict = {}
    exception_message = []
    for info in data['smart_info']:
        if info[3] < info[5]:
            exception_message.append(info)
    if exception_message:
        message_dict['type'] = "600070002"
        message_dict['severity'] = "ERROR"
        message_dict['message'] = ("smart detection abnormal, "
                                   "abnormal info: {0}"
                                   .format(exception_message))
        return message_dict
    else:
        type_list = ['600070002', '700070002']
        message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
        if not message:
            return None
        if message['severity'] == "ERROR":
            message_dict['severity'] = "INFO"
            message_dict['type'] = "700070002"
            message_dict['message'] = "smart detection abnormal recovered"
        else:
            return None
    messge_dict['date'] = data['monitor_time']
    message_dict['node'] = data['node_name']
    message_dict['device'] = data['device_name']
    return message_dict

def deal_detection_node_connection_data(data, mongo_dict):
    message_dict = {}
    if data['connected_number'] == (data['node_number'] - 1):
        type_list = ['700080001', '600080001']
        message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
        if not message:
            return None
        else:
            if message['severity'] == "ERROR":
                message_dict['severity'] = "INFO"
                message_dict['type'] = "700080001"
                message_dict['message'] = "Network connected back to normal."
            else:
                return None
    elif data['connected_number'] > (data['node_number']/2):
        message_dict['type'] = "600080001"
        message['severity'] = "ERROR"
        message_dict['message'] = ("Network connected failed, node is: {0}."
                                   .format(data['ping_failed']))
    else:
        return None
    message_dict['date'] = data['monitor_time']
    message_dict['node'] = data['node_name']
    message_dict['device'] = data['device_name']
    return message_dict

def deal_redundancy_power_rank_monitor_data(data, mongo_dict):
    message_dict = {}
    down_list = []
    if data['power_rank'] == 2:
        type_list = ['600040001', '700040001']
        message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
        if not message:
            return None
        else:
            if message['severity'] == "ERROR":
                message_dict['severity'] = "INFO"
                message_dict['type'] = "700040001"
                message_dict['message'] = "redundancy power demotion recorvered"
            else:
                return None
    else:
        if data['module_info']['module1'] != 'ok':
            down_list.append('module1')
        if data['module_info']['module2'] != 'ok':
            down_list.append('module2')
        message['severity'] = "ERROR"
        message_dict['type'] = "600040001"
        message_dict['message'] = ("redundancy power demotion, "
                                  "down module: {0}".format(down_list))
    message_dict['date'] = data['monitor_time']
    message_dict['node'] = data['node_name']
    message_dict['device'] = data['device_name']
    return message_dict

def deal_cpu_usage_monitor_data(data, mongo_dict, threshold):
    message_dict = {}
    if data['cpu_usage'] >= threshold['600010001']:
        message['severity'] = "WARNING"
        message_dict['type'] = "600010001"
        message_dict['message'] = "High CPU usage"
    elif data['cpu_usage'] < threshold['700010001']:
        type_list = ['600010001', '700010001']
        message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
        if not message:
            return None
        else:
            if message['severity'] == "WARNING":
                message['severity'] = "INFO"
                message_dict['type'] = "700010001"
                message_dict['message'] = "CPU usage back to normal."
            else:
                return None
    message_dict['date'] = data['monitor_time']
    message_dict['node'] = data['node_name']
    message_dict['device'] = data['device_name']
    return message_dict

def deal_mem_usage_monitor_data(data, mongo_dict, threshold):
    message_dict = {}
    if data['men_usage'] >= threshold['600020001']:
        message_dict['severity'] = "WARNING"
        message_dict['type'] = "600020001"
        message_dict['message'] = "High MEM usage"
    if data['men_usage'] < threshold['700020001']:
        type_list = ['600020001', '700020001']
        message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
        if not message:
            return None
        else:
            if message['severity'] == "WARNING":
                message_dict['severity'] = "INFO"
                message_dict['type'] = "700020001"
                message_dict['message'] = "MEM occupy back to normal."
            else:
                return None
    message_dict['date'] = data['monitor_time']
    message_dict['node'] = data['node_name']
    message_dict['device'] = data['device_name']
    return message_dict

def deal_udev_monitor_disk_data(data, mongo_dict):
    message_dict = {}
    if data['disk_tatus'] == 'down':
        message_dict['severity'] = "ERROR"
        message_dict['type'] = "600070003"
        message_dict['message'] = "disk was uprooted"
    if data['disk_tatus'] == 'up':
        type_list = ['600070003', '700070003']
        message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
        if not message:
            return None
        else:
            if message['severity'] == "ERROR":
                message_dict['severity'] = "INFO"
                message_dict['type'] = "700070003"
                message_dict['message'] = "disk wsw inserted"
            else:
                return None
    message_dict['date'] = data['monitor_time']
    message_dict['node'] = data['node_name']
    message_dict['device'] = data['device_name']
    return message_dict

def deal_data_disk_rdwr_monitor_data(data, mongo_dict):
    message_dict = {}
    if data['disk_write'] == 'failed' or data['disk_read'] == 'failed':
        message_dict['severity'] = "ERROR"
        message_dict['type'] = "600070001"
        message_dict['message'] = ("data disk read or write abnormal, "
                                   "write: {0}; read: {1}.".format(
                                   data['disk_write'], data['disk_read']))
    else:
        type_list = ['600070001', '700070001']
        message = get_alarm_info_in_alarmcol(type_list, data, mongo_dict)
        if not message:
            return None
        else:
            if message['severity'] == "ERROR":
                message_dict['severity'] = "INFO"
                message_dict['type'] = "700070001"
                message_dict['message'] = ("data disk read or write abnormal "
                                           "recovered")
            else:
                return None
    message_dict['date'] = data['monitor_time']
    message_dict['node'] = data['node_name']
    message_dict['device'] = data['device_name']
    return message_dict

def alarm_information_of_soft_raid (data, mongo_dict):
    dict = {}
    if not data:
        digi_log.info ("data is None")
        return dict
    if data['monitor_type'] == 'raid_monitor':
        if data['raid_type'] == 'Failed':
            dict['type'] = '600090002'
            dict['severity'] = 'CRITICAL'
            dict['message'] = 'raid service is damage'
        elif data['raid_type'] == 'Degraded':
            dict['type'] = '600090001'
            dict['severity'] = 'ERROR'
            dict['message'] = 'raid service is degraded'
        elif data['raid_type'] == 'NewArray':
            dict['type'] = '700090001'
            dict['severity'] = 'INFO'
            dict['message'] = 'new raid service'
        elif data['raid_type'] == 'RebuildStart':
            dict['type'] = '700090002'
            dict['severity'] = 'INFO'
            dict['message'] = 'raid service rebuild start'
        elif data['raid_type'] == 'RebuildFinished':
            find_dict = {
                    'monitor_rebuild' : data['monitor_rebuild'],
                    'node' : data['node'],
                    'raid_name' : data['raid_name'],
                    'raid_type' : 'RebuildStart',
                    'UUID' : data['raid_device_uuid']
                    }
            raid_info = find_raid_info_from_db (find_dict, mongo_dict)
            if raid_info == -1:
                digi_log.error ("find raid info failed")
                dict = {}
                return dict
            old_active_device_num = raid_info['raid_device_active_num']
            current_active_device_num = data['raid_device_active_num']
            if old_active_device_num == current_active_device_num:
                dict['type'] = '600090003'
                dict['severity'] = 'ERROR'
                dict['message'] = 'raid service rebuild failed'
            elif old_active_device_num < current_active_device_num:
                raid_state = data['raid_status']
                if raid_state == 'degraded':
                    dict['type'] = '700090003'
                    dict['severity'] = 'INFO'
                    dict['message'] = 'raid service part of the repair complete'
                    data['device'] = data['active_disks'] + data['spare_disks']
                elif raid_state == 'clean':
                    dict['type'] = '700090004'
                    dict['severity'] = 'INFO'
                    dict['message'] = 'raid service rebuild finish'
                else:
                    digi_log.info ("other event")
                    return None
            else:
                digi_log.info ("other event")
                return None
        else:
            digi_log.info ("other event")
            return None
        if data['device'] != '--' and data['device']:
            dict['device'] = data['device']
        else:
            dict['device'] = '--'
        dict['node'] = data['node']
        dict['data'] = data['data']
        dict['servicename'] = data['servicename']
        return dict

def disk_mount_alarm_filter (data):
    dict = {}
    if data['monitor_type_disk_mount'] == 'disk_mount_failed':
        dict['data'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        dict['type'] = '600130001'
        dict['severity'] = 'ERROR'
        dict['servicename'] = data['servicename']
        dict['message'] = "disk mount failed"
        dict['node'] = data['node']
        dict['device'] = data['device']
    elif data['monitor_type_disk_mount'] == 'disk_remount_success':
        dict['data'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        dict['type'] = '700130001'
        dict['severity'] = 'INFO'
        dict['servicename'] = data['servicename']
        dict['message'] = "disk remount success"
        dict['node'] = data['node']
        dict['device'] = data['device']
    return dict

def service_usage_monitor_filter (data, threshold={}):
    dict = {}
    if data['monitor_type'] == "vol_size":
        total_size = data['use_size'] + data['not_use_size']
        use_percent = (data['use_size'] / total_size) * 100
        if use_percent >= threshold['600160001']:
            message = "The service %s use_space is insufficient "% data['vol_name']
            digi_log.error(message, 3)
            dict['type'] = '600160001'
            dict['severity'] = 'ERROR'
            dict['message'] = message
        elif user_percent <= threshold['700160001']:
            message = "The service %s use_space is recovery "% data['vol_name']
            digi_log.error(message, 3)
            dict['type'] = '700160001'
            dict['severity'] = 'INFO'
            dict['message'] = message
        else:
            return dict
        dict['servicename'] = data['vol_name']
        dict['data'] = data['data']
        dict['node'] = data['node']
        dict['device'] = '--'
        return dict

########## The filter function  ##########
def filter_and_probe_alarm_data(data, mongo_dict = {}, threshold = {}):
    alarm_info = {}
    index = {}

    process_list = ['battery','digioceanfs_gui','digioceand.pid','node_manager','smbd','nfs','cluster2','quota-mount','quotad','digioceanshd','disk_mount']
    if data['monitor_type'] in process_list:
        if not mongo_dict:
            return alarm_info

        ########## The corresponding data from the database ##########
        index['node'] = data['node']
        index['monitor_type'] = data['monitor_type']
        index['process_name'] = data['process_name']
        mongo_dict['monitorcol'].sort([('data',pymongo.DESCENDING)])
        mongo_dict['monitorcol'].limit(1)
        data_old = mongo_dict['monitorcol'].read(index)
        if not data_old:
            return alarm_info
        if data_old == -1:
            ret = reconnect_mongodb ('monitorcol', mongo_dict)
            if ret < 0:
                return alarm_info
            mongo_dict['monitorcol'].sort([('data',pymongo.DESCENDING)])
            mongo_dict['monitorcol'].limit(1)
            data_old = mongo_dict['monitorcol'].read(index)
            if not data_old:
                return alarm_info
            if data_old == -1:
                exit()

        ########## alarm information of battary ##########
        if data['monitor_type'] == 'battery':
            alarm_information_of_battary(data, data_old, alarm_info)
        ########## alarm information of digioceanfs_gui ##########
        if data['monitor_type'] == 'digioceanfs_gui':
            alarm_information_of_digioceanfs_gui(data, data_old, alarm_info)
        ########## alarm information of digioceand ##########
        if data['monitor_type'] == 'digioceand.pid':
            alarm_information_of_digioceand(data, data_old, alarm_info)
        ########## alarm information of node_manager ##########
        if data['monitor_type'] == 'node_manager':
            alarm_information_of_node_manager(data, data_old, alarm_info)
        ########## alarm information of Cifs ##########
        if data['monitor_type'] == 'smbd':
            alarm_information_of_Cifs(data, data_old, alarm_info)
        ########## alarm information of Nfs ##########
        if data['monitor_type'] == 'nfs':
            alarm_information_of_Nfs(data, data_old, alarm_info)
        ########## alarm information of service mount ##########
        if data['monitor_type'] == 'cluster2':
            alarm_information_of_service_mount(data, data_old, alarm_info)
        ########## alarm information of service quota ##########
        if data['monitor_type'] == 'quota-mount':
            alarm_information_of_service_quota(data, data_old, alarm_info)
        if data['monitor_type'] == 'quotad':
            alarm_information_of_quotad(data, data_old, alarm_info);
        ########## alarm information of digioceanshd ##########
        if data['monitor_type'] == 'digioceanshd':
            alarm_information_of_digioceanshd(data, data_old, alarm_info)
        ########## alarm information of disk mount ##########
        if data['monitor_type'] == 'disk_mount':
            alarm_information_of_disk_mount(data, data_old, alarm_info)

    if data['monitor_type'] == "check_system_disk":
        alarm_dict = deal_check_system_disk_data(data)
    elif data['monitor_type'] == "fan_speed_monitor":
        alarm_dict = deal_fan_speed_monitor_data(data, mongo_dict)
    elif data['monitor_type'] == "disk_size_monitor":
        alarm_dict = deal_disk_size_monitor_data(data, mongo_dict, threshold)
    elif data['monitor_type'] == "disk_inode_monitor":
        alarm_dict = deal_disk_inode_monitor_data(data, mongo_dicti, threshold)
    elif data['monitor_type'] == "power_volts_monitor":
        alarm_dict = deal_power_monitor_data(data, mongo_dict)
    elif data['monitor_type'] == "cpu_temp_monitor":
        alarm_dict = deal_cpu_temp_monitor_data(data, mongo_dict)
    elif data['monitor_type'] == "netcard_bond_monitor":
        alarm_dict = deal_netcard_bond_monitor_data(data, mongo_dict)
    elif data['monitor_type'] == "netcard_speed_monitor":
        alarm_dict = deal_netcard_speed_monitor_data(data, mongo_dict)
    elif data['monitor_type'] == "disk_smart_detection":
        alarm_dict = deal_disk_smart_detection_data(data)
    elif data['monitor_type'] == "detection_node_connection":
        alarm_dict = deal_detection_node_connection_data(data, mongo_dict)
    elif data['monitor_type'] == "redundancy_power_rank_monitor":
        alarm_dict = deal_redundancy_power_rank_monitor_data(data, mongo_dict)
    elif data['monitor_type'] == "cpu_usage_monitor":
        alarm_dict = deal_cpu_usage_monitor_data(data, mongo_dict, threshold)
    elif data['monitor_type'] == "mem_usage_monitor":
        alarm_dict = deal_mem_usage_monitor_data(data, mongo_dict, threshold)
    elif data['monitor_type'] == "udev_monitor_disk":
        alarm_dict = deal_udev_monitor_disk_data(data, mongo_dict)
    elif data['monitor_type'] == "data_disk_rdwr_monitor":
        alarm_dict = deal_data_disk_rdwr_monitor_data(data, mongo_dict)
    elif data['monitor_type'] == 'raid_monitor':
        alarm_info = alarm_information_of_soft_raid(data, mongo_dict)
    elif data['monitor_type'] == 'disk_mount_report':
        alarm_info = disk_mount_alarm_filter (data)
    elif data['monitor_type'] == "vol_size":
        alarm_info = service_usage_monitor_filter (data, threshold)
    return alarm_info

def update_write_event_to_db(data, alarmcol, monitor, thresholdcol, aflag=False, mongo_dict={}):

    updata_list = ['redundancy_power_rank_monitor','detection_node_connection','check_system_disk','disk_smart_detection','netcard_speed_monitor',
                   'netcard_bond_monitor','cpu_temp_monitor','disk_inode_monitor','disk_size_monitor','disk_inode_monitor','disk_size_monitor',
                   'power_volts_monitor','fan_speed_monitor','node_size_monitor']

    jiaolong_updata_list = ['vol_size']

    tongle_updata_list = ['battery','digioceanfs_gui','digioceand.pid','node_manager','smbd','nfs','cluster2','quota-mount',
                          'quotad','digioceanshd','disk_mount','cluster2','battery','quota-mount']

    insert_list = ['mem_usage_monitor','cpu_usage_monitor','node_size_monitor','netcard_flux_monitor','disk_io_monitor','raid_monitor','disk_mount_report']

    thresholdcol_list = ['disk_size_monitor','disk_inode_monitor','cpu_usage_monitor','mem_usage_monitor']

    threshold = {}
    match  = {}
    ret = -1

    alarm_data = {}

    if data['monitor_type'] in updata_list:
        match = {'monitor_type':data['monitor_type'], 'node_name': data['node_name'],'device_name':data['device_name']}

    elif data['monitor_type'] in jiaolong_updata_list:
        match = {'monitor_type':data['monitor_type'],'node':data['node'],'vol_uuid':data['vol_uuid']}

    elif data['monitor_type'] in tongle_updata_list:
        match = {'process_name':data['process_name'],'monitor_type':data['monitor_type']}

    elif  data['monitor_type'] in insert_list:
        if isinstance(monitor,Digi_Collection) is False:
            digi_log.error("isinstance(monitor,Digi_Collection) is False")
            return -1
        ret = monitor.write(data)
        digi_log.debug("write :"+data)
        if ret == -1:
            digi_log.error('write db false :',data)
            return -1
    else:
        digi_log.error ("Write the database type is wrong :"+data['monitor_type'])

    if match != {}:
        result = monitor.read(match)
        if len(result) > 0:
            updata = {'$set':data}
            ret = monitor.update(match,updata)
            digi_log.debug("updata :"+match)
            if ret == -1:
                digi_log.error("updata false :"+match)
                return  -1
        else:
            ret = monitor.write(data)
            digi_log.debug("write :"+data)
            if ret == -1:
                digi_log.error('write db false :',data)
                return -1

    if data['monitor_type'] in thresholdcol_list:
        threshold = update_probe_threshold_key(data['monitor_type'],thresholdcol)
    alarm_data = filter_and_probe_alarm_data(data, mongo_dict, threshold)
    if alarm_data:
        digi_debug ("The alarm information :"+data)
        if isinstance(monitor,Digi_Collection) is False:
            digi_log.error("isinstance(monitor,Digi_Collection) is False")
            return -1

        if alarm_handle_process(alarm_data,instance) is False:
            ret = get_max_alarm_collection_id(alarmcol,alarm_data)
            if ret == -1:
                return -1

    return True

def db_coalesced_choice(db,data,action = False):

    result = []
    if isinstance(db,Digi_Collection) is False:
        return -1

    result = db.read(data)
    if result == []:
        digi_debug("Database is not contained in this data entry")
        return 0
    elif result > 1 and action == True:
        pass
    else:
        return 1

def alarm_handle_process1(htype,data):

    matches = {'type':htype,'node':data['node'],'servicename':data['servicename'],'device':data['device'],'handled':False}
    up_data = {'$set':{'handled':True}}
    ret = instance.update(matches,up_data,True)
    if ret == -1:
        digi_error("May be the original error data didn't write ! data :"+data)
    return ret

def alarm_handle_process(data,instance):
    matchup = [700010001,700010002,700020001,700030001,700030002,
               700040001,700040002,700040003,700050001,700060001,
               700070002,700070003,700070004,700080001,700110001,
               700120001,                              700130001]

    a = {'700140001':[600140001,600140002],'700140002':[600140003,600140004],'700140003':[600140005,600140006],
         '700140004':[600140007,600140008],'700140005':[600140009,600140010],'700140006':[600140011,600140012],
         '700140007':[600140013,600140014],                         '700090004':[600090001,600090002]}

    nomatchup = {'700070005':600070006,'700070006':600070007,'700070007':600070008,'700080004':600080003,
                 '700080003':600080002,                '700090002':600090003}

    directs = [700150001,700150002,           700080002,700090001]
    
    atype = data['type']

    if atype//100000000 == 6:
        if db_coalesced_choice(instance,data) == 0:
            return get_max_alarm_collection_id(instance,data)
 
    elif atype//100000000 == 7:
        if atype in matchup:
            htype = int(str(atype).replace('7','6',1))
            ret = alarm_handle_process1(htype,data)
            if ret == -1:
                digi_error("Update the error message to make mistakes")
            if db_coalesced_choice(instance,data) == 0:
                ret = get_max_alarm_collection_id(instance,data)
                if ret == -1:
                    return -1

        elif str(atype) in a:
            result = a[str(data['type'])]
            for i in range(0,1):
                ret = alarm_handle_process1(result[i].data)
                if ret == -1:
                    digi_error("Update the error message to make mistakes")
                if db_coalesced_choice(instance,data) == 0:
                    ret = get_max_alarm_collection_id(instance,data)
                    if ret == -1:
                        return -1

        elif atype in nomatchup:
            ret = alarm_handle_process1(nomatchup[data['type']],data)
            if ret == -1:
                digi_error("Update the error message to make mistakes")
            if db_coalesced_choice(instance,data) == 0:
                ret = get_max_alarm_collection_id(instance,data)
                if ret == -1:
                    return -1

        elif atype in directs:
            if db_coalesced_choice(instance,data) == 0:
                ret = get_max_alarm_collection_id(instance,data)
                if ret == -1:
                    return -1
        else:
            digi_error("atype is : "+atype+"data is "+data)
    else:
        digi_error("atype is : "+atype+"data is "+data)
    return 0
