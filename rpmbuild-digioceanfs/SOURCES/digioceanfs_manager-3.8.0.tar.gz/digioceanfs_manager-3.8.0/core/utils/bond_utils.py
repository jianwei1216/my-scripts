#-*- coding: utf-8 -*-
#peranetcard.py

import os
import sys 
import re
import time
import subprocess
import string

import settings

#currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
#if currpath not in sys.path:
#        sys.path.append(currpath)
#from base import Page,stow,session,web,menus,_
#import settings
#from libcommon.bonding.bond import *
from manager_utils import *
import net_utils_tool
from bond_utils_tool import *

#ETHFILE = "/etc/network/interfaces"
ETHFILE = settings.ETHFILE 

#class netcardbond(Page):
#    def _logic(self):
#        self.content = stow({
#        
#        })
#        self.setup = stow({
#            'breadcrumbs':[stow({'showname':_("network"),'name':'Network','url':'/netcardbond'}),stow({'showname':_("netcardbond"),'name':'netcardbond','url':''})],
#            'menus':menus,
#            'template':'netcardbond'
#        })
#    def _action(self):
#        params = web.input()
#    def GET(self):
#        return self.render()
#    def POST(self):
#        return self.action()
#        
#class listbonds(Page):
#    def _logic(self):
#        ethnames = getEthNames()
#        bondnames = getBondNames()
#        bondinfos = []
#        for bond in bondnames:
#            bondinfo = {}
#            bondinfo['name'] = bond
#            bondinfo['slaves'] = ','.join(getSlaveNames(bond))
#            bondinfo['mode'] = getBondMode(bond)
#            bondinfos.append(bondinfo)
#        unslaves = getUnslaveEthNames()
#        i = 0 
#        ln = len(ethnames)
#        while i < ln: 
#            j = i + 1 
#            while j < ln: 
#                if (cmp(ethnames[i],ethnames[j]) > 0) and (len(ethnames[i]) >= len(ethnames[j])):
#                    tmp = ethnames[i]
#                    ethnames[i] = ethnames[j]
#                    ethnames[j] = tmp 
#                j += 1
#            i += 1
#        i = 0 
#        ln = len(unslaves)
#        while i < ln: 
#            j = i + 1 
#            while j < ln: 
#                if (cmp(unslaves[i],unslaves[j]) > 0) and (len(unslaves[i]) >= len(unslaves[j])):
#                    tmp = unslaves[i]
#                    unslaves[i] = unslaves[j]
#                    unslaves[j] = tmp 
#                j += 1
#            i += 1
#        ethstr = ','.join(ethnames)
#        self.content = stow({
#            'ethnames':ethnames,
#            'unslaves':unslaves,
#            'bondnames':bondnames,
#            'ethstr':ethstr,
#            'bondinfos':bondinfos
#        })
#        self.setup = stow({
#            'template':'listbonds'
#        })
#    def GET(self):
#        return self.render(ajax=True)
#class setbond(Page):
#    def _logic(self):
#        modelist = ['Balance Round-Robin','Active Backup','Balance - XOR','Broadcast','802.3ad','Balance-tlb','Balance-alb']
#        modedeslist = [
#            "Round-Robin会将封包的传输使用“以序循环”的拍程方式，将封包平均分散在可用的网络接口。这种模式可以有效将网络通讯的数据流量分散到所有的网络连记上，因而可提升系统的传输效能。",
#            "网络容错提供了一个更可靠的网络使用环境，假设主要的网络端口因为硬件或是线路出现问题的话，则备援的网络端口会自动接替主网络端口进行传输，不会造成网络传输的中断。当主网络端口恢复正常后，则传输的工作会自动转移到主网络端口上。",
#            "Balance XOR会将封包的传输使用“哈希法”的拍程方式，将封包平均分散在可用的网络接口。这种模式可以有效将网络通讯的数据流量分散到所有的网络联机上，因而可提升系统的传输效能。",
#            "Broadcast提供了一个可靠的网络使用环境，它会同时将封包传给可用的网络接口。",
#            "此模式是根据802.3ad规范把所有的网络界面丛集在一起并分享同样的网络速度和双工模式。此模式提供负载平衡和容错功能，但需要一个交换机，支持IEEE802.3ad动态链路聚合LACP模式与正确的配置。",
#            "此模式不需要任何特殊的交换机支持。对外的数据流是根据目前每个网络接口的网络负载（计算相对速度）平均的对外送出。而对内传入流量是以目前正在运作中的接口来接收。如果接收的接口故障时，另一个接口会实时套用其MAC地址并马上接替其工作。此模式同时提供负载平衡和容错功能。",
#            "此模式拥有模式五所有的特性之外并包括IPv4的流量接收负载平衡（rlb）,并且不需要任何特殊的交换机支持。接收负载平衡主要是透过ARP的协议来答复本机系统的网络数据流。此模式提供负载平衡和容错功能。"
#        ]
#        mode = listBondMode()
#        unslaves = getUnslaveEthNames()
#        i = 0 
#        ln = len(unslaves)
#        while i < ln: 
#            j = i + 1 
#            while j < ln: 
#                if (cmp(unslaves[i],unslaves[j]) > 0) and (len(unslaves[i]) >= len(unslaves[j])):
#                    tmp = unslaves[i]
#                    unslaves[i] = unslaves[j]
#                    unslaves[j] = tmp 
#                j += 1
#            i += 1
#        self.content = stow({
#            'mode':mode,
#            'modelist':modelist,
#            'modedeslist':modedeslist,
#            'unslaves':unslaves
#        })
#        self.setup = stow({
#            'template':'setbond'
#        })
def load_mod(mod_name):
    cmd = []
    cmd.append("/sbin/modprobe")
    cmd.append(mod_name)
    ret = execute(cmd)

def rm_mod(mod_name):
    cmd = []
    cmd.append("/sbin/rmmod")
    cmd.append(mod_name)
    ret = execute(cmd)

def network_restart():
    cmd = []
    cmd.append("/etc/init.d/network")
    cmd.append("restart")
    ret = execute(cmd)

def ifdown_eth(ethname):
    cmd = []
    cmd.append("ifdown")
    cmd.append(ethname)
    ret = execute(cmd)

def ifup_lo():
    cmd = []
    cmd.append("ifup")
    cmd.append("lo")
    ret = execute(cmd)

def set_bond(eth_list, bond_mode, bond_addr_eth):
    """
        return code specify:
        1:    bonding set success
        2:    bonding set failed    
        3:    eth amount less than 2
    """
    ethnames  = eth_list
    mode      = bond_mode
    whichchip = bond_addr_eth

    bondname = getNewBondName()
    if len(ethnames) <= 1:
        return 3
    ethnames.sort()
    load_mod("bonding")

    addr = getEthAddr(whichchip)
    for ethname in ethnames:
        ethinfo = {}
        ETHFILE = settings.NETWORKCONFDIR + 'ifcfg-' + ethname
        ethinfo['BOOTPROTO'] = 'none'
        ethinfo['MASTER'] = bondname
        ethinfo['SLAVE'] = 'yes'
        net_utils_tool.write_eth_file(ETHFILE,ethinfo)
    BONDFILE = settings.NETWORKCONFDIR + 'ifcfg-' + bondname
    if not os.path.exists(BONDFILE):
        os.system('touch %s' % BONDFILE) 
    bondinfo = {}
    bondinfo['DEVICE'] = bondname
    bondinfo['BOOTPROTO'] = 'none'
    bondinfo['ONBOOT'] = 'yes'
    bondinfo['IPADDR'] = addr[0]
    if addr[1]:
        bondinfo['NETMASK'] = addr[1]
    if addr[2]:
        bondinfo['BROADCAST'] = addr[2]
    if addr[3]:
        bondinfo['GATEWAY'] = addr[3]
    net_utils_tool.write_eth_file(BONDFILE,bondinfo)

    # auto load bonding mode
    result = ''
    if os.path.exists('/etc/modprobe.d/bonding.conf'):
        f = open('/etc/modprobe.d/bonding.conf','r+')
        result = f.read()
        f.close()
    result += 'alias %s bonding\n' % bondname
    result += 'options bond0 miimon=100 mode=%s\n' % mode
    f = open('/etc/modprobe.d/bonding.conf','w+')
    f.write(result)
    f.close()

    network_restart()
    return 1

def del_bond(bondname):
    """
        return code specify:
        1:    del bond success
        2:    del bond failed
    """
    ethnames = getSlaveNames(bondname)
    for ethname in ethnames:
        ethinfo = {}
        ETHFILE = settings.NETWORKCONFDIR + 'ifcfg-' + ethname
        ethdic = net_utils_tool.read_eth_file(ETHFILE)
        if '#BOOTPROTO' in ethdic:
            ethinfo['BOOTPROTO'] = ethdic['#BOOTPROTO']
        else:
            ethinfo['BOOTPROTO'] = ''
        ethinfo['MASTER'] = ''
        ethinfo['SLAVE'] = ''
        net_utils_tool.write_eth_file(ETHFILE,ethinfo)        

    BONDFILE = settings.NETWORKCONFDIR + 'ifcfg-' + bondname
    os.system('sudo rm %s' % BONDFILE)    

    #for ethname in ethnames:
    #    ifdown_eth(ethname)

    rm_mod("bonding")

    f = open('/etc/modprobe.d/bonding.conf','r+')
    result = f.read()
    f.close()
    result = re.sub('alias %s bonding\noptions %s miimon=100 mode=\d+\n' % (bondname,bondname),'',result)
    f = open('/etc/modprobe.d/bonding.conf','w+')
    f.write(result)
    f.close()
    
    network_restart()

    #ifup_lo()

    return 0

if __name__ == "__main__":
    ret = set_bond(["eth0","eth1"], 5, "eth0")
    digi_debug("set_bond return:%d" % (ret),5)
#    del_bond("bond0")
