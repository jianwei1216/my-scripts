# -*- coding: utf-8 -*-
import os
import re
import string
import subprocess

import net_utils
import net_utils_tool

from manager_utils import *
from manager_protocol import *

# TODO: FIX ERROR and EXCEPTION WITHOUT LOGGING

CMD_RSYSLOG = "/etc/init.d/rsyslog"
LOG_CONF_EXTENDS = "/etc/rsyslog.d/99-digioceanfs.conf"

def ipaddr_validation(ipaddr):
    if not net_utils_tool.check_ipaddress(ipaddr):
        return False
    
    return True

def ipaddr_is_lo(ipaddr):
    try: 
        m = re.match("^(\d+)\.(\d+)\.(\d+)\.(\d+)$",ipaddr)
    except:
        
        return False
    
    if m:
        if string.atoi(m.group(1)) == 127:
            return True
        
    return False

def ipaddr_is_local(ipaddr):
    if net_utils.host_is_local(ipaddr):
        return True
    
    return False

def config_as_mgr():
    
    fd = open(LOG_CONF_EXTENDS, 'w')
    
    try:
        sequence_of_strings = ["$ModLoad imudp\n","$UDPServerRun 514\n","daemon.info | /usr/local/digioceanfs_gui/libcommon/monitor_pipe\n"]
        fd.seek(0)
        fd.writelines(sequence_of_strings)
        fd.close()
        
    except:
        if not fd.closed:
            fd.close()
        return -1    
        
    return 0

def config_as_client(ipaddr):

    fd = open(LOG_CONF_EXTENDS, 'w')
    
    try:
        sequence_of_strings = ["$ModLoad imudp\n","$UDPServerRun 514\n","daemon.info @%s\n"%(ipaddr)]
        fd.seek(0)
        fd.writelines(sequence_of_strings)
        fd.close()
        
    except:
        if not fd.closed:
            fd.close()
        return -1    

    return 0

#### #### #### #### #### #### 

def rsyslog_start(params):
    command = CMD_RSYSLOG 
    if not os.path.exists(command):
        return -1
    
    try:
        # return subprocess.call([command,'start'])
        subprocess.Popen('/etc/init.d/rsyslog'+' start'+' &> /dev/null',shell=True)
        
    except:
        return -1

    return 0

def rsyslog_stop(params):
    command = CMD_RSYSLOG
    if not os.path.exists(command):
        return -1

    try:
        # return subprocess.call([command,'stop'])
        subprocess.Popen('/etc/init.d/rsyslog'+' stop'+' &> /dev/null',shell=True)
    
    except:
        return -1
    
    return 0

def rsyslog_restart(params):
    command = CMD_RSYSLOG
    if not os.path.exists(command):
        return -1

    try:
        # return subprocess.popen([command,'restart','&>/dev/null'], shell=True)
        subprocess.Popen('/etc/init.d/rsyslog'+' restart'+' &> /dev/null',shell=True)
    
    except:
        return -1
    
    return 0
  
def rsyslog_add_config(params):
    mgr_ipaddr = params[0]
    if not ipaddr_validation(mgr_ipaddr):
        return -1
    
    if ipaddr_is_lo(mgr_ipaddr):
        return config_as_mgr()
    
    if ipaddr_is_local(mgr_ipaddr):
        return config_as_mgr()
    
    return config_as_client(mgr_ipaddr)
    
def rsyslog_del_config(params):
    
    try:
        if len(params) > 0 :
            ipaddr = params[0]
            
            if ipaddr_is_lo(ipaddr):
                return -1
            
            if not ipaddr_is_local(ipaddr):
                return 0
        
        if os.path.exists(LOG_CONF_EXTENDS):
            os.remove(LOG_CONF_EXTENDS)
        
    except:
        return -1
    
    return 0

CMD_START   = "start"
CMD_STOP    = "stop"
CMD_RESTART = "restart"
CMD_ADD     = "add"
CMD_DESTROY = "destroy"

rsyslog_cmd = { CMD_START   :  rsyslog_start,
                CMD_STOP    :  rsyslog_stop,
                CMD_RESTART :  rsyslog_restart,
                CMD_ADD     :  rsyslog_add_config,
                CMD_DESTROY :  rsyslog_del_config,
                };

def rsyslog_adapter(cmd, params):
    digi_debug("%s: doing CMD %s"%(RSYSLOG_REQUEST,cmd),5)
    ret = rsyslog_cmd[cmd](params)
    digi_debug("%s: done CMD %s"%(RSYSLOG_REQUEST,cmd),5)
    
    if (cmp(cmd, CMD_ADD) == 0) or (cmp(cmd, CMD_DESTROY) == 0):
        if ret == 0:
            digi_debug("%s restarted by %s"%(RSYSLOG_REQUEST,cmd),5)
            try: 
                ret = rsyslog_cmd[CMD_RESTART]([])
            
            except Exception:
                digi_debug("%s raise exception by %s"%(RSYSLOG_REQUEST,cmd),3)
                # exc_type, exc_value, exc_traceback = sys.exc_info()
                # print "*** print_tb:"
                # traceback.print_tb(exc_traceback, limit = 1, file=sys.stdout)
                # print "*** print_exception:"
                # traceback.print_exception(exc_type, exc_value, exc_traceback, limit = 2, file=sys.stdout)
                # print "*** print_exc:"
                # traceback.print_exc()
                # print "*** format_exc, first and last line:"
                # formatted_lines = traceback.format_exc().splitlines()
                # print formatted_lines[0]
                # print formatted_lines[-1]
                # print "*** format_exception:"
                # print repr(traceback.format_exception(exc_type, exc_value, exc_traceback))
                # print "*** extract_tb:"
                # print repr(traceback.extract_tb(exc_traceback))
                # print "*** format_tb:"
                # print repr(traceback.format_tb(exc_traceback))
                # print "*** tb_lineno:", exc_traceback.tb_lineno
                
                return  2
    # adapt to convention
    if ret != 0 :
        return 2
     
    return 1 

'''    
def test_suite():
    # print ipaddr_validation('10.10.1.1')
    # print ipaddr_validation('10.10.1')
    # print ipaddr_validation('10.10.11111.1')
    # print ipaddr_validation('10.10.1.a')
    
    # print ipaddr_is_lo('10.10.1.1')
    # print ipaddr_is_lo('127.0.0.1')
    
    # print ipaddr_is_local('10.10.1.1')
    # print ipaddr_is_local('10.10.5.120')
    
    # print config_as_mgr()
    print config_as_client('10.10.1.1')
    # print rsyslog_start()
    # print rsyslog_stop()
    # print rsyslog_restart()
    # print rsyslog_add_config('10.10.1.1')
    # print rsyslog_del_config()
    # print rsyslog_adapter("start", '10.10.1.1')
'''
