# -*- coding: utf-8 -*-
import time
import re
import os
import subprocess
import tempfile
#import Digioceanfs_error

from manager_utils import *

# createRaid(5, 256, ['sdo','sdp','sdq'] )

RAID_DEV_PREFIX="/dev/md"
RAID_DEV_PATH="/dev/"
RAID_SYMBOL_PATH="/dev/disk/by-id/"

DISK_RAID_LEVEL="MD_LEVEL"
DISK_RAID_UUID="MD_UUID"
DISK_RAID_EVENTS="MD_EVENTS"
DISK_RAID_DEVICES="MD_DEVICES"
DISK_RAID_UPDATE_TIME="MD_UPDATE_TIME"


def createRaid(level,chunk,devices):
    raidname = getNewRaidNum()
    logfile = open('/var/log/mdadm.log','a')
    devnum = len(devices)
    if level == '5':
        cmd = "%s -C %s -l%s -c%s -n%s -f 2>/dev/null" % ('/sbin/mdadm',raidname,level,chunk,devnum)
    else:
        cmd = "%s -C %s -l%s -c%s -n%s 2>/dev/null" % ('/sbin/mdadm',raidname,level,chunk,devnum)
    for dev in devices:
        cmd += " " + "/dev/disk/by-id/" + dev

    timestr = time.strftime("%b %d %X",time.localtime())
    print >> logfile, "%s nas admin: %s" % (timestr,cmd)

    cmd += ''' << EOF
yes
EOF
'''
    ste = os.system(cmd)
    print >> logfile, "%s nas admin: create raid return:%d" % (timestr, ste)
    if level != '0':
        cmd = "%s -w %s 2>/dev/null" % ('/sbin/mdadm',raidname)
        os.system(cmd)
    if ste == 256:
        print >> logfile, "%s nas admin: create raid fail" % timestr
        logfile.close()
        return ''
    else:
        print >> logfile, "%s nas admin: create raid succeed" % timestr
        logfile.close()
        os.system('/sbin/mdadm --detail --scan > /etc/mdadm/mdadm.conf')
        return raidname

def getNewRaidNum():
    bigestnum = 9 #TODO:this should be a constant
    mds = getRaidName()
    for md in mds:
        num = int(md[7:])
        if num > bigestnum:
            bigestnum = num

    bigestnum = bigestnum + 1
    return "/dev/md%s" % bigestnum

#########################################################
# get raidName from /proc/mdstat
# [/dev/md10,/dev/md11]
# 5+0 only get terminal raid name
#########################################################
def getRaidName():
    raids = []
    allmds = []

    raidfile = open('/proc/mdstat','r')
    lines = raidfile.readlines()
    raidfile.close()

    for line in lines:
        m = re.match("(^md\d+)\s+:\s",line)
        if m != None:
            allmds.append("/dev/" + m.group(1))
    allmds.sort()
    return allmds

#########################################################
# get the raid stat, build , alert ,ok ,error
#########################################################
def getRaidStat(md):
    mdlevel = getMdLevel(md)
    if mdlevel == '0':
        mdstat = checkRaid0(md)
    elif mdlevel == '1':
        mdstat = checkRaid1(md)
    elif mdlevel == '5':
        mdstat = checkRaid5(md)
    elif mdlevel == '6':
        mdstat = checkRaid6(md)
    elif mdlevel == '10':
        mdstat = checkRaid1(md)
    else: #5 + 0
        mdstat = checkRaid50(md)

    return mdstat
#########################################################
# check raid 0 from /proc/mdstat
# checkRaid1('/dev/md10'):
#   build,alert,error,ok
#########################################################
def checkRaid0(raidname):
    #(1) check the mdstat , no occur ?
    matstr = "%s.+\(F\).*" % raidname[5:]
    mdconf = open('/proc/mdstat','r')
    lines = mdconf.readlines()
    mdconf.close()

    for line in lines:
        if re.match(matstr,line):
            return 'error'
    #(2)check the mdadm command, no occur ?
    proc = subprocess.Popen("%s -D %s 2>/dev/null" % ('/sbin/mdadm',raidname),shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    result = proc.stdout.readlines() + proc.stderr.readlines()
    proc.wait()

    for line in result:
        if re.search(_("scsierr"),line) or re.search(_("scsidead"),line):
            return 'error'
    #(3) pvs error , occur here
    proc = subprocess.Popen(settings.pvscan,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    result = proc.stdout.readlines() + proc.stderr.readlines()
    proc.wait()
    for line in lines:
        if re.search(raidname,line):
            if re.search(_("pvserr"),line):
                return 'error'
    return 'ok'

#########################################################
# check raid 1 from /proc/mdstat
# checkRaid1('/dev/md10'):
#   build,alert,error,ok
#########################################################
def checkRaid1(raidname):
    mdposition = 0
    under_line = 0

    mdconf = open('/proc/mdstat','r')
    lines = mdconf.readlines()
    mdconf.close()

    lines.append('\n\n')

    i = 0
    while i < len(lines):
        if re.match("\A" + raidname[5:],lines[i]):
            mdposition = i
            break
        i += 1
    m = re.match(".*(sd\w+)\[\d+\]\(F\)",lines[mdposition])
    if m:
        defaultdev = m.group(1)
    underlinelen = lines[mdposition + 1].count('_')
    if underlinelen == 0:
        m = re.search('resync',lines[mdposition + 2]) #init = build
        if m:
            return 'build'
        else:
            return 'ok'
    elif underlinelen == 1:
        if re.search("recovery",lines[mdposition + 2]):
            return 'build'
        else:
            m = re.match(".*(sd\w+)\[\d+\]\(F\)",lines[mdposition]) #one disk fail,remove it
            if m:
                defaultdev = m.group(1)
                proc = subprocess.Popen("%s --remove %s /dev/%s 2>/dev/null" % ('/sbin/mdadm',raidname,defaultdev),shell=True,stdout=subprocess.PIPE)
                proc.wait()
            m = re.match(".*raid1\s(sd\w+)",lines[mdposition]) #another fail,error
            if m:
                proc = subprocess.Popen("%s /dev/%s" % (settings.raiduuid,m.group(1)),shell=True,stdout=subprocess.PIPE)
                result = proc.stdout.readline()
                proc.wait()
                if re.search("read error",result):
                    return 'error'
            return 'alert'
    else:
        return 'error'

#########################################################
# check raid 5 from /proc/mdstat
# checkRaid5('/dev/md10')
# build,alert,error,ok
#########################################################
def checkRaid5(raidname):
    mdconf = open('/proc/mdstat','r')
    lines = mdconf.readlines()
    mdconf.close()
    disks = unuseddisks()
    lines.append('\n\n')
    mdposition = 0
    underlinelen = 0

    i = 0
    while i < len(lines):
        if re.match("\A%s" % raidname[5:],lines[i]):
            mdposition = i
            break
        i += 1
    underlinelen = lines[mdposition + 1].count('_')
    if underlinelen == 0:
        if re.search("resync",lines[mdposition + 2]):
            return 'build'
        m = re.match(".*(sd\w+)\[\d+\]\(F\)",lines[mdposition])
        if m:
            defaultdev = m.group(1)
            proc = subprocess.Popen("%s --remove %s /dev/%s 2>/dev/null" % ('/sbin/mdadm',raidname,defaultdev),shell=True,stdout=subprocess.PIPE)
            proc.wait()
        return 'ok'
    elif underlinelen >= 2:
        return 'error'
    else:
        m = re.match(".*(sd\w+)\[\d+\]\(F\)",lines[mdposition])
        if m:
            defaultdev = m.group(1)
            proc = subprocess.Popen("%s --remove %s /dev/%s 2>/dev/null" % ('/sbin/mdadm',raidname,defaultdev),shell=True,stdout=subprocess.PIPE)
            proc.wait()
        if len(disks):
            diskname = disk.getDevFileName(disks[0])
            cmd = "%s --add %s %s 2>/dev/null" % ('/sbin/mdadm',raidname,diskname)
            proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
            proc.wait()
        if re.search('recovery',lines[mdposition + 2]):
            return 'build'
        else:
            return 'alert'

#########################################################
# check raid 6 from /proc/mdstat
# checkRaid6('/dev/md10')
# build,alert,error,ok
#########################################################
def checkRaid6(raidname):
    mdconf = open('/proc/mdstat','r')
    lines = mdconf.readlines()
    lines.append("\n\n")

    mdposition = 0
    underlinelen = 0
    i = 0
    conflen = len(lines)
    while i < conflen:
        if re.match("\A%s" % raidname[5:],lines[i]):
            mdposition = i
            break
        i += 1
    underlinelen = lines[mdposition + 1].count('_')
    if underlinelen == 0:
        if re.search('resync',lines[mdposition + 2]):
            return 'build'

        m = re.match(".*(sd\w+)\[\d+\]\(F\)",lines[mdposition])
        if m:
            defaultdev = m.group(1)
            proc = subprocess.Popen("%s --remove %s /dev/%s 2>/dev/null" % ('/sbin/mdadm',raidname,defaultdev),shell=True,stdout=subprocess.PIPE)
            proc.wait()
        return 'ok'
    elif underlinelen > 2:
        return 'error'
    else:
        m = re.match(".*(sd\w+)\[\d+\]\(F\)",lines[mdposition])
        if m:
            defaultdev = m.group(1)
            proc = subprocess.Popen("%s --remove %s /dev/%s 2>/dev/null" %('/sbin/mdadm',raidname,defaultdev),shell=True,stdout=subprocess.PIPE)
            proc.wait()
        if underlinelen == 1:
            if re.search('recovery',lines[mdposition + 2]):
                return 'build'
            else:
                return 'alert'
        if underlinelen == 2:
            if re.search('recovery',lines[mdposition + 2]):
                return 'build'
            else:
                return 'ser_alert'

#########################################################
# check raid (5+0)
# while getting included raid1(5) state
# stat: build,alert,error,ok
#   checkRaid50('/dev/md13')
#########################################################
def checkRaid50(raidname):
    statdisc = ['error','alert','build','ok']
    ipos = 3

    subraids = getSubRaid(raidname)

    for subraid in subraids:
        subraidstat = getRaidStat(subraid)
        statpos = statdisc.index(subraidstat)
        if statpos < ipos:
            ipos = statpos
    return statdisc[ipos]

#########################################################
# get the md state from /proc/mdstat
# inactive or active
# getRaidAct('/dev/md10')
# return 0(active), -1(unactive), 1(error)
#########################################################
def getRaidAct(md):
    if re.search('dev',md):
        md = md[5:]
    matchstr = "^%s\s+:\s+(\w+)\s" % md
    raidfile = open('/proc/mdstat','r')
    lines = raidfile.readlines()
    raidfile.close()
    for line in lines:
        m = re.match(matchstr,line)
        if m:
            if m.group(1) == "inactive":
                return -1
            elif m.group(1) == "active":
                return 0
            else:
                return 1
    return 1

#########################################################
# get raid level : 0,1,5,10,50 or -1 (error)
# getRaidLevel('/dev/md10')
#########################################################
def getMdLevel(mdname):
    mdlevel = '-1'
    matchstr = "^%s\s+:\s.*raid(\d+)\s(\w+)" % mdname[5:]
    raidfile = open('/proc/mdstat','r')
    lines = raidfile.readlines()
    #print lines
    raidfile.close()

    for line in lines:
        m = re.match(matchstr,line)
        #print m
        if m:
            mdlevel = m.group(1)
    return mdlevel

#########################################################
# get sub raid name in 10 , 50
# return raid name or []:
# ['/dev/md10','/dev/md11','/dev/md12']
#########################################################
def getSubRaid(raidname):
    if re.search('dev',raidname):
        raidname = raidname[5:]

    subraids = []
    matchstr = "^%s\s+:\s+.*raid\d\s+md\d+\[\d+\]" % raidname

    mdfile = open('/proc/mdstat','r')
    lines = mdfile.readlines()
    mdfile.close()

    for line in lines:
        m = re.match(matchstr,line)
        if m:
            m = re.findall('md\d+',line)
            if len(m) >= 0:
                if raidname in m:
                    m.remove(raidname)
                i = 0
                while i < len(m):
                    subraids.append('/dev/%s' % m[i])
                    i += 1
            break
    return subraids


#########################################################
# get raid size from file : /proc/mdstat
# K
#########################################################
def getRaidSize(raidname):
    if re.search('dev',raidname):
        raidname = raidname[5:] #/dev/md10 --> md10
    matchstr = "^%s\s+:\s+.*raid\d.*\n" % raidname
    mdconf = open('/proc/mdstat','r')
    lines = mdconf.readlines()
    mdconf.close()
    lines.append("\n")

    i = 0
    while i < len(lines):
        m = re.match(matchstr,lines[i])
        if m:
            m = re.match("\s+(\d+)",lines[i + 1])
            if m:
                return m.group(1)
        i += 1
    return '0'

def remove_mdadm_conf(uuid):
    try:
        handle = open("/etc/mdadm/mdadm.conf","r")
        conf_list = handle.readlines()
        for line in conf_list:
            if uuid in line:
                conf_list.remove(line)
                break
            
        str=''.join(conf_list)    
        handle.close()
        handle = open("/etc/mdadm/mdadm.conf","w")
        handle.write(str)
        handle.close()    
    except Exception,e:
        digi_debug("remove_mdadm_conf, caught exception: %s" % e,3)
    return 1
    

#########################################################
# delete raid from /proc/mdstat
# delRaid(raidName)
#  ("md10")
#########################################################
def delRaid(raidname):

    raid_name = '/dev/disk/by-id/' + raidname
    #raidname = os.readlink(raid_name)
    raidname = os.path.realpath(raid_name)
    raid = getDiskByRaidName(raidname.replace('/dev/',''))
    handle = os.popen("mdadm -D %s 2>/dev/null"%raidname)
    list=handle.readlines()
    for line in list:
        tmp = line.split()
        if tmp and tmp[0] == 'UUID':
            uuid = tmp[2].strip()
            break
    handle.close()
    cmd = "%s --stop %s 2>/dev/null" % ('/sbin/mdadm',raidname)
#    rglob.addlog("nas admin: %s" % cmd)
    raid_id = raid_name
    proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    result = '\t'.join(proc.stdout.readlines() + proc.stderr.readlines())
    ret = proc.wait()
    if not ret:
        try:
            os.remove(raid_id)
        except Exception,e:
            digi_debug("delRaid, caught exception: %s" % e,3)

#    if result.find('fail to stop array') >= 0:
#        rglob.addlog("nas admin: delete raid %s failed" % raid_name)
#        return 'fail to stop array'
#    rglob.addlog("nas admin: delete raid %s successfully")

    clearDisk(raid)
    remove_mdadm_conf(uuid)
#    os.remove(raid_name)
    return 0

def raidCreateSymbol(raidname):
    try:
        devpath = RAID_DEV_PATH + raidname
        symbolpath = RAID_SYMBOL_PATH + 'md-uuid-' + diskRaidInfo(devpath, DISK_RAID_UUID)
        os.symlink(devpath, symbolpath)
    except Exception, e:
        digi_debug("Create symbol link error", 3)
        #raise DigioceanfsError

#########################################################
# clear the raid information in the disk
# clearDisk(['sda','sdb'...])
#########################################################
def clearDisk(disks):
    for disk in disks:
        diskname = '/dev/' + disk
        proc = subprocess.Popen("%s --zero-super %s 2>/dev/null" % ('/sbin/mdadm',diskname),shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        proc.wait()
    return

#########################################################
# get raid from /proc/mdstat
# getDiskByRaidName(raidname)
#  ("md10")
#########################################################
def getDiskByRaidName(raidname):
    raid = []

    mdconf = open('/proc/mdstat','r')
    lines = mdconf.readlines()
    mdconf.close()

    if re.search('dev',raidname):
        raid = raidname[5:]
    matchstr = "^%s\s+:\s+.*raid\d+\s(sd\w.*)\n" % raidname
    for line in lines:
        m = re.match(matchstr,line)
        if m:
            temp = m.group(1).replace("(F)","").replace("(S)","") #if have (F) or (S) characters
            devs = re.split("\[\d+\]\s*",temp)
            for dev in devs:
                  if dev:
                      raid.append(dev)
                  else:
                      break
    return raid

#########################################
# get hotspare disks
# getHotspare('md11')
# return ['sda','sdb','sdc']
#########################################
def getHotspare(mdname):
    hotdisks = []

    mdname = "/dev/%s"%(mdname)
    submds = getSubRaid(mdname)
    if len(submds) == 0:
        submds = [mdname]

    for md in submds:
        proc = subprocess.Popen("%s -QD %s 2>/dev/null" % ('/sbin/mdadm',md),shell=True,stdout=subprocess.PIPE)
        lines = proc.stdout.readlines()
        proc.wait()

        for line in lines:
            m = re.match("\s+\d+\s+\d+\s+\d+\s+-\d*\s+spare\s+(.*)\n",line)
            if m:
                devname = m.group(1)
                hotdisks.append(devname.split('/')[2])

    return hotdisks

#########################################
# add hotspare to raid
# addHotspare(raidName,disks)
# ("md10",['sda','sdb'])
#########################################
def addHotspare(raidname,disk):
    raidlevel = getMdLevel(raidname)
    raidname = "/dev/disk/by-id/%s"%(raidname)
    if raidlevel == '0':
        return 60001

    #'5+0'
#    for ndisk in disks:
    diskname = '/dev/disk/by-id/' + disk
    cmd = "%s --add %s %s 2>/dev/null" % ('/sbin/mdadm',raidname,diskname)
    proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
    ret = proc.wait()
    os.system("mdadm -Ds > /etc/mdadm/mdadm.conf 2>/dev/null")
    os.system("echo PROGRAM /usr/bin/handle_raid_event.py >> /etc/mdadm/mdadm.conf")
    return ret

#########################################
# remove hotspare from md
# delHotspare(mdName,disks)
#   ("md10",['sda','sdb'])
#########################################
def delHotspare(md,somedisk):
    print md, somedisk
    md = "/dev/disk/by-id/%s"%(md)
    diskname = ''
    logfile = open('/var/log/mdadm.log','a')
    for disk in somedisk:
        #diskname = '%s /dev/disk/by-id/%s'%(diskname, disk)
        diskname = '/dev/%s'%(disk)
        cmd = "%s --fail %s %s 2>/dev/null" % ('/sbin/mdadm',md,diskname)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        msg = '\t'.join(proc.stdout.readlines() + proc.stderr.readlines())
        proc.wait()
        timestr = time.strftime("%b %d %X",time.localtime())
        print >> logfile, "%s nas admin: fail hot spare with command: %s" % (timestr,cmd)

        if msg.find('failed') >= 0:
            logfile.close()
            return 60005
        else:
            cmd = "%s --remove %s %s 2>/dev/null" % ('/sbin/mdadm',md,diskname)
            proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
            proc.wait()
            clearDisk(somedisk)
            print >> logfile, "%s nas admin: remove hot spare with command: %s" % (timestr,cmd)
    logfile.close()
    os.system("mdadm -Ds > /etc/mdadm/mdadm.conf 2>/dev/null")
    os.system("echo PROGRAM /usr/bin/handle_raid_event.py >> /etc/mdadm/mdadm.conf")
    return 0
#########################################################
# get all disks in mds
# form the /proc/mdstat get the sda,sdb...
#########################################################
def allDisksInMd():
    disks = []
    mdfile = open('/proc/mdstat','r')
    lines = mdfile.readlines()
    mdfile.close()

    for line in lines:
        m = re.match("^md\d+\s+:\s+.*raid",line)
        if m:
            m = re.match(".*raid\d+\s+(sd\w+.*)\n",line)
            if m:
                info = re.split(" ",m.group(1))
                for eachinfo in info:
                    disks.append(re.split("\[",eachinfo)[0])
    return disks

def diskRaidInfo(dev_path, info_type=''):
    disk_raid_info = dict()
    cmd = []
    cmd.append("/sbin/mdadm")
    if dev_path.find('md') >= 0:
        cmd.append("-D")
    else:
        cmd.append("-E")
    cmd.append(dev_path)
    cmd.append("--export")
    #cmd.append("2>/dev/null")
    tmp_img = tempfile.TemporaryFile()
    ret = execute(cmd, std=tmp_img)
    if dev_path.find('md') >= 0 and ret != 0:
        digi_debug("**NOTICE: Found broken raid device, stop it right now!", 5)
        cmd = ['/sbin/mdadm','-S',dev_path]
        ret = execute(cmd)
    #if ret != 0:
    #    return None
    tmp_img.seek(0)
    lines = tmp_img.readlines()
    for a_line in lines:
        a_line_elements = a_line.split('\n')[0].split('=')
        if len(a_line_elements) < 2:
            continue
        disk_raid_info[a_line_elements[0]] = a_line_elements[1]
    if not info_type:
        return disk_raid_info
    if not disk_raid_info.__contains__(info_type):
        return None
    return disk_raid_info[info_type].replace(':','-')

def diskRaidGroup(dev_path):
    cmd = []
    cmd.append("mdadm -E %s 2>/dev/null  | grep ^\"Preferred Minor\" | awk '{print $4}'"%(dev_path))
    cmd.append("mdadm -E %s 2>/dev/null  | grep Name |awk '{print $3}'"%(dev_path))
    tmp_img = tempfile.TemporaryFile()
    ret = execute(cmd, std=tmp_img, shell=True)
    tmp_img.seek(0)
    a_line = tmp_img.readline()
    try:
        md_group = a_line.split('\n')[0].split(':')[1]
    except Exception,e:
        return None
    if len(md_group) != 2:
        return None
    return "md%s"%(md_group)

def diskRaidState(dev_path):
    cmd = []
    #cmd.append("mdadm -E %s 2>/dev/null | grep ^this | awk '{print $6}'"%(dev_path))
    cmd.append("mdadm -E %s | grep '  State'| awk '{print $3}'"%(dev_path))
    tmp_img = tempfile.TemporaryFile()
    ret = execute(cmd, std=tmp_img, shell=True)
    tmp_img.seek(0)
    a_line = tmp_img.readline()
    state = a_line.split('\n')[0]
    if len(state) < 2:
        return None
    return state

def diskRaidUUID(dev_path):
    return diskRaidInfo(dev_path, DISK_RAID_UUID)

def diskRaidDevices(dev_path):
    return diskRaidInfo(dev_path, DISK_RAID_DEVICES)


def activeRaid(raid_group, raid_UUID, raid_device_list):
    cmd = []
    cmd.append("mdadm")
    cmd.append("-A")
    cmd.append("/dev/%s"%(raid_group))
    cmd.append("-u")
    cmd.append(raid_UUID)
    for raid_device in raid_device_list:
        cmd.append(raid_device)
    cmd.append("-f")
    #cmd.append("2 >/dev/null")
    ret = execute(cmd)
    if ret != 0:
        return False
    return True

MDSTAT="/proc/mdstat"

def getRaidProgress(dev):
    raidprocess = {}
    raiddevmatch = '^(md(\d+))\s+:\s+(active\s+raid(\d+)|inactive)\s+(.*)\n'
    raidprocessmatch = '(recovery|resync)'
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    reslen = len(result)
    i = 0
    while i < reslen:
        rdm = rpm = None
        rdm = re.match(raiddevmatch,result[i])
        if rdm:
            rpm = re.search(raidprocessmatch,result[i + 2])
            if rpm:
                raidname = rdm.group(1)
                tmp1,tmp2 = result[i + 2].split("%")
                tmp1 = tmp1.split("=")
                rppercent = tmp1[-1].strip()
                tmp2,tmp3 = tmp2.split("min")
                tmp2 = tmp2.split("=")
                rptime = tmp2[-1].strip()
                rpspeed = tmp3.split('=')[-1]
                raidprocess[raidname] = rppercent+','+rptime+','+rpspeed
            i += 2
            continue
        else:
            i += 1
    if raidprocess.__contains__(dev):
        return raidprocess[dev]

    return None

