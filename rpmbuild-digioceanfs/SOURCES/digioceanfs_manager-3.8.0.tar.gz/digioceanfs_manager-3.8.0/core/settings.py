import os
import commands

#Paths
HOSTFILE = '/etc/hosts'
HOSTNAMEFILE = '/etc/sysconfig/network'
RCLOCALPATH = '/etc/rc.local'
NFSCONF = '/etc/exports'
NFSRMTAB = '/var/lib/nfs/rmtab'
SMBCONF = '/etc/samba/smb.conf'
SHADOW = '/etc/shadow'
PASSWD = '/etc/passwd'

CPUINFO = '/proc/cpuinfo'
#RSYSLOG = '/etc/init.d/rsyslog'
MDSTAT = 'mdstat'#'/proc/mdstat'

#network#
# For debian6
ETHFILE = '/etc/network/interfaces'
ALLNETINFO = '/sys/class/net'
NETWORKCONFDIR = '/etc/sysconfig/network-scripts/'

# For CentOS 6+

#disk#
SCSIDEVICE = '/sys/class/scsi_device'
SASDEVICE = '/sys/class/sas_device'
DISKDEVICE = '/sys/block/%s/device'
DISKDEV = '/sys/class/scsi_device/%s/device/block'
JOBD = '/usr/local/admin/softraid/jobd'
PARTITIONS = '/proc/partitions'
DISKSERIAL = '/dev/disk/by-id'
SYSBLOCK = '/sys/block'


#others#
USERNAMEPREFIX = 'digioceanfs_smb_'
SMBCONFPREFIX = '/etc/digioceanfs/services'

#SAMBA=os.path.exists("/etc/init.d/samba") and '/etc/init.d/samba' or '/etc/init.d/smb' 
SYNC_SCRIPT='/usr/local/digioceanfs_manager/utils/disk_sync.pyc'
SMBBASEUID='3000'
PRIDOMAINPATH='/etc/digioceanfs/DOMAINNAME'
PRIHOSTNAMEPATH='/etc/digioceanfs/HOSTNAME'
SMSCONF='/etc/digioceanfs/sms.conf'
IPMICONF='/etc/digioceanfs/ipmi.conf'

#gluster-3.4

CTDBMTDIR = '/cluster2/ctdb'
CTDBSYSCONF = '/etc/sysconfig/ctdb'
CTDBCONF = '/etc/ctdb'


item_list =  globals() 
ignorechecklist = ['SYNC_SCRIPT','DISKDEVICE','DISKDEV','JOBD','ETHFILE','SMBCONFPREFIX','SASDEVICE','SCSIDEVICE','CTDBMTDIR','CTDBSYSCONF','CTDBCONF','SMBBASEUID','PRIDOMAINPATH','PRIHOSTNAMEPATH','SMSCONF','IPMICONF']

def getCommandsPath(command):
    ret, path = commands.getstatusoutput('which %s' % command)
    if not ret:
        #utils.manager_utils.digi_debug("**Command check, Found command path: %s " % path, 7)
        return path
    else:
        #utils.manager_utils.digi_debug("**Command check, %s not found, exiting now ..." % command, 3)
        return None

#Commands
COMMANDS={'smbpasswd':getCommandsPath('smbpasswd'),
          'smbstatus':getCommandsPath('smbstatus'),
          'useradd':getCommandsPath('useradd'),
          'userdel':getCommandsPath('userdel'),
          'usermod':getCommandsPath('usermod'),
          'netstat':getCommandsPath('netstat'),
          'dmidecode':getCommandsPath('dmidecode'),
          'smartctl':getCommandsPath('smartctl'),
          'smbd':getCommandsPath('smbd'),
          'ipmitool':getCommandsPath('ipmitool'),
          'setfacl':getCommandsPath('setfacl'),
          'getfacl':getCommandsPath('getfacl'),
          'ifconfig':getCommandsPath('ifconfig'),
          'mii-tool':getCommandsPath('mii-tool'),
          'digiocean':getCommandsPath('digiocean'),
          'mount':getCommandsPath('mount'),
          'blkid':getCommandsPath('blkid'),
          'mkfs.xfs':getCommandsPath('mkfs.xfs'),
          'attr':getCommandsPath('attr'),
          'clear_xattr':getCommandsPath('clear_xattr'),
          'systemctl':getCommandsPath('systemctl'),
          'ip':getCommandsPath('ip'),
          'chattr':getCommandsPath('chattr')
          }
FSTYPE={
        'GLUSTERFS':'glusterfs',
        'DIGIOCEANFS':'digioceanfs',
        'EXT2':'ext2',
        'EXT3':'ext3',
        'EXT4':'ext4',
        'xfs':'xfs'
        }

import utils.manager_utils

def _path_check(item_list=globals()):
    # core cmd check
    import os
    for k,v in item_list.items():
        if type(k) == str:
            if k in ignorechecklist:
                continue
        if v and type(v) == str and v[0] == '/':
            utils.manager_utils.DEBUG_LVL = 7
            if not (os.path.isdir(v) or os.path.isfile(v)):
                utils.manager_utils.digi_debug("Path or Command: %s not found, exiting now ..." % v, 3)
                exit()
            else:
                try:
                    utils.manager_utils.digi_debug("Path or Command: %s found, continue ..." % v, 7)
                except Exception, e:
                    print e
        else:
            #Command or fstype
            if k == 'COMMANDS':
                global COMMANDS
                for key,value in COMMANDS.items():
                    cmd_path = getCommandsPath(key)
                    if  cmd_path:
                        COMMANDS[key] = getCommandsPath(key)
                    else:
                        exit()
                pass
            if k == 'FSTYPE':
                continue
    print COMMANDS

def _os_check():
    pass

if __name__ == "__main__":
    _path_check(item_list)
