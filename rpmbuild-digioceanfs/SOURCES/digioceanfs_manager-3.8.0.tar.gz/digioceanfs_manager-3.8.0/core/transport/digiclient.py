# Example: Connect to a server (tcp)
# Connect to a smtp server at localhost and send an email.
# For real applications you should use smtplib.
# -*- coding: utf-8 -*-
import socket,select
import sys
import os
import simplejson
import time
import threading
from struct import pack, unpack

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)

utilspath = os.path.join(currpath[:currpath.rfind('manager')],'utils')
if not utilspath in sys.path:
    sys.path.append(utilspath)

import settings
from manager_utils import *
from net_utils_tool import PING

BUFFER_SIZE = 81920

class DigiClient:
    def __init__(self, (ipaddr, port)):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.settimeout(3)
        #self.host_info = (ipaddr, port)
        self.connected = False
        self.error_message = ""
        self.can_be_connected = True
        self.data_type = ""
#        try:
#            #ip = socket.gethostbyaddr(socket.gethostname())[2][0]
#            hostname = get_config_file(settings.PRIHOSTNAMEPATH).read().strip()
#            ip = socket.gethostbyaddr(hostname)[2][0]
#        except:
#            ip = ipaddr 
        self.ip_addr = ipaddr 
        self.host_info = (self.ip_addr, port)

    def connect(self):
        #digi_debug("[Transport]:connect %s"%(self.host_info[0]), 7)
        #if not PING(self.host_info[0]):
        #    return 29
        if not self.can_be_connected:
            digi_debug("[Transport]:connect failed", 3)
            return 29
        try:
            self.sock.connect(self.host_info)
        except socket.error,e:
            if e.args[0] == 111:
                self.error_message = "Connection refused,check out if the server has been setup!"
                digi_debug("[Transport]:connect failed, Error msg: %s" % self.error_message, 3)
                self.can_be_connected = False
                return 29
            else:
                self.error_message = "Unknown error_0!%s"%(e)
                digi_debug("[Transport]:connect failed, Error msg: %s" % e, 3)
                self.can_be_connected = False
                return 29
        self.connected = True
        #print "connect success --------------------------- %s" % self.host_info[0]
        return 0

    def submit(self, type, data=''):
        try:
            self.data_type = type
            ret = self.sock.send("%d;%s%s"%(type, data, '\177')) #add this magic byte to ensure all revieve
            #digi_debug("[Transport]:%d bytes send to server: %s"%(ret,self.host_info), 7)
            #digi_debug("[Transport]: send data: %s" % data)
        except socket.error,e:
            if e.args[0] == 32:
                self.error_message = "Can't send message!"
                digi_debug("[Transport]:connect failed, Error msg: %s" % self.error_message, 3)
            else:
                self.error_message = "Unknown error!_1"
                digi_debug("[Transport]:connect failed, Error msg: %s" % self.error_message, 3)
            return False
        #print "submit success --------------------------- %d ------------------ %s" % (type , self.host_info[0])
        return True

    def receive(self):
        data = ''
        try:
            n = 1;
            flag = True 
            while flag:
                if n > 1:
                    if not PING(self.ip_addr):
                        break
                #if not self.ip_addr:
                #    infds,outfds,errfds = select.select([self.sock,],[],[],n)
                #else:
                #digi_debug('timeout now is %s seconds'% (str(n)))
                infds,outfds,errfds = select.select([self.sock,],[],[],5)
                while 1:
                    if len(infds) != 0:
                        ret_length_package = self.sock.recv(4)
                        ret_length = unpack('i', ret_length_package)[0]
                        fmt = str(ret_length) + 's'
                        if ret_length:
                            ret_data_package = self.sock.recv(ret_length)
                            while len(ret_data_package) < ret_length:
                                ret_data_package += self.sock.recv(ret_length)
                            #ret_data_package = self.sock.recv(ret_length)
                            ret_data = unpack(fmt, ret_data_package)[0]
                            #digi_debug("[Transport]:%d bytes receive"%(len(ret_data)))
                            if ret_data.find('[Processing]') < 0:
                                data = ret_data
                                flag = False
                                break
                            elif ret_data.find('[Processing]') >= 0:
                                os.system('echo ' + ret_data + ' >> /usr/local/digioceanfs_gui/libcommon/processing')
                    else:
                        if n <= 60:
                            n += 1
                            break
                        else:
                            #digi_debug('nodata coming')
                            flag = False 
                            break        
                #    else:
                #        if n <= 2:
                #            n += 1
                #            #break
                #        else:
                #            digi_debug('##### no remote call return!!!#####')
                #            break
                #if len(infds) == 0:
                #    digi_debug('nodata coming')
                #    break
                #if not ret:
                #    digi_debug('##### no remote call return!!!#####')
                #    break
                #data_length = unpack('i', ret[:4])[0]
                #print data_length
                #fmt = 'i' + str(data_length) + 's'
                #print fmt 
                #print [ret] 
                #data = unpack(fmt, ret)
                #print data 
                #if ret.find('processing result test') >= 0:
                #    print ret 
                #    data += ret
                #else:
                #    data += ret
                #digi_debug("transport:%d bytes receive"%(len(ret_data)))
                #if data[-17:] == "####send_over####":
                #    digi_debug('===============================================================')
                #    digi_debug(data[:-17])
                #    digi_debug('===============================================================')
                #    data = data[:-17]       #cut the over words
                #break
            #print "recieve success ----------------------------------------"
        except Exception, e:
            self.error_message = "unknown error"
            digi_debug("[Transport]:receive massage failed, Error msg: %s" % e, 3)
            return None
        return data

    def close(self):
        #digi_debug("[transport]:disconnect %s"%(self.host_info[0]))
        self.sock.close()
        self.connected = False

    def disconnect(self):
        #digi_debug("[transport]:disconnect %s"%(self.host_info[0]))
        self.sock.close()
        self.connected = False

    def status(self):
        return self.connected

    def get_error_message(self):
        return self.error_message

def send_request ():
    f = open("/etc/digioceanfs_manager/nodes/10.10.12.110_nic","w")
    c = DigiClient(('10.10.12.110', 9997))
    c.connect()
    c.submit('nic_fetch_info')
    f.write(c.receive())
    c.submit('cpu_fetch_info')
    #digi_debug(c.receive())
    c.disconnect()


if __name__ == "__main__":
    threads = 1
    thread_pool = []
    for i in range(threads):
        th = threading.Thread(target=send_request)
        thread_pool.append(th)
    for i in range(threads):
        thread_pool[i].start()
    for i in range(threads):
        threading.Thread.join(thread_pool[i])

