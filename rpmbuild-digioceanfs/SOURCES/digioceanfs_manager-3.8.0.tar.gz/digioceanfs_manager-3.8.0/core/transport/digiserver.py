# Create a Server, calling handler for every client
# You can test it with "telnet localhost 1029"
# -*- coding: utf-8 -*-
import sys
import os
import socket
import re
import time
import select
import traceback
from struct import * 
from threading import Thread
from SocketServer import BaseServer
from SocketServer import BaseRequestHandler

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)

utilspath = os.path.join(currpath[:currpath.rfind('manager')],'utils')
if not utilspath in sys.path:
    sys.path.append(utilspath)

from manager_utils import *

BUFFER_SIZE = 81920

class DigiServer(BaseServer):

    address_family = socket.AF_INET

    socket_type = socket.SOCK_STREAM

    socket_port = 0

    request_queue_size = 100

    def __init__(self, server_address, handler_parser, handler_post, acquire_lock, release_lock, proc_queue_handler):
        BaseServer.__init__(self, server_address, OptionRequestHandler)
        self.socket = socket.socket(self.address_family, self.socket_type)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        #self.socket.listen(1000)
        #self.socket.settimeout(3)
        self.socket_port = server_address[1]
        self.server_bind()
        self.server_activate()
        self.handler_parser  = handler_parser
        self.handler_post    = handler_post
        self.acquire_lock    = acquire_lock
        self.release_lock    = release_lock
        self.proc_queue_handler = proc_queue_handler 
        #self.request_list   = dict() 
        self.request_list    = [(self.socket, ('',9997))]
        #self.request_list    = [self.socket]
        self.timeout         = 60 
        self.request_num     = 0

    def server_bind(self):
        try:
            self.socket.bind(('0.0.0.0', self.socket_port))
            #self.socket.listen(20)
        except Exception, e:
            #digi_debug("DigiServer caught exception: %s" % traceback.print_exc(e))
            digi_debug("DigiServer failed to bind ipaddress, exiting now ...", 3)
            #exit()
            raise e 

    def server_activate(self):
        self.socket.listen(self.request_queue_size)

    def server_close(self):
        self.socket.close()
    
    def get_request(self):
        current_socket = self.socket.accept()
        self.request_num += 1
        self.request_list.append(current_socket)

    def get_req(self, fd_set):
        for req in self.request_list:
            if fd_set.fileno() == req[0].fileno():
                request = fd_set
                client_address = req[1]
        return request, client_address


    def handle_request(self):
        """Handle one request, possibly blocking.

        Respects self.timeout.
        """
        # Support people who used socket.settimeout() to escape
        # handle_request before self.timeout was available.
        timeout = self.socket.gettimeout()
        if timeout is None:
            timeout = self.timeout
        elif self.timeout is not None:
            timeout = min(timeout, self.timeout)
        request_list = []
        request_list = [item[0] for item in self.request_list]
        #for i in request_list:
        #    digi_debug(type(i))
        fd_sets = select.select(request_list, [], [], timeout)
        if not fd_sets[0]:
            self.handle_timeout()
            return
        else:
            for req in fd_sets[0]:
                if req.fileno() == self.socket.fileno():
                    current_request = self.socket.accept()
                    self.request_num += 1
                    self.request_list.append(current_request)
                else:
                    self._handle_request_noblock(req)
                    break

    def _handle_request_noblock(self, fd_set):
        """Handle one request, without blocking.

        I assume that select.select has returned that the socket is
        readable before this function was called, so there should be
        no risk of blocking in get_request().
        """
        try:
            request, client_address = self.get_req(fd_set)
        except socket.error:
            return
        if self.verify_request(request, client_address):
            try:
                self.process_request(request, client_address)
                #self.request_list.remove(self.get_req(request))
                #request.close()
            except:
                self.handle_error(request, client_address)
                self.close_request(request)

    def handle_timeout(self):
        return True

    def close_request(self, request):
        pass

    def server_forever(self):
        while 1:
            self.handle_request()

    def start_loop (self):
        self.server_forever()

    def finish_request(self, request, client_address):
        """Finish one request by instantiating RequestHandlerClass."""
        self.RequestHandlerClass(request, client_address, self, self.handler_parser, self.handler_post, self.proc_queue_handler)

    def fileno(self):
        return self.socket.fileno()


class OptionRequestHandler(BaseRequestHandler):
    def __init__(self, request, client_address, server, handler_parser, handler_post, proc_queue_handler):
        BaseRequestHandler.__init__(self, request, client_address, server)
        self.handler_parser = handler_parser
        self.handler_post = handler_post
        self.proc_queue_handler = proc_queue_handler 

    def setup(self):
        #digi_debug("[Transport]:%s connected "% self.client_address[0], 7)
        self.server.acquire_lock()
    def handle(self):
        try:
            flag = True
            while flag:
                data = self.request.recv(BUFFER_SIZE)
                #digi_debug("[Transport]:%d bytes receive"%(len(data)), 7)
                #digi_debug("[Transport]:%d in request_list" % self.server.request_num)
                if len(data) == 0:
                    self.server.request_list.remove(self.server.get_req(self.request))
                    self.server.request_num -= 1
                    #digi_debug("[Transport]:%d in request_list after" % self.server.request_num)
                    return
                while data[-1] != '\177':	#check the magic byte
                    #digi_debug("[Transport]:recieve not enough bytes", 5)
                    data_tmp = self.request.recv(BUFFER_SIZE)
                    data = "%s%s"%(data, data_tmp)
                data = data[:-1]
                _type = int(data.split(';', 1)[0])
                payload = data.split(';', 1)[1]
                if self.server.proc_queue_handler == 'node_messager':
                    #digi_debug("node messager reveice: %s -- %s " % (_type, payload))
                    re_data = self.server.handler_parser(_type, payload)
                    if len(re_data.strip()) == 0:
                        re_data = 'none'
                    re_data_length = len(re_data)
                    fmt = 'i' + str(re_data_length) + 's'
                    package = pack(fmt, re_data_length, re_data)
                    ret = self.request.send(package)
                    #digi_debug("[Transport]:%d bytes send"%(len(re_data)), 7)
                    self.server.handler_post()
                    continue
                collect_data_thread = Thread(target=self.server.handler_parser, args=(_type, payload))
                collect_data_thread.start()
                #digi_debug('--------------------------------------------------------------')
                #collect_data_thread.join()
                while 1:
                    re_data = self.server.proc_queue_handler()[1]
                    #digi_debug(re_data)
                    #digi_debug(type(re_data))
                    re_data_length = len(re_data)
                    #define package fmt
                    fmt = 'i' + str(re_data_length) + 's'
                    package = pack(fmt, re_data_length, re_data)
                    if re_data.find('[Processing]') >= 0:
                        #re_data_final = re_data
                        #re_data_final = re_data + "####send_over####"
                        #send package
                        ret = self.request.send(package)
                        #digi_debug("[Transport]:%d bytes send"%(len(re_data)), 7)
                        self.server.handler_post()
                    else:
                        #re_data_final = re_data + "####send_over####"
                        ret = self.request.send(package)
                        #ret = self.request.send(re_data_final)
                        self.server.handler_post()
                        #digi_debug("[Transport]:%d bytes send"%(len(re_data)), 7)
                        flag = False
                        break                     
        except Exception,e:
            print e
            digi_debug("[Transport]: Fatal error raise in digiserver: %s" % traceback.print_exc(e), 2)
    def finish(self):
        #digi_debug("[Transport]: %s disconnected" % self.client_address[0], 7)
        self.server.release_lock()
