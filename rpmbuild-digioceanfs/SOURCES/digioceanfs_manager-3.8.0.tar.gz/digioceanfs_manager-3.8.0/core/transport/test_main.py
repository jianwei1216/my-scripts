# Create a Server, calling handler for every client
# You can test it with "telnet localhost 1029"

import tools
from digiserver import DigiServer
from manager_protocol import *

def protocol_parse(type, payload):
    re_data = ''
    if type == protocol_request_type["node_list_cpu"]:
        re_data = str(tools.getCPUinfo())
    elif type == protocol_request_type["node_list_nic"]:
        re_data = str(tools.getNICinfo())
    else:
        re_data = ''
    return re_data

s = DigiServer(('', 9997), protocol_parse)
s.start_loop()
