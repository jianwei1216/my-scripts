#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import sys
import time

sys.path.append('/usr/local/digioceanfs_manager/monitor_reporter')
from monitor_reporter import *
from get_info import *

sys.path.append(os.path.dirname('/usr/local/digioceanfs_manager/utils'))
from monitor_report_log import digi_log
from mgmt_mongodb_utils import *

def get_disk_status_info_by_udev(dev_info):
    dict = {}
    mongo_dict = {}
    mongo_dict = connect_mongodb()
    if not mongo_dict:
        digi_log.error("udev monitor, connect_mongodb() failed and exit()")
        return None

    local_name = get_local_hostname_by_ip()
    if not local_name:
        digi_log.error("udev monitor, get_device_status_info(), get local "
                       "hostname failed.")
        return None
    timer = time.strftime("%Y/%m/%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Udev monitor, get_device_status_info(), get system "
                       "time failed.")
        return None
    device_name = "/dev/{0}".format(dev_info[1])
    id_name = replace_disk_name_by_id(device_name)
    if not id_name:
        return None
    dict['monitor_type'] = "udev_monitor_disk"
    dict['node_name'] = local_name
    dict['monitor_time'] = timer
    dict['device_name'] = id_name
    dict['disk_tatus'] = dev_info[2]
    return dict

def main():
    dict = {}
    dict = get_disk_status_info_by_udev(sys.argv)
    if dict:
        update_write_event_to_db(dict, alarmcol, monitor, thresholdcol, aflag=False, mongo_dict={})

if __name__ == '__main__':
    main()
