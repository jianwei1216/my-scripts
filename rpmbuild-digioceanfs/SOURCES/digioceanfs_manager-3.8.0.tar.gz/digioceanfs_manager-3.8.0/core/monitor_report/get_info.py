#!/usr/bin/python
#coding=utf-8

import sys
import os
import re
import datetime
import dircache
from Queue import Queue
import subprocess
import threading
import traceback
import time
from time import ctime,sleep

sys.path.append('/usr/local/digioceanfs_manager/utils')

from mongo_utils import *
from pyNmonParser import pyNmonParser
from monitor_report_log import digi_log

fstab_file  = "/etc/fstab"
check_file = "/check_system_file"
check_data_disk_file = "/usr/local/digioceanfs_manager/monitor_reporter/check_data_disk_file"
netconf_dir = "/etc/sysconfig/network-scripts"
disk_by_id  = "/dev/disk/by-id/"
hosts_file = "/etc/hosts"
DIGIOCEAN = '/usr/sbin/digiocean'
DIGIOCEAND = '/usr/sbin/digioceand'

sleep_time  = 5
sleep_time1 = 10
sleep_time2 = 20
sleep_time3 = 30
sleep_time4 = 60

########## get service list ##########
def get_service_list():
    num = 0
    service_name = []
    try:
        info = subprocess.Popen("ls /var/lib/digioceand/vols/", shell=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        info.wait()
        stderr1 = info.stderr.readlines()
        if stderr1:
            digi_log.error("Monitor report, get_service_list() "
                           "failed and %s"%stderr1)
            return None
        stdout1 = info.stdout.readlines()
        if not stdout1:
            digi_log.warn("Monitor report, get_service_list() get info is None")
            return None
        while stdout1.split("\n")[num]:
            service_name.append(stdout1.split("\n")[num])
            num = num + 1
    except Exception,e:
        digi_log.error("Alarm information, get_service_list(), caught exception: %s" % traceback.print_exc(e))
    return service_name

########## get status of service ##########
def get_status_of_service(service_name):
    service_status = {}
    try:
        for index in xrange(len(service_name)):
            info = os.popen("cat /var/lib/digioceand/vols/%s/info|grep -w status"%service_name[index]).read()
            if "1" in info:
                service_status['%s'% service_name[index]] = 'On'
            else:
                service_status['%s'% service_name[index]] = 'Off'
    except Exception,e:
        digi_log.error("Alarm information, get_status_of_service , caught exception: %s" % traceback.print_exc(e))
    return service_status

########## get type of service ##########
def get_type_of_service(service_name):
    ''' "0":Distribute ，"2":Replicate, Distributed-Replicate，"4":Disperse, Distributed-Disperse,
         At present a total of five kinds of services'''
    service_type = {}
    try:
        for index in xrange(len(service_name)):
            info = os.popen("cat /var/lib/digioceand/vols/%s/info|grep -w type"%service_name[index]).read()
            service_type[service_name[index]] = info[5]
    except Exception,e:
        digi_log.error("Alarm information, get_type_of_service() , caught exception: %s" % traceback.print_exc(e))
    return service_type

########## get quota status of service ##########
def get_quota_status_of_service(service_name):
    quota_info = {}
    try:
        for index in xrange(len(service_name)):
            result = os.popen("ls /var/lib/digioceand/vols/%s"% service_name[index]).read()
            if 'quota' in result:
                quota_info['%s'% service_name[index]] = 'On'
            else:
                quota_info['%s'% service_name[index]] = 'Off'
    except Exception,e:
        digi_log.error("Alarm information, get_quota_status_of_service() , caught exception: %s" % traceback.print_exc(e))
    return quota_info

########## get used disk in service ##########
def get_used_disk_in_service(service_name):
    num = 0
    disk_name = []
    try:
        hostname = get_local_hostname_by_ip()
        if not hostname:
            digi_log.warn('get_local_hostname_by_ip()  is return None')
            return None
        for index in xrange(len(service_name)):
            num = 0
            info = os.popen("ls /var/lib/digioceand/vols/%s|grep %s"%(service_name[index],hostname)).read()
            while info.split("\n")[num]:
                disk_name.append((info.split("\n")[num]).split(".")[3])
                num = num + 1
        for index in xrange(len(disk_name)):
            disk_name[index] = '/' + (disk_name[index]).split('-')[0] + '/' + (disk_name[index]).split('-')[1] + '-' +(disk_name[index]).split('-')[2]
    except Exception,e:
        digi_log.error("Alarm information, get_used_disk_in_service() , caught exception: %s" % traceback.print_exc(e))
    return disk_name

########## get battery info ##########
def get_battery_info(queue):
    while True:
        battery_info = {}
        try:
            info = subprocess.Popen("ipmicfg -pminfo |grep "
                    "'AC Input Voltage'|grep -v 0.0|awk '{print $5}'",
                    shell=True,stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE)
            info.wait()
            stderr = info.stderr.readlines()
            if stderr:
                digi_log.error("Monitor report, ipmicfg get battery info failed")
                sleep(sleep_time1)
                continue
            info1 = subprocess.Popen("ipmicfg -pminfo|grep Status", shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE)
            info1.wait()
            stderr = info1.stderr.readlines()
            if stderr:
                digi_log.error("Monitor report, ipmicfg get battery info failed")
                sleep(sleep_time1)
                continue
            stdout1 = info.stdout.readlines()
            if not stdout1:
                digi_log.warn("Alarm information, Not get battery info")
            stdout2 = info1.stdout.readlines()
            if not stdout2:
                digi_log.warn("Alarm information, Not get battery info")
            if not stdout1 and not stdout2:
                digi_log.error("Alarm information, the device does not have battery module")
                sleep(sleep_time1)
                continue
            battery_info['monitor_time'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
            battery_info['battery_electricity'] = info.split('\n')[0]
            if '[COMM,MEMORY,LOGIC EVENT]' in info1:
                battery_info['battery_status'] = 'Full'
            elif '[UNIT WAS BUSY]'in info1:
                battery_info['battery_status'] = 'Discharge'
            else:
                battery_info['battery_status'] = 'Charging'
            battery_info['node'] = get_local_hostname_by_ip()
            if not battery_info['node']:
                digi_log.warn('get_local_hostname_by_ip() return None')
                sleep(sleep_time1)
                continue
            battery_info['monitor_type'] = 'battery'
            battery_info['process_name'] = 'battery'
            queue.put(battery_info)
        except Exception,e:
            digi_log.error("Alarm information, get_battery_info() , got exception: %s" % traceback.print_exc(e))
        sleep(sleep_time1)

########## get service process info ##########
def get_service_process_info(queue):
    while True:
        service_name = []
        service_name = get_service_list()
        if not service_name:
            digi_log.warn("get_service_list() is None")
            sleep(sleep_time3)
            continue
        try:
            for index in xrange(len(service_name)):
                result = os.popen("ps aux|grep /cluster2|grep -w %s|grep -v grep" % service_name[index]).read()
                process_info = {}
                process_info['process_name'] = "/cluster2/" + service_name[index]
                if result:
                    process_info['process_status'] = "On"
                else:
                    process_info['process_status'] = "Off"
                process_info['monitor_time'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
                process_info['node'] = get_local_hostname_by_ip()
                if not process_info['node']:
                    digi_log.warn('get_local_hostname_by_ip() return None')
                    continue
                process_info['monitor_type'] = "cluster2"
                process_info['alarm_flag'] = 'False'
                queue.put(process_info)
        except Exception,e:
            digi_log.error("Alarm information, get_service_process_info(), got exception: %s" % traceback.print_exc(e))
        sleep(sleep_time3)

########## get disk process info ##########
def get_disk_process_info(queue):
    while True:
        service_name = []
        disk_name = []
        try:
            service_name = get_service_list()
            if not service_name:
                digi_log.warn("get_service_list() is None")
                sleep(sleep_time3)
                continue
            disk_name = get_used_disk_in_service(service_name)
            if not disk_name:
                digi_log.warn('get_used_disk_in_service() is failed')
                sleep(sleep_time3)
                continue
            info = os.popen("ps  aux | grep -w digioceanfsd | grep -v grep |awk '{print $21}'").read()
            for index in xrange(len(disk_name)):
                process_info = {}
                process_info["process_name"] = disk_name[index]
                if disk_name[index] in info:
                    process_info['process_status'] = 'On'
                else:
                    process_info['process_status'] = 'Off'
                process_info['monitor_time'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
                process_info['node'] = get_local_hostname_by_ip()
                if not process_info['node']:
                    digi_log.warn('get_local_hostname_by_ip() return None')
                    continue
                process_info['monitor_type'] = 'disk_mount'
                process_info['alarm_flag'] = 'False'
                queue.put(process_info)
        except Exception,e:
            digi_log.error("Alarm information, get_disk_process_info(), got exception: %s" % traceback.print_exc(e))
        sleep(sleep_time3)

########## get quota process info ##########
def get_quota_process_info(queue):
    while True:
        service_name = []
        service_name = get_service_list()
        if not service_name:
            digi_log.warn("get_service_list() is None")
            sleep(sleep_time3)
            continue
        try:
            for index in xrange(len(service_name)):
                result = os.popen("ps aux|grep quota-mount-%s|grep -v grep" % service_name[index]).read()
                process_info = {}
                process_info['process_name'] = "quota-mount-" + service_name[index]
                if result:
                    process_info['process_status'] = 'On'
                else:
                    process_info['process_status'] = 'Off'
                process_info['monitor_time'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
                process_info['node'] = get_local_hostname_by_ip()
                if not process_info['node']:
                    digi_log.warn('get_local_hostname_by_ip() return None')
                    continue
                process_info['monitor_type'] = 'quota-mount'
                process_info['alarm_flag'] = 'False'
                queue.put(process_info)
        except Exception,e:
            digi_log.error("Alarm information, get_quota_process_info(), got exception: %s" % e)
        sleep(sleep_time3)

########## get process info ##########
def get_process_info(queue):
    #process_list = ["smbd","rsyslogd","crond","smartd","sshd","snmpd","snmptrapd","rpcbind","nginx",
    #                "digioceand.pid","digioceanshd","node_manager","digioceanfs_gui","nfs","quotad"]
    process_list = ["smbd","digioceand.pid","digioceanshd","node_manager","digioceanfs_gui","nfs","quotad"]
    while True:
        try:
            for index in xrange(len(process_list)):
                result = os.popen("ps aux|grep -w %s|grep -v grep"%process_list[index]).read()
                process_info={}
                process_info['process_name'] = process_list[index]
                if result:
                    process_info['process_status'] = 'On'
                else:
                    process_info['process_status'] = 'Off'
                process_info['monitor_time'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
                process_info['node'] = get_local_hostname_by_ip()
                if not process_info['node']:
                    digi_log.warn('get_local_hostname_by_ip() return None')
                    continue
                process_info['monitor_type'] = process_list[index]
                process_info['alarm_flag'] = 'False'
                queue.put(process_info)
        except Exception,e:
            digi_log.error("Alarm information, get_process_info(), got exception: %s" % traceback.print_exc(e))
        sleep(sleep_time3)

################################################################################
#get local hostname by ip
def get_local_hostname_by_ip():
    try:
        ifconfig_path = os.popen("which ifconfig").read().rstrip('\n')
        ip_out = subprocess.Popen("%s -a|grep -w 'inet'|"
                                   "grep -v '127.0.0.1'|awk '{print $2}'"%ifconfig_path, 
                                   shell=True, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE)
        ip_out.wait()
        stderr = ip_out.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_local_hostname(), "
                           "get ip failed, with error: %s" % stderr)
            return None
    except Exception, e:
        digi_log.error("Monitor reporter, get_local_hostname(), call popen "
                       "failed, with error: %s" % e)
        return None
    try:
        hosts_out = subprocess.Popen("cat %s" % hosts_file, shell=True,
                                     stdout=subprocess.PIPE, 
                                     stderr=subprocess.PIPE)
        hosts_out.wait()
        stderr = hosts_out.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_local_hostname(), use 'cat'"
                           " get hosts info failed, with error: %s" % e)
    except Exception, e:
        digi_log.error("Monitor reporter, get_local_hostname(), call Popen "
                       "cat hosts file failed, with error: %s" % e)
        return None
    hosts_list = hosts_out.stdout.readlines()
    if not hosts_list:
        digi_log.debug("Monitor reporter, get_local_hostname(), get hosts info "
                       "is null.")
    ip_list = ip_out.stdout.readlines()
    if not ip_list:
        digi_log.debug("Monitor reporter, get_local_hostname(), get all local "
                       "ip info is null.")
    for ip in ip_list:
        for hosts in hosts_list:
            if hosts[0] != '#':
                if (hosts.find(ip.rstrip('\n')) != -1 and
                   hosts.find('####DigioceanfsNode####') != -1):
                       return hosts.split(' ')[1]
    return None

def get_all_real_netcard_name():
    netcard_list = []
    try:
        out = subprocess.Popen("ifconfig -a|grep 'flags'|grep -v 'bond'|"
                               "grep -v 'virbr'|grep -v 'lo'|awk '{print $1}'",
                               shell=True, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE)
        out.wait()
        stderr = out.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter,get_all_real_netcard_name(), use "
                           "'ifconfig' failed, with error: %s" % stderr)
            return None
    except Exception, e:
        digi_log.error("Monitor reporter,get_all_real_netcard_name(), call "
                       "Popen get all netcard name failed, with ereor: %s" % e)
        return None
    stdout = out.stdout.readlines()
    if stdout:
        for info in stdout:
            netcard_list.append(info.rstrip(':\n'))
        return netcard_list
    else:
        digi_log.debug("Monitor reporter, get_all_real_netcard_name(), get "
                       "all netcard name is null.")
        return None

def get_system_disk_name_by_lvm():
    is_find = 0
    try:
        fstab_out = subprocess.Popen("cat %s|grep -v ^#|awk '{print $1" "$2}'|"
                                    "grep -E /$|awk '{print $1}'" % fstab_file,
                                    shell=True, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE)
        fstab_out.wait()
        stderr = fstab_out.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_system_disk_name_by_lvm(), "
                           "cat fstab get info failed, with error: %s" % stderr)
            return None
    except Exception, e:
        digi_log.error("Monitor reporter, get_system_disk_name_by_lvm(), call "
                       "Popen get fstab file info failed, with error: %s" % e)
        return None
    root_dev = fstab_out.stdout.readlines()
    if root_dev:
        if root_dev[0].split('/')[2] == "mapper":
            root_dev_list = root_dev[0].lstrip('/').split('/')
            lv_path = "/{0}/{1}".format(root_dev_list[0], root_dev_list[2])
            lv_path = lv_path.replace('-', '/')
            try:
                lv_out = subprocess.Popen("lvdisplay|grep -E 'LV Path|VG Name'|"
                                          "awk '{print $3}'", shell=True,
                                          stdout=subprocess.PIPE,
                                          stderr=subprocess.PIPE)
                lv_out.wait()
                stderr = lv_out.stderr.readlines()
                if stderr:
                    digi_log.error("Monitor reporter, "
                                   "get_system_disk_name_by_lvm(), use "
                                   "'lvdisplay' get lv info failed, "
                                   "with error: %s" % stderr)
                    return None
            except Exception, e:
                digi_log.error("Monitor reporter, "
                               "get_system_disk_name_by_lvm(),"
                               "call Popen failed, with error: %s" % e)
                return None
            vg_info = lv_out.stdout.readlines()
            vg_temp = 0
            vg_name = ""
            for vg in vg_info:
                if vg.rstrip('\n') == lv_path:
                    vg_name = vg_info[vg_temp+1].rstrip('\n')
                    break
                vg_temp += 1
            try:
                pv_out = subprocess.Popen("pvdisplay|grep -E 'PV Name|VG Name'|"
                                          "awk '{print $3}'", shell=True,
                                          stdout=subprocess.PIPE,
                                          stderr=subprocess.PIPE)
                pv_out.wait()
                stderr = pv_out.stderr.readlines()
                if stderr:
                    is_find = 0
                    for stderr_info in stderr:
                        if (stderr_info.find("leaked on lvdisplay "
                                             "invocation") != -1):
                            is_find += 1
                    if is_find != len(stderr):
                        digi_log.error("Monitor reporter, "
                                    "get_system_disk_name_by_lvm(), use "
                                    "'pvdisplay' failed, error: %s" % stderr)
                        return None
            except Exception, e:
                digi_log.error("Monitor reporter, "
                               "get_system_disk_name_by_lvm(), "
                               "call Popen failed, with error: %s" % e)
                return None
            pv_info = pv_out.stdout.readlines()
            pv_find = 0
            is_find = 0
            pv_name = ""
            for pv in pv_info:
                if pv.rstrip('\n') == vg_name:
                    pv_name = pv_info[pv_find-1].rstrip('\n')
                    if pv_name:
                        is_find = 1
                    break
                pv_find += 1
            if pv_find:
                system_disk = re.match("\D*", pv_name)
                if system_disk:
                    system_disk = system_disk.group()
                    return system_disk
        else:
            system_disk = re.match("\D*", root_dev)
            if system_disk:
                system_disk = system_disk.group()
                return system_disk
    return None

def get_system_disk_by_blkid():
    try:
        boot_out = subprocess.Popen("blkid |grep -E 'swap|LVM' |"
                                    "grep -E 'sd|hd|md'", shell=True,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE)
        boot_out.wait()
        stderr = boot_out.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_system_disk_by_blkid(), "
                           "use 'blkid' failed, with error: %s" % stderr)
            return None
    except Exception, e:
        digi_log.error("Monitor reporter, get_system_disk_by_blkid(), call "
                       "Popen failed, with error: %s" % e, 3)
        return None
    boot_dev = boot_out.stdout.readlines()
    if boot_dev:
        disk_dev = boot_dev[0][:boot_dev[0].rfind(':')]
        system_disk = re.match("\D*", boot_dev[0])
        if system_disk:
            system_disk = system_disk.group()
            return system_disk
    return None

def get_system_disk_name():
    system_disk = get_system_disk_by_blkid()
    if not system_disk:
        system_disk = get_system_disk_name_by_lvm()
        if not system_disk:
            return None
    return system_disk

def replace_disk_name_by_id(disk_dev):
    try:
        id_out = subprocess.Popen("ls -l %s|grep %s|grep 'wwn'|"
                                  "awk '{print $9}'" % 
                                  (disk_by_id, disk_dev[5:]), shell=True,
                                  stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE)
        id_out.wait()
        stderr = id_out.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, replace_disk_name_by_id(), get "
                           "disk id failed, with error: %s" % stderr)
            return None
    except Exception, e:
        digi_log.error("Monitor reporter, replace_disk_name_by_id(), call "
                       "Popen get disk id failed, with error: %s" % e)
        return None
    disk_id = id_out.stdout.readlines()
    if disk_id:
        id_name = disk_id[0].rstrip('\n')
        return id_name
    return None

def get_disk_size_info(disk_dev, local_name, system_disk, size_info):
    dict = {}
    size_list = []
    for size in size_info:
        if size.find(disk_dev) != -1:
            size = size.rstrip('\n').split(' ')
            for info in size:
                if info:
                    size_list.append(info)
    if len(size_list) < 6:
        return None
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_disk_size_info(), get system "
                       "time failed.")
        return None
    part_name = re.search("[0-9]", disk_dev)
    if part_name:
        dict['device_name'] = disk_dev
    elif disk_dev.find('/dev/mapper') != -1:
        dict['device_name'] = disk_dev
    else:
        if disk_dev == system_disk:
            dict['device_name'] = disk_dev
        else:
            disk_id_name = replace_disk_name_by_id(disk_dev)
            if not disk_id_name:
                return None
            dict['device_name'] = disk_id_name
    dict['monitor_type'] = "disk_size_monitor"
    dict['monitor_time'] = timer
    dict['node_name'] = local_name
    dict['total_size'] = float(size_list[1])
    dict['used_size'] = float(size_list[2])
    dict['size_usage'] = ("%.2f" % ((float(size_list[2])/
                                     float(size_list[1]) * 100)))
    return dict

def get_disk_inode_info(disk_dev, local_name, system_disk, inode_info):
    dict = {}
    inode_list = []
    for inode in inode_info:
        if inode.find(disk_dev) != -1:
            inode = inode.rstrip('\n').split(' ')
            for info in inode:
                if info:
                    inode_list.append(info)
    if len(inode_list) < 6:
        return None
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_disk_inode_info(), get system "
                       "time failed.")
        return None
    part_name = re.search("[0-9]", disk_dev)
    if part_name:
        dict['device_name'] = disk_dev
    elif disk_dev.find('/dev/mapper') != -1:
        dict['device_name'] = disk_dev
    else:
        if disk_dev == system_disk:
            dict['device_name'] = disk_dev
        else:
            disk_id_name = replace_disk_name_by_id(disk_dev)
            if not disk_id_name:
                return None
            dict['device_name'] = disk_id_name
    dict['monitor_time'] = timer
    dict['node_name'] = local_name
    dict['monitor_type'] = "disk_inode_monitor"
    dict['total_inode'] = int(inode_list[1])
    dict['used_inode'] = int(inode_list[2])
    dict['ionde_usage'] = ("%.2f" % ((float(inode_list[2])/
                                      float(inode_list[1])) * 100))
    return dict

def get_system_disk_swapzone_info(disk_dev, zone_dev, local_name):
    dict = {}
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_system_disk_swapzone_info(), "
                       "get system time failed.")
        return None
    try:
        proc = subprocess.Popen("free -k|grep 'Swap'", shell=True,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        proc.wait()
        stderr = proc.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_system_disk_swapzone_info(),"
                           " use free get swap info failed, with "
                           "error: %s" % stderr)
            return None
    except Exception, e:
        digi_log.error("Monitor reporter, get_system_disk_swapzone_info(), "
                       "call Popen get swap info failed, with error: %s" % e)
        return None
    free_info = proc.stdout.readlines()
    free_size = []
    if free_info:
        free_info = free_info[0].rstrip('\n').split(' ')
        for info in free_info:
            if info:
                free_size.append(info)
    if len(free_size) < 4:
        return None
    dict['monitor_time'] = timer
    dict['node_name'] = local_name
    dict['monitor_type'] = "disk_size_monitor"
    dict['device_name'] = "system_disk"
    dict['zone_name'] = zone_dev
    dict['total_size'] = int(free_size[1])
    dict['used_size'] = int(free_size[2])
    dict['size_usage'] = ("%.2f" % ((float(free_size[2])/
                                     float(free_size[1])) * 100))
    return dict

def get_system_disk_zone_info(disk_dev, system_disk, queue, deal_flag, 
                              local_name, size_info, inode_info):
    dict = {}
    #system disk partition
    if deal_flag == 0:
        try:
            proc = subprocess.Popen("cat %s|grep -v ^#|awk '{print $1" "$2}'|"
                                    "grep -E /$|awk '{print $1}'" % fstab_file,
                                    shell=True, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE)
            proc.wait()
            stderr = proc.stderr.readlines()
            if stderr:
                digi_log.error("Monitor reporter, get_system_disk_zone_info(), "
                               "cat /etc/fstab failed, with error: %s" % stderr)
                return None
        except Exception, e:
            digi_log.error("Monitor reporter, get_system_disk_zone_info(), "
                        "call Popen cat /etc/fstab failed, with error: %s" % e)
            return None
        root_dev = proc.stdout.readlines()
        #find lvm, deal it
        if root_dev[0].rstrip('\n').split('/')[2] == "mapper":
            try:
                lvm_out = subprocess.Popen("lvdisplay|grep -E Name|"
                                           "awk '{print $3}'", shell=True,
                                           stdout=subprocess.PIPE,
                                           stderr=subprocess.PIPE)
                lvm_out.wait()
                stderr = lvm_out.stderr.readlines()
                if stderr:
                    is_find = 0
                    for stderr_info in stderr:
                        if (stderr_info.find("leaked on lvdisplay "
                                             "invocation") != -1):
                            is_find += 1
                    if is_find != len(stderr):
                        digi_log.error("Monitor reporter, "
                                       "get_system_disk_zone_info(), use "
                                       "'lvmdisplay' get lvm name failed, "
                                       "with error: %s" % stderr)
                        return None
            except Exception, e:
                digi_log.error("Monitor reporter, "
                               "get_system_disk_zone_info(), call Popen use "
                               "'lvmdisplay' failed, with error: %s" % e)
                return None
            lvm_name = lvm_out.stdout.readlines()
            name_list = []
            for lvm in lvm_name:
                lvm = lvm.rstrip('\n')
                name_list.append(lvm)
            length = len(name_list)
            for i in range(1,(length/2) + 1):
                dict = {}
                if name_list[2*(i-1)].find("swap") != -1:
                    swap_zone_name = ("/dev/mapper/{0}-{1}".format(
                                      name_list[2*i-1], name_list[2*(i-1)]))
                    dict = get_system_disk_swapzone_info(system_disk,
                                                         swap_zone_name, 
                                                         local_name)
                    if dict:
                        queue.put(dict)
                else:
                    LVM_name = ("{0}-{1}".format(name_list[2*i-1],
                                                     name_list[2*(i-1)]))
                    Zone_name = "/dev/mapper/{0}".format(LVM_name)
                    dict = get_disk_size_info(Zone_name, local_name,
                                              system_disk, size_info)
                    if dict:
                        dict['zone_name'] = dict['device_name']
                        dict['device_name'] = "system_disk"
                        queue.put(dict)
                    dict = {}
                    dict = get_disk_inode_info(Zone_name, local_name,
                                               system_disk, inode_info)
                    if dict:
                        dict['zone_name'] = dict['device_name']
                        dict['device_name'] = "system_disk"
                        queue.put(dict)
    dict = get_disk_size_info(disk_dev, local_name, system_disk, size_info)
    if dict:
        dict['zone_name'] = dict['device_name']
        dict['device_name'] = "system_disk"
        queue.put(dict)
    dict = {}
    dict = get_disk_inode_info(disk_dev, local_name, system_disk, inode_info)
    if dict != None:
        dict['zone_name'] = dict['device_name']
        dict['device_name'] = "system_disk"
        queue.put(dict)

def get_fan_info(fan_list, name_flag, local_name):
    dict = {}
    #Avoid list index out of range
    if len(fan_list) < 19:
        return None
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_fan_info(), "
                       "get system time failed.")
        return None
    if fan_list[2] == "na":
        return None
    else:
        if fan_list[0] == "FAN1":
            dict['device_name'] = "cpu1_fan"
        if fan_list[0] == "FAN2":
            dict['device_name'] = "cpu2_fan"
        if name_flag > 2:
            dict['device_name'] = "crate_fan{0}".format(name_flag-2)
        dict['monitor_time'] = timer
        dict['monitor_type'] = "fan_speed_monitor"
        dict['current_value'] = float(fan_list[2])
        dict['min_threshold'] = float(fan_list[10])
        dict['max_threshold'] = float(fan_list[16])
        dict['min_recover'] = float(fan_list[12])
        dict['max_recover'] = float(fan_list[14])
        dict['node_name'] = local_name
    return dict

def get_power_info(local_name):
    dict = {}
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_power_info(), get "
                       "system time failed.")
        return None
    try:
        power_out = subprocess.Popen("ipmitool -I open sensor|grep '12V'",
                                     shell=True, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE)
        power_out.wait()
        stderr = power_out.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_power_info(), get power " 
                           "info failed, with error: %s" % stderr)
            return None
    except Exception, e:
        digi_log.error("Monitor reporter, get_power_info(), get power info "
                       "failed, with error: %s" % e)
        return None
    power_info = power_out.stdout.readlines()
    if power_info:
        power_list = []
        power = power_info[0].rstrip('\n').split(' ')
        for info in power:
            if info:
                power_list.append(info)
        if len(power_list) < 19:
            return None
        if power_list[2] == "na":
            return None
        dict['monitor_time'] = timer
        dict['monitor_type'] = "power_volts_monitor"
        dict['device_name'] = power_list[0]
        dict['node_name'] = local_name
        dict['current_value'] = float(power_list[2])
        dict['min_threshold'] = float(power_list[10])
        dict['max_threshold'] = float(power_list[16])
        dict['min_recover'] = float(power_list[12])
        dict['max_recover'] = float(power_list[14])
        return dict
    else:
        digi_log.error("Monitor reporter, get_power_info(), get power info"
                       " get power info is null, failed.")
        return None

def get_cpu_temp_info(cpu_temp_list, local_name):
    dict = {}
    if len(cpu_temp_list) < 21:
        return None
    if cpu_temp_list[2] == "na":
        return None
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_cpu_temp_info(), get system "
                       "time failed.")
        return None
    dict['monitor_time'] = timer
    dict['monitor_type'] = "cpu_temp_monitor"
    dict['device_name'] = cpu_temp_list[0]
    dict['node_name'] = local_name
    dict['current_value'] = float(cpu_temp_list[3])
    dict['max_threshold'] = float(cpu_temp_list[18])
    dict['max_recover'] = float(cpu_temp_list[16])
    return dict

def get_bond_netcard_name_by_conf(bond_dev):
    netcard_list = []
    bondcard_name_list = []
    netcard_list = get_all_real_netcard_name()
    if not netcard_list:
        digi_log.error("Monitor reporter, get_bond_netcard_name_by_conf(),"
                       " get all netcard name failed.")
        return None
    for netcard in netcard_list:
        is_slave_true = 0
        #Possible have multi-line slave(master),aviod program crash.
        try:
            proc_out = subprocess.Popen("cat %s/ifcfg-%s|grep -w 'SLAVE=yes'"
                                        % (netconf_dir, netcard), shell=True,
                                        stdout=subprocess.PIPE, 
                                        stderr=subprocess.PIPE)
            proc_out.wait()
            stderr = proc_out.stderr.readlines()
            if stderr:
                digi_log.error("Monitor reporter, "
                               "get_bond_netcard_name_by_conf(), cat conf file"
                               " get bond info failed, error: %s" % stderr)
                return None
        except  Exception, e:
            digi_log.error("Monitor reporter, get_bond_netcard_name_by_conf(),"
                           " call Popen get bond info failed, error: %s" % e)
        is_slave = proc_out.stdout.readlines()
        if not is_slave:
            return None
        for slave in is_slave:
            if slave[0] != "#":
                is_slave_true = 1
                break
        if is_slave_true:
            try:
                master_out = subprocess.Popen("cat %s/ifcfg-%s|grep -w 'MASTER'"
                                             % (netconf_dir, netcard), shell=True,
                                             stdout=subprocess.PIPE,
                                             stderr=subprocess.PIPE)
                master_out.wait()
                stderr = master_out.stderr.readlines()
                if stderr:
                    digi_log.error("Monitor reporter, "
                                   "get_bond_netcard_name_by_conf(), get "
                                   "netcard mster info failed, with "
                                   "error: %s" % stderr)
                    return None
            except Exception, e:
                digi_log.error("Monitor reporter, "
                               "get_bond_netcard_name_by_conf(), call Popen "
                               "get netcard master info failed, with "
                               "error: %s" % e)
                return None
            is_master = master_out.stdout.readlines()
            if not is_master:
                return None
            for master in is_master:
                if is_master[0] != "#":
                    bond_name = master.split("=")[1].rstrip("\n")
                    if bond_name == bond_dev:
                        bondcard_name_list.append(netcard)
                        break
    return bondcard_name_list

def get_bond_netcard_info(bond_dev, local_name):
    dict = {}
    netcard_status_list = []
    name_list = []
    status_list = []
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_bond_netcard_info()," 
                       "get system time failed.")
        return None
    netcard_list = get_bond_netcard_name_by_conf(bond_dev)
    if not netcard_list:
        return None
    try:
        proc_status = subprocess.Popen("cat /proc/net/bonding/%s" % bond_dev,
                                       shell=True, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE)
        proc_status.wait()
        stderr = proc_status.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_bond_netcard_info(), get "
                           "bond status failed, with error: %s" % stderr)
            return None
    except Exception, e:
        digi_log.error("Monitor reporter, get_bond_netcard_info(), call Popen"
                       " to get bond status failed, with error: %s" % e)
        return None
    bond_status = proc_status.stdout.readlines()
    for status_info in bond_status:
        if status_info.find("Slave Interface:") != -1:
            status = status_info.rstrip('\n').split(' ')
            name_list.append(status[2])
        if status_info.find("MII Status:") != -1:
            status =status_info.rstrip('\n').split(' ')
            status_list.append(status[2])
    for netcard in netcard_list:
        netcard = netcard.rstrip(":")
        netcard_dict = {}
        i = 1
        j = 0
        for name in name_list:
            if name == netcard:
                netcard_dict['netcard_status'] = status_list[i]
                j = j + 1
            i = i + 1
        if j == 0:
            netcard_dict['netcard_status'] = "netcard down"
        netcard_dict['netcard_name'] = netcard
        netcard_status_list.append(netcard_dict)
    dict['bond_status'] = status_list[0]
    dict['monitor_time'] = timer
    dict['netcard_info'] = netcard_status_list
    dict['monitor_type'] = "netcard_bond_monitor"
    dict['device_name'] = bond_dev
    dict['node_name'] = local_name
    return dict

def get_netcard_speed_info(netcard, local_name):
    dict = {}
    support_list = []
    speed_list = []
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_netcard_speed_info(), "
                       "get system time failed.")
        return None
    try:
        ethtool_out = subprocess.Popen("ethtool %s" % netcard, shell=True,
                                       stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE)
        ethtool_out.wait()
        stderr = ethtool_out.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_netcard_speed_info(), "
                           "use ethtool get %s info failed, with "
                           "error: %s." % (netcard, stderr))
            return None
    except Exception, e:
        digi_log.error("Monitor reporter, get_netcard_speed_info(), call "
                       "Popen get netcard info failed, with error: %s" % e)
    ethtool_str = ethtool_out.stdout.readlines()
    if ethtool_str:
        for ethtool_info in ethtool_str:
            if ethtool_info.find("baseT/Full") != -1:
                if ethtool_info.find("Advertised link modes:") != -1:
                    break
                if ethtool_info.find("Supported link modes:") != -1:
                    ethtool_info = ethtool_info[22:]
                ethtool_list = ethtool_info.rstrip('\n').split(' ')
                for info in ethtool_list:
                    if info != "" and info != '\t':
                        support_list.append(info)
        link_speed_list = []
        for link_speed in support_list:
            speeds = re.match('\d+', link_speed)
            if speeds:
                speed = speeds.group()
                link_speed_list.append(speed)
            else:
                return None
        true_speed = 0
        for i in link_speed_list:
            if float(i) > float(true_speed):
                true_speed = i
        for ethtool_info in ethtool_str:
            if ethtool_info.find("Speed:") != -1:
                ethtool_list = ethtool_info.rstrip('\n').split(' ')
                for info in ethtool_list:
                    if info != "":
                        speed_list.append(info)
                current_str = speed_list[1]
                if current_str == "Unknown":
                    current_speed == "Unknown"
                    dict['current_speed'] = current_speed
                else:
                    current_speed = re.match('\d+', current_str)
                    if current_speed:
                        current_speed = current_speed.group()
                        dict['current_speed'] = float(current_speed)
                    else:
                        return None
    dict['node_name'] = local_name
    dict['monitor_type'] = "netcard_speed_monitor"
    dict['monitor_time'] = timer
    dict['device_name'] = netcard
    dict['theoretical_value'] = float(true_speed)
    return dict

def judge_disk_is_support_smartctl(disk_dev, smart_info):
    is_support = 0
    for info in smart_info:
        if info.rstrip('\n') == 'SMART support is: Enabled':
            is_support = 1
            break
    if not is_support:
        try:
            open_out = subprocess.Popen("smartctl -s on %s" % disk_dev,
                                        shell=True, stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE)
            open_out.wait()
            stderr = open_out.stderr.readlines()
            if stderr:
                digi_log.error("Monitor reporter, get_disk_smart_dete_info(), "
                               "use 'smartctl' open disk %s smartctl function "
                               "failed, with error: %s" % (disk_dev, stderr))
                return 0
        except Exception, e:
            digi_log.error("Monitor reporter, get_disk_smart_dete_info(), call "
                           "Popen to open disk %s smart function failed, with "
                           "error: %s" % (disk_dev, e))
            return 0
        open_info = open_out.stdout.readlines()
        for info in open_info:
            if info[0].rstrip('\n') == 'SMART Enabled.':
                is_support = 1
                break
        if not is_support:
            digi_log.error("Monitor reporter, get_disk_smart_dete_info(), can "
                           "not open disk %s smart function." % disk_dev)
            return 0
    return is_support

def get_disk_detection_info_list(disk_dev, smart_info):
    temp_list = []
    type_find = 0
    monitor_info_list = []
    for info in smart_info:
        if info.find('Rotation Rate:') != -1:
            info = info.rstrip('\n').split(' ')
            for temp_info in info:
                if temp_info:
                    temp_list.append(temp_info)
            temp_find = 1
            break
    if temp_find:
        disk_speed = re.match('\d+', temp_list[2])
        if disk_speed:
            info_find = 0
            for s_info in smart_info:
                if info_find:
                    if s_info == '\n':
                        break
                    temp_list = []
                    info = s_info.rstrip('\n').split(' ')
                    for temp_info in info:
                        if temp_info:
                            temp_list.append(temp_info)
                    monitor_info_list.append(temp_list)
                if s_info.find('ATTRIBUTE_NAME') != -1:
                    info_find = 1
            return monitor_info_list
        else:
            digi_log.error("Monitor reporter, get_disk_smart_dete_info(), "
                           "disk %s is a Solid State Device, can not get "
                           "smart info." % disk_dev)
    return None

def get_disk_smart_dete_info(disk_dev, system_disk, local_name):
    dict = {}
    monitor_info_list = []
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_disk_smart_dete_info(), "
                       "get system time failed.")
        return None
    try:
        smart_out = subprocess.Popen("smartctl -a %s" % disk_dev, shell=True,
                                     stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE)
        smart_out.wait()
        stderr = smart_out.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_disk_smart_dete_info(), use "
                           "'smartctl' get %s smart detection info failed, "
                           "with error: %s" % (disk_dev, stderr))
            return None
    except Exception, e:
        digi_log.error("Monitor reporter, get_disk_smart_dete_info(), call "
                       "Popen get disk smart info failed, with error: %s" % e)
        return None
    smart_info = smart_out.stdout.readlines()
    #flag disk is or not open support smartctl detection
    is_support = judge_disk_is_support_smartctl(disk_dev, smart_info)
    if is_support:
        temp_list = []
        type_find = 0
        #get disk smartctl detection info
        monitor_info_list = get_disk_detection_info_list(disk_dev, smart_info)
        if monitor_info_list:
            dict['smart_info'] = monitor_info_list
            if disk_dev == system_disk:
                disk_id_name = "system_disk"
            else:
                disk_id_name = replace_disk_name_by_id(disk_dev)
                if not disk_id_name:
                    return None
                dict['device_name'] = disk_id_name
            dict['monitor_time'] = timer
            dict['monitor_type'] = "disk_smart_detection"
            dict['node_name'] = local_name
            return dict
    return None

def get_check_system_disk_info(fp, test_str):
    dict = {}
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_check_system_disk_info(), "
                       "get system time failed.")
        return None
    local_name = get_local_hostname_by_ip()
    if not local_name:
        digi_log.error("Monitor reporter, get_check_system_disk_info(), "
                       "get hostname failed.")
        return None
    try:
        os.lseek(fp, 0, 0)
        write_byte = os.write(fp, test_str)
        os.fsync(fp)
    except Exception, e:
        digi_log.error("Monitor reporter, get_check_system_disk_info(), write "
                       "to '/check_system_file' failed, with error: %s" % e)
        return None
    if write_byte >= 0:
        dict['system_disk_status'] = "ok"
    else:
        try:
            os.lseek(fp, 0, 0)
            write_byte = os.write(fp, test_str)
            os.fsync(fp)
        except Exception, e:
            digi_log.error("Monitor reporter, get_check_system_disk_info(), "
                           "write to '/check_system_file' failed, with "
                           "error: %s" % e)
            return None
        if write_byte >= 0:
            dict['system_disk_status'] = "ok"
        else:
            dict['system_disk_status'] = "broken"
    dict['device_name'] = "system_disk"
    dict['node_name'] = local_name
    dict['monitor_time'] = timer
    dict['monitor_type'] = "check_system_disk"
    return dict

def get_network_connected_info(queue, node_name):
    ping_result_dict = {}
    try:
        ping_out = subprocess.Popen("ping -c 4 %s|grep '0 received'|wc -l" %
                                    node_name, shell=True, 
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE)
        ping_out.wait()
        stderr = ping_out.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_check_system_disk_info(),"
                           "command PING is failed, with error: %s" % stderr)
            return None
    except Exception, e:
        digi_log.error("Monitor reporter, get_check_system_disk_info(), call"
                       "Popen get ping result failed, with error: %s" % e)
        return None
    ping_result = ping_out.stdout.readlines()
    if ping_result:
        if ping_result[0].rstrip('\n') == '0':
            ping_result_dict['ping_result'] = "ok"
        else:
            ping_result_dict['ping_result'] = "failed"
        ping_result_dict['ping_node_name'] = node_name
        queue.put(ping_result_dict)
    else:
        return None

def get_redundancy_power_monitor_info(queue):
    while True:
        dict = {}
        module_dict = {}
        module_flag = 1
        number = 0
        timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
        if not timer:
            digi_log.error("Monitor reporter, "
                           "get_redundancy_power_monitor_info(), "
                           "get system time failed.")
            continue
        local_name = get_local_hostname_by_ip()
        if not local_name:
            digi_log.error("Monitor reporter, "
                           "get_redundancy_power_monitor_info(), "
                           "get local hostname failed.")
            continue
        try:
            ipmicfg_out = subprocess.Popen("ipmicfg -pminfo", shell=True,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE)
            ipmicfg_out.wait()
            stderr = ipmicfg_out.stderr.readlines()
            if stderr:
                digi_log.error("Monitor reporter, "
                               "get_redundancy_power_monitor_info(), use "
                               "ipmicfg get redundancy power info "
                               "failed, with error: %s" % stderr)
                continue
        except Exception, e:
            digi_log.error("Monitor reporter, "
                           "get_redundancy_power_monitor_info(), call "
                           "Popen to get redundancy power info failed, with"
                           " error: %s" % e)
            continue
        ipmicfg_list = ipmicfg_out.stdout.readlines()
        if ipmicfg_list:
            if ipmicfg_list[0].find('Not detect the power module.') != -1:
                digi_log.info("Monitor reporter, "
                               "get_redundancy_power_monitor_info(), not "
                               "find redundancy power module in this node.")
                time.sleep(sleep_time1)
                continue
            status_list = []
            for ipmicfg_str in ipmicfg_list:
                if ipmicfg_str.find("Status") != -1:
                    temp_list = []
                    ipmicfg_info = ipmicfg_str.rstrip('\n').split(' ')
                    for info in ipmicfg_info:
                        if info:
                            temp_list.append(info)
                    status_list.append(temp_list[3])
            status_list = status_list[0:2]
            for status in status_list:
                if status == "OK](00h)":
                    module_dict['module{0}'.format(module_flag)] = "ok"
                    number += 1
                else:
                    module_dict['module{0}'.format(module_flag)] = "down"
                module_flag += 1
            dict['module_info'] = module_dict
            dict['device_name'] = "redundancy_power"
            dict['monitor_time'] = timer
            dict['monitor_type'] = "redundancy_power_rank_monitor"
            dict['node_name'] = local_name
            dict['power_rank'] = number
            if dict:
                queue.put(dict)
            time.sleep(sleep_time1)

def get_disk_rdwr_info(disk_info, local_name):
    dict = {}
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_disk_rdwr_info(), get system "
                       "time failed.")
        return None
    test_str = "checkdatadiskrdwrinfo"
    os.system("cp %s %s" % (check_data_disk_file, disk_info[2]))
    file_name = "{0}/check_data_disk_file".format(disk_info[2])
    try:
        fp = os.open(file_name, os.O_RDWR)
    except Exception, e:
        digi_log.error("Monitor reporter, get_disk_rdwr_info(), open file "
                       "failed, with error: %s" % e)
        return None
    try:
        read_byte = os.read(fp, 10)
    except Exception, e:
        digi_log.error("Monitor reporter, get_disk_rdwr_info(), read to "
                       "file failed, with error: %s" % e)
        return None
    if not read_byte:
        try:
            read_byte = os.read(fp, 10)
        except Exception, e:
            digi_log.error("Monitor reporter, get_disk_rdwr_info(), read to "
                           "file failed, with error: %s" % e)
            return None
        if not read_byte:
            dict['disk_read'] = 'failed'
        else:
            dict['disk_read'] = 'ok'
    else:
        dict['disk_read'] = 'ok'
    try:
        write_byte = os.write(fp, test_str)
        os.fsync(fp)
    except Exception, e:
        digi_log.error("Monitor reporter, get_disk_rdwr_info(), write to "
                       "file error, with error: %s" % e)
        return None
    if write_byte >= 0:
        dict['disk_write'] = "ok"
    else:
        try:
            write_byte = os.write(fp, test_str)
            os.fsync(fp)
        except Exception, e:
            digi_log.error("Monitor reporter, get_disk_rdwr_info(), write to "
                           "file error, with error: %s" % e)
            return None
        if write_byte >= 0:
            dict['disk_write'] = "ok"
        else:
            dict['disk_write'] = "falied"
    os.close(fp)
    os.system("rm -rf %s" % file_name)
    id_name = replace_disk_name_by_id(disk_info[0])
    if not id_name:
        return None
    dict['device_name'] = id_name
    dict['node_name'] = local_name
    dict['monitor_time'] = timer
    dict['monitor_type'] = "data_disk_rdwr_monitor"
    return dict

def get_all_mounted_disk_dev_name():
    mounted_disk_list = []
    try:
        mount_out = subprocess.Popen("mount|grep '/dev/sd'|awk '{print $1}'",
                                     shell=True, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE)
        mount_out.wait()
        stderr = mount_out.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_all_mounted_disk_dev_name(),"
                           " use 'mount' get mounted disks failed, with error:"
                           " %s" % stderr)
            return None
    except Exception, e:
        digi_log.error("Monitor reporter, get_all_mounted_disk_dev_name(), call"
                       " Popen get mounted disks failed, with error: %s" % e)
        return None
    stdout = mount_out.stdout.readlines()
    if stdout:
        for disk in stdout:
            mounted_disk_list.append(disk.rstrip('\n'))
        return mounted_disk_list
    else:
        return None

def disk_dev_name_deal_with_none_system_disk(dev_list):
    disk_list = []
    for dev_name in dev_list:
        disk = re.match("\D*", dev_name)
        if disk:
            disk = disk.group()
        else:
            return None
        is_have_disk = 0
        for disk_name in disk_list:
            if disk_name == disk:
                is_have_disk = 1
                break
        if is_have_disk:
            continue
        else:
            disk_list.append(disk)
    return disk_list

def get_all_disk_info(queue):
    while True:
        size_dict = {}
        inode_dict = {}
        node_total_size = 0
        node_used_size = 0
        node_disk_list = []
        system_disk = get_system_disk_name()
        dev_list = get_all_mounted_disk_dev_name()
        if not dev_list:
            digi_log.error("Monitor reporter, get_all_disk_info(), "
                           "not find mounted disks.")
            continue
        local_name = get_local_hostname_by_ip()
        if not local_name:
            digi_log.error("Monitor reporter, get_all_disk_info(), "
                           "get hostname failed.")
            continue
        try:
            size_out = subprocess.Popen("df|grep '/dev/'", shell=True,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE)
            size_out.wait()
            stderr = size_out.stderr.readlines()
            if stderr:
                digi_log.error("Monitor reporter, get_all_disk_info(), use "
                               "'df' get disk size info failed, with "
                               "error: %s" % stderr)
        except Exception, e:
            digi_log.error("Monitor reporter, get_all_disk_info(), call Popen "
                           " use 'df' failed, with error: %s" % e)
        size_info = size_out.stdout.readlines()
        try:
            inode_out = subprocess.Popen("df -i|grep '/dev/'", shell=True,
                                         stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE)
            inode_out.wait()
            stderr = inode_out.stderr.readlines()
            if stderr:
                digi_log.error("Monitor reporter, get_all_disk_info(), use "
                               "'df' get disk inode info failed, with "
                               "error: %s" % stderr)
        except Exception, e:
            digi_log.error("Monitor reporter, get_all_disk_info(), call "
                           "Popen use 'df' failed, with error: %s" % e)
        inode_info = inode_out.stdout.readlines()
        if not system_disk:
            #not handle all disk partitions
            disk_list = disk_dev_name_deal_with_none_system_disk(dev_list)
            if not disk_list:
                return None
            for disk in disk_list:
                #will the system disk as data disk
                if size_info:
                    size_dict = get_disk_size_info(disk, local_name,
                                                   system_disk, size_info)
                    if size_dict:
                        queue.put(size_dict)
                if inode_info:
                    inode_dict = get_disk_inode_info(disk, local_name,
                                                     system_disk, inode_info)
                    if inode_dict:
                        queue.put(inode_dict)
        else:
            #flag deal system_disk number
            handle_system_disk = 0
            #judge already deal data_disk
            data_disk_list = []
            is_have_data_disk = 0
            #will abandon all data disk partitions
            for disk_name in dev_list:
                disk = re.match("\D*", disk_name)
                if disk:
                    disk = disk.group()
                else:
                    continue
                #is system_disk or system_disk partitions
                if disk == system_disk:
                    get_system_disk_zone_info(disk_name, system_disk, queue, 
                                              handle_system_disk, local_name,
                                              size_info, inode_info)
                    handle_system_disk = 1
                else:
                    for data_disk in data_disk_list:
                        if disk == data_disk:
                            is_have_data_disk = 1
                            break
                    if not is_have_data_disk:
                        if size_info:
                            size_dict = get_disk_size_info(disk, local_name,
                                                           system_disk, size_info)
                            if size_dict:
                                queue.put(size_dict)
                        if inode_info:
                            inode_dict = get_disk_inode_info(disk, local_name,
                                                         system_disk, inode_info)
                            if inode_dict:
                                queue.put(inode_dict)
                        data_disk_list.append(disk)
                    else:
                        continue
                if size_dict:
                    if size_dict['device_name'] != system_disk:
                        node_disk_list.append(size_dict['device_name'])
                        node_total_size += size_dict['total_size']
                        node_used_size += size_dict['used_size']
        node_size_dict = {}
        node_size_dict['monitor_type'] = "node_size_monitor"
        node_size_dict['node_name'] = local_name
        node_size_dict['monitor_time'] = inode_dict['monitor_time']
        node_size_dict['total_size'] = node_total_size
        node_size_dict['used_size'] = node_used_size
        node_size_dict['size_usage'] = ("%.2f" % ((float(node_used_size)/
                                        float(node_total_size)) * 100))
        node_size_dict['node_disk_list'] = node_disk_list
        node_size_dict['device_name'] = "node_all_data_disk"
        queue.put(node_size_dict)
        time.sleep(sleep_time4)

def get_all_fan_info(queue):
    while True:
        dict = {}
        fan_name_flag = 1
        local_name = get_local_hostname_by_ip()
        if not local_name:
            digi_log.error("Monitor reporter, get_all_fan_info(), " 
                           "get hostname failed.")
            continue
        try:
            fan_out = subprocess.Popen("ipmitool -I open sensor|grep FAN",
                                       shell=True, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE)
            fan_out.wait()
            stderr = fan_out.stderr.readlines()
            if stderr:
                digi_log.error("Monitor reporter, get_all_fan_info(), get fan "
                               "sensor info failed, with error: %s" % stderr)
                continue
        except Exception, e:
            digi_log.error("Monitor reporter, get_all_fan_info(), "
                           "call Popen to get fan seneor info failed, with "
                           "error: %s" % e)
            continue
        fan_info = fan_out.stdout.readlines()
        if fan_info:
            for fan in fan_info:
                fan_list = []
                fan = fan.rstrip('\n').split(' ')
                for info in fan:
                    if info:
                        fan_list.append(info)
                dict = get_fan_info(fan_list, fan_name_flag, local_name)
                fan_name_flag += 1
                if dict:
                    queue.put(dict)
            time.sleep(sleep_time1)
        else:
            digi_log.info("Monitor reporter, get_all_fan_info(), get "
                          "fan sensor info is NULL, failed.")
            continue

def get_all_power_info(queue):
    while True:
        dict = {}
        local_name = get_local_hostname_by_ip()
        if not local_name:
            digi_log.error("Monitor reporter, get_all_power_info(), "
                           "get hostname failed.")
            continue
        dict = get_power_info(local_name)
        if dict:
            queue.put(dict)
        time.sleep(sleep_time1)

def get_all_cpu_temp_info(queue):
    while True:
        dict = {}
        local_name = get_local_hostname_by_ip()
        if not local_name:
            digi_log.error("Monitor reporter, get_all_cpu_temp_info(), "
                           "get hostname failed.")
            continue
        try:
            cpu_out = subprocess.Popen("ipmitool -I open sensor|"
                                       "grep 'CPU Temp'", shell=True, 
                                       stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE)
            cpu_out.wait()
            stderr = cpu_out.stderr.readlines()
            if stderr:
                digi_log.error("Monitor reporter, get_all_cpu_temp_info(), "
                               "use ipmitool get cpu temp failed, " 
                               "with error: %s" % stderr)
                continue
        except Exception, e:
            digi_log.error("Monitor reporter, get_all_cpu_temp_info(), "
                           "call Popen to get cpu temp info failed.")
            continue
        cpu_temp_info = cpu_out.stdout.readlines()
        if cpu_temp_info:
            for cpu_info in cpu_temp_info:
                cpu_temp_list = []
                cpu_info = cpu_info.rstrip('\n').split(' ')
                for info in cpu_info:
                    if info:
                        cpu_temp_list.append(info)
                dict = get_cpu_temp_info(cpu_temp_list, local_name)
                if dict:
                    queue.put(dict)
            time.sleep(sleep_time3)
        else:
            digi_log.error("Monitor reporter, get_all_cpu_temp_info(), "
                           "get cpu temp info is null, failed.")
            continue

def get_all_bond_info(queue):
    while True:
        dict = {}
        local_name = get_local_hostname_by_ip()
        if not local_name:
            digi_log.error("Monitor reporter, get_all_bond_info(), "
                           "get hostname failed.")
            continue
        try:
            bond_out = subprocess.Popen("ifconfig -a|grep 'bond'|"
                                        "awk '{print $1}'", shell=True, 
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE)
            bond_out.wait()
            stderr = bond_out.stderr.readlines()
            if stderr:
                digi_log.error("Monitor reporter, get_all_bond_info(), get "
                               "all bond name failed, with error: %s" % stderr)
                continue
        except Exception, e:
            digi_log.error("Monitor reporter, get_all_bond_info(), call Popen "
                           "to get all bond name failed, with error: %s" % e)
            continue
        bond_list = bond_out.stdout.readlines()
        if bond_list:
            for bond in bond_list:
                bond_name = bond.rstrip(':\n')
                dict = get_bond_netcard_info(bond_name, local_name)
                if dict:
                    queue.put(dict)
            time.sleep(sleep_time2)
        else:
            digi_log.info("Monitor reporter, get_all_bond_info(), "
                           "use command get bond name is null.")
            continue

def get_all_netcard_speed_info(queue):
    while True:
        dict = {}
        local_name = get_local_hostname_by_ip()
        if not local_name:
            digi_log.error("Monitor reporter, get_all_netcard_speed_info(), "
                           "get hostname failed.")
            continue
        netcard_list = get_all_real_netcard_name()
        if not netcard_list:
            digi_log.error("Monitor reporter, get_all_netcard_speed_info(), "
                           "get all netcard name failed.")
            continue
        if netcard_list:
            for netcard in netcard_list:
                dict = get_netcard_speed_info(netcard, local_name)
                if dict:
                    queue.put(dict)
            time.sleep(sleep_time1)

def get_all_disk_smart_dete_info(queue):
    while True:
        dict = {}
        compare_list = []
        system_disk = get_system_disk_name()
        local_name = get_local_hostname_by_ip()
        if not local_name:
            digi_log.error("Monitor reporter, get_all_disk_smart_dete_info(), "
                           "get hostname failed.")
            continue
        #get all mounted disks, include all partitions
        dev_list = get_all_mounted_disk_dev_name()
        #take out all partitions symbol, every disk only appear once in list
        disk_list = disk_dev_name_deal_with_none_system_disk(dev_list)
        for disk in disk_list:
            dict = get_disk_smart_dete_info(disk, system_disk, local_name)
            if dict:
                queue.put(dict)
        time.sleep(sleep_time4)

def check_system_disk_status(queue):
    try:
        ret = os.path.exists(check_file)
        if not ret:
            os.system("touch %s" % check_file)
        fp = os.open(check_file, os.O_WRONLY|os.O_TRUNC)
    except Exception, e:
        digi_log.error("Monitor reporter, check_system_disk_status(), open "
                       "'/check_system_file' failed, with error: %s." % e)
    test_str = "asdfghjkl"
    while True:
        dict = {}
        dict = get_check_system_disk_info(fp, test_str)
        if dict:
            queue.put(dict)
        time.sleep(sleep_time2)

def get_all_node_connection_info(queue):
    node_connected_queue = Queue(1000)
    while True:
        dict = {}
        connected_info_dict = {}
        connected_list = []
        unconnected_list = []
        connected_number = 0
        name_list = []
        local_name = get_local_hostname_by_ip()
        if not local_name:
            digi_log.error("Monitor reporter, get_all_node_connection_info(), "
                           "get local hostname failed.")
            continue
        timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
        if not timer:
            digi_log.error("Monitor reporter, get_all_node_connection_info(), "
                           "get system time failed.")
            continue
        try:
            node_out = subprocess.Popen("digiocean peer status|grep 'Hostname:'|"
                                        "awk '{print $2}'", shell=True,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE)
            node_out.wait()
            stderr = node_out.stderr.readlines()
            if stderr:
                digi_log.error("Monitor reporter, "
                               "get_all_node_connection_info(), get service "
                               "all node name failed, with error: %s" % stderr)
                continue
        except Exception, e:
            digi_log.error("Monitor reporter, get_all_node_connection_info(), "
                           "call Popen get all node name failed, with "
                           "error: %s" % e)
            continue
        node_list = node_out.stdout.readlines()
        if node_list:
            for node_name in node_list:
                try:
                    node_name = node_name.rstrip('\n')
                    node_name = (threading.Thread(
                                 target = get_network_connected_info, 
                                 args = (node_connected_queue, node_name, )))
                    node_name.start()
                    name_list.append(node_name)
                except Exception, e:
                    digi_log.error("Monitor reporter, "
                                   "get_all_node_connection_info(), create "
                                   "thread failed, with error: %s" % e)
                    continue
            for name in name_list:
                name.join()
            while node_connected_queue.qsize():
                connected_info_dict = node_connected_queue.get()
                if connected_info_dict:
                    if connected_info_dict['ping_result'] == "ok":
                        connected_number += 1
                        (connected_list.append(
                                    connected_info_dict['ping_node_name']))
                    else:
                        (unconnected_list.append(
                                    connected_info_dict['ping_node_name']))
            node_number = len(node_list) + 1
            dict['monitor_type'] = "detection_node_connection"
            dict['monitor_time'] = timer
            dict['node_name'] = local_name
            dict['connected_number'] = connected_number
            dict['node_number'] = node_number
            dict['ping_ok'] = connected_list
            dict['ping_failed'] = unconnected_list
            if dict:
                queue.put(dict)
        else:
            digi_log.info("Monitor reporter, get_all_node_connection_info(), "
                          "get service node_list is null.")
        time.sleep(sleep_time3)

def get_all_disk_rdwr_monitor_info(queue):
    while True:
        local_name = get_local_hostname_by_ip()
        if not local_name:
            digi_log.error("Monitor reporter, get_all_disk_rdwr_monitor_info(), "
                           "get local hostname failed.")
            return None
        proc = subprocess.Popen("mount|grep '/dev/sd'|grep '/digioceanfs/wwn'",
                                shell=True, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)
        stderr = proc.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_all_disk_rdwr_monitor_info(), "
                           "get mounted disk failed, with error: %s" % stderr)
            continue
        stdout = proc.stdout.readlines()
        if not stdout:
            digi_log.error("Monitor reporter, get_all_disk_rdwr_monitor_info(), "
                           "get mounted disk is null, failed.")
            continue
        for disk_info in stdout:
            disk_info_list = []
            disk_info = disk_info.rstrip('\n').split(' ')
            for info in disk_info:
                if info:
                    disk_info_list.append(info)
            dict = get_disk_rdwr_info(disk_info_list, local_name)
            if dict:
                queue.put(dict)
        time.sleep(sleep_time4)

def get_cpu_usage_data(queue, data_dict, local_name):
    dict = {}
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_cpu_usage_data(), "
                       "get system time failed.")
        return None
    cpu_data = data_dict['CPU_ALL']
    cpu_data = cpu_data[1:]
    for data in cpu_data:
        if data[0] == "User%":
            dict['user_usage'] = float(data[1])
        elif data[0] == "Sys%":
            dict['sys_usage'] = float(data[1])
        elif data[0] == "CPUs":
            dict['cpu_usage'] = float(data[1])
    dict['monitor_type'] = "cpu_usage_monitor"
    dict['monitor_time'] = timer
    dict['device_name'] = "CPU"
    dict['node_name'] = local_name
    queue.put(dict)

def get_mem_usage_data(queue, data_dict, local_name):
    dict = {}
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_mem_usage_data(), "
                       "get system time failed.")
        return None
    mem_data = data_dict['MEM'][1:]
    for data in mem_data:
        if data[0] == "memtotal":
            dict['mem_total'] = float(data[1])
        elif data[0] == "memfree":
            dict['mem_free'] = float(data[1])
    dict['men_usage'] = "%.2f" % ((float(dict['mem_total']) - float(
                        dict['mem_free']))/float(dict['mem_total']) * 100)
    dict['monitor_type'] = "mem_usage_monitor"
    dict['node_name'] = local_name
    dict['monitor_time'] = timer
    dict['device_name'] = "Memory"
    queue.put(dict)

def get_netcard_flux_data(net_data, netcard, local_name):
    dict = {}
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_netcard_flux_data(), "
                       "get system time failed.")
        return None
    for net in net_data:
        if("%s-write-KB/s" % netcard) == net[0]:
            dict['netcard_write'] = float(net[1])
        if("%s-read-KB/s" % netcard) == net[0]:
            dict['netcard_read'] = float(net[1])
    dict['device_name'] = netcard
    dict['monitor_type'] = "netcard_flux_monitor"
    dict['node_name'] = local_name
    dict['time'] = timer
    return dict

def get_ip_by_netcard_name(netcard_name):
    try:
        out = subprocess.Popen("ifconfig %s|grep -w 'inet'|awk '{print $2}'"
                               % netcard_name, shell=True,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,)
        out.wait()
        stderr = out.stderr.readlines()
        if stderr:
            digi_log.error("Monitor reporter, get_ip_by_netcard_name(), use "
                           "'ifconfig' failed, with error: %s" % stderr)
            return None
    except Exception, e:
        digi_log.error("Monitor reporter, get_ip_by_netcard_name(), call "
                       "Popen use 'ifconfig' failed, with error: %s" % e)
        return None
    stdout = out.stdout.readlines()
    if stdout:
        ip = stdout[0].rstrip('\n')
        return ip
    else:
        return None

def get_all_netcard_flux_info(queue, data_dict, local_name):
    netcard_list = get_all_real_netcard_name()
    if not netcard_list:
        digi_log.error("Monitor reporter, get_all_netcard_flux_info(), "
                       "get netcard list failed.")
        return None
    net_data = data_dict['NET'][1:]
    for netcard in netcard_list:
        dict = {}
        ip = get_ip_by_netcard_name(netcard)
        dict = get_netcard_flux_data(net_data, netcard ,local_name)
        if dict:
            dict['netcard_ip'] = ip
            queue.put(dict)

def get_disk_io_info(disk_data_list, disk, local_name, system_disk):
    flag = 1
    dict = {}
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    if not timer:
        digi_log.error("Monitor reporter, get_all_disk_io_info(), "
                       "get system time failed.")
        return None
    if disk == system_disk:
        disk_name = "system_disk"
    else:
        disk_name = replace_disk_name_by_id(disk)
    for disk_data in disk_data_list:
        for data in disk_data:
            if data[0] == disk[5:]:
                if flag == 1:
                    dict['disk_read'] = float(data[1])
                elif flag == 2:
                    dict['disk_write'] = float(data[1])
        flag = flag + 1
    dict['monitor_time'] = timer
    dict['monitor_type'] = "disk_io_monitor"
    dict['node_name'] = local_name
    dict['device_name'] = disk_name
    return dict

def get_all_disk_io_info(queue, data_dict, local_name):
    dict = {}
    node_disk_io = {}
    compare_list = []
    system_disk = get_system_disk_name()
    disk_data_list = []
    node_total_disk_read_io = 0
    node_total_disk_write_io = 0
    dev_list = get_all_mounted_disk_dev_name()
    if not dev_list:
        digi_log.error("Monitor reporter, get_all_disk_io_info(), get all "
                       "mounted disk failed.")
        return None
    disk_list = disk_dev_name_deal_with_none_system_disk(dev_list)
    if not disk_list:
        return None
    disk_read_data = data_dict['DISKREAD'][1:]
    disk_data_list.append(disk_read_data)
    disk_write_data = data_dict['DISKWRITE'][1:]
    disk_data_list.append(disk_write_data)
    for disk in disk_list:
        dict = get_disk_io_info(disk_data_list, disk, local_name, system_disk)
        if dict:
            queue.put(dict)
        if system_disk:
            if disk == system_disk:
                continue
            else:
                node_total_disk_read_io += dict['disk_read']
                node_total_disk_write_io += dict['disk_write']
    timer = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    node_disk_io['monitor_type'] = "node_disk_io_monitor"
    node_disk_io['node_name'] = local_name
    node_disk_io['monitor_time'] = timer
    node_disk_io['node_read'] = node_total_disk_read_io
    node_disk_io['node_write'] = node_total_disk_write_io
    node_disk_io['device_name'] = "node_all_data_disk"
    if node_disk_io:
        queue.put(node_disk_io)

def analyse_nmon_data_get_io_info(queue):
    while True:
        is_true = os.path.exists("/tmp/nmon_data")
        if not is_true:
            os.makedirs("/tmp/nmon_data")
        else:
            os.system("rm -rf /tmp/nmon_data/*")
        try:
            proc = subprocess.Popen("nmon -s 3 -c 1 -f -m /tmp/nmon_data",
                                    shell=True, stdout=subprocess.PIPE, 
                                    stderr=subprocess.PIPE)
            proc.wait()
            stderr = proc.stderr.readlines()
            if stderr:
                digi_log.error("Monitor reporter, "
                               "analyse_nmon_data_get_io_info(), use "
                               "nmon failed, with error: %s" % stderr)
                continue
        except Exception, e:
            digi_log.error("Monitor reporter, analyse_nmon_data_get_io_info(),"
                           " call Popen use nmon failed, with error: %s" % e)
            continue
        time.sleep(3)
        try:
            name_out = subprocess.Popen("ls /tmp/nmon_data", shell=True,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE)
            name_out.wait()
            stderr = name_out.stderr.readlines()
            if stderr:
                digi_log.error("Monitor reporter, "
                               "analyse_nmon_data_get_io_info(), "
                               "use 'ls' failed, with error: %s" % e)
                continue
        except Exception, e:
            digi_log.error("Monitor reporter, analyse_nmon_data_get_io_info(), "
                           "call Popen use 'ls' failed, with error: %s" % e)
        data_name = name_out.stdout.readlines()
        if data_name:
            inputStr = open("/tmp/nmon_data/%s" % data_name[0].rstrip('\n')).read()
            pynmonParser = pyNmonParser(inputStr)
            local_name = get_local_hostname_by_ip()
            if not local_name:
                digi_log.error("Monitor reporter, analyse_nmon_data_get_io_info(), "
                               "get local hostname failed.")
                continue
            nmon_dict = {}
            nmon_dict = pynmonParser.parse()
            Get_cpu_usage_info_pthread = threading.Thread(target = 
                                         get_cpu_usage_data, args = 
                                         (queue, nmon_dict, local_name, ))
            Get_mem_usage_info_pthread = threading.Thread(target = 
                                         get_mem_usage_data, args = 
                                         (queue, nmon_dict, local_name, ))
            Get_net_flux_info_pthread = threading.Thread(target = 
                                        get_all_netcard_flux_info, args = 
                                        (queue, nmon_dict, local_name, ))
            Get_disk_io_info_pthread = threading.Thread(target = 
                                       get_all_disk_io_info, args = 
                                       (queue, nmon_dict, local_name, ))

            Get_cpu_usage_info_pthread.start()
            Get_mem_usage_info_pthread.start()
            Get_net_flux_info_pthread.start()
            Get_disk_io_info_pthread.start()

            time.sleep(sleep_time3)
################################################################################

def get_alarm_info_in_alarmcol(type_list, data, mongo_dict):
    id_list = []
    message_list = []
    message = {}
    max_id = 0
    if not mongo_dict:
        digi_log.error("Monitor reporter, get_alarm_info_in_alarmcol() "
                       "db handle dict is null, can not judge, failed.")
        return None
    mongo_dict['alarmcol'].sort([('id', pymongo.DESCENDING)])
    mongo_dict['alarmcol'].limit(1)
    for type_info in type_list:
        message = (mongo_dict['alarmcol'].read({'node': data['node_name'],
                    'device': data['device_name'], 'type': type_info}))
        if not message:
            continue
        elif message == -1:
            ret = reconnect_mongodb(mongo_dict['alarmcol'], mongo_dict)
            if ret == -1:
                digi_log.error("Monitor reporter, "
                               "get_alarm_info_in_alarmcol() reconnecte "
                               "db failed, mongo_dict['alarmcol'] is null.")
                return None
            message = (mongo_dict['alarmcol'].read(
                      {'node': data['node_name'], 
                       'device': data['device_name'], 'type': type_info}))
            if not message:
                continue
        message_list.append(message)
        id_list.append(message['id'])
    for id in id_list:
        if max_id < id:
            max_id = id
    for message_info in message_list:
        if message_info['id'] == max_id:
            message = message_info
            break
    return message

def is_digioceand_runing ():
    if os.path.exists(DIGIOCEAND):
        try:
            status_line = os.popen("ps -ef | grep -v grep | grep digioceand.pid").read()
        except Exception,e:
            digi_log.error ("popen is failed, and error info is %s"%e)
            return False
        if status_line:
                return True
    return False

def get_volume_size_data (mount_line):
    mount_line_list = []
    list = []
    mount_line_list = mount_line.split(' ')
    for i in mount_line_list:
        if not i == '':
            list.append(i)
    return list

def get_volume_uuid (vol_name):
    volume_uuid = ''
    try:
        if os.path.exists(DIGIOCEAN) and is_digioceand_runing():
            proc = subprocess.Popen("%s volume info %s"%(DIGIOCEAN,vol_name),
                    shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            vol_info = proc.stdout.readlines() + proc.stderr.readlines()
            proc.wait()
        else:
            digi_log.error ("digiocean or digioceand process is not exists")
            return volume_uuid
    except Exception,e:
        digi_log.error ("popen is failed, and error info is %s"%e)
        return volume_uuid
    for line in vol_info:
        if line.find('not exist') >= 0:
            digi_log.error ("get_volume_uuid, current volume %s is not exists"%vol_name)
            return volume_uuid
    for line in vol_info:
        if line:
            volume_uuid_line = re.findall('Volume ID:\s+.*',line)
            if volume_uuid_line:
                volume_uuid_list = re.split (':\s+',volume_uuid_line[0])
                volume_uuid = volume_uuid_list[1]
    return volume_uuid

def get_volume_size_info (queue, vol_name):
    dict = {}
    dict['monitor_type'] = "vol_size"
    dict['node'] = get_local_hostname_by_ip()
    if not dict['node']:
        return None
    dict['data'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
    try:
        mount_list = os.popen ("df").readlines()
    except Exception,e:
        digi_log.error ("popen is failed, and error info is %s"%e, 3)
        return None
    i = 0
    for mount_line in mount_list:
        if mount_line.find (vol_name) >= 0:
            list = get_volume_size_data (mount_line)
            break
        i += 1
    if i == len(mount_list):
        dict['use_size'] = '--'
        dict['not_use_size'] = '--'
        dict['total_size'] = '--'
        digi_log.error ("not found %s service mount"%vol_name)
        return None
    else:
        dict['use_size'] = list[2]
        dict['not_use_size'] = list[3]
        dict['total_size'] = int(list[2]) + int(list[3])
    dict['vol_name'] = vol_name
    dict['vol_uuid'] = get_volume_uuid (vol_name)
    if not dict['vol_uuid']:
        return None
    dict['event_group'] = 'SERVICE'
    queue.put(dict)

def get_volume_usage_info_thread(queue):
    while True:
        vols = get_service_list ()
        if not vols:
            digi_log.warn("get_service_list() is None")
            sleep(sleep_time)
            continue
        for vol in vols:
            if vol:
                get_volume_size_info (queue, vol)
        time.sleep(sleep_time)

def get_disk_info_from_db (data, db):
    if not data:
        digi_log.error ("data is None")
        return 'None'
    db.sort([('id', pymongo.DESCENDING)])
    db.limit(1)
    event_info = db.read(data)
    if not event_info:
        digi_log.error ("read mongodb is None")
        return 'None'
    if event_info == -1:
        digi_log.error ("mongodb is error")
    return event_info

def check_out_disk_event (data):
    if not data:
        digi_log.error ("data is None")
        return 'None'
    if data['monitor_type_disk_mount'] == 'disk_mount_failed':
        digi_log.debug ("False")
        return False
    elif data['monitor_type_disk_mount'] == 'disk_remount_success':
        digi_log.debug ("True")
        return True
    return 'None'

def find_raid_info_from_db (dict, mongo_dict = {}):
    if not dict or not mongo_dict:
        digi_log.error ("dict or mongo_dict is None")
        return -1
    if mongo_dict['monitorcol']:
        mongo_dict['monitorcol'].sort ([('id', pymongo.DESCENDING)])
        mongo_dict['monitorcol'].limit (1)
        result = mongo_dict['monitorcol'].read(dict)
        if not result:
            digi_log.error ("Not query data from mongodb")
            return -1
        if result == -1:
            digi_log.error ("mongodb read data failed")
            ret = reconnect_mongodb ('monitorcol', mongo_dict)
            if ret < 0:
                digi_log.error (" reconnect_mongodb error")
                return -1
            mongo_dict['monitorcol'].sort([('id',pymongo.DESCENDING)])
            mongo_dict['monitorcol'].limit(1)
            result = mongo_dict['monitorcol'].read(dict)
            if not result:
                digi_log.error ("Not query data from mongodb")
                return -1
            if result == -1:
                digi_log.error ("mongodb read data failed, and exit()")
                exit()
        return result
    return -1
