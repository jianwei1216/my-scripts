#!/usr/bin/python
#coding=utf-8
import sys
import os
import re
import datetime
import dircache
from Queue import Queue
import subprocess
import threading
import traceback
import time
from time import ctime,sleep

sys.path.append('/usr/local/digioceanfs_manager/utils')
sys.path.append('/usr/local/digioceanfs_manager/monitor_report')

from monitor_report_log import digi_log
from mongo_utils import *
from get_info import *
from mgmt_mongodb_utils import *

########## the main function ##########
def start_process():
    mongo_dict = {}
    mongo_dict = connect_mongodb()
    if not mongo_dict:
        digi_log.error("connect_mongodb() failed and exit()")
        return None

    monitor_info_queue = Queue(100)
    gather_info = {}
    threads = []
    try:
        t1 = threading.Thread(name='service_process', target=get_service_process_info, args=(monitor_info_queue,))
        threads.append(t1)
        t2 = threading.Thread(name='disk_process', target=get_disk_process_info, args=(monitor_info_queue,))
        threads.append(t2)
        t3 = threading.Thread(name='quota_process', target=get_quota_process_info, args=(monitor_info_queue,))
        threads.append(t3)
        t4 = threading.Thread(name='process_info', target=get_process_info, args=(monitor_info_queue,))
        threads.append(t4)
        t5 = threading.Thread(name='battery_info', target=get_battery_info, args=(monitor_info_queue,))
        threads.append(t5)
        t6 = threading.Thread(name='fan_info', target=get_all_fan_info, args=(monitor_info_queue,))
        threads.append(t6)
        t7 = threading.Thread(name='power_info', target=get_all_power_info, args=(monitor_info_queue,))
        threads.append(t7)
        t8 = threading.Thread(name='disk_info', target=get_all_disk_info, args=(monitor_info_queue,))
        threads.append(t8)
        t9 = threading.Thread(name='cpu_info', target=get_all_cpu_temp_info, args=(monitor_info_queue,))
        threads.append(t9)
        t10 = threading.Thread(name='bond_info', target=get_all_bond_info, args=(monitor_info_queue,))
        threads.append(t10)
        t11 = threading.Thread(name='netcard_speed_info', target=get_all_netcard_speed_info, args=(monitor_info_queue,))
        threads.append(t11)
        t12 = threading.Thread(name='smart_info', target=get_all_disk_smart_dete_info, args=(monitor_info_queue,))
        threads.append(t12)
        t13 = threading.Thread(name='system_disk_status', target=check_system_disk_status, args=(monitor_info_queue,))
        threads.append(t13)
        t14 = threading.Thread(name='node_connection_info', target=get_all_node_connection_info, args=(monitor_info_queue,))
        threads.append(t14)
        t15 = threading.Thread(name='nmon_io_info', target=analyse_nmon_data_get_io_info, args=(monitor_info_queue,))
        threads.append(t15)
        t16 = threading.Thread(name='redundancy_power_info', target=get_redundancy_power_monitor_info, args=(monitor_info_queue,))
        threads.append(t16)
        t17 = threading.Thread(name='check_data_disk_rdwr', target=get_all_disk_rdwr_monitor_info, args=(monitor_info_queue,))
        threads.append(t17)
        t18 = threading.Thread(name='volume_usage_info', target=get_volume_usage_info_thread, args=(monitor_info_queue,))
        threads.append(t18)

        for t in threads:
            t.setDaemon(True)
            t.start()
    except Exception, e:
            digi_log.error("Alarm information, multi threading caught exception: %s" % traceback.print_exc(e))
    while True:
        gather_info = monitor_info_queue.get()
        if gather_info:
            update_write_event_to_db(process_info, mongo_dict['alarmcol'],
                    mongo_dict['monitorcol'], mongo_dict['thresholdcol'],
                    False, mongo_dict)
            #print gather_info
    t.join()

if __name__ == '__main__':

    start_process()
