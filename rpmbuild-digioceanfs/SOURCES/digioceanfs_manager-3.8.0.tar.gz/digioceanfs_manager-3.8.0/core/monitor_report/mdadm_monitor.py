import sys,socket
import json
import os
import subprocess
import re
import dircache
import socket
from datetime import datetime

sys.path.append('/usr/local/digioceanfs_manager/utils')
from monitor_report_log import digi_log
from mongo_utils import *
from mgmt_mongodb_utils import *

sys.path.append('/usr/local/digioceanfs_manager/monitor_report')
from get_info import *

def get_raid_disk (raid_name):
    disks = []
    mdfile = open('/proc/mdstat','r')
    lines = mdfile.readlines()
    mdfile.close()
    match_line = "^%s\s+:\s+.*raid"%raid_name
    print match_line
    for line in lines:
        match_line = re.match(match_line,line)
        if match_line:
            match = re.match(".*raid\d+\s+(sd\w+.*)\n",line)
            if match:
                info = re.split(" ",match.group(1))
                for eachinfo in info:
                    disks.append(re.split("\[",eachinfo)[0])
    return disks

def get_raid_name(device):
    raid_name = device
    if device:
        raid_name = device.replace('/dev/','')
    return raid_name

def get_raid_level (raid_device):
    mdlevel = '-1'
    mdname = get_raid_name (raid_device)
    matchstr = "^%s\s+:\s.*raid(\d+)\s(\w+)"% mdname
    raidfile = open('/proc/mdstat','r')
    lines = raidfile.readlines()
    raidfile.close()

    for line in lines:
        m = re.match(matchstr,line)
        if m:
            mdlevel = m.group(1)
    return mdlevel

def get_raid_service_name_from_config (raid_device):
    if not raid_device:
        digi_log.warn("raid_device is None")
        return None
    raid_info = get_raid_info (raid_device)
    raid_uuid = raid_info['raid_device_uuid'].replace(':', '-')
    vol_path = '/etc/digioceanfs/vols/'
    if os.path.exists (vol_path):
        if not os.path.isfile (vol_path):
            disks = dircache.listdir (vol_path)
        else:
            digi_log.error("the path:%s is a file"%vol_path)
            return None
    else:
        digi_log.info("the path:%s is not exists"%vol_path)
        return None
    for disk in disks:
        if disk.find(raid_uuid) >= 0:
            break
    else:
        digi_log.warn("not find raid_uuid")
        return None
    disk_service_path = vol_path + disk + '/user'
    if os.path.exists (disk_service_path):
        if os.path.isfile (disk_service_path):
            f = open (disk_service_path, 'r')
            service_name = StringIO.StringIO(f.read())
            if service_name:
                return service_name
    digi_log.warn("other error")
    return None

def get_raid_info (raid_device):
    dict = {}
    proc = subprocess.Popen("%s -D %s 2>/dev/null" % ('/sbin/mdadm',raid_device),
            shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    result = proc.stdout.readlines() + proc.stderr.readlines()
    proc.wait()
    # variable init
    spare_disks = []
    active_disks = []
    fault_disks = []
    raid_status = ''
    raid_device_num = 0
    raid_device_total_num = 0
    raid_device_active_num = 0
    raid_device_working_num = 0
    raid_device_failed_num = 0
    raid_device_spare_num = 0
    raid_device_uuid = ''
    # regular expression init
    match_spare_disk = "\s\sspare.*"
    match_active_disk = "active\s\w+.*"
    match_fault_disk = "faulty.*"
    match_state = "State :\s.*"
    match_raid_device = "Raid Devices :\s.*"
    match_total_device = "Total Devices :\s.*"
    match_active_device = "Active Devices :\s.*"
    match_working_device = "Working Devices :\s.*"
    match_failed_device = "Failed Devices :\s.*"
    match_spare_device = "Spare Devices :\s.*"
    match_UUID = "UUID :\s.*"
    # for match the info
    for line in result:
        disk_line = re.findall (match_spare_disk, line)
        if disk_line:
            info = re.split ('   ',disk_line[0])
            if info and info[1]:
                spare_disks.append(info[1])
                continue
        disk_line = re.findall(match_active_disk,line)
        if disk_line:
            info = re.split('   ',disk_line[0])
            if info and info[1]:
                active_disks.append(info[1])
                continue
        disk_line = re.findall(match_fault_disk,line)
        if disk_line:
            info = re.split('   ',disk_line[0])
            if info and info[1]:
                fault_disks.append(info[1])
                continue
        disk_line = re.findall(match_state,line)
        if disk_line:
            if disk_line[0].find('FAILED') >= 0:
                raid_status = 'FAILED'
                continue
            elif disk_line[0].find('degraded') >= 0:
                raid_status = 'degraded'
                continue
            elif (disk_line[0].find ('clean') >= 0) or (disk_line[0].find ('active') >= 0):
                raid_status = 'clean'
                continue
            else:
                raid_status = ''
                continue
        disk_line = re.findall(match_raid_device,line)
        if disk_line:
            raid_device_num_list = re.split ('\s+:\s+',disk_line[0])
            if raid_device_num_list:
                raid_device_num = raid_device_num_list[1]
                continue
            else:
                raid_device_num = 0
                continue
        disk_line = re.findall(match_total_device, line)
        if disk_line:
            raid_device_total_num_list = re.split ('\s+:\s+', disk_line[0])
            if raid_device_total_num_list:
                raid_device_total_num = raid_device_total_num_list[1]
                continue
            else:
                raid_device_total_num = 0
                continue
        disk_line = re.findall(match_active_device, line)
        if disk_line:
            raid_device_active_num_list = re.split ('\s+:\s+', disk_line[0])
            if raid_device_active_num_list:
                raid_device_active_num = raid_device_active_num_list[1]
                continue
            else:
                raid_device_active_num = 0
                continue
        disk_line = re.findall(match_working_device, line)
        if disk_line:
            raid_device_working_num_list = re.split ('\s+:\s+', disk_line[0])
            if raid_device_working_num_list:
                raid_device_working_num = raid_device_working_num_list[1]
                continue
            else:
                raid_device_working_num = 0
                continue
        disk_line = re.findall(match_failed_device, line)
        if disk_line:
            raid_device_failed_num_list = re.split ('\s+:\s+', disk_line[0])
            if raid_device_failed_num_list:
                raid_device_failed_num = raid_device_failed_num_list[1]
                continue
            else:
                raid_device_failed_num = 0
                continue
        disk_line = re.findall(match_spare_device, line)
        if disk_line:
            raid_device_spare_num_list = re.split ('\s+:\s+', disk_line[0])
            if raid_device_spare_num_list:
                raid_device_spare_num_list = raid_device_failed_num_list[1]
                continue
            else:
                raid_device_spare_num = 0
                continue
        disk_line = re.findall(match_UUID, line)
        if disk_line:
            raid_device_uuid_list = re.split ('\s+:\s+', disk_line[0])
            if raid_device_uuid_list:
                raid_device_uuid = raid_device_uuid_list[1]
                continue
            else:
                raid_device_uuid = ''
                continue
    dict['spare_disks'] = spare_disks
    dict['active_disks'] = active_disks
    dict['fault_disks'] = fault_disks
    dict['raid_status'] = raid_status
    dict['raid_device_num'] = raid_device_num
    dict['raid_device_total_num'] = raid_device_total_num
    dict['raid_device_active_num'] = raid_device_active_num
    dict['raid_device_working_num'] = raid_device_working_num
    dict['raid_device_failed_num'] = raid_device_failed_num
    dict['raid_device_spare_num'] = raid_device_spare_num
    dict['raid_device_uuid'] = raid_device_uuid
    return dict

def event_deal (event,event_device,sub_device = None):
    data = {}
    data['device'] = '--'
    raid_name = get_raid_name(event_device)
    data['raid_name'] = raid_name
    if event == 'Fail' or event == 'FailSpare':
        data = dict(data, **get_raid_info (event_device))
        raid_status = data['raid_status']
        if raid_status == 'FAILED':
            data['raid_type'] = 'Failed'
        elif raid_status == 'degraded':
            data['raid_type'] = 'Degraded'
        else:
            digi_log.warn("raid_type is \'--\'")
            data['raid_type'] = '--'
        if sub_device:
            data['device'] = sub_device
    elif event == 'NewArray':
        data['raid_type'] = 'NewArray'
        data = dict(data, **get_raid_info (event_device))
    elif event == 'RebuildStarted' or re.match("Rebuild\d+",event):
        data['raid_level'] = get_raid_level (event_device)
        data['monitor_rebuild'] = 'monitor_raid_rebuild'
        data['raid_type'] = 'RebuildStart'
        data = dict(data, **get_raid_info (event_device))
    elif event == 'RebuildFinished':
        data['monitor_rebuild'] = 'monitor_raid_rebuild'
        data['raid_level'] = get_raid_level (event_device)
        data['raid_type'] = 'RebuildFinished'
        data = dict(data, **get_raid_info (event_device))
    elif event == 'DeviceDisappeared':
        digi_log.debug("mdadm monitor raid device Disappeared")
        return None
    else:
        digi_log.debug("mdadm monitor other events")
        return None
    data['data'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
    service_name = get_raid_service_name_from_config (event_device)
    if not service_name:
        data['servicename'] = '--'
        digi_log.error("get_raid_service_name_from_config() is return None")
        return None
    else:
        data['servicename'] = service_name
    data['node'] = get_local_hostname_by_ip()
    if not data['node']:
        digi_log.error("get_local_hostname_by_ip() is None")
        return None
    data['monitor_type'] = 'raid_monitor'
    mongo_dict = connect_mongodb()
    if not mongo_dict:
        digi_log.error("connect_mongodb() is failed")
        return None
    update_write_event_to_db (data, mongo_dict['alarmcol'],
            mongo_dict['monitorcol'], mongo_dict['thresholdcol'],
            False, mongo_dict)
