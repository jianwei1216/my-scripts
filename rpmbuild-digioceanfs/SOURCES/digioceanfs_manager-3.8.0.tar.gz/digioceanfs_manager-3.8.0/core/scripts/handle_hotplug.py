#!/usr/bin/python

import sys
import os
import raid

if   __name__  ==  "__main__":
    
    handle = os.popen("cat /proc/mdstat | grep \"^md\" | awk \'{print $1}\'")
    
    name_list = handle.readlines()
    
    for dev_name in name_list:

        hd = os.popen("mdadm -D /dev/%s 2>/dev/null"%dev_name.strip())

        while True:

            content = hd.readline()

            if not content:
                break

            if "Raid Devices" in content:
                cont = content.strip().split()
                stan = int(cont[3])
                if stan < 4 :
                    break

            if "Working Devices" in content:
                cont = content.strip().split()
                work = int(cont[3])
                if stan < 4 :
                    break

                if stan > work:
                    raid.event_handler("DiskHotplug", "/dev/%s"%dev_name.strip())
                    break
                
        hd.close()
        
    handle.close()
