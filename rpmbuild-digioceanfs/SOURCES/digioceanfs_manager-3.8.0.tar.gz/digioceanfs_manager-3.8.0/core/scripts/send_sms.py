#-*- coding: utf-8 -*-

import time
import serial
import re
import sys
import os
import pickle

#---------------------------------
#   mobile addr and SMSC init
#---------------------------------
def addr_init(destaddr):
    dest_addr_list = []
    dest_addr = destaddr.replace('+','')
    if len(dest_addr)%2 == 1:
        dest_addr = dest_addr + 'F'
    tmp_list = list(dest_addr)
    for i in range(0,len(tmp_list),2):
        dest_addr_list.append(tmp_list[i+1])
        dest_addr_list.append(tmp_list[i])
    dest_addr = ''.join(dest_addr_list) 
    return dest_addr

#---------------------------------
#   message init
#---------------------------------
def mesg_init(addr,MESG):
    if type(MESG) == unicode:
        mesg = MESG
    else:
        mesg = MESG.decode('utf-8')
    mesg = str([mesg])
    m = re.search("\[u'(.*)'\]",mesg)
    if m:
        mesg = m.group(1)
    mesglist = list(mesg)
    i = 0
    while i < len(mesglist):
        if not mesglist[i] == '\\':
            mesglist[i] = "%04x" % ord(mesglist[i])
            i += 1
        else:
            i += 6
    mesg = ''.join(mesglist).replace("\u",'')
    hex_len = '%02x' % (len(mesg)/2)
    mesg = hex_len + mesg
    return mesg

#---------------------------------
#   send chinese message
#---------------------------------
def send_chinese_mesg(ser,mobaddr,mesg,ctraddr):
    #---------- mesg init ---------#
    ctr_addr = '0891' + addr_init(ctraddr)
    mob_addr = addr_init(mobaddr)
    addr = '11000D91' + mob_addr + '000800'
    mesgstr = mesg_init(addr,mesg)
    size = len(addr + mesgstr)/2
    #---------- send mesg ---------#
    ser.write("AT+CMGF=0\r")
    time.sleep(0.1)
    line = ser.read(ser.inWaiting())
    print line
    ser.write("AT+CMGS=%s\r" % size)
    time.sleep(0.1)
    line = ser.read(ser.inWaiting())
    print line
    message = ctr_addr + addr + mesgstr + '\032\r'
    ser.write(message)
    time.sleep(0.1)
    while ser.inWaiting():
        line = ser.readline()
        print line
		
#---------------------------------
#   send english message
#---------------------------------
def send_english_mesg(ser,mobaddr,mesg):
    mobaddr = mobaddr.replace('+86','')
    ser.write("AT+CMGF=1\r")
    time.sleep(0.1)
    line = ser.read(ser.inWaiting())
    print line
    ser.write("AT+CMGS=%s\r" % mobaddr)
    time.sleep(0.1)
    line = ser.read(ser.inWaiting())
    print line
    message = mesg + '\032\r'
    ser.write(message)
    time.sleep(0.1)
    while ser.inWaiting():
        line = ser.readline()
        print line
    
#------------------------------------
#    flag = 0 : english message
#    flag = 1 : chinese message   
#------------------------------------
def send_sms_message(flag,CTRADDR,MOBADDR,mesg):
    if flag == 0:
        tmp = len(mesg) / 140
    else:
        tmp = len(mesg) / 70
    for i in range(tmp+1):
        try:
            ser = serial.Serial("/dev/ttyGSM",9600)
            ser.write("AT\r")
            time.sleep(0.1)
            line = ser.read(ser.inWaiting())          #inWating val is the length of waiting queue 
            print line
            if not line.find("OK") >= 0:           
                ser.close()
                break
            else:          #AT return OK 
                if flag == 0:
                    send_english_mesg(ser,str(MOBADDR),mesg[i*140:(i+1)*140])
                else:
                    send_chinese_mesg(ser,str(MOBADDR),mesg[i*70:(i+1)*70],str(CTRADDR))
                ser.close()
        except Exception,e:
            errstr = "%s" % e.__str__ + ' : ' + ','.join([str(arg) for arg in e.args])
            if errstr.find("SerialException") >= 0 and errstr.find("could not open port") >= 0:
                errstr = "GSM Modem not connected."
            print >> sys.stderr,errstr 
            break

if __name__ == "__main__":
    if len(sys.argv) >= 5:
        send_sms_message(int(sys.argv[1]),sys.argv[2],sys.argv[3],' '.join(sys.argv[4:]))
    else:
        pass
