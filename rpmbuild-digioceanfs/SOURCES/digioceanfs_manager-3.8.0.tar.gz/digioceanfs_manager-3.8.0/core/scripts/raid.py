#!/usr/bin/env python

import sys
import os
import subprocess
import tempfile
import syslog

if not "/usr/share/digioceanfs_manager/utils" in sys.path:
    sys.path.append("/usr/share/digioceanfs_manager/utils")

from manager_utils import get_dev_by_id
from manager_utils import get_dev_id_map

HANDLER_IDENT = "RAID"

def handler_open_syslog() :
    syslog.openlog( HANDLER_IDENT,syslog.LOG_PID,syslog.LOG_DAEMON)
    return

def handler_close_syslog() :
    syslog.closelog()
    return

def handler_syslog(msg, level=syslog.LOG_CRIT) : # TODO: Log level control
    syslog.syslog(level, "[mdadm event] %s"%msg)
    
def disk_is_mounted(disk):

    if not disk :
        handler_syslog("disk_is_mount receive None!")
        return False
    
    proc = subprocess.Popen("mount | grep %s"%(disk), stdout=subprocess.PIPE, shell=True)
    ret  = proc.wait()
    s    = proc.stdout.readlines()

    if not s :
        return False
    
    if s and len(s) == 0 :
        return False

    handler_syslog("Disk %s has been mounted!"%disk)
    return True

CMD_FIRST = "FIRST"
CMD_ALL   = "ALL"
def find_spare_disks(cmd=CMD_FIRST) :
    
    used   = []
    all    = []
    unused = []

    proc = subprocess.Popen('/usr/bin/digi_partition --list | grep -v md', stdout=subprocess.PIPE, shell=True)
    ret = proc.wait()
    s = proc.stdout.readlines()
    for ss in s:
        all.append(ss.strip())
    handler_syslog( "".join(s))
    
    service_list = os.listdir("/etc/digioceanfs/services")
    if service_list :
        hd       = os.popen('cat `find /etc/digioceanfs/services/ -name disks ` | awk \'gsub("\\[", "") gsub("\\]", " ") gsub("\\"", "") gsub("\\,", "") {for( i=1; i <= NF; i++) print $i}\'')
        s        = hd.readlines()
        for ss in s:
            used.append(get_dev_by_id(ss.strip()))
        hd.close()
#        handler_syslog( "".join(s.strip())) # Debug
        
    if not all:
        handler_syslog( "No spare DISK avail!")
        return None

#    handler_syslog( "All disks NOT in RAID: ".join(all)) # Debug

#    print "".join(used)
#    print len(used)
    
    if len(used) > 0 :
        for tgt in all :
            find = False
            for dev in used :
                if tgt == dev :
                    find = True
                    break

            if not find :
                if cmd == CMD_ALL :
                    unused.append("/dev/%s"%(tgt))
                    
                else : # [Default]  cmd == CMD_FIRST :
                    handler_syslog( "Spare DISK %s!"%tgt)
                    return "/dev/%s"%tgt
                    
    else :
        if cmd == CMD_ALL :
            for tgt in all :
                unused.append("/dev/%s"%(tgt))
            return unused
                
        else : # [Default]  cmd == CMD_FIRST :
            return "/dev/%s"%all[0]

    return None

def new_replace_fail(md, lost_disk, spare_disk, level=syslog.LOG_CRIT) :
    
#    print md #debug
#    print spare_disk #debug
    
    proc = subprocess.Popen( "/sbin/mdadm %s -a %s"%(md, spare_disk), stdout=subprocess.PIPE, shell=True)
    ret = proc.wait()
    msg = proc.stdout.read()  

    syslog.syslog(level, msg)
    
def fail_event_handler(dev, level = syslog.LOG_CRIT) :

    lost_disk  = None
    spare_disk = None
    
    if type(dev) == list :
        md = dev[0]
        
    elif type(dev) == str :
        md = dev

    spare_arr = find_spare_disks(CMD_ALL)
    if (not spare_arr) or (len(spare_arr) == 0) :
        syslog.syslog( syslog.LOG_CRIT, "No spare disk assist degreaded array.--")
        return

    for spare_disk in spare_arr :
        if not disk_is_mounted(spare_disk) :
            break

        spare_disk = None # in case of all disks are mounted
        
    if spare_disk == None :
        syslog.syslog( syslog.LOG_CRIT, "No spare disk assist degreaded array.")
        return

    syslog.syslog( syslog.LOG_CRIT, spare_disk)
        
    new_replace_fail(md, lost_disk, spare_disk, level = syslog.LOG_CRIT)
        
def event_handler(event, dev = None): # major interface

    handler_open_syslog()
    
    if event == None :
	return 

    if type(event) != str :
        return
    
    if event == 'DeviceDisappeared' :
#		    An md array which previously was configured appears
#		    to  no  longer  be  configured.  (syslog  priority:
#		    Critical)
#
#		    If  mdadm was  told to  monitor an  array  which is
#		    RAID0    or   Linear,    then   it    will   report
#		    DeviceDisappeared   with   the  extra   information
#		    Wrong-Level.  This  is because RAID0  and Linear do
#		    not support the device-failed, hot-spare and resync
#		    operations which are monitored.
        handler_syslog( "%s"%(event))

    elif event == 'RebuildStarted' :
#		    An   md  array   started   reconstruction.  (syslog
#		    priority: Warning)
        handler_syslog( "%s"%(event))
	
    elif event == 'RebuildFinished' :
#		    An md  array that  was rebuilding, isn't  any more,
#		    either   because  it   finished  normally   or  was
#		    aborted. (syslog priority: Warning)
        handler_syslog( "%s"%(event))
	
    elif event == 'Fail' :
#	            An  active component  device of  an array  has been
#		    marked as faulty. (syslog priority: Critical)

        handler_syslog( "%s"%(event))
        
        fail_event_handler(dev, level = syslog.LOG_CRIT)
	
        
    elif event == 'FailSpare' :
#		    A spare component device which was being rebuilt to
#		    replace  a   faulty  device  has   failed.  (syslog
#		    priority: Critical)
        
        handler_syslog( "%s"%(event))

        fail_event_handler(dev, level = syslog.LOG_CRIT)
	
    elif event == 'SpareActive' :
#		    A spare component device which was being rebuilt to
#		    replace  a  faulty  device  has  been  successfully
#		    rebuilt   and  has   been  made   active.   (syslog
#		    priority: Info)
        handler_syslog( "%s"%(event))
	
    elif event == 'NewArray' :
#		    A   new  md   array  has   been  detected   in  the
#		    /proc/mdstat file.   (syslog priority: Info)
        handler_syslog( "%s"%(event))
	
    elif event == 'DegradedArray' :
#		    A newly noticed array appears to be degraded.  This
#		    message is not generated when mdadm notices a drive
#		    failure  which causes  degradation,  but only  when
#		    mdadm  notices that  an array  is degraded  when it
#		    first sees the array.  (syslog priority: Critical)

        handler_syslog( "%s"%(event))

        fail_event_handler(dev, level = syslog.LOG_CRIT)
	
    elif event == 'MoveSpare' :
#		    A spare  drive has been  moved from one array  in a
#		    spare-group to  another to allow a  failed drive to
#		    be replaced.  (syslog priority: Info)

        handler_syslog( "%s"%(event))
	
    elif event == 'SparesMissing' :
#		    If mdadm  has been told, via the  config file, that
#		    an  array should  have  a certain  number of  spare
#		    devices, and  mdadm detects that it  has fewer than
#		    this number  when it first sees the  array, it will
#		    report a  SparesMissing message.  (syslog priority:
#		    Warning)

        handler_syslog( "%s"%(event))
	
    elif event == 'TestMessage' :
#		    An array was found  at startup, and the --test flag
#		    was given.  (syslog priority: Info)

        handler_syslog( "%s"%(event))
	
    elif len(event) == 9 and event[:6] == 'Rebuild' : # RebuildNN
#		    Where NN is 20, 40,  60, or 80, this indicates that
#		    rebuild  has  passed that  many  percentage of  the
#		    total. (syslog priority: Warning)
        
        handler_syslog( "%s"%(event))
        
    elif event == 'DiskHotplug' :  # Udev event
#                   Quand une disque bouchon
        
        handler_syslog( "%s"%(event))

        fail_event_handler(dev, level = syslog.LOG_CRIT)
        
    else : # mismatched event
        
        handler_syslog( "Unknow Event %s!"%event)

    handler_close_syslog()
    
    return
