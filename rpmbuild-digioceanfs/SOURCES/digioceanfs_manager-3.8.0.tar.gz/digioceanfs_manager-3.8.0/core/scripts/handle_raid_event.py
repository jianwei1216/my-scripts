#!/usr/bin/python

import os
import re
import sys
import raid
sys.path.append('/usr/local/digioceanfs_manager/monitor_report')
from mdadm_report import *

def get_hosts_name():
    handle = open("/etc/hosts", "r")
    line_list = handle.readlines()
    reg = "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"
    p = re.compile(reg)
    key_list = []
    val_list = []
    for line in line_list:
        if p.match(line):
            tmp_list = line.split()
            if len(tmp_list) >= 2:
                if tmp_list[0] != '127.0.0.1':
                    key_list.append(tmp_list[0])
                    val_list.append(tmp_list[1])
    host_dict = dict(zip(key_list, val_list))
    handle.close()
    return host_dict

def get_ip_addr():
    addr_list = []
    reg = "inet addr:"
    p = re.compile(reg)
    handle = os.popen("ifconfig")
    line_list = handle.readlines()
    for line in line_list:
        if p.search(line):
            fd = os.popen("echo \'%s\' | awk \'{print $2}\' | awk -F: \'{print $2}\'"%line)
            str = fd.read().strip()
            if str != '127.0.0.1':
                addr_list.append(str)
            fd.close()
    handle.close()
    return addr_list

if __name__ == '__main__':

    argv1 = sys.argv[1]
    argv2 = sys.argv[2]
    if len(sys.argv) == 4:
        argv3 = sys.argv[3]
        event_deal (argv1, argv2, argv3)
    else:
        event_deal (argv1, argv2)

    host_dict = get_hosts_name()
    addr_list = get_ip_addr()

    for ip in addr_list:
        if host_dict.has_key(ip):
            node_name = host_dict[ip]
            break

    str = node_name

    for i in range(1, len(sys.argv)):
        str = str + ' ' + sys.argv[i]
    
    os.system('logger -p daemon.info -t RAID %s'%str)

    argc = len(sys.argv)

    if argc <= 1 :
        # print "None parameter fetched!" # debug
        exit(-1)

    event = None  
 
    if argc > 1 :
        event = sys.argv[1]
        
    dev = []
    if argc > 2 :
        dev = sys.argv[2:]

    raid.event_handler(event, dev)
