#!/usr/bin/python
import os
import sys
import shutil
import syslog
import time

LOG_LEVEL = ['M', 'A', 'C', 'E', 'W', 'N', 'I', 'D']
LOG_LEVEL_EMERG   = 0
LOG_LEVEL_ALERT   = 1
LOG_LEVEL_CRIT    = 2
LOG_LEVEL_ERR     = 3
LOG_LEVEL_WARNING = 4
LOG_LEVEL_NOTICE  = 5
LOG_LEVEL_INFO    = 6
LOG_LEVEL_DEBUG   = 7

timestamp = time.strftime("%Y%m%d%H%M%S", time.localtime())

USAGE = 'Usage: mode(-b:-r) path\n    backup files to path or restore files from path'

defaut_name = "digi_conf_bak%s.tar.gz"%(timestamp)

backup_files = ["etc/hosts", 
                "etc/digioceanfs", 
                "etc/digioceanfs_manager"] 

cur_path = os.path.abspath(os.path.curdir)

CMD_IDENT = 'DigiBackup'

def log_level(lv):
    level = None
    if lv == LOG_LEVEL_EMERG:
        level = syslog.LOG_EMERG 
    elif lv == LOG_LEVEL_ALERT:
        level = syslog.LOG_ALERT
    elif lv == LOG_LEVEL_CRIT:
        level = syslog.LOG_CRIT
    elif lv == LOG_LEVEL_ERR:
        level = syslog.LOG_ERR
    elif lv == LOG_LEVEL_WARNING:
        level = syslog.LOG_WARNING
    elif lv == LOG_LEVEL_NOTICE:
        level = syslog.LOG_NOTICE
    elif lv == LOG_LEVEL_INFO:
        level = syslog.LOG_INFO
    elif lv == LOG_LEVEL_DEBUG:
        level = syslog.LOG_DEBUG
    else:
        level = syslog.LOG_DEBUG
        lv    = LOG_LEVEL_DEBUG

    return (level, LOG_LEVEL[lv])

def init_br_log():
    syslog.openlog( CMD_IDENT,syslog.LOG_PID,syslog.LOG_USER)
    return

def destroy_br_log():
    syslog.closelog()
    return
    
def br_log(lv, lg):
    lv, mark = log_level(lv)
    lg = '['+mark+'] '+lg
    syslog.syslog( lv, lg)
    return

def path_unify(path):
    if path:
        if os.path.isdir(path):
            return os.path.abspath(path + '/' + defaut_name)
        else:
            return os.path.abspath(path)
    else:
        return os.path.abspath(os.path.curdir + defaut_name)

def parse_args():
    if len(sys.argv) == 2:
        mode = sys.argv[1]
        path = None
    elif len(sys.argv) == 3:
        mode, path = sys.argv[1:]
    else:
        print USAGE
        exit(-1)   
    return (mode, path)
      
def back_conf(dpath, spath):
    files = ''
    msg = ''
    os.chdir(os.path.abspath(dpath))
    for i in range(len(backup_files)):
        if not os.path.exists(backup_files[i]):
            msg = "Configure File[%s] doesn't EXIST!"%backup_files[i]
            print msg
            br_log(LOG_LEVEL_INFO, msg)
            continue
        files += backup_files[i]
        files += ' '
    return os.system("tar -czf %s %s"%(spath, files))

def restore_conf(dpath, spath):
    if not os.path.exists(spath):
        print "Backup Source[%s] DOES NOT EXIST!"%(spath)
        exit(-1)
    os.chdir(os.path.abspath(dpath))
    return os.system('tar -zxf '+ spath)

def main():
    init_br_log()

    mode, path = parse_args()
    
    path = path_unify(path)

    if mode == '-b':
        back_conf('/', path)
        br_log(LOG_LEVEL_INFO, 'Backup configure files to '+ path)

    elif mode == '-r':
        restore_conf('/', path)
        br_log(LOG_LEVEL_INFO, 'Restore configure files from '+ path)

    else:
        print "Invaild Parameters: mode[%s] path[%s]\n"%(mode, path)
        print USAGE

try:
    main()

finally:
    destroy_br_log()
    os.chdir(cur_path)
        
    