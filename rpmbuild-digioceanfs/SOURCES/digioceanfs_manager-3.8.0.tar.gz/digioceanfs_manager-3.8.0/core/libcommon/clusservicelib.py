#!/usr/bin/env python
#-*- coding: utf-8 -*-

import os
import sys
import subprocess
import re
import copy
import pickle
import simplejson
import logging
from decimal import *
from libcommon import utils

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)
homepath = currpath[:currpath.find('libcommon')]
if not homepath in sys.path:
    sys.path.append(homepath)
utilspath = os.path.join(homepath,'utils')
if not utilspath in sys.path:
    sys.path.append(utilspath)

from log import Log
import settings

Log()
Ologger = logging.getLogger("asyncManager")

#########################################################################################################
#
#   Function: func_service_create
#   Purpose: add a new service for the cluster
#
#########################################################################################################

def func_service_create(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

#########################################################################################################
#
#   Function: func_service_list_all
#   Purpose: to list all services info
#
#########################################################################################################

def func_service_list_all(options):
    clusterservices = []
    try:
        p_status = 'name: (\S+)\s+service total size: (\S+)\s+service used size: (\S*)\s+service raid level: (\S+)\s+service status: (\S+)\s+'
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc_status = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result_status = proc_status.stdout.readlines()
        proc_status.wait()
        retcode = result_status[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode != '0':
            return ' '.join(result_status)
        if len(result_status)>1:
            for i in range(len(result_status)):
                arr=result_status[i].replace('\n','')
                index=arr.split(': ')
                if index[0]=='Volume Name':
                    x=0
                    end=''
                    while end!='Bricks':
                        end=result_status[i+x].replace('\n','')
                        end=end.split(':')
                        end=end[0]
                        x+=1
                    service=dict()						
                    service['servicename']=index[1]
                    for j in range(x-1):
                        r=result_status[i+j].replace('\n','')
                        s=r.split(': ')
                        if s[0]=='Type':		
                            service['raidlv']=s[1]
                            continue
                        elif s[0]=='Replica Number':	
                            service['afr']=s[1]
                            continue
                        elif s[0]=='Stripe Number':	
                            service['strip']=s[1]
                            continue
                        elif s[0]=='Volume ID':		
                            service['vid']=s[1]
                            continue
                        elif s[0]=='Status':		
                            service['status']=s[1]
                            continue
                        elif s[0]=='Number of Bricks':		
                            service['disknum']=s[1]
                            continue
                        elif s[0]=='Transport-type':		
                            service['type']=s[1]
                            continue
                        elif s[0]=='Free Size':		
                            service['freesize']=s[1]
                            continue
                        elif s[0]=='Total Size':		
                            service['totalsize']=s[1]
                            continue
                        elif s[0]=='Brick Status':		
                            service['brickstatus']=s[1]
                            continue
                        else:
                            pass
                    try:
                        service['afr']
                    except:    
                        service['afr']='NaN'
                    try:
                        service['strip']
                    except:    
                        service['strip']='NaN'
                    if 	service['freesize']=='N/A':
                        service['usage']=0
                        service['freesize']=0.0
                        service['totalsize']=0.0
                        service['usedsize']=0.0
                    else:
                        if float(service['totalsize'])==0:
                            service['usedsize']=0						
                            service['usage']=0
                        else:	
                            service['usedsize']=float(service['totalsize'])-float(service['freesize'])
                            service['usage']=round(Decimal(str(service['usedsize']))/Decimal(str(service['totalsize'])), 2)	
                        service['freesize']=utils.getUnit_2('', service['freesize'])
                        service['totalsize']=utils.getUnit_2('', service['totalsize'])
                        service['usedsize']=utils.getUnit_2('', service['usedsize'])
                    service['client']=len(func_client_node_list_all('service client_list ' + service['servicename']))
					
                    service['afr_info']='0'#result2[1].strip()
                    if service['raidlv'].find('Disperse') >= 0:
                        re_result = re.match('(.*)\((.*)\)(.*)',service['disknum'])
                        if re_result:
                            disperse_detail = re_result.groups()[1]
                            service['afr'] = disperse_detail.split(" + ")[1]
                            service['strip'] = str(int(disperse_detail.split(" + ")[0]) + 1)
                    clusterservices.append(service)
        else:
            clusterservices=[]
        return clusterservices
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

#########################################################################################################
#
#   Function: func_service_list_disk
#   Purpose: to list all disks info in a service
#
#########################################################################################################

def func_service_list_disk(options):
    bricks=[]
    try:
        cmd = 'sudo python %s %s ' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode != '0':
            return ' '.join(result)
        if len(result)>2:
            for i in range(len(result)):
                index=result[i].replace('\n','')
                if index=='------------------------------------------------------------------------------':
                    brick=dict()				
                    for j in range(12):
                        r=result[i+j].replace('\n','')
                        s=r.split(":")
                        if s[0].strip()=='Brick':
                            brick_name=s[1].strip().split(' ')
                            brick['mount_point']=brick_name[1]+':'+s[2].strip()
                            mark=brick['mount_point'].split('/')
                            brick['mark']=mark[2]							
                            continue							
                        elif s[0].strip()=='Online':
                            brick['status']=s[1].strip()
                            continue
                        elif s[0].strip()=='File System':
                            brick['fs']=s[1].strip()
                            continue
                        elif s[0].strip()=='Device':
                            brick['interface']=s[1].strip()
                            continue
                        elif s[0].strip()=='Disk Space Free':
                            brick['free']=s[1].strip()
                            continue
                        elif s[0].strip()=='Total Disk Space':
                            brick['total']=s[1].strip()
                            continue
                        else:
                            pass
					
                    if brick['free']=='NaN' or brick['free']=='0Bytes':
                        brick['usage']='NaN'
                    else:
                        free=re.match('\d+.\d+',brick['free'])
                        free=free.group()
                        free_unit=brick['free'].replace(free,'')
                        free=float(free)
                        if free_unit=='KB':
                            free=free*1024
                        elif free_unit=='MB':
                            free=free*1024*1024
                        elif free_unit=='GB':
                            free=free*1024*1024*1024
                        elif free_unit=='TB':
                            free=free*1024*1024*1024*1024
                        else:
                            pass
					
                        total=re.match('\d+.\d+',brick['total'])
                        total=total.group()
                        total_unit=brick['total'].replace(total,'')
                        total=float(total)
                        if total_unit=='KB':
                            total=total*1024
                        elif total_unit=='MB':
                            total=total*1024*1024
                        elif total_unit=='GB':
                            total=total*1024*1024*1024
                        elif total_unit=='TB':
                            total=total*1024*1024*1024*1024
                        else:
                            pass
									
                        usedsize=total-free
                        brick['usage']=round(Decimal(str(usedsize))/Decimal(str(total)), 2)
                    bricks.append(brick)
        else:
            bricks=[]

        return bricks
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return bricks

#########################################################################################################
#
#   Function: func_service_extend
#   Purpose: extend the capacity of a service by adding new disks
#
#########################################################################################################
def func_service_extend(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

def func_client_node_list_all(options):
    if len(options.split()) > 2:
        service_name = options.split()[2]
    clusterclientnodes=[]
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode != '0':
            return ' '.join(result)
        if len(result)>1:
            for i in result:
                r=i.replace('\n','')
                if r!='0' and r!='':
                    s=r.split('\t')				
                    node=dict()
                    node['service_name']=service_name
                    node['node_name']=s[0]
                    if s[1]=='started':
                        node['status']='1'
                    else:
                        node['status']='0'
                    clusterclientnodes.append(node)
        else:
            clusterclientnodes=[]
        return clusterclientnodes
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

def func_client_node_create(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

def func_client_node_delete(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 	

def func_client_node_start(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

def func_client_node_stop(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

def func_raidlv_detail(service_name):
    bricks=[]
    try:
        cmd = 'sudo python %s service list_disk %s' % (settings.DIGI_MANAGER, service_name)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode != '0':
            return ' '.join(result)
        if len(result)>2:
            for i in range(len(result)):
                index=result[i].replace('\n','')
                if index=='------------------------------------------------------------------------------':
                    brick=dict()				
                    for j in range(12):
                        r=result[i+j].replace('\n','')
                        s=r.split(":")
                        if s[0].strip()=='Brick':
                            brick_name=s[1].strip().split(' ')
                            brick['mount_point']=brick_name[1]+':'+s[2].strip()
                            mark=brick['mount_point'].split('/')
                            brick['mark']=mark[2]							
                            continue							
                        elif s[0].strip()=='Online':
                            brick['status']=s[1].strip()
                            continue
                        elif s[0].strip()=='File System':
                            brick['fs']=s[1].strip()
                            continue
                        elif s[0].strip()=='Device':
                            brick['interface']=s[1].strip()
                            continue
                        elif s[0].strip()=='Disk Space Free':
                            brick['free']=s[1].strip()
                            continue
                        elif s[0].strip()=='Total Disk Space':
                            brick['total']=s[1].strip()
                            continue
                        else:
                            pass
					
                    if brick['free']=='NaN' or brick['free']=='0Bytes':
                        brick['usage']='NaN'
                    else:
                        free=re.match('\d+.\d+',brick['free'])
                        free=free.group()
                        free_unit=brick['free'].replace(free,'')
                        free=float(free)
                        if free_unit=='KB':
                            free=free*1024
                        elif free_unit=='MB':
                            free=free*1024*1024
                        elif free_unit=='GB':
                            free=free*1024*1024*1024
                        elif free_unit=='TB':
                            free=free*1024*1024*1024*1024
                        else:
                            pass
					
                        total=re.match('\d+.\d+',brick['total'])
                        total=total.group()
                        total_unit=brick['total'].replace(total,'')
                        total=float(total)
                        if total_unit=='KB':
                            total=total*1024
                        elif total_unit=='MB':
                            total=total*1024*1024
                        elif total_unit=='GB':
                            total=total*1024*1024*1024
                        elif total_unit=='TB':
                            total=total*1024*1024*1024*1024
                        else:
                            pass
									
                        usedsize=total-free
                        brick['usage']=round(Decimal(str(usedsize))/Decimal(str(total)), 2)
                    bricks.append(brick)
        else:
            bricks=[]

        return bricks
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'
		
def func_service_cifs_add_user(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 
        
def func_service_cifs_del_user(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

def func_service_cifs_list_user(options):
    try:
        cmd= 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
		
        cmd2= 'sudo python %s service cifs_list_links %s' % (settings.DIGI_MANAGER, options.split()[1])
        proc2 = subprocess.Popen(cmd2, shell=True, stdout=subprocess.PIPE)
        result2 = proc2.stdout.readlines()
        proc2.wait()
        retcode2 = result2[0].strip()
        Ologger.info("%s return %s" %(cmd2,retcode2))
		
        user_list = []
        if retcode == '0\n':
            for user in result[1:-1]: 
                if user.strip() == 'nouser':
                    break
                user_arr=dict()
                user_arr['user']=user.strip()
                linked=0;
                for link in result2[1:-1]:
                    link=link.split('\t')
                    if link[1].strip()==user.strip():
                        linked+=1
                        user_arr['node']=link[0]
                        user_arr['pid']=link[2]
                if linked>0:
                    user_arr['link']='linked'
                else:
                    user_arr['node']=''
                    user_arr['pid']=''
                    user_arr['link']='unlink'				
                user_list.append(user_arr)
            return user_list
        else:
            return ' '.join(result)
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'
        
def func_service_nfs_list_user(options):
    try:
        cmd= 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        user_list = []
        if retcode == '0\n':
            user_str=result[1].replace('\n','')
            if user_str != 'None':
                user_list=user_str.replace('None','').split(',')
            return user_list
        else:
            return ' '.join(result) 
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))       
        return '-1' 
    
def func_service_nfs_add_user(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 
        
def func_service_nfs_del_user(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

def func_service_list_cifs_links(options):
    try:
        cmd= 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        links_list = []
        if retcode == '0\n':
            for link in result[1:-1]:
                linkdata = link.split('\t')
                linkdatadict = {}
                if len(linkdata) > 2:
                    linkdatadict['nodename']  = linkdata[0]
                    linkdatadict['username']  = linkdata[1]
                    linkdatadict['pid']       = linkdata[2]
                    linkdatadict['linktime'] = linkdata[3]
                elif len(linkdata) == 2:
                    if linkdata[1] == 'nolink':
                        linkdatadict['nodename'] = linkdata[0]
                        linkdatadict['nolink'] = linkdata[1]
                    else:
                        linkdatadict['nodename'] = linkdata[0]
                        linkdatadict['error'] = linkdata[1]
                else:
                    linkdatadict['fatalerror'] = 'fatalerror'
                links_list.append(linkdatadict)
            return links_list
        else:
            return ' '.join(result) 
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'
    
def func_service_del_cifs_links(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 
            
#########################################################################################################
#
#   Function: func_service_export
#   Purpose: export a serivce using cifs
#
#########################################################################################################
def func_service_cifs_export(options):
    nodes_status_dic = {}
    cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    result = proc.stdout.readlines()
    proc.wait()
    retcode = result[0].strip()
    Ologger.info("%s return %s" %(cmd,retcode))
    if retcode == '0' and options.split()[3] == 'status':
        for node_status in result[1:-1]:
            node_status = node_status.split()
            nodes_status_dic[node_status[0]] = node_status[1]
        return nodes_status_dic
    else:
        return ' '.join(result[1:])

def func_service_nfs_export(options):
    #nodes_status = []
    cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    result = proc.stdout.readlines()
    proc.wait()
    retcode = result[0].strip()
    Ologger.info("%s return %s" %(cmd,retcode))
    if retcode == '0\n' and options.split()[3] == 'status':
        nodes_status=result[1].replace('\n','').split(' : ')
        nodes_status=nodes_status[1].lower()
        return nodes_status
    else:
        return ' '.join(result)

#########################################################################################################
#
#   Function: func_service_start
#   Purpose: start a service
#
#########################################################################################################
def func_service_start(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

#########################################################################################################
#
#   Function: func_service_stop
#   Purpose: stop a service
#
#########################################################################################################
def func_service_stop(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

#########################################################################################################
#
#   Function: func_service_destroy
#   Purpose: destroy service that needed
#
#########################################################################################################
def func_service_destroy(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

def func_service_list_dir(servicename):
    targetpath = '/cluster2/%s' % servicename
    children = []
    try:
        for path in os.listdir(targetpath):
            subpath = os.path.join(targetpath, path.decode('utf-8'))
            if os.path.isdir(subpath.encode('utf-8')):
                children.append({"name": path, "path": subpath, "isParent":"true"})
    except Exception, e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'
    return children


def func_service_quota_setup(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        if len(options.split()) > 3:
            option = options.split()[3]
        else:
            result = proc.stdout.read().strip()
            Ologger.info("%s return %s" %(cmd,result))
            return result
        if option == 'list':
            result = proc.stdout.readlines()
            proc.wait()
            retcode = result[0].strip()
            Ologger.info("%s return %s" %(cmd,retcode))
            servicename = options.split()[2]
            subdir = func_service_list_dir(servicename)
            search_dict = {}
            if retcode!='0':
                return ' '.join(result)
            else:
                if len(result[1:]) >= 2:
                    for line in result[3:]:
                        if len(line.split()) == 3:
                            path, size, u_size = line.split()
                            search_dict[path] = size
            for dir in subdir:
                r_path = dir['path'].replace('/cluster2/%s' % servicename, '').encode('utf-8')
                if r_path in search_dict:
                    size, unit = re.match('(\d+)(\D+)',search_dict[r_path]).groups()
                    dir['quota_unit'] = unit
                    dir['quota_size'] = size     
                else:
                    dir['quota_size'] = '-'  
                    dir['quota_unit'] = '-'
            return simplejson.dumps(subdir)
        else:
            result = proc.stdout.readlines()
            retcode = result[0].strip()
            Ologger.info("%s return %s" %(cmd,retcode))
            proc.wait()
            if retcode != '0':
                return ' '.join(result)
            return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

def func_service_replace_disk(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

def func_service_set_spare(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 
