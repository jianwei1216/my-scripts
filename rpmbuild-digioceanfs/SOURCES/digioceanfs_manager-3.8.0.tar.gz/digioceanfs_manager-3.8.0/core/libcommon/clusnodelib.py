#!/usr/bin/env python
#-*- coding: utf-8 -*-

import os
import sys
import subprocess
import re
import copy
import utils
import traceback 
import logging
from threading import Thread 
from xml.dom import minidom
import xml.etree.ElementTree as etree

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)
homepath = currpath[:currpath.find('libcommon')]
if not homepath in sys.path:
    sys.path.append(homepath)
utilspath = os.path.join(homepath,'utils')
if not utilspath in sys.path:
    sys.path.append(utilspath)

from log import Log
import settings

Log()
Ologger = logging.getLogger("asyncManager")

def execute(cmd, tmp):
    proc = subprocess.Popen(cmd, shell=True, stdout=tmp)
    proc.wait()
    tmp.seek(0)

#########################################################################################################
#
#   Function: func_node_create
#   Purpose: add a new node for the cluster
#
#########################################################################################################
def func_node_create(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

#########################################################################################################
#
#   Function: func_node_list_all
#   Purpose: to list all nodes info
#
#########################################################################################################
def func_node_list_all(options):
    clusternodes = []
    key = ['nodename','ipaddr','diskinfo','cifsstatus','nfsstatus','status']
    clusternodes_status = func_node_status('node status')
    clusternodes_cifs_status = func_node_cifs_status('node cifs_status')
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result.pop(0).strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode != '0':
            return ' '.join(result)
        else:
            result.pop(-1)
            p = '^(\S+)\s(\S+)\s+$'
            for v in result:
                m = re.match(p, v)
                if m:
                    value = list(m.groups())
                    nodeinfo = [[],clusternodes_cifs_status[value[0]],'',clusternodes_status[value[0]]]
                    value.extend(nodeinfo)
                    d = dict(zip(key,value))
                    clusternodes.append(d)
            return clusternodes
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

#########################################################################################################
#
#   Function: func_node_status
#   Purpose: to replace a old node(this maybe broken or has broken disks)
#
#########################################################################################################
def func_node_status(options):
    '''{'node-1':'start', 'node-2':'stop'}'''
    nodes_status = dict()
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode == '0':
            p = '^(\S+)\t(\S+)\s+'
            for line in result[1:-1]:
                status = re.findall(p, line)
                nodes_status[status[0][0]] = status[0][1]
            return nodes_status
        else:
            return ' '.join(result) 
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'
    
def func_node_cifs_status(options):
    '''{'node-1':'start', 'node-2':'stop'}'''
    nodes_status = dict()
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode == '0':
            p = '^(\S+)\t(\S+)\s+'
            for line in result[1:-1]:
                status = re.findall(p, line)
                nodes_status[status[0][0]] = status[0][1]
            return nodes_status
        else:
            return ' '.join(result)
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'
    
def func_node_cifs_restart(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'
    
def func_node_static_info(options):
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        proc.wait()
        result_proc = proc.stdout.readlines()
        retcode = result_proc[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode != '0':
            return ' '.join(result_proc)
        f = open('/etc/digioceanfs_manager/nodes/' + options.split()[2] + '_' + 'staticsysinfo','r')
        str = f.read()
        result_xml = str.split('\n')
        xml_str = ''.join(str.split('\n')[1:])
        xml_dom = minidom.parseString(xml_str)
        return xml_dom.toxml()
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

def func_node_dynamic_info(options):
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        proc.wait()
        result_proc = proc.stdout.readlines()
        retcode = result_proc[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode != '0':
            return ' '.join(result_proc)
        f = open('/etc/digioceanfs_manager/nodes/' + options.split()[2] + '_' + 'dynamicsysinfo','r')
        str = f.read()
        result_xml = str.split('\n')
        xml_str = ''.join(str.split('\n')[1:])
        xml_dom = minidom.parseString(xml_str)
        return xml_dom.toxml()
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'
#########################################################################################################
#
#   Function: func_node_raid_info
#   Purpose: to list disks info in a raid
#
#########################################################################################################
def func_node_raid_info(options):
    clusternoderaidinfo = []
    key = ['position','status','devname','type','vandor','sn_number','size','type_in_raid','raidname','nodename']
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        proc.wait()
        result = proc.stdout.readlines()
        Ologger.info("%s return %s" %(cmd,result))
        if result[0].strip() != '0':
            return ' '.join(result)
        else:
            node = options.split()[2]
            disklist = []
            flag = -1
            for raid in result[1:-1]:
                raidinfo = raid.split()
                diskinfo = raid.split('\t')
                if len(diskinfo) < 2:
                    disklist.append(diskinfo[0].strip())
                    flag += 1
					
                if 'in_raid' in raidinfo:
                    d = dict(zip(key,raidinfo))
                    d['size'] = utils.getUnit('', d['size'])
                    if node == '':
                        d['nodename'] = disklist[flag]
                    else:
                        d['nodename']=node
                    clusternoderaidinfo.append(d)
            return clusternoderaidinfo
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

def func_node_list_raid_hs(options):
    clusternoderaidinfo = {}
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        p = 'hot_spare'
        if retcode == '0':
            for line in result[1:-1]:
                if p in line.split():
                    dataline = line.split()
                    raidname = dataline[-1].strip()
                    if raidname not in clusternoderaidinfo:
                        clusternoderaidinfo[raidname] = []
                        clusternoderaidinfo[raidname].append(dataline[2].strip())
                    else:
                        clusternoderaidinfo[raidname].append(dataline[2].strip())
            else:
                return clusternoderaidinfo
        else:
            return ' '.join(result)
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

#def func_node_list_raid(options):
#    clusternoderaidinfo = {}
#    try:
#        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
#        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
#        #Ologger.info(cmd)
#        result = proc.stdout.readlines()
#        proc.wait()
#        retcode = result[0].strip()
#        p = 'hot_spare'
#        if retcode == '0':
#            for line in result[1:-1]:
#                if p in line.split():
#                    dataline = line.split()
#                    raidname = dataline[-1].strip()
#                    if raidname not in clusternoderaidinfo:
#                        clusternoderaidinfo[raidname] = []
#                        clusternoderaidinfo[raidname].append(dataline[2].strip())
#                    else:
#                        clusternoderaidinfo[raidname].append(dataline[2].strip())
#            else:
#                return clusternoderaidinfo
#        else:
#            return retcode == '0' and retcode or (retcode)
#    except Exception,e:
#        logger.debug(e)
#        return retcode == '0' and retcode or (retcode)

def func_node_raid_status():
    event_dict = readFromRaidPipe()
    raidstatus = event_dict
    if raidstatus:
        return raidstatus


#########################################################################################################
#
#   Function: func_node_raid_progress
#   Purpose: to check out the status of raid that is synchronizing
#
#########################################################################################################
def func_node_raid_progress(options):
    clusternoderaidprogress = {}
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode == '0\n':
            for res in result[1:5]:
                res = res.strip()
                res = res.split(': ')
                if res[0] == 'raid name':
                    clusternoderaidprogress['name'] = res[1]
                elif res[0] == 'raid level':
                    clusternoderaidprogress['level'] = res[1]
                elif res[0] == 'raid status':
                    clusternoderaidprogress['status'] = res[1]
                else:
                    clusternoderaidprogress['progress'] = res[1]
        else:
            return ' '.join(result)
        return clusternoderaidprogress
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

#########################################################################################################
#
#   Function: func_node_disk_info
#   Purpose: to list disks info in a node or a cluster
#
#########################################################################################################
def func_node_disk_info(options):
    retcode = '0'
    clusternodediskinfo = []
    key_nodisk = ['position','nodisk', 'devname']
    key_raid = ['position','status','devname','type','vandor','sn_number','size','type_in_raid','raidname','istart','pid']
    key_service = ['position','status','devname','type','vandor','sn_number','size','port','servicename','istart','pid']
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode != '0':
            return ' '.join(result)
        if len(options.split()) > 2:
            for res in result[1:-1]:
                if len(res.split()) <= 3:
                    diskinfo = res.split()
                    disk = dict()
                    disk['position'] = '-'
                    disk['status'] = diskinfo[1].strip()
                    disk['devname'] = diskinfo[2].strip()
                    disk['type'] = '-'
                    disk['vandor'] = '-'
                    disk['sn_number'] = '-'
                    disk['size'] = '-'
                    disk['port'] = '-'
                    disk['nodename'] = '-'
                    disk['size'] = '-'
                    clusternodediskinfo.append(disk)
                    continue
                diskinfo = res.split()
                for i in range(len(diskinfo)):
                    diskinfo[i] = diskinfo[i].strip()
                if diskinfo[1] == "in_raid":
                    d = dict(zip(key_raid,diskinfo))
                else:
                    d = dict(zip(key_service,diskinfo))
                d['nodename'] = options.split()[2]
                d['size'] = utils.getUnit('', d['size'])
                clusternodediskinfo.append(d)
            return clusternodediskinfo
        else:
            disklist = []
            flag = -1
            if retcode == '0':
                for res in result[1:-1]:
                    disk = dict()
                    diskinfo = res.split('\t')
                    if len(diskinfo) < 2:
                        disklist.append(diskinfo[0].strip())
                        flag += 1
                    elif len(diskinfo) == 3:
                        disk['position'] = diskinfo[0].strip()
                        disk['status'] = diskinfo[1].strip()
                        disk['devname'] = diskinfo[2].strip()
                        disk['type'] = '-'
                        disk['vandor'] = '-'
                        disk['sn_number'] = '-'
                        disk['size'] = '-'
                        disk['port'] = '-'
                        disk['nodename'] = '-'
                        disk['size'] = '-'
                        clusternodediskinfo.append(disk)
                    elif len(diskinfo) <= 8:
                        disk['position'] = diskinfo[0].strip()
                        disk['status'] = diskinfo[1].strip()
                        disk['devname'] = diskinfo[2].strip()
                        disk['type'] = diskinfo[3].strip()
                        disk['vandor'] = diskinfo[4].strip()
                        disk['sn_number'] = diskinfo[5].strip()
                        disk['size'] = diskinfo[6].strip()
                        disk['port'] = diskinfo[7].strip()
                        disk['nodename'] = disklist[flag]
                        disk['size'] = utils.getUnit('', disk['size'])
                        clusternodediskinfo.append(disk)
                    else:
                        if diskinfo[1].strip()=='no_disk':
                            disk['position'] = '-'
                            disk['status'] = diskinfo[1].strip()
                            disk['devname'] = diskinfo[2].strip()
                            disk['type'] = '-'
                            disk['vandor'] = '-'
                            disk['sn_number'] = '-'
                            disk['size'] = '-'
                            disk['port'] = '-'
                            disk['nodename'] = '-'
                            disk['size'] = '-'
                        else:
                            disk['position'] = diskinfo[0].strip()
                            disk['status'] = diskinfo[1].strip()
                            disk['devname'] = diskinfo[2].strip()
                            disk['type'] = diskinfo[3].strip()
                            disk['vandor'] = diskinfo[4].strip()
                            disk['sn_number'] = diskinfo[5].strip()
                            disk['size'] = diskinfo[6].strip()
                            disk['port'] = diskinfo[7].strip()
                            if disk['status'] == 'in_raid':
                                disk['raidname'] = diskinfo[8].strip()
                            else:
                                disk['servicename'] = diskinfo[8].strip()
                            disk['istart'] = diskinfo[9].strip()
                            disk['nodename'] = disklist[flag]
                            disk['size'] = utils.getUnit('', disk['size'])
                        clusternodediskinfo.append(disk)
                return clusternodediskinfo
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'


#########################################################################################################
#
#   Function: func_node_iface_info
#   Purpose: to list disks info in a raid
#
#########################################################################################################
def func_node_iface_info(options):
    clusternodeifaceinfo = []
    key = ['devname','devtype','mac','ipaddr','broadcast','netmask','status']
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode != '0':
            return ' '.join(result)
        for res in result[1:-1]:
            nicinfo = res.split('\t')
            nicinfo.pop(-1)
            if len(nicinfo) == 2:
                nicinfo = [nicinfo[1],'','','','','down']
                d = dict(zip(key,nicinfo))
            elif len(nicinfo) == 7:
                nicinfo.append('ok')
                d = dict(zip(key,nicinfo[1:]))
            elif len(nicinfo) > 7:
                sub_nic = nicinfo[7:]
                nicinfo = nicinfo[:7]
                nicinfo.append('ok')
                d = dict(zip(key,nicinfo[1:]))
                d['sub_nic'] = sub_nic
            else:
                continue
            clusternodeifaceinfo.append(d)
        return clusternodeifaceinfo
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

#########################################################################################################
#
#   Function: func_node_ipaddr_set
#   Purpose: change an old ipaddr
#
#########################################################################################################
def func_node_ipaddr_set(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

#########################################################################################################
#
#   Function: func_node_bond_set
#   Purpose: create a netcard bond
#
#########################################################################################################
def func_node_bond_set(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

#########################################################################################################
#
#   Function: func_node_bond_set
#   Purpose: delete a bond
#
#########################################################################################################
def func_node_bond_del(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

#########################################################################################################
#
#   Function: func_node_raid_create
#   Purpose: create a raid
#
#########################################################################################################
def func_node_raid_create(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

#########################################################################################################
#
#   Function: func_node_raid_del
#   Purpose: delete a raid
#
#########################################################################################################
def func_node_raid_del(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

#########################################################################################################
#
#   Function: func_node_raid_del
#   Purpose: set a hot spire disk for a raid
#
#########################################################################################################
def func_node_raid_set_hs(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

#########################################################################################################
#
#   Function: func_node_raid_del_hs
#   Purpose: delete a hot spire disk from a raid
#
#########################################################################################################
def func_node_raid_del_hs(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

#########################################################################################################
#
#   Function: func_node_disk_update
#   Purpose: update disks status
#
#########################################################################################################
import sys
from subprocess import PIPE, Popen
from threading  import Thread

try:
    from Queue import Queue, Empty
except ImportError:
    from queue import Queue, Empty  # python 3.x

ON_POSIX = 'posix' in sys.builtin_module_names

def enqueue_output(out, queue):
    for line in iter(out.readline, ''):
        queue.put(line)
    #out.close()


def func_node_disk_update(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

def func_node_processing():
    process_word = readFromProcessPipe()
    if process_word:
        return process_word 

#########################################################################################################
#
#   Function: func_node_list_inactive
#   Purpose: list all the disks which status is inactive
#
#########################################################################################################
def func_node_list_inactive(options):
    clusternoderaid_inactive = []
    inactivedisklist = []
    clusternoderaids = []
    flag = -1
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        result_str = result[1:]
        if retcode == '0':
            for res in result_str[0:-1]:
                disk_inactive = {}
                disk_inactive['raidname'] = res.split()[0]
                disk_inactive['normal_count'] = res.split()[1]
                disk_inactive['diskname'] = res.split()[2]
                disk_inactive['disk_type'] = res.split()[3]
                disk_inactive['belong_raid_uuid'] = res.split()[-1]
                inactivedisklist.append(disk_inactive)
        else:
            return  ' '.join(result)
        if inactivedisklist:
            for disk in inactivedisklist:
                if not clusternoderaid_inactive:
                    raid_inactive = {}
                    raid_inactive['devname'] = disk['raidname']
                    raid_inactive['normal_count'] = int(disk['normal_count'])
                    raid_inactive['disk_num'] = 1 
                    raid_inactive['child'] = [{disk['diskname']: disk['disk_type']}]
                    raid_inactive['uuid'] = disk['belong_raid_uuid']
                    clusternoderaid_inactive.append(raid_inactive)
                else:
                    _clusternoderaid_inactive = clusternoderaid_inactive
                    flag = False
                    for raid in _clusternoderaid_inactive:
                        if raid['uuid'] == disk['belong_raid_uuid']:
                            raid['child'].append({disk['diskname']: disk['disk_type']})
                            raid['disk_num'] += 1
                            flag = True
                            break
                    if not flag:
                        raid_inactive = {}
                        raid_inactive['devname'] = disk['raidname']
                        raid_inactive['normal_count'] = int(disk['normal_count'])
                        raid_inactive['disk_num'] = 1 
                        raid_inactive['child'] = [{disk['diskname']: disk['disk_type']}]
                        raid_inactive['uuid'] = disk['belong_raid_uuid']
                        clusternoderaid_inactive.append(raid_inactive)
                            
            return clusternoderaid_inactive
        else:
            return []
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

#########################################################################################################
#
#   Function: func_node_disk_active
#   Purpose: disactive disks that needed
#
#########################################################################################################
def func_node_disk_active(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

def func_node_disk_muti_op(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'
#########################################################################################################
#
#   Function: func_node_delete
#   Purpose: delete node in cluster
#
#########################################################################################################
def func_node_delete(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

#########################################################################################################
#
#   Function: func_node_get_device_id
#   Purpose: get node device id in cluster
#
#########################################################################################################
def func_node_get_device_id(options):
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True,stdout=subprocess.PIPE)
        proc.wait()
        result = proc.stdout.readlines()
        ret = result[0].strip()
        retcode = result[1].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if ret == "0":
            return retcode
        else:
            return ' '.join(result)
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 

#########################################################################################################
#
#   Function: func_node_check_license
#   Purpose: check license on node in cluster
#
#########################################################################################################
def func_node_check_license(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

def func_node_ctdb_set(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER,options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

def func_node_list_cpu(options):
    try:
        cmd = 'sudo python %s %s' % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True,stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode != '0':
            return ' '.join(result)
        else:
            cpuinfo = result[1].strip().replace('"','')
            return cpuinfo
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

if __name__ == '__main__':
    func_node_disk_update('node-1')
