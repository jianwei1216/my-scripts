#!/usr/bin/env python
#-*- coding: utf-8 -*-

import os
import sys
import subprocess
import re
import copy
import utils
import logging
from xml.dom import minidom
import xml.etree.ElementTree as etree

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)
homepath = currpath[:currpath.find('libcommon')]
if not homepath in sys.path:
    sys.path.append(homepath)
utilspath = os.path.join(homepath,'utils')
if not utilspath in sys.path:
    sys.path.append(utilspath)

from log import Log
import settings

Log()
Ologger = logging.getLogger("asyncManager")

def func_login(username, passwd):
    try:
        cmd = "sudo python %s login %s %s -w" % (settings.DIGI_MANAGER, username, passwd)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode == '0' and retcode or _(retcode)
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return retcode == '0' and retcode or _(retcode)
    
def func_logout():
    try:
        cmd = "sudo python %s logout"% (settings.DIGI_MANAGER)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode == '0' and retcode or _(retcode)
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return retcode == '0' and retcode or _(retcode)

def func_domain_set(options):
    try:
        cmd = "sudo python %s %s" % (settings.DIGI_MANAGER, options)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        retcode = proc.stdout.read().strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        proc.wait()
        return retcode
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1'

def func_domain_get():
    try:
        cmd = "sudo python %s domain_get" % (settings.DIGI_MANAGER)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        Ologger.info("%s return %s" %(cmd,retcode))
        if retcode!='0':
            return ' '.join(result) 
        return result[1].strip()
    except Exception,e:
        Ologger.debug(traceback.print_exc(e))
        return '-1' 
