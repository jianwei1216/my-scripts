import os, sys, string
import subprocess
import StringIO

#Cachesize calculator
cache_size = "`echo $(( $(grep 'MemTotal' /proc/meminfo | sed 's/[^0-9]//g') / 5120 ))`"

def find_in_list (list, name):
    try:
        index = list.index(name)
    except ValueError:
        return None
    return list[index]

def find_in_list_index (list, name):
    try:
        index = list.index(name)
    except ValueError:
        return None
    return index

class Comparable:
    def __init__(self, name):
        self.name = name

    def __str__(self):
        return self.name

    def __eq__(self, other):
        return self.name.__eq__(other.__str__())

class DynamicSortNode():
    def __init__(self, node):
        self.node = node
        self.weight = int(0)

    def weighter(self, quality):
        self.weight = self.weight+quality

    def lighter(self, quality):
        self.weight = self.weight-quality

    def get_node(self):
        return self.node

    def get_weight(self):
        return self.weight

    def __str__(self):
        return self.node.__str__()

    def __eq__(self, other):
        return self.node.__eq__(other)

    def __hash__(self):
        return id(self)

class DynamicSort():
    def __init__(self):
        self.node_list = []

    def exist_or_add(self, node_name, class_type):
        dnode = find_in_list(self.node_list, node_name)
        if not dnode:
            anode = class_type(node_name)
            dnode = DynamicSortNode(anode)
            self.node_list.append(dnode)
        return dnode

    def get_head(self):
        if not len(self.node_list) > 0:
            return None
        return self.node_list[0]

    def weight(self, dnode, quality):
        index = find_in_list_index(self.node_list, dnode)
        if index is None:
            return False

        self.node_list[index].weighter(quality)
        while index > 0:
            if self.node_list[index].get_weight() > self.node_list[index-1].get_weight():
                d = self.node_list.pop(index)
                self.node_list.insert(index-1, d)
                index = index-1
            else:
                break

        return True

    def light(self, dnode, quality):
        index = find_in_list_index(self.node_list, dnode)
        if index is None:
            return False

        self.node_list[index].lighter(quality)
        while index < len(self.node_list)-1:
            if self.node_list[index].get_weight() < self.node_list[index+1].get_weight():
                d = self.node_list.pop(index)
                self.node_list.insert(index+1, d)
                index = index+1
            else:
                break
        if self.node_list[index].get_weight() == 0:
            self.node_list.pop(index)

        return True

    def push_new(self, node_name, class_type):
        dnode = self.exist_or_add(node_name, class_type)
        if not self.weight(dnode, 1):
            return None
        return dnode.get_node()

    def pop_max(self, count=1):
        #initial pop count dict
        pop_dict = {}
        for dnode in self.node_list:
            pop_dict[dnode] = 0

        #ditribute pop number to each node
        i = 0
        node_count = len(self.node_list)
        for dnode in self.node_list:
            pop_dict[dnode] = count/node_count
            if i < (count%node_count):
                pop_dict[dnode] = pop_dict[dnode]+1
            i = i + 1

        #make pop number of each node under its limit
        index = 0
        index_list = range(len(self.node_list))
        index_list.reverse()
        for index in index_list:
            dnode = self.node_list[index]
            if dnode.get_weight() < pop_dict[dnode]:
                less = pop_dict[dnode] - dnode.get_weight()
                pop_dict[dnode] = dnode.get_weight()
                if i == 0:
                    print "there is no more node to pop!!!"
                    continue
                iter = 0
                while less != 0:
                    add_node = self.node_list[iter]
                    pop_dict[add_node] = pop_dict[add_node] + 1
                    iter = iter + 1
                    iter = iter%index
                    less = less - 1

        index = 0
        pop_list = []
        for index in index_list:
            dnode = self.node_list[index]
            if pop_dict[dnode] > 0:
                self.light(dnode, pop_dict[dnode])
                pop_list.append([dnode.get_node(), pop_dict[dnode]])

        return pop_list

class Node(Comparable):
    def __init__(self, name):
        Comparable.__init__(self, name)
        self.volume_list = []

    def add_volume(self, port):
        self.volume_list.append(port)

    def fetch_volume(self, count=1):
        volume_list = []
        for i in range(count):
            try:
                port = self.volume_list.pop()
            except ValueError:
                continue
            volume_list.append(self.__str__()+"-"+port)
        return volume_list

class Group(Comparable):
    def __init__(self, name):
        Comparable.__init__(self, name)
        self.sorter = DynamicSort()

    def push(self, node_name, port):
        anode = self.sorter.push_new(node_name, Node)
        anode.add_volume(port)

    def single_pop(self):
        node_list = self.sorter.pop_max()
        anode = node_list[0][0]
        if not anode:
            return None
        return anode.fetch_volume()[0]

    def multi_pop(self, count):
        node_list = self.sorter.pop_max(count)
        volume_list = []

        for anode in node_list:
            volume_list.extend(anode[0].fetch_volume(anode[1]))
        return volume_list

class Groups():
    def __init__(self):
        self.sorter = DynamicSort()

    def push(self, group_name, node_name, port):
        agroup = self.sorter.push_new(group_name, Group)
        agroup.push(node_name, port)

    def single_pop(self):
        group_list = self.sorter.pop_max()
        agroup = group_list[0][0]
        if not agroup:
            return None
        return agroup.single_pop()

    def multi_pop(self, count):
        group_list = self.sorter.pop_max(count)
        volume_list = []

        for agroup in group_list:
            volume_list.extend(agroup[0].multi_pop(agroup[1]))
        return volume_list

class CreateVolfile:

    def __init__ (self, server_dict, server, transport,
                  transports, options, server_array):

        self.host_dict = server_dict
        self.host = server
        self.volume_name = options.volume_name
        self.transport = transport
        self.transports = transports
        self.gfs_port = options.port
        self.gfs_ib_port = options.port + 1
        self.auth_parameters = options.auth_param
        self.raid_type = options.raid_type
        self.local_prioritize = options.local_prioritize
        self.ib_devport = options.ib_dev
        self.num_servers = len (self.host_dict.keys())
        self.conf_dir = options.conf_dir
        self.host_array = server_array
        self.unused = options.unused
        self.debug = options.debug
        self.volume_size_server = options.size_server
        self.volume_size_client = options.size_client
        self.mount_point = options.mount_point
        self.mserver_port = options.mserver_port
        self.layout_version = options.layout_version
        self.old_vol_file = options.old_vol_file
        self.extend_vol_file = options.extend_vol_file
        self.afr_num = options.afr_num
        self.afr_byhand = options.afr_byhand
        self.stripe_num = options.stripe_num

    def create_mount_volfile (self):

        raid_type = self.raid_type
        local_prioritize = self.local_prioritize 

        if self.conf_dir:
            mount_fd = file ("%s/%s.vol" % (self.conf_dir,
                                               str(self.volume_name)), "w")
        else:
            mount_fd = file ("%s.vol" % (str(self.volume_name)), "w")

        print "Generating client volfiles.. for transport '%s'" % (self.transport)


        cmdline = string.join (sys.argv, ' ')

        mount_fd.write ("## file auto generated by %s (mount.vol)\n" %
                        sys.argv[0])
        mount_fd.write ("# Cmd line:\n")
        mount_fd.write ("# $ %s\n\n" % cmdline)

        if raid_type is not None:
            # Used for later usage
            mount_fd.write ("# RAID %s\n" % raid_type)

        mount_fd.write ("# TRANSPORT-TYPE %s\n" % self.transport)
        subvolumes = []
        for host in self.host_dict.keys():
            i = 1
            for exports in self.host_dict[host]:
                print "exports:%s"%(exports)
                mount_fd.write ("volume %s-%s\n"%(host,exports[0]))
                mount_fd.write ("    type protocol/client\n")
                mount_fd.write ("    option transport-type %s\n"%self.transport)
                mount_fd.write ("    option remote-host %s\n"%host)
                mount_fd.write ("    option ping-timeout %s\n"%str(5))
                if self.transport == 'ib-verbs':
                    mount_fd.write ("    option transport.ib-verbs.port %d\n"%self.ib_devport)
                    mount_fd.write ("    option remote-port %d\n"%self.gfs_ib_port)
                if self.transport == 'tcp':
                    mount_fd.write ("    option transport.socket.nodelay on\n")
                    mount_fd.write ("    option remote-port %s\n"%(exports[0]))

                mount_fd.write ("    option remote-subvolume brick1\n")
                mount_fd.write ("end-volume\n\n")
                i += 1

        groups = Groups()
        for entry in self.host_array:
            group = entry.split(':')[0]
            node = entry.split(':')[1]
            port = entry.split(':')[2].split('/',1)[0]
            subvolumes.append(str(node) + '-' + str(port))
            if (raid_type=="1" or raid_type=="01") and not self.afr_byhand:
                groups.push(group, node, port)

        # Replicate section
        if raid_type=="1" or raid_type=="01":
            max_mirror_idx = len(subvolumes)/self.afr_num
            index = 0
            for index in range(max_mirror_idx):
                sub = []
                if self.afr_byhand:
                    for i in range(self.afr_num):
                        sub.append(subvolumes.pop())
                else:
                    sub = groups.multi_pop(self.afr_num)
                mount_fd.write("volume mirror-%s-%d\n"%(self.layout_version, index)  )
                mount_fd.write("    type cluster/replicate\n"                        )
                mount_fd.write("    subvolumes %s\n"%(string.join(sub,' '))          )
                mount_fd.write("    option metadata-change-log on\n"                 )
                mount_fd.write("    option strict-readdir on\n"                 )
                if local_prioritize == "1":
                    mount_fd.write ("    option afr-nufa-enable on\n"                         )
                mount_fd.write("end-volume\n\n"                                      )
            index = max_mirror_idx

#        exportlist = {}
#        node_bricks = []
#        node_list = []
#        group_list = []
#
#        for entry in self.host_array:
#            group = entry.split(':')[0]
#            node = entry.split(':')[1]
#            port = entry.split(':')[2].split('/',1)[0]
#            subvolumes.append(str(node) + '-' + str(port))
#            node_list.append(node)
#            if node in node_bricks:
#                continue
#            else:
#                node_bricks.append(node)
#                group_list.append(group)
#
#                max_mirror_idx = len (subvolumes) / self.afr_num
#                mirror_idx = 0
#                index = 0
#                while index < max_mirror_idx:
#
#                    #find the node which have most bricks
#                    max_bricks = 0
#                    for tmp_node in node_bricks:
#                        trav_bricks = node_list.count(tmp_node)
#                        if max_bricks < trav_bricks:
#                            max_bricks = trav_bricks
#                            max_node = tmp_node
#
#                    max_node_idx = node_bricks.index(max_node)
#                    max_group = group_list[max_node_idx]
#                    min_bricks = max_bricks
#
#                    #exclude the node in max_group, find the "min_node" in any others
#                    tmp_list = []
#                    for tmp_brick in node_bricks:
#                        tmp_list.append(tmp_brick)
#                    if group_list.count(max_group) < len(group_list):
#                        i = 0
#                        for trav in group_list:
#                            if trav == max_group:
#                                tmp_list.remove(node_bricks[i])
#                            i+=1
#                    min_node = tmp_list[0]
#
#                    for tmp_node in tmp_list:
#                        if tmp_node == min_node:
#                            continue
#                        trav_bricks = node_list.count(tmp_node)
#                        if min_bricks > trav_bricks:
#                            min_bricks = trav_bricks
#                            min_node = tmp_node
#                        elif min_bricks == trav_bricks:
#                            min_total_bricks = 0
#                            trav_total_bricks = 0
#                            group_min_idx = node_bricks.index(min_node)
#                            group_trav_idx = node_bricks.index(tmp_node)
#                            group_min = group_list[group_min_idx]
#                            group_trav = group_list[group_trav_idx]
#                            i = 0
#                            for min_total in node_bricks:
#                                if group_list[i] == group_min:
#                                    min_total_bricks += node_list.count(min_total)
#                                if group_list[i] == group_trav:
#                                    trav_total_bricks += node_list.count(min_total)
#                                i+=1
#                            if trav_total_bricks >= min_total_bricks:
#                                min_bricks = trav_bricks
#                                min_node = tmp_node
#
#                    max_brick_idx = node_list.index(max_node)
#                    min_brick_idx = node_list.index(min_node)
#
#                    if max_brick_idx == min_brick_idx:
#                        min_brick_idx += 1
#                    pop_max_idx = max_brick_idx
#                    node_list.remove(max_node)
#                    pop_min_idx = node_list.index(min_node)
#                    node_list.remove(min_node)
#                    if (node_list.count(max_node)==0) and (node_bricks.count(max_node)!=0):
#                        group_idx = node_bricks.index(max_node)
#                        node_bricks.remove(max_node)
#                        group_list.pop(group_idx)
#
#                    if (node_list.count(min_node)==0) and (node_bricks.count(min_node)!=0):
#                        group_idx = node_bricks.index(min_node)
#                        node_bricks.remove(min_node)
#                        group_list.pop(group_idx)
#
#                    mount_fd.write ("volume mirror-%s-%d\n" %(self.layout_version, index))
#                    mount_fd.write ("    type cluster/replicate\n")
#                    mount_fd.write ("    subvolumes %s %s\n" %
#                                    (subvolumes[max_brick_idx],
#                                     subvolumes[min_brick_idx]))
#                    mount_fd.write ("end-volume\n\n")
#                    subvolumes.pop(pop_max_idx)
#                    subvolumes.pop(pop_min_idx)
#                    mirror_idx += 2
#                    index += 1

        if raid_type=="1" or raid_type=="01":
            subvolumes = []
            flag = 0
            while flag < index:
                subvolumes.append ("mirror-%s-%d" %(self.layout_version, flag))
                flag += 1

        # Stripe section.. if given
        if raid_type=="0" or raid_type=="01":
            max_stripe_idx = len (subvolumes) / self.stripe_num
            stripe_idx = 0
            index = 0
            while index < max_stripe_idx:
                sub = []
                for i in range(self.stripe_num):
                    sub.append(subvolumes[stripe_idx + i])
                mount_fd.write ("volume stripe-%s-%d\n" %(self.layout_version, index))
                mount_fd.write ("    type cluster/stripe\n")
                mount_fd.write ("    option block-size 128KB\n")
                mount_fd.write ("    option use-xattr no\n")
                mount_fd.write ("    subvolumes %s\n"%string.join(sub, ' '))
                mount_fd.write ("end-volume\n\n")
                stripe_idx += self.stripe_num
                index +=1

        if raid_type=="0" or raid_type=="01":
            subvolumes = []
            flag = 0
            while flag < index:
                subvolumes.append ("stripe-%s-%d" %(self.layout_version, flag))
                flag += 1

        mount_fd.write ("volume distribute\n")
        mount_fd.write ("    type cluster/dht\n")
        mount_fd.write ("    option layout-version %s\n"%(self.layout_version))
        mount_fd.write ("    option min-free-disk 5%\n"                       )
        mount_fd.write ("    option lookup-unhashed on\n"                     )
        if local_prioritize == "1":
            mount_fd.write ("    option nufa-enable on\n"                         )
        mount_fd.write ("    subvolumes %s\n"%string.join (subvolumes,' ')    )
        mount_fd.write ("end-volume\n\n"                                      )
        subvolumes = []
        subvolumes.append("distribute")

#        if self.volume_size_client:
#            mount_fd.write ("volume quota\n")
#            mount_fd.write ("    type features/quota\n")
#            mount_fd.write ("    option disk-usage-limit %s\n" % self.volume_size_client)
#            if self.unused:
#                mount_fd.write ("#  option minimum-free-disk-limit 10GB "
#                                "# minimum free disk value (default) 0\n")
#                mount_fd.write ("#  option refresh-interval 10\n")
#            mount_fd.write ("    subvolumes %s\n" % subvolumes[0])
#            mount_fd.write ("end-volume\n\n")

        mount_fd.write ("volume readahead\n")
        mount_fd.write ("    type performance/read-ahead\n")
        mount_fd.write ("    option page-count 16\n")

        if self.unused:
            mount_fd.write ("#   option force-atime-update yes # force updating atimes, default off\n")
        if self.volume_size_client:
            mount_fd.write ("    subvolumes quota\n")
        else:
            mount_fd.write ("    subvolumes %s\n" % subvolumes[0])
        mount_fd.write ("end-volume\n\n")

        mount_fd.write ("volume iocache\n")
        mount_fd.write ("    type performance/io-cache\n")
        mount_fd.write ("    option cache-size %sMB\n" % cache_size)
        mount_fd.write ("    option cache-timeout 1\n")
        if self.unused:
            mount_fd.write ("#   option priority *.html:1,abc*:2 # Priority list for iocaching files\n")
        mount_fd.write ("    subvolumes readahead\n")
        mount_fd.write ("end-volume\n\n")

        #mount_fd.write ("volume writebehind\n")
        #mount_fd.write ("    type performance/write-behind\n")
        #mount_fd.write ("    option cache-size 512KB\n")
        #if self.unused:
            #mount_fd.write ("    option enable-trickling-writes yes # Flush final write calls when network is free\n")
            #mount_fd.write ("    option enable-O_SYNC yes # Enable O_SYNC for write-behind\n")
           # mount_fd.write ("    option disable-for-first-nbytes 1 # Disable first nbytes with very small initial writes\n")
        #mount_fd.write ("    subvolumes iocache\n")
       # mount_fd.write ("end-volume\n\n")

        mount_fd.write ("volume quickread\n")
        mount_fd.write ("    type performance/quick-read\n")
        mount_fd.write ("    option cache-timeout 1\n")
        mount_fd.write ("    option max-file-size 64kB\n")
        mount_fd.write ("    subvolumes iocache\n")
        mount_fd.write ("end-volume\n\n")

#        mount_fd.write ("volume statprefetch\n")
#        mount_fd.write ("    type performance/stat-prefetch\n")
#        mount_fd.write ("    subvolumes quickread\n")
#        mount_fd.write ("end-volume\n\n")

        mount_fd.write ("volume mserver\n")
        mount_fd.write ("    type protocol/mserver\n")
        mount_fd.write ("    option transport-type msocket\n")
        mount_fd.write ("    option transport.socket.listen-port %s\n"%(self.mserver_port))
        mount_fd.write ("end-volume\n\n")

        mount_fd.write ("volume fuse\n")
        mount_fd.write ("    type mount/fuse\n")
        mount_fd.write ("    option mountpoint %s\n"%(self.mount_point))
        mount_fd.write ("    subvolumes quickread mserver\n")
        mount_fd.write ("end-volume\n")


        return

    def create_export_volfile (self):

        local_prioritize = self.local_prioritize 
        cmdline = string.join (sys.argv, ' ')

        if self.conf_dir:
            exp_fd = file ("%s/%s.vol" %
                           (self.conf_dir,
                            str(self.volume_name)),"w")
        else:
            exp_fd = file ("%s-export.vol" %
                           (str(self.host + '-' + self.volume_name)),"w")

        print "Generating server volfiles.. for server '%s'" % (self.host)


#        print "config dir is:%s"%(self.conf_dir)
#        print "volume name is:%s"%(self.volume_name)
#
#        vol_file_path = "%s/%s.vol"%(self.conf_dir, self.volume_name)
#        print vol_file_path
#
#        exp_fd = file (vol_file_path, "w")
#
#        print "Generating server volfiles.. for server '%s'" % (self.host)

        exp_fd.write ("## file auto generated by %s (export.vol)\n" %
                      sys.argv[0])
        exp_fd.write ("# Cmd line:\n")
        exp_fd.write ("# $ %s\n\n" % cmdline)
        total_bricks = []
        i=1
        for export in self.host_dict[self.host]:
            exp_fd.write ("volume posix%d\n" % i)
            exp_fd.write ("  type storage/posix\n")
            if self.unused:
                exp_fd.write("# option o-direct enable # (default: disable) boolean type only\n")
                exp_fd.write("# option export-statfs-size no # (default: yes) boolean type only\n")
                exp_fd.write("# option mandate-attribute off # (default: on) boolean type only\n")
                exp_fd.write("# option span-devices 8 # (default: 0) integer value\n")
                exp_fd.write("# option background-unlink yes # (default: no) boolean type\n")

            exp_fd.write ("  option directory %s\n" % export[1])
            exp_fd.write ("end-volume\n\n")

            if self.volume_size_server:
                exp_fd.write ("volume quota%d\n" % i)
                exp_fd.write ("  type features/quota\n")
                exp_fd.write ("  option disk-usage-limit %s\n" % self.volume_size_server)
                if self.unused:
                    exp_fd.write ("#  option minimum-free-disk-limit 10GB "
                                  "# minimum free disk value (default) 0\n")
                    exp_fd.write ("#  option refresh-interval 10\n")
                exp_fd.write ("  subvolumes posix%d\n" % i)
                exp_fd.write ("end-volume\n\n")


            exp_fd.write ("volume locks%d\n" % i)
            exp_fd.write ("    type features/locks\n")
            if self.unused:
                exp_fd.write ("#   option mandatory on # Default off, used in specific applications\n")
            if self.volume_size_server:
                exp_fd.write ("    subvolumes quota%d\n" % i)
            else:
                exp_fd.write ("    subvolumes posix%d\n" % i)
            exp_fd.write ("end-volume\n\n")

            exp_fd.write ("volume brick%d\n" % i)
            exp_fd.write ("    type performance/io-threads\n")
            exp_fd.write ("    option thread-count 8\n")
            if self.unused:
                exp_fd.write ("#    option autoscaling yes # Heuristic for autoscaling threads on demand\n")
                exp_fd.write ("#    option min-threads 2 # min count for thread pool\n")
                exp_fd.write ("#    option max-threads 64 # max count for thread pool\n")

            exp_fd.write ("    subvolumes locks%d\n" % i)
            exp_fd.write ("end-volume\n\n")

            total_bricks.append("brick%s" % i)
            i += 1

        for transport in self.transports:
            exp_fd.write ("volume server-%s\n" % transport)
            exp_fd.write ("    type protocol/server\n")
            exp_fd.write ("    option transport-type %s\n" % transport)
            for brick in total_bricks:
                exp_fd.write ("    option auth.addr.%s.allow %s\n" %
                              (brick, self.auth_parameters))

            if transport == 'ib-verbs':
                exp_fd.write ("    option transport.ib-verbs.listen-port %d\n" % self.gfs_ib_port)
                exp_fd.write ("    option transport.ib-verbs.port %d\n"%(self.ib_devport))
            if transport == 'tcp':
                exp_fd.write ("    option transport.socket.listen-port %d\n" % self.gfs_port)
                exp_fd.write ("    option transport.socket.nodelay on\n")

            exp_fd.write ("    subvolumes %s\n"%(string.join(total_bricks, ' ')))
            exp_fd.write ("end-volume\n\n")

        return

    def create_extend_volfile (self):

        raid_type = self.raid_type

        if self.conf_dir:
            extend_fd = file ("%s/%s-ext.vol"%(self.conf_dir, str(self.volume_name)), "w")
        else:
            extend_fd = file ("%s-ext.vol"%(str(self.volume_name)), "w")

        print "Generating extend volfiles.. for transport '%s'"%(self.transport)


        cmdline = string.join (sys.argv, ' ')

        subvolumes = []

#        extend_fd.write ("# $ %s\n\n" % cmdline)

        extend_fd.write ("parent_volume=distribute\n\n")

        for host in self.host_dict.keys():
            i = 1
#            print "host:%s"%(host)
            for exports in self.host_dict[host]:
#                print "exports:%s"%(exports)
                extend_fd.write ("volume %s-%s\n"%(host,exports[0]))
                extend_fd.write ("    type protocol/client\n")
                extend_fd.write ("    option transport-type %s\n"%self.transport)

                extend_fd.write ("    option remote-host %s\n"%host)
                if self.transport == 'ib-verbs':
                    extend_fd.write ("    option transport.ib-verbs.port %d\n"%self.ib_devport)
                    extend_fd.write ("    option transport.remote-port %d\n"%self.gfs_ib_port)
                if self.transport == 'tcp':
                    extend_fd.write ("    option transport.socket.nodelay on\n")
                    extend_fd.write ("    option transport.remote-port %s\n"%(exports[0]))

                extend_fd.write ("    option remote-subvolume brick1\n")
                extend_fd.write ("end-volume\n\n")
                i += 1

        groups = Groups()
        for entry in self.host_array:
            group = entry.split(':')[0]
            node = entry.split(':')[1]
            port = entry.split(':')[2].split('/',1)[0]
            subvolumes.append(str(node) + '-' + str(port))
            if (raid_type=="1" or raid_type=="01") and not self.afr_byhand:
                groups.push(group, node, port)

        # Replicate section
        if raid_type=="1" or raid_type=="01":
            max_mirror_idx = len(subvolumes)/self.afr_num
            index = 0
            for index in range(max_mirror_idx):
                sub = []
                if self.afr_byhand:
                    for i in range(self.afr_num):
                        sub.append(subvolumes.pop())
                else:
                    sub = groups.multi_pop(self.afr_num)
                extend_fd.write("volume mirror-%s-%d\n"%(self.layout_version, index)  )
                extend_fd.write("    type cluster/replicate\n"                        )
                extend_fd.write("    option metadata-change-log on\n"                 )
                extend_fd.write("    option strict-readdir on\n"                 )
                extend_fd.write("    subvolumes %s\n"%(string.join(sub,' '))          )
                if self.local_prioritize == "1":
                    mount_fd.write ("    option afr-nufa-enable on\n"                         )
                extend_fd.write("end-volume\n\n"                                      )
            index = max_mirror_idx

#        exportlist = {}
#        node_bricks = []
#        node_list = []
#        group_list = []
#
#        for entry in self.host_array:
#            group = entry.split(':')[0]
#            node = entry.split(':')[1]
#            port = entry.split(':')[2].split('/',1)[0]
#            subvolumes.append(str(node) + '-' + str(port))
#            node_list.append(node)
#            if node in node_bricks:
#                continue
#            else:
#                node_bricks.append(node)
#                group_list.append(group)
#
#        # Replicate section
#        if raid_type=="1" or raid_type=="01":
#            max_mirror_idx = len (subvolumes) / self.afr_num
#            mirror_idx = 0
#            index = 0
#            while index < max_mirror_idx:
#
#                max_bricks = 0
#                for tmp_node in node_bricks:
#                    trav_bricks = node_list.count(tmp_node)
#                    if max_bricks < trav_bricks:
#                        max_bricks = trav_bricks
#                        max_node = tmp_node
#
#                max_node_idx = node_bricks.index(max_node)
#                max_group = group_list[max_node_idx]
#                min_bricks = max_bricks
#
#                tmp_list = []
#                for tmp_brick in node_bricks:
#                    tmp_list.append(tmp_brick)
#                if group_list.count(max_group) < len(group_list):
#                    i = 0
#                    for trav in group_list:
#                        if trav == max_group:
#                            tmp_list.remove(node_bricks[i])
#                        i+=1
#                min_node = tmp_list[0]
#                for tmp_node in tmp_list:
#                    if tmp_node == min_node:
#                        continue
#                    trav_bricks = node_list.count(tmp_node)
#                    if min_bricks > trav_bricks:
#                        min_bricks = trav_bricks
#                        min_node = tmp_node
#                    elif min_bricks == trav_bricks:
#                        min_total_bricks = 0
#                        trav_total_bricks = 0
#                        group_min_idx = node_bricks.index(min_node)
#                        group_trav_idx = node_bricks.index(tmp_node)
#                        group_min = group_list[group_min_idx]
#                        group_trav = group_list[group_trav_idx]
#                        i = 0
#                        for min_total in node_bricks:
#                            if group_list[i] == group_min:
#                                min_total_bricks += node_list.count(min_total)
#                            if group_list[i] == group_trav:
#                                trav_total_bricks += node_list.count(min_total)
#                            i+=1
#                        if trav_total_bricks >= min_total_bricks:
#                            min_bricks = trav_bricks
#                            min_node = tmp_node
#
#                max_brick_idx = node_list.index(max_node)
#                min_brick_idx = node_list.index(min_node)
#
#                if max_brick_idx == min_brick_idx:
#                    min_brick_idx += 1
#                pop_max_idx = max_brick_idx
#                node_list.remove(max_node)
#                pop_min_idx = node_list.index(min_node)
#                node_list.remove(min_node)
#                if (node_list.count(max_node) == 0) and (node_bricks.count(max_node) != 0):
#                    group_idx = node_bricks.index(max_node)
#                    node_bricks.remove(max_node)
#                    group_list.pop(group_idx)
#
#                if (node_list.count(min_node) == 0) and (node_bricks.count(min_node) != 0):
#                    group_idx = node_bricks.index(min_node)
#                    node_bricks.remove(min_node)
#                    group_list.pop(group_idx)
#
#
#                extend_fd.write ("volume mirror-%s-%d\n" %(self.layout_version, index))
#                extend_fd.write ("    type cluster/replicate\n")
#                extend_fd.write ("    subvolumes %s %s\n" %
#                                (subvolumes[max_brick_idx],
#                                 subvolumes[min_brick_idx]))
#                extend_fd.write ("    option metadata-change-log on\n")
#                extend_fd.write ("end-volume\n\n")
#                subvolumes.pop(pop_max_idx)
#                subvolumes.pop(pop_min_idx)
#                mirror_idx += 2
#                index += 1

        if raid_type=="1" or raid_type=="01":
            subvolumes = []
            flag = 0
            while flag < index:
                subvolumes.append ("mirror-%s-%d" %(self.layout_version, flag))
                flag += 1

        # Stripe section.. if given
        if raid_type=="0" or raid_type=="01":
            max_stripe_idx = len (subvolumes) / self.stripe_num
            stripe_idx = 0
            index = 0
            while index < max_stripe_idx:
                sub = []
                for i in range(self.stripe_num):
                    sub.append(subvolumes[stripe_idx + i])
                extend_fd.write ("volume stripe-%s-%d\n" %(self.layout_version, index))
                extend_fd.write ("    type cluster/stripe\n")
                extend_fd.write ("    option block-size 128KB\n")
                extend_fd.write ("    option use-xattr no\n")
                extend_fd.write ("    subvolumes %s\n"%string.join(sub, ' '))
                extend_fd.write ("end-volume\n\n")
                stripe_idx += self.stripe_num
                index +=1

        if raid_type=="0" or raid_type=="01":
            subvolumes = []
            flag = 0
            while flag < index:
                subvolumes.append ("stripe-%s-%d" %(self.layout_version, flag))
                flag += 1

#        if len (subvolumes) > 1:
        extend_fd.write ("volume distribute\n")
        extend_fd.write ("    type cluster/dht\n")
        extend_fd.write ("    option layout-version %s\n"%(self.layout_version))
        extend_fd.write ("    option min-free-disk 5%\n"                       )
        extend_fd.write ("    option lookup-unhashed on\n")
        if self.local_prioritize == "1":
            extend_fd.write ("    option nufa-enable on\n"                         )
        extend_fd.write ("    subvolumes %s\n"%string.join (subvolumes,' '))
        extend_fd.write ("end-volume\n\n")
        subvolumes[0] = "distribute"

    def append_extend_volfile(self):
        a_line = ""
        subvolumes = []
        vol_img = StringIO.StringIO()

        if not os.path.isfile(self.old_vol_file):
            print "old_vol_file not exist"
            sys.exit(1)

        if not os.path.isfile(self.extend_vol_file):
            print "extend_vol_file not exist"
            sys.exit(1)

        old_vol_fd    = file(self.old_vol_file,    "r")
        extend_vol_fd = file(self.extend_vol_file, "r")

        #find the parent_volume in extend_vol_file
        a_line = extend_vol_fd.readline()
        while len(a_line) > 0:
            if a_line.split('=')[0].__eq__("parent_volume"):
                parent_vol = a_line.split('\n')[0].split('=')[1]
                break
            a_line = extend_vol_fd.readline()

        print "parent_vol is: %s"%(parent_vol)

        a_line = old_vol_fd.readline()
        while len(a_line) > 0:
            if not a_line.split('\n')[0].__eq__("volume %s"%(parent_vol)):
                vol_img.write(a_line)
                a_line = old_vol_fd.readline()
            else:
                b_line = extend_vol_fd.readline()
                while not b_line.split('\n')[0].__eq__("volume %s"%(parent_vol)):
                    vol_img.write(b_line)
                    b_line = extend_vol_fd.readline()

                while not b_line.split()[0].__eq__("subvolumes"):
                    vol_img.write(b_line)
                    b_line = extend_vol_fd.readline()

                while not a_line.split()[0].__eq__("subvolumes"):
                    a_line = old_vol_fd.readline()

                subvolumes = a_line.split('\n')[0].split()[1:]
                subvolumes = subvolumes + b_line.split('\n')[0].split()[1:]

                vol_img.write("    subvolumes ")
                for subvolume in subvolumes:
                    vol_img.write("%s "%(subvolume))
                vol_img.write("\n")

                a_line = old_vol_fd.readline()

        vol_img.seek(0)

        old_vol_fd.close()
        new_vol_fd = open(self.old_vol_file, "w")
        new_vol_fd.truncate()
        new_vol_fd.write(vol_img.read())
        new_vol_fd.close()

    def remove_extend_volfile(self):
        print "not implement"
