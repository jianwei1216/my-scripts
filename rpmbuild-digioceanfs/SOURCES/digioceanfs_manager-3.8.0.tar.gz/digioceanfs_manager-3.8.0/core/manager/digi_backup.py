# -*- coding: utf-8 -*-
import os
import sys
import pyinotify

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))

utilspath = os.path.join(currpath[:currpath.rfind('manager')],'utils')
if not utilspath in sys.path:
    sys.path.append(utilspath)

import backup_utils



if __name__ == "__main__":
    try:
        exit(backup_utils.backup_files())
        
    except Exception, e:
        exit(-1)
