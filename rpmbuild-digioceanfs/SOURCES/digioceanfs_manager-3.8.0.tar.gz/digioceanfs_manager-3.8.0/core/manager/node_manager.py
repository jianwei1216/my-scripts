#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import subprocess
import tempfile
import dircache
import pickle
import re
import thread
import threading
import time
import logging
import signal
import dircache
import traceback
import commands
import Queue
import Digioceanfs_error
import random as ran
import fcntl
from xml.dom import minidom
from optparse import OptionParser
from optparse import Values

from pyinotify import WatchManager, Notifier,ThreadedNotifier, ProcessEvent, IN_DELETE, IN_CREATE,IN_MODIFY, IN_CLOSE_WRITE, IN_MOVED_FROM, IN_MOVED_TO

sys.path.append('/usr/local/digioceanfs_manager')
sys.path.append('/usr/local/digioceanfs_manager/monitor_report')
from get_info import *
sys.path.append('/usr/local/digioceanfs_manager/utils')
from mongo_utils import *
from mgmt_mongodb_utils import *

import settings

import traceback

#from digi_manager import node
import digi_manager
from backup_utils import latest_pack

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)

transportpath = os.path.join(currpath[:currpath.rfind('manager')],'transport')
if not transportpath in sys.path:
    sys.path.append(transportpath)

utilspath = os.path.join(currpath[:currpath.rfind('manager')],'utils')
if not utilspath in sys.path:
    sys.path.append(utilspath)

import manager_utils

from manager_utils import *
from raid_utils import *
from node_utils import *
from net_utils import *
from samba_utils import *
from bond_utils import *
from nfs_utils import *
from afr_utils import *
from smart_utils import *
from vol_file_utils import *
from sysinfo import *
from sysv_ipc import *
from pyNmonParser import *

from digiserver import DigiServer
from digiclient import DigiClient

from manager_protocol import *

from net_utils_tool import PING
from inotify_utils import notify

from localthread import *

import rsyslog_utils

config_dir_prefix   = "/etc/digioceanfs/vols"
export_dir_prefix   = "/digioceanfs"
service_dir_prefix  = "/etc/digioceanfs/services"
mount_dir_prefix    = "/cluster2"
digiocean_vols_dir_prefix = "/var/lib/digioceand/vols/"

server_conf_file_path     = "/etc/digioceanfs/server.conf"
add_storage_log_file_path = "/var/log/digioceanfs/CCS/"
NODE_MESSAGER_PORT = 9998

login_file_path = "/etc/digioceanfs_manager/login_lock"
DIGIMANAGER_CONF_FILE_PATH = "/etc/digioceanfs_manager/services"
DISK_PORT_BASE = 10001
MANAGEMENT_NODE_FILE_PATH = "/etc/digioceanfs/management_node"
NMON_PATH="/etc/digioceanfs/nmon"

MSIZE = 1024*512
KEY_MIN = 1
SHM_KEY_0 = 2147483620
SHM_KEY_1 = 2147483621
SP_KEY_0  = 2147483610
SP_KEY_1  = 2147483611
SP_KEY_PLUG  = 2147483600
CMD_GET_ASI = "/usr/bin/get_asi"

PROC_QUEUE = Queue.Queue() 
MSG_QUEUE = Queue.Queue() 
SNMSG_QUEUE = Queue.Queue()     #send notify message

def get_system_disks():
    disk_name_list = []
    disk_list      = []
    if os.path.exists("/etc/digioceanfs/compute_only"):
        return disk_list
    cmd = []
    cmd.append("/usr/bin/digi_partition")
    cmd.append("--list")
    tmp_img = tempfile.TemporaryFile()
    execute(cmd,tmp_img, err_ignore=True)
    tmp_img.seek(0)

    tmp_line = tmp_img.readline().split('\n')[0]
    while tmp_line:
        disk_name_list.append(tmp_line)
        tmp_line = tmp_img.readline().split('\n')[0]

    #if we got a disk with no id, we try 20 times to wait udev create the symbol link
    #if we find Semaphore_plug increace to 1, then the device symbol link is created
    #n = 20
    #while n > 0:
    sp_plug = Semaphore(2147483600, 0, 0600)
    dev_id_map = get_dev_id_map()
    for disk_name in disk_name_list:
        if disk_name not in dev_id_map:
            for _disk_name in disk_name_list:
                if _disk_name.find('md') >= 0:
                    raidCreateSymbol(_disk_name)
                else:
                    #sp_plug.acquire(None, 1)
                    pass
            dev_id_map = get_dev_id_map()
            if disk_name not in dev_id_map:
                continue 
            disk_list.append([dev_id_map[disk_name], disk_name])
        else:
            disk_list.append([dev_id_map[disk_name], disk_name])
            
    if not disk_list:
        digi_debug("Node manager, Found system disks:%s"%(disk_list), 5)
    else:
        digi_debug("Node manager, Found system disks:%s"%(disk_list), 7)
    return disk_list

def get_raid_disks(raid_dev):
    """
        return code specify:
        (raid_level, raid_status, disk_list)
        'disk_list' format:
        | dev_name | disk_id | disk_space | disk_role |
    """
    raid_level  = ""
    raid_status = ""
    disk_list   = []

    cmd = []
    #cmd.append("/usr/bin/digi_partition")
    #cmd.append("--list-raid")
    #cmd.append(raid_dev)
    cmd.append("mdadm")
    cmd.append("-D")
    cmd.append("/dev/%s" % raid_dev)
    tmp_img = tempfile.TemporaryFile()
    ret = execute(cmd,tmp_img)
    tmp_img.seek(0)
    lines = tmp_img.readlines()
    _lines = []
    for line in lines:
        if line.find(" : ") >= 0:
            key, value = tuple([l.strip() for l in line.split(' : ')])
            print key,value
            if key == 'Raid Level':
                raid_level = value.replace('raid', '')
            elif key == 'State':
                if value.find('degraded') >= 0:
                    raid_status = 'degraded'
                elif value.find('FAILED') >= 0:
                    raid_status = 'failed'
                elif value.find('inactive') >= 0:
                    raid_status = 'inactive'
                elif value.find('read-only') >= 0:
                    raid_status = 'read-only'
                else:
                    raid_status = 'active'
            else:
                pass
        else:
            _lines.append(line)

    #first get 'raid_level' and 'raid_status'
    #a_line = tmp_img.readline()
    #if a_line:
    #    raid_level = a_line.split('\n')[0].split()[0]
    #    raid_status = a_line.split('\n')[0].split()[1]

    #format 'disk_list'
    lines = tmp_img.readlines()
    lines = _lines
    print lines
    digi_debug("Node manager, Digi_partition --list-raid return %s"%(lines), 7)
    hot_spare_disks = getHotspare(raid_dev)
    dev_id_map      = get_dev_id_map()
    position_map = get_position_by_dev()[0]
    jobd = get_position_by_dev()[1]
    for a_line in lines:
        if a_line.find('/dev/sd') >= 0:
            print a_line.strip().split()
            dev_info = a_line.strip().split()
            dev_number = dev_info[0]
            dev_major = dev_info[1]
            dev_minor = dev_info[2]
            dev_raiddevice = dev_info[3]
            dev_role = dev_info[4:-1]
            dev_name = dev_info[-1]
            dev_name = dev_name.replace('/dev/', '')
            dev_role = ','.join(dev_role)
            print dev_number, dev_major, dev_minor, dev_raiddevice, dev_role, dev_name
        else:
            continue
        #a_split_line = a_line.split('\n')[0].split()
        #if len(a_split_line) > 2:
        #    digi_debug("Node manager, Get disk in raid: %s error, got %s"%(raid_dev, a_split_line), 5)
        #    continue
        #dev_name   = a_split_line[0]
        file_content = get_config_file("/sys/block/%s/size"%(dev_name))
        size_line = file_content.readline().split('\n')[0]
        disk_space = long(size_line)/2
        #if hot_spare_disks.__contains__(dev_name):
        #    disk_role = "hot_spare"
        #else:
        #    disk_role = "normal"
        try:
            dev_type_flag = int(get_config_file('/sys/block/%s/queue/rotational' % dev_name).read().strip())
            if dev_type_flag:
                dev_type = 'HDD'
            else:
                dev_type = 'SSD'
        except Exception, e:
            print e
            digi_debug("Node Manager, Disk get self type error", 3)
            digi_debug("Node Manager, traceback: %s" % traceback.print_exc(e), 3)
            dev_type = 'UNKNOWN'
        try:
            dev_model = str(get_config_file('/sys/block/%s/device/model' % dev_name).read().strip())
        except Exception, e:
            print e
            digi_debug("Node Manager, Disk get self model error", 3)
            digi_debug("Node Manager, traceback: %s" % traceback.print_exc(e), 3)
            dev_model = 'UNKNOWN'
        if not dev_id_map.__contains__(dev_name):
            digi_debug("Node manager, Dev %s is not in dev id map" % dev_name, 3)
            continue
        disk_id = dev_id_map[dev_name]

        try:
            disk_position = str(position_map[dev_name])+'/'+str(jobd)
        except Exception, e:
            traceback.print_exc(e)
            disk_position = -1
        #if dev_role.find('faulty') < 0:
        disk_list.append([disk_position, ','.join([dev_name, dev_type, dev_model]), disk_id, disk_space, dev_role])

    return (raid_level, raid_status, disk_list)

def add_storage(extend_file_path, client_conf_file_path):
    cmd = []
    cmd.append("/usr/bin/add_storage")
    cmd.append("-e")
    cmd.append("%s"%(extend_file_path))
    cmd.append("-f")
    cmd.append("%s"%(client_conf_file_path))

    tmp_img = tempfile.TemporaryFile()
    ret = execute(cmd, tmp_img)

    tmp_img.seek(0)
    ret_line = tmp_img.readline().split('\n')[0]

    return ret_line

def del_storage(client_conf_file_path):
    cmd = []
    cmd.append("/usr/bin/delstorage")
    cmd.append("-f")
    #digi_debug(client_conf_file_path)
    cmd.append("%s" % (client_conf_file_path))
    #digi_debug(client_conf_file_path)
    tmp_img = tempfile.TemporaryFile()
    ret = execute(cmd, tmp_img)

    tmp_img.seek(0)
    ret_line = tmp_img.readline().split('\n')[0]

    return ret_line

def storage_online(client_conf_file_path):
    cmd = []
    cmd.append("/usr/bin/on_line")
    cmd.append("-f")
    cmd.append("%s"%(client_conf_file_path))
    ret = execute(cmd)
    return ret

def partition_disk(disk_path):
    #collect_result("[Processing]: Partition disk ...")
    cmd = []
    cmd.append("/usr/bin/digi_partition")
    cmd.append("-d")
    cmd.append(disk_path)
    pid = execute(cmd)
    if pid:
        digi_debug("Node manager, Partition disk:%s, process pid:%d"%(disk_path, pid), 7)
        ret = return_or_kill(pid, 60)
        digi_debug("Node manager, partition disk:%s, process return status:%s"%(disk_path, ret), 7)

def umount_disk(disk_path):
    #collect_result("[Processing]: Partition disk ...")
    umount_time = 1
    cmd = []
    tmp_img = tempfile.TemporaryFile()
    cmd.append("findmnt -l |grep %s |wc -l" % disk_path)
    ret = execute(cmd, std=tmp_img, shell=True, err_ignore=True)
    tmp_img.seek(0)
    try:
        umount_time = int(tmp_img.read().strip())
    except:
        pass
    for i in range(umount_time):
        cmd = []
        cmd.append("/bin/umount")
        cmd.append("-lf")
        cmd.append(disk_path)
        pid = execute(cmd, err_ignore=True)
        if pid:
            digi_debug("Node manager, Umount disk:%s, process pid:%d"%(disk_path, pid), 7)
            ret = return_or_kill(pid, 60)
            digi_debug("Node manager, Umount disk:%s, process return status:%s"%(disk_path, ret), 7)
            
def node_messager(node_name, message_type, payload):
    """
        return code specify:
        None:    failed
    """
    transport = DigiClient((node_name, NODE_MESSAGER_PORT))
    ret = transport.connect()
    if ret != 0:
        digi_debug("Node manager, Node messager connect failed", 3)
        return None

    ret = transport.submit(message_type, payload)
    if not ret:
        digi_debug("Node manager, Node messager send messages failed", 3)
        return None

    ret = transport.receive()

    transport.disconnect()

    return ret

class disk (object):
    """
object to indicate one disk
usage:
    1.define an instance of the object with an dev name
      adisk = disk("sda")
    2.initial the instance by hand
      ret = adisk.init_disk()
      ret = 67 #the hard disk does not exist
            68 #hard disk exist, but has no port number
            69 #port number exist, but has no user
            70 #user exist, but not start
            71 #user exist, cluster spare disk
            0  #started

    raid_sub_disks:
        disk_name |             disk_id            | disk_space | disk_role_in_raid
          sda     | scsi-SATA_ST3500320NS_9QM62F3S |    8192    |     normal
          sdb     | scsi-SATA_ST3500630NS_9QG7QSR1 |    8192    |     normal
          sdc     | scsi-SATA_ST3500320NS_9QMA4A4M |    8192    |     normal
          sdd     | scsi-SATA_ST3750330NS_9QK11R9S |    8192    |     hot_spare
"""
    def init_disk (self):
        #if self.dev_id.find('ivcs') >= 0:
        #    self.set_dev('iVCS')
        #    #self.get_dev()
        #    #total_size = os.system("df -lP /usr/local/ivcs-data/vstore/ |awk '{print $2}' |sed 1d ")
        #    tmp_img = tempfile.TemporaryFile()
        #    cmd = []
        #    cmd.append("df -lP /usr/local/ivcs-data/vstore/ |awk '{print $2}' |sed 1d ")
        #    ret = execute(cmd, std=tmp_img, shell=True)
        #    tmp_img.seek(0)
        #    proc_line = tmp_img.readlines()
        #    if len(proc_line) > 0:
        #        self.size = long(proc_line[0].strip())
        #        digi_debug(self.size)
        #    self.disk_is_raid = False
        #    self.get_position()
        #    #digi_debug(">> %s << position is >> %d <<" %(self.get_dev(), self.position))
        #    if not self.get_port():
        #        digi_debug("Disk %s has no port number" % self.dev, 2)
        #        return 68
        #    if not self.get_user():
        #        digi_debug("Disk %s has no user" % self.dev, 5)
        #        return 69
        #    self.get_pid()
        #    if self.status() != 0:
        #        digi_debug("Disk %s has not been started" % self.dev, 5)
        #        return 70
        #else:
        try:
            stat_out = os.stat(self.dev_id_path)
        except OSError:
            digi_debug("Node manager, Disk %s not exists" % self.dev, 2)
            return 67 #return error message
        if not (stat_out.st_mode & 16384) and (stat_out.st_mode & 8192):
            return 67 #return error message

        
        if self.get_dev():
            file_content = get_config_file("/sys/block/%s/size"%(self.dev))
            size_line = file_content.readline()
        else:
            digi_debug("Node manager, Disk %s was no_disk"%(self.dev),3)
            self.dev = "no_disk"
            return 67# return error message

        if self.check_spare():
            digi_debug("**Debug: Node manager, Disk %s is cluster spare disk" % self.dev, 7)
        
        if len(size_line) > 0:
            self.size = size_line.split('\n')[0]
        else:
            digi_debug("Node manager, /sys/block/%s/size was empty"%(self.dev),3)
            return 72# return error message
        if self.size>0:
            self.size = long(size_line)/2
        else:
            digi_debug("Node manager, /sys/block/%s/size was <=0."%(self.dev),3)
            self.size=0
            return 72# return error message
        self.set_size()
        
        if self.dev[:2] == "md":
            self.disk_is_raid = True
            self.position = -1
            (self.raid_level, self.raid_status, self.raid_sub_disks) = get_raid_disks(self.dev)
        else:
            self.disk_is_raid = False
            self.get_position()
            #digi_debug(">> %s << position is >> %d <<" %(self.get_dev(), self.position))

        if not self.get_port():
            digi_debug("Node manager, Disk %s has no port number" % self.dev, 2)
            return 68

        if not self.get_user():
            digi_debug("Node manager, Disk %s has no user" % self.dev, 5)
            return 69

        self.get_node()
        #digi_debug(self.get_node())

#        if not os.path.isfile(self.pid_file_path):
#            return 70

        self.get_pid()

        if self.status() != 0:
            digi_debug("Node manager, Disk %s has not been started" % self.dev, 3)
            return 70
        

        return 0

    def __init__ (self, dev_id, dev=""):
        self.dev            = dev
        self.dev_id         = dev_id
        self.disk_is_raid   = bool #all types see manager_protocol.py:disk_type
        self.raid_level     = "" #raid level:0,1,10,5,6
        self.raid_status    = "" #raid status:active,inactive
        self.raid_sub_disks = [] #for disks in raid
        self.port           = ""
        self.user           = ""
        self.node           = ""
        self.pid            = ""
        self.size           = long()
        self.position       = int()
        
        self.cluster_spare  = ''

        self.config_dir = config_dir_prefix+"/"+self.dev_id
        self.export_dir = export_dir_prefix+"/"+self.dev_id
        self.digiocean_disk_pid_dir = "" 
        self.pid_file_name = "" 

        self.dev_file_path  = "%s/dev"%(self.config_dir)
        self.port_file_path = "%s/port"%(self.config_dir)
        self.user_file_path = "%s/user"%(self.config_dir)
        self.node_file_path = "%s/node"%(self.config_dir)
        self.vol_file_path = "%s/%s.vol"%(self.config_dir, self.dev_id)
        self.pid_file_path = "%s/%s.pid"%(self.config_dir, self.dev_id)
        self.digiocean_pid_file_path = ""
        self.log_file_path = "%s/%s.log"%(self.config_dir, self.dev_id)
        self.size_file_path = "%s/size"%(self.config_dir)

        #ONLY for disk in service of type afr.
        self.afr_syn_file_list     = Queue.Queue()
        self.afr_syn_find_th       = None
        self.afr_syn_find_lock     = thread.allocate_lock()
        self.afr_syn_find_done     = True
        self.afr_syn_do_th         = None
        self.afr_syn_do_lock       = thread.allocate_lock()
        self.afr_syn_do_done       = True
        #these 4 member is for synchronous between mirrors
        self.afr_syn_mode          = afr_syn_mode_type["none"]
        self.afr_syn_passive_lock  = thread.allocate_lock()
        self.afr_syn_passive_addr  = ""
        self.afr_syn_passive_lock.acquire()

        self.dev_id_path = "%s/%s"%(DEV_ID_DIR, self.dev_id)

#        self.init_disk()

    def get_dev (self):
#        if not self.dev:
        #if self.dev_id.find('ivcs') >= 0:
        #    return self.dev
        self.dev = get_dev_by_id(self.get_dev_id())
        if not self.dev:
            digi_debug("Node manager, Disk %s become no disk" % self.dev, 3)
            self.dev = "no_disk"
#            file_content = get_config_file(self.dev_file_path)
#            dev_line = file_content.readline()
#            if len(dev_line) > 0:
#                self.dev = dev_line.split('\n')[0]
        return self.dev
    
    def get_type(self):
        if self.disk_is_raid:
            return "RAID"
        try:
            fd = open('/sys/block/%s/queue/rotational'% self.dev, 'r')
            rotational_flag = int(fd.read().strip())
            if rotational_flag:
                return 'HDD'
            else:
                return 'SSD'
        except Exception, e:
            digi_debug("Node Manager, Disk get self type error", 3)
            digi_debug("Node Manager, traceback: %s" % traceback.print_exc(e), 3)
            return 'UNKNOWN'
            
    def get_model(self):
        if self.disk_is_raid:
            return self.raid_level
        try:
            fd = open('/sys/block/%s/device/model' % self.dev, 'r')
            model = str(fd.read().strip())
            if model:
                return model
            else:
                return 'UNKNOWN'
        except Exception, e:
            digi_debug("Node Manager, Disk get self model error", 3)
            digi_debug("Node Manager, traceback: %s" % traceback.print_exc(e), 3)
            return 'UNKNOWN'

    def get_position(self,position_map_list = ''):
        if position_map_list:
            if position_map_list == '-1/16':
                self.position = '-1/16'
            else:
                dev_name = self.get_dev()
                position_map = position_map_list[0]
                jobd = position_map_list[1]
                try:
                    disk_position = str(position_map[dev_name])+'/'+str(jobd)
                except Exception, e:
                    traceback.print_exc(e)
                    disk_position = -1
                self.position = disk_position
        else:
            self.position = get_position_by_dev(self.get_dev())
            #digi_debug(self.get_dev())
        return self.position

    def set_dev (self, dev):
        if dev:
            self.dev = dev
            file_img = StringIO.StringIO(dev)
            set_config_file(self.dev_file_path, file_img)
        else:
            os.remove(self.dev_file_path)
            self.dev = ""

    def get_dev_id (self):
        return self.dev_id

    def is_raid (self):
        return self.disk_is_raid

    def get_dev_id_path(self):
        return self.dev_id_path

    #these method is for raid only
    def get_raid_level (self):
        return self.raid_level

    def get_raid_status (self):
        return self.raid_status

    def get_raid_progress (self):
        return getRaidProgress(self.get_dev())

    def get_raid_sub_disk(self):
        return self.raid_sub_disks

    #these method should return an value while the disk is in an inactive raid
    def get_disk_raid_info(self):
        return diskRaidInfo(self.dev_id_path)

    def get_disk_raid_UUID(self):
        return diskRaidUUID(self.dev_id_path)

    def get_disk_raid_group(self):
        return diskRaidGroup(self.dev_id_path)

    def get_disk_raid_state(self):
        return diskRaidState(self.dev_id_path)

    def get_disk_raid_devices(self):
        return diskRaidDevices(self.dev_id_path)

    def add_hs_disk (self, disks):
        """
            append the a hot spare disk in the format of:(same with method 'get_raid_disks')
            | dev_name | disk_id | disk_space | disk_role |
        """
        for adisk in disks:
            dev_name   = adisk.get_dev()
            disk_id    = adisk.get_dev_id()
            disk_space = adisk.get_size()
            disk_role  = "hot_spare"
            self.raid_sub_disks.append([dev_name, disk_id, disk_space, disk_role])

    def remove_hs_disk (self, disk_names):
        disk_info_list = []
        for disk_info in self.raid_sub_disks:
            if disk_names.__contains__(disk_info[1]):
                disk_info_list.append(disk_info)
        for disk_info in disk_info_list:
            self.raid_sub_disks.remove(disk_info)

    def valid_hs_disk(self, disk_name):
        for disk_info in self.raid_sub_disks:
            try:
                _disk_name = disk_info[1].split(',')[0]
            except:
                _disk_name = ""
            if _disk_name == disk_name:
                if disk_info[4] == "spare":
                    return True
        digi_debug("Node manager, Disk %s is not valid for hs setting" % disk_name, 3)
        return False



    def get_port (self):
        if not self.port:
            file_content = get_config_file(self.port_file_path)
            port_line = file_content.readline()
            if len(port_line) > 0:
                self.port = port_line.split('\n')[0]
        return self.port

    def set_port (self, port):
        self.port = port
        file_img = StringIO.StringIO(self.port)
        set_config_file(self.port_file_path, file_img)
        return self.vol_file_init()

    def get_user (self):
        if not self.user:
            file_content = get_config_file(self.user_file_path)
            user_line = file_content.readline()
            if len(user_line) > 0:
                self.user = user_line.split('\n')[0]
        return self.user

    def set_user (self, user):
        """
            return code:
            0:    set user success
            1:    set user failed
            parameter specify:
            if user not NULL, the actuel set user process will be placed
            if user is NULL, the disk will be stop, and user will be set to NULL
        """
        if not user:
            if self.status() == 0:
                self.stop()
            ret = os.remove(self.user_file_path)
            digi_debug("Node manager, Disk %s remove disk user file return: %s" % (self.dev, ret), 7)
            self.user = ""
            return 0
        self.user = user
        file_img = StringIO.StringIO(self.user)
        set_config_file(self.user_file_path, file_img)
        return self.vol_file_init()

    def get_node (self):
        if not self.node:
            file_content = get_config_file(self.node_file_path)
            node_line = file_content.readline()
            if len(node_line) > 0:
                self.node = node_line.split('\n')[0]
        return self.node

    def set_node (self, node):
        if not node:
            os.remove(self.node_file_path)
            digi_debug("Node manager, Disk %s remove disk node file return: %s" % (self.dev, ret), 7)
            self.node = ""
            return 0
        self.node = node
        file_img = StringIO.StringIO(self.node)
        set_config_file(self.node_file_path, file_img)
        return 0

    def get_pid (self):
        self.digiocean_disk_pid_dir = digiocean_vols_dir_prefix + self.user + '/run/' 
        self.pid_file_name = self.node + '-' + 'digioceanfs-' + self.dev_id 
        self.digiocean_pid_file_path = self.digiocean_disk_pid_dir + self.pid_file_name + '.pid'

        if os.path.exists(self.digiocean_pid_file_path):
            file_content = get_config_file(self.digiocean_pid_file_path)
            pid_line = file_content.readline()
            if len(pid_line) > 0:
                self.pid = pid_line.split('\n')[0]
                if os.path.exists(self.pid_file_path):
                    os.remove(self.pid_file_path)
                os.symlink(self.digiocean_pid_file_path,self.pid_file_path)
                #file_img = StringIO.StringIO(self.pid)
                #set_config_file(self.pid_file_path, file_img)
            else:
               self.pid="0"
            #if self.status() != 0:
            #   self.pid="0"
        else:
            self.pid = "0"
        return self.pid

    def get_size (self):
        return self.size
    
    def set_size(self):
#        if self.dev_id.find('ivcs')<0:
#            if self.dev_id_path:
#                stat_out=os.stat(self.dev_id_path)
#            else:
#               os.remove(self.dev_id_path)
#                digi_debug("Disk id %s check dev id path raise error" % (self.dev_id_path), 5)
#                self.dev_id_path=""
#                return 66#return error message
#            if self.dev:
#                file_content = get_config_file("/sys/block/%s/size"%(self.dev))
#            else:
#                digi_debug("/sys/block/%s/size was empty"%(self.dev),5)
#                file_content = None
#                return 72#return error message
#            size_line=file_content.readline()
#            if len(size_line) > 0:
#                self.size = size_line.split('\n')[0]
#            else:
#                digi_debug("/sys/block/%s/size was empty"%(self.dev),5)
#                return 72#return error message
#            if self.size>0:
#            self.size = long(size_line)/2
        file_img = StringIO.StringIO(self.size)
        set_config_file(self.size_file_path, file_img)

    def get_no_disk_size(self):
        if self.size_file_path:
            file_content = get_config_file(self.size_file_path)
            size_line = file_content.readline()
            if len(size_line) > 0:
                self.size = size_line.split('\n')[0]
                if self.size>0:
                    self.size = long(size_line)
            return self.size
        else:
            os.remove(self.size_file_path)
            digi_debug("Node manager, Disk %s check size file path raise error" % (self.dev), 3)
            self.size_file_path=""
            return 66
        #if len(size_line) > 0:
        #    self.size = size_line.split('\n')[0]
        #else:
        #    digi_debug("Disk %s check size file path raise error" % (self.size_file_path), 5)
        #    return 66
        #if self.size>0:
        #    self.size = long(size_line)
        #    return self.size
        #else:
        #    digi_debug("Disk %s check size file path raise error" % (self.size_file_path), 5)
        #    self.size = 0
        #    return 66
    
    def get_used_size(self):
        fst = os.statvfs(self.export_dir)
        return fst.f_frsize*(fst.f_blocks-fst.f_bfree)

    def clear_disk_glusterfs_attr(self):
        cmd = []
        #cmd.append('/usr/local/digioceanfs_manager/manager/clear_xattrs.sh')
        cmd.append(settings.COMMANDS['clear_xattr'])
        cmd.append(self.export_dir)
        execute(cmd)

    def start (self):
        #if the disk status is 'running', we should still check
        #weither the disk is mounted
        if self.status() == 0:
            if os.path.ismount(self.export_dir):
                digi_debug("Node manager, Disk %s is mounted when ready to start" % self.dev, 3)
                return 61 #return error message
            #self.stop()

        try:
            stat_out = os.stat(self.dev_id_path)
        except Exception, OSError:
            digi_debug("Node manager, Disk %s check dev id path raise error" % self.dev, 3)
            return 66 #return error message
        if not (stat_out.st_mode & 16384) and (stat_out.st_mode & 8192):
            digi_debug("Node manager, Disk %s check dev id path raise error" % self.dev, 3)
            return 66 #return error message

        # check if the disk is the same disk
        #if os.path.realpath(self.dev_id_path).find(self.dev) >= 0:
        #    pass

        if not os.path.isdir(self.export_dir):
            try:
                os.mkdir(self.export_dir)
            except Exception, OSError:
                pass

        if not self.user:
            digi_debug("Node manager, Disk %s check disk user raise error" % self.dev, 3)
            return 71 #return error message

        if not os.path.ismount(self.export_dir):
           # cmd = []
           # #cmd.append("/bin/mount")
           # cmd.append(settings.COMMANDS['mount'])
           # #if self.dev_id_path.find('ivcs') >= 0:
           # #    cmd.append('--bind')
           # cmd.append(self.dev_id_path)
           # cmd.append(self.export_dir)
            test_times = 10
            while test_times >= 1:
                #ret = execute(cmd)
                ret = self.mount()
                if ret != 0:
                    test_times = test_times - 1
                    continue
                    #ret = execute(cmd)
                else:
                    break
            else:
                return 62 #return error message

        #cmd = []
        #cmd.append("/usr/sbin/glusterfsd")
        #cmd.append("-f%s"%(self.vol_file_path))
        #cmd.append("-p%s"%(self.pid_file_path))
        #cmd.append("-l%s"%(self.log_file_path))
        #ret = execute(cmd, err_ignore=True)
        #digi_debug("Disk start : %s return:%d"%(self.dev, ret), 7)
        #if ret == 1:
        #    self.stop_with_out_pid()
        #    cmd = []
        #    cmd.append("/usr/sbin/glusterfsd")
        #    cmd.append("-f%s"%(self.vol_file_path))
        #    cmd.append("-p%s"%(self.pid_file_path))
        #    cmd.append("-l%s"%(self.log_file_path))
        #    ret = execute(cmd)
        self.get_pid()
        if not self.pid or self.pid == '0':
            return 65 
        return 0

    #TODO:remove programe name hard coding:digioceanfsd
    def stop_with_out_pid(self):
        tmp_img = tempfile.TemporaryFile()
        cmd = []
        cmd.append("/bin/ps -Cdigioceanfsd -f --no-heading | grep \"%s/%s\""%(self.config_dir, self.dev_id))
        ret = execute(cmd, std=tmp_img, shell=True)
#        proc = subprocess.Popen("/bin/ps -Cdigioceanfsd -f --no-heading | grep \"%s/%s\""%(self.config_dir, self.dev),
#                                 shell=True, stdout=tmp_img, close_fds=True)
#        ret = proc.wait()
        tmp_img.seek(0)
        proc_line = tmp_img.readlines()
        if len(proc_line) < 1:
            return
        pid = proc_line[0].split()[1]
        cmd = []
        cmd.append("/bin/kill")
        cmd.append(pid)
        ret = execute(cmd)
#        proc = subprocess.Popen(["/bin/kill",
#                                 "%s"%(pid)])
#        ret = proc.wait()

    def stop (self):
        if self.status() == 0:
            cmd = []
            cmd.append("/bin/kill")
            cmd.append(self.pid)
            ret = execute(cmd, err_ignore=True)
#            proc = subprocess.Popen(["/bin/kill",
#                                     "%s"%(self.pid)],
#                                    close_fds=True)
#            ret = proc.wait()
            return 0
        digi_debug("Node manager, Disk stop %s, but already stop" % self.dev, 3)
        return 63 #return error message

    #def restart(self):
    #    self.stop()
    #    self.start()

    def status (self):
        """
            return code:
            0:    disk is running
            64:   disk is not running, but pid file exist, it will be delete after called
            65:   disk is not running
        """
        if self.pid and self.pid != '0':
            #black_hole = open('/dev/null')
            cmd = []
            cmd.append("/bin/ps")
            cmd.append("-p%s"%(self.pid))
            ret = execute(cmd)
            if ret != 0:
                if os.path.exists(self.pid_file_path):
                    os.remove(self.pid_file_path)
                digi_debug("Disk %s not running, but pid file exist" % self.dev, 5)
                return 64 #return error message
            else:
                return 0
        else:
            digi_debug("Node manager, Disk %s is not running" % self.dev, 3)
            return 65 #return error message
        
    def set_spare(self):
        """return True when success, else False
        """
        if not self.ismounted(self.dev):
            self.mount()
        cmd = ['setfattr -n "trusted.digioceanfs.disk.spare" -v "spare" %s' % self.export_dir]
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, std=tmp_img, shell=True)
        tmp_img.seek(0)
        if not ret:
            return True
        else:
            return False
    
    def set_replaced(self):
        if not self.ismounted(self.dev):
            self.mount()
        cmd = ['setfattr -n "trusted.digioceanfs.disk.spare" -v "replaced" %s' % self.export_dir]
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, std=tmp_img, shell=True)
        tmp_img.seek(0)
        if not ret:
            return True
        else:
            return False
        
    def check_spare(self):
        """return True when spare disk found
        else return False
        """
        if not self.ismounted(self.dev):
            self.mount()
        cmd = ['getfattr -h -d -e text -m "trusted.digioceanfs.disk.spare" %s' % self.export_dir]
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, std=tmp_img, shell=True)
        tmp_img.seek(0)
        if not ret:
            lines = tmp_img.readlines()
            for line in lines:
                if line.find('trusted.digioceanfs.disk.spare') >= 0:
                    self.cluster_spare = line.split('=')[1].strip()
                    digi_debug("Node Manager, found spare feathur on disk %s: %s" % (self.dev, self.cluster_spare))
                    return True
                else:
                    self.cluster_spare = ''
            else:
                self.cluster_spare = ''
                return False
        else:
            return False

    def restart(self):
        if not os.path.ismount(self.export_dir):
           # cmd = []
           # #cmd.append("/bin/mount")
           # cmd.append(settings.COMMANDS['mount'])
           # cmd.append(self.dev_id_path)
           # cmd.append(self.export_dir)
           # ret = execute(cmd, err_ignore=True)
            ret = self.mount()
            if ret != 0:
                return False
        if self.status() != 0:
            self.start()
        return True

    def destroy (self):
        """destroy the disk files and directory when remove from the system or create raid"""
        digi_debug("Node Manager, disk destroy: %s" % self.dev_id)
        if self.status() == 0:
            self.stop()
        if os.path.exists(self.pid_file_path):
            os.system("rm %s" % self.pid_file_path)
        if os.path.isfile(self.size_file_path):
            os.system("rm %s" % self.size_file_path)
        if os.path.isfile(self.log_file_path):
            os.system("rm %s" % self.log_file_path)
        if os.path.isfile(self.vol_file_path):
            os.system("rm %s" % self.vol_file_path)
        if os.path.isfile(self.port_file_path):
            os.system("rm %s" % self.port_file_path)
        if os.path.isfile(self.user_file_path):
            os.system("rm %s" % self.user_file_path)
            if self.user:
                self.user = ""
        if os.path.isfile(self.node_file_path):
            os.system("rm %s" % self.node_file_path)
        if os.path.isfile(self.dev_file_path):
            #print os.remove(self.dev_file_path)
            os.system("rm %s" % self.dev_file_path)
        if os.path.isdir(self.config_dir):
            #print os.rmdir(self.config_dir)
            os.system("rm -rf %s" % self.config_dir)
        if os.path.isdir(self.export_dir):
            while os.path.ismount(self.export_dir):
                cmd = []
                cmd.append("/bin/umount")
                cmd.append(self.export_dir)
                cmd.append("-lf")
                ret = execute(cmd, err_ignore=True)
            #os.system("rm -rf %s" % self.export_dir)

    def reset(self):
        if os.path.isfile(self.user_file_path):
            os.system("rm -rf %s" % self.user_file_path)
        return 0

    def ismounted(self, dev):
        cmd=[settings.COMMANDS['mount']]
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, tmp_img)
        if ret:
            digi_debug("*ERROR: Node manager mount failed", 3)
            return True
        else:
            if tmp_img.read().find(dev) >= 0:
                digi_debug("Node manager, Detect disk %s mount status: mounted" % dev, 7)
                return True
        digi_debug("Node manager, Detect disk %s mount status: not mounted" % dev, 7)
        return False

    def mount(self):
        flage_2 = -1
        data = {}
        data['node'] = get_local_hostname_by_ip()
        if not data['node']:
            digi_debug("Node Manager, disk mount failed", 3)
            return False
        data['device'] = self.dev_id
        data['monitor_type'] = 'disk_mount_report'
        mongo_dict = connect_mongodb()
        if not mongo_dict:
            digi_debug("Node Manager, connect mongodb Failed", 3)
            return False
        event_info = get_disk_info_from_db(data, mongo_dict['monitorcol'])
        if not event_info == 'None':
            flage_1 = 0
            ret = check_out_disk_event (event_info)
            if ret == True:
                flage_2 = 1
            elif ret == False:
                flage_2 = 0
            else:
                flage_2 = -1
        elif event_info == -1:
            digi_debug("Node Manager, not get disk info feom db other error", 3)
            return False
        else:
            flage_1 = 1
        data['dev'] = self.dev
        cmd = []
        cmd.append(settings.COMMANDS['mount'])
        cmd.append(self.dev_id_path)
        cmd.append(self.export_dir)
        ret = execute(cmd)
        if ret:
            digi_debug("Node manager, Mount disk: %s failed" % self.dev, 3)
            if flage_2 == 1 or flage_2 == -1:
                data['monitor_type_disk_mount'] = 'disk_mount_failed'
                data['servicename'] = self.get_user()
                update_write_event_to_db(data, mongo_dict['alarmcol'],
                        mongo_dict['monitorcol'], mongo_dict['thresholdcol'],
                        False, mongo_dict)
            return False
        else:
            if flage_1 == 1:
                digi_debug("None Manager, mount disk info is not found in mongodb", 3)
                return True
            if flage_2 == 0:
                data['monitor_type_disk_mount'] = 'disk_remount_success'
                data['servicename'] = self.get_user()
                update_write_event_to_db(data, mongo_dict['alarmcol'],
                        mongo_dict['monitorcol'], mongo_dict['thresholdcol'],
                        False, mongo_dict)
            return True

    def format(self):
        """format disk"""
        ismounted = self.ismounted(self.dev) or os.path.ismount(self.export_dir)
        digi_debug("Node manager, Format disk detect disk %s mount status: %s" % (self.dev, ismounted),3)
        if os.path.isdir(self.export_dir):
            while ismounted:
                cmd = []
                cmd.append("/bin/umount")
                cmd.append(self.export_dir)
                cmd.append("-lf")
                ret = execute(cmd, err_ignore=True) 
                cmd = []
                cmd.append("/bin/umount")
                cmd.append('/dev/%s' % self.dev)
                cmd.append("-lf")
                ret = execute(cmd, err_ignore=True) 
                ismounted = self.ismounted(self.dev)
        cmd = []
        cmd.append(settings.COMMANDS['mkfs.xfs'])
        cmd.append("-s")
        cmd.append("size=512")
        cmd.append(self.dev_id_path)
        cmd.append("-f")
        ret = execute(cmd)
        if ret:
            return 1
        else:
            return 0


    def partition(self):
        umount_disk(self.export_dir)
        partition_disk(self.get_dev())

#this function is called when a disk is initialed for the first time
#or the port of this disk is changed
    def vol_file_init (self):
        #collect_result("[Processing]: Create volen file ...")
        init_dir (self.export_dir,True,0444)

        #cmd = []
        #cmd.append("/usr/bin/digioceanfs-volgen")
        #cmd.append("-n%s"%(self.dev_id))
        #cmd.append("-c%s"%(self.config_dir))
        #cmd.append("-p%s"%(self.port))
        #cmd.append("agroup:127.0.0.1:%s"%(self.export_dir))
        #ret = execute(cmd)
#        proc = subprocess.Popen(["/usr/bin/digioceanfs-volgen",
#                                 "-n%s"%(self.dev),
#                                 "-c%s"%(self.config_dir),
#                                 "-p%s"%(self.port),
#                                 "127.0.0.1:%s"%(self.export_dir)],
#                                close_fds=True)
#        ret = proc.wait()
        return 0

    def afr_syn_find_thread(self):
        filename_list = list()

        filename_list.append("/")

        digi_debug("Node manager, find thread of disk:%s start"%self.get_dev_id(),5)

        if self.afr_syn_mode == afr_syn_mode_type["passive"]:
            self.afr_syn_passive_lock.acquire()
            digi_debug("Node manager, disk:%s got afr_syn_passive lock"%(self.get_dev_id()),5)

        while len(filename_list) > 0:
            filename = filename_list.pop()
            if os.path.isdir("%s%s"%(self.export_dir, filename)):
                newfiles = dircache.listdir("%s%s"%(self.export_dir, filename))
                if len(newfiles) < 1:
                    self.afr_syn_file_list.put(filename)
                for newfile in newfiles:
                    filename_list.append("%s/%s"%(filename, newfile))
            else:
                self.afr_syn_file_list.put(filename)

        self.afr_syn_find_lock.acquire()
        self.afr_syn_find_done = True
        self.afr_syn_find_lock.release()

        digi_debug("Node manager, find thread of disk:%s stop"%self.get_dev_id(),5)

    def afr_syn_do_thread(self, service_export_dir):
        file_count = int(0)
#        cmd = []
#        cmd.append("/bin/touch")
#        cmd.append("")

        digi_debug("Node manager, do thread of disk:%s start"%self.get_dev_id(),5)

        while True:
            filename = None
            try:
                filename = self.afr_syn_file_list.get(block=True, timeout=2)
            except Queue.Empty,e:
                self.afr_syn_find_lock.acquire()
                if self.afr_syn_find_done:
                    self.afr_syn_find_lock.release()
                    break
                self.afr_syn_find_lock.release()
            if filename:
                file_count = file_count + 1
#                digi_debug("stat file %s%s"%(service_export_dir, filename))
#                cmd[1] = "%s%s"%(service_export_dir, filename)
#                execute(cmd)
                os.stat("%s%s"%(service_export_dir, filename))

        self.afr_syn_do_lock.acquire()
        self.afr_syn_do_done = True
        self.afr_syn_do_lock.release()

        if self.afr_syn_mode == afr_syn_mode_type["active"]:
            self.afr_syn_release_remote_passive_lock()

        digi_debug("Node manager, do thread of disk:%s stop, stat:%d files"
                   %(self.get_dev_id(), file_count),5)

    def set_afr_syn_mode(self, mode):
        self.afr_syn_mode = afr_syn_mode_type[mode]

    def set_afr_syn_passive_addr(self, passive_addr):
        self.afr_syn_passive_addr = passive_addr

    def afr_syn_release_remote_passive_lock(self):
        #send release lock request to a remote server
        node_messager(self.afr_syn_passive_addr[0],
                     node_messager_type["afr_passive_unlock"],
                     self.afr_syn_passive_addr[1])

    def afr_syn_release_passive_lock(self):
        if self.afr_syn_passive_lock.locked():
            self.afr_syn_passive_lock.release()

    def afr_syn(self, service_export_dir, syn_mode, passive_addr):
        """
            return code specify:
            1:    syn start success
            2:    syn start already
            3:    syn do thread start already
        """
        self.set_afr_syn_mode(syn_mode)
        self.set_afr_syn_passive_addr(passive_addr)

        self.afr_syn_find_lock.acquire()
        if self.afr_syn_find_done:
            self.afr_syn_find_done = False
            self.afr_syn_find_lock.release()
        else:
            self.afr_syn_find_lock.release()
            return 2

        #Create find thread here
        self.afr_syn_find_th = threading.Thread(target=self.afr_syn_find_thread)
        self.afr_syn_find_th.start()

        self.afr_syn_do_lock.acquire()
        if self.afr_syn_do_done:
            self.afr_syn_do_done = False
            self.afr_syn_do_lock.release()
        else:
            self.afr_syn_do_lock.release()

            #Wait the "do" thread a timeout.
            #If it does not return during the timeout, return.
            #Just ensure that the "do" thread will be run,
            #incase it is in an exist status before we check the mark.
            self.afr_syn_do_th.join(timeout=0.1)
            if self.afr_syn_do_th.isAlive():
                return 3

            self.afr_syn_do_lock.acquire()
            self.afr_syn_do_done = False
            self.afr_syn_do_lock.release()

        self.afr_syn_do_th = threading.Thread(target=self.afr_syn_do_thread,
                                              args=(service_export_dir,))
        self.afr_syn_do_th.start()

        return 1

    def __str__(self):
        return self.dev_id

    def __eq__ (self, other):
        if type(other) == str:
            return self.dev_id.__eq__(other.__str__())
        else:
            return (self.dev_id + self.node.__str__()).__eq__(other.__str__() + other.node.__str__())



class service():
    """
        while taking an action to the service proc, first use self.status()
        to check the proc.
        if the proc started, self.pid will be set;
        if not, self.status() will return 0
    """
    def init_file_path(self):
        """
            dir and files:
            /etc/digioceanfs/services/


        """
        self.config_dir            = "%s/%s"%(service_dir_prefix, self.name)
        self.mount_dir             = "%s/%s"%(mount_dir_prefix, self.name)
        #self.vol_file_path         = "%s/%s.vol"%(self.config_dir, self.name)
        #self.log_file_path         = "%s/%s.log"%(self.config_dir, self.name)
        #self.pid_file_path         = "%s/%s.pid"%(self.config_dir, self.name)
        #self.afr_info_file_path    = "%s/%s.info"%(self.config_dir, self.name)
        #self.disk_file_path        = "%s/disks"%(self.config_dir)
        #self.mserver_file_path     = "%s/mserver"%(self.config_dir)
        #self.version_file_path     = "%s/version"%(self.config_dir)
        #self.extend_file_path      = "%s/127.0.0.1.vol"%(self.config_dir)
        #self.client_conf_file_path = "%s/client.conf"%(self.config_dir)
        #self.asi_conf_file_path    = "%s/%s/asi.conf"%(DIGIMANAGER_CONF_FILE_PATH, self.name)
        self.cifs_conf_path        = "%s/smb.conf"%(self.config_dir)

#        digi_debug(self.config_dir)
#        digi_debug(self.vol_file_path)
#        digi_debug(self.disk_file_path)

        init_dir(self.config_dir)

    def init_from_file(self):
        mserver_file_line = get_config_file(self.mserver_file_path).readline()
        if len(mserver_file_line) > 0:
            self.mserver_port = int(mserver_file_line.split('\n')[0])
        else:
            digi_debug("Node manager, Service %s mserver file content is None" % self.name, 2)

        version_file_line = get_config_file(self.version_file_path).readline()
        if len(version_file_line) > 0:
            self.version = int(version_file_line.split('\n')[0])
        else:
            digi_debug("Node manager, Service %s version file content is None" % self.name, 2)

        disks_img = get_config_file(self.disk_file_path)
        if disks_img.len < 1:
            digi_debug("Node manager, Service %s disk file content is None" % self.name, 2)
            return
        disk_list = simplejson.loads(disks_img.readline())
        for disk_name in disk_list:
            adisk = self.node_manager.get_disk_by_name(disk_name)
            if not adisk:
                digi_debug("Node manager, Service %s init error: disk not exist" % (self.name), 3)
                continue
            self.disks.append(adisk)

    def init_client_conf_file(self):
        client_conf_img = StringIO.StringIO(unicode("127.0.0.1:%d\n"%(self.mserver_port)))
        set_config_file(self.client_conf_file_path, client_conf_img)

    def __init__(self, node_manager, service_name=""):
        self.node_manager = node_manager
        self.name         = service_name
        self.mserver_port = int()
        self.version      = int()

        self.config_dir   = ""
        self.mount_dir    = ""

        self.vol_file_path         = ""
        self.log_file_path         = ""
        self.pid_file_path         = ""
        self.afr_info_file_path    = ""
        self.disk_file_path        = ""
        self.mserver_file_path     = ""
        self.version_file_path     = ""
        self.extend_file_path      = ""
        self.client_conf_file_path = ""
        self.cifs_conf_path        = ""

        self.pid          = ""
        self.disks        = []

        if service_name:
            self.init_file_path()
            #self.init_from_file()
            #if not os.path.isfile(self.client_conf_file_path):
            #    self.init_client_conf_file()

    def get_name(self):
        return self.name

    def set_vol_file(self, vol_file_content):
        vol_file_img = StringIO.StringIO(vol_file_content)
        set_config_file(self.vol_file_path, vol_file_img)

    def get_mserver_port(self):
        return self.mserver_port

    def set_mserver_port(self, mserver_port):
        self.mserver_port = mserver_port
        mserver_file_img = StringIO.StringIO(self.mserver_port)
        set_config_file(self.mserver_file_path, mserver_file_img)
        self.init_client_conf_file()

    def get_version(self):
        return self.version

    def set_version(self, version):
        self.version = version
        version_file_img = StringIO.StringIO(version)
        set_config_file(self.version_file_path, version_file_img)

    def validate_version(self, version):
        return self.version == version

    def set_extend_file(self, extend_file_img):
        extend_file_img_s = StringIO.StringIO(extend_file_img)
        set_config_file(self.extend_file_path, extend_file_img_s)

    def clean_extend_file(self):
        if os.path.isfile(self.extend_file_path):
            os.remove(self.extend_file_path)

    def get_disks(self):
        return self.disks

    def get_disk_by_name(self, disk_name):
        return find_in_list(self.disks, disk_name)

    def get_pid(self):
        return self.pid

    def get_space_used(self):
        """
            return code:
            ("0",{total_size}{used_size}):    service status normal, return used space size
            ("1","",""):               service is not available
        """
        totol_size = long()
        free_size = long()
        try:
            fs_stat = os.statvfs("%s"%(self.mount_dir))
        except OSError,e:
            digi_debug("Node manager, Service %s is no longer available"%(self.name), 3)
            return ("1","","")
        totol_size = long(fs_stat.f_bsize) * long(fs_stat.f_blocks)
        free_size = long(fs_stat.f_bsize) * long(fs_stat.f_bfree)
        return ("0", str(totol_size/1024), str((totol_size - free_size)/1024))

    def add_disk(self, adisk):
        disk_list = []
        self.disks.append(adisk)
        for adisk in self.disks:
            disk_list.append(adisk.get_dev_id())
        disk_names = simplejson.dumps(disk_list)
        disks_img = StringIO.StringIO(disk_names)
        set_config_file(self.disk_file_path, disks_img)

    def remove_disk(self, adisk):
        disk_list = []
        self.disks.remove(adisk)
        for adisk in self.disks:
            disk_list.append(adisk.get_dev_id())
        disk_names = simplejson.dumps(disk_list)
        disks_img = StringIO.StringIO(disk_names)
        set_config_file(self.disk_file_path, disks_img)

    def start(self, version):
        """
            0:    start success
            1:    start failed
            2:    already started
            3:    version does not match
        """
        if self.version != version:
            return 3

#add disks that need to start to sync_list

        sync_disk = '' 
        for adisk in self.disks:
            try:
                tdisk_id = adisk.get_dev_id()
                tdisk_node = adisk.get_node()
                tdisk_port = adisk.get_port()
                tdisk = [tdisk_node, tdisk_port]
                mirror_dict = vol_afr_mirror(self.vol_file_path)
                ret = adisk.status()
                if not ret:
                    for mirror_name, disk_list in mirror_dict.iteritems():
                        if tdisk in disk_list:
                            sync_disk = tdisk_id
                else:
                    adisk.start()
            except Exception, e:
                digi_debug("Node manager, Service start got exception: %s" % traceback.print_exc(), 3)

        if self.status():
        #check disk for sync
            try:
                if sync_disk:
                    os.system("%s %s %s %s &" % (settings.SYNC_SCRIPT, sync_disk, export_dir_prefix, self.mount_dir))
                else:
                    digi_debug("Node manager, Service start found disk for sync not found!", 3)
                    #return 1
            except Exception,e:
                digi_debug("Node manager, Service start got exception: %s" % traceback.print_exc(), 3)
            return 2

        ret = 0
        while ret == 0:
            cmd = []
            cmd.append("/bin/umount")
            cmd.append("-lf")
            cmd.append(self.mount_dir)
            ret = execute(cmd, err_ignore=True)
        init_dir(self.mount_dir,True,0444)
        cmd = []
        cmd.append("/usr/sbin/digioceanfs")
        cmd.append("-f%s"%(self.vol_file_path))
        cmd.append("-l%s"%(self.log_file_path))
        cmd.append("-p%s"%(self.pid_file_path))
        cmd.append("-i%s"%(self.afr_info_file_path))
        ret = execute(cmd)
#        proc = subprocess.Popen(["/usr/sbin/digioceanfs",
#                                 "-f%s"%(self.vol_file_path),
#                                 "-l%s"%(self.log_file_path),
#                                 "-p%s"%(self.pid_file_path)],
#                                close_fds=True)
#        ret = proc.wait()

#check disk for sync
        try:
            if sync_disk:
                os.system("%s %s %s %s &" % (settings.SYNC_SCRIPT, sync_disk, export_dir_prefix, self.mount_dir))
            else:
                digi_debug("Node manager, Service start found disk for sync not found!", 3)
        except Exception,e:
            digi_debug("Node manager, Service start got exception: %s" % traceback.print_exc(), 3)
        return ret

    def stop(self):
        """
            return code:
            1:stop service success
            2:stop service failed
            3:the service already been stoped
        """
        if not self.status():
            digi_debug("Node manager, Service stop found %s already stop" % self.name, 3)
            return 3
        cmd = []
        cmd.append("/bin/kill")
        cmd.append(self.pid)
        ret = execute(cmd, err_ignore=True)
#        proc = subprocess.Popen(["/bin/kill",
#                                 "%s"%(self.pid)],
#                                close_fds=True)
#        ret = proc.wait()

        if ret == 1:
            return 2

        ret = 0
        while ret == 0:
            cmd = []
            cmd.append("/bin/umount")
            cmd.append("-lf")
            cmd.append(self.mount_dir)
            ret = execute(cmd, err_ignore=True)

        for adisk in self.disks:
            ret = adisk.stop()
            digi_debug("Node manager, Service %s, stop disk: %s, return: %d"%(self.name, adisk.get_dev_id(), ret), 7)

        return 1

    def remove_nfs_config(self):
        #handle = open("/etc/exports","r")
        handle = open(settings.NFSCONF,"r")
        list = handle.readlines()
        for line in list:
            line = line.strip()
            if line:
                tmp = line.split()
                if tmp[0] == self.mount_dir:
                    list.remove(line)
                    break
            
        str=''.join(list)    
        handle.close()
        #handle = open("/etc/exports","w")
        handle = open(settings.NFSCONF,"w")
        handle.write(str)
        handle.close()
        return 1

    def destroy(self):
        """
            1:destroy service success
            2:destroy service failed, service can not be stoped
        """
        #ret = 0
        #while ret == 0:
        #    cmd = []
        #    cmd.append("/bin/umount")
        #    cmd.append("-lf")
        #    cmd.append(self.mount_dir)
        #    ret = execute(cmd, err_ignore=True)
#            proc = subprocess.Popen(["/bin/umount",
#                                     "%s"%(self.mount_dir)],
#                                    close_fds=True)
#            ret = proc.wait()
#            digi_debug("umount %s return %d"%(self.mount_dir, ret))
        #while self.check_proc():
        #    cmd = []
        #    cmd.append("kill")
        #    cmd.append("-9")
        #    cmd.append("%s"%(self.pid))
        #    execute(cmd, err_ignore=True)
        #if self.status():
        #    if not self.stop() == 1:
        #        return 2
        
        if os.path.isfile(self.cifs_conf_path):
            smb_user_list = get_smb_user_info(self.name)
            #digi_debug(smb_user_list)
            if smb_user_list:
                for user in smb_user_list:
                    del_user_force(self.name, user)        
        
        cmd = []
        cmd.append("/bin/rm")
        cmd.append("-rf")
        cmd.append(self.config_dir)
        cmd.append(self.mount_dir)
        ret = execute(cmd, err_ignore=True)
#        proc = subprocess.Popen(["/bin/rm",
#                                 "-rf",
#                                 "%s"%(self.config_dir),
#                                 "%s"%(self.mount_dir)],
#                                close_fds=True)
#        ret = proc.wait()
        samba_del_service(self.cifs_conf_path)
        self.remove_nfs_config()
        digi_debug("Node manager, Service destroy %s, remove dirs return:%d"%(self.name, ret), 7)
        del_from_fstab(self.name)
        return 1

    def check_proc(self):
        cmd = []
        cmd.append("/bin/ps -Cdigioceanfs -f --no-heading | grep %s"
                   % self.name)
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, std=tmp_img, shell=True)
        tmp_img.seek(0)
        proc_line = tmp_img.readlines()
        if len(proc_line) < 1:
            return 0
        self.pid = proc_line[0].split()[1]
        return 1

    def status_proc(self):
        """
            return:
            0:    stop
            1:    running
        """
        #check whether the proc is running while pid file does not exist while return 0
        if not os.path.exists(self.pid_file_path):
            return self.check_proc()

        pid_img = get_config_file(self.pid_file_path)
        pid_line = pid_img.readline()
        if len(pid_line) < 2:
            os.remove(self.pid_file_path)
            return self.check_proc()

        self.pid = pid_line.split('\n')[0]
        cmd = []
        cmd.append("/bin/ps")
        cmd.append("-p%s"%(self.pid))
        ret = execute(cmd)
        if ret == 0:
            return 1
        os.remove(self.pid_file_path)
        return self.check_proc()

    def status_disks(self):
        """
            return:
            False:    not all start
            True:     all start
        """
        for adisk in self.disks:
            if adisk.status() != 0:
                return False
        return True

    def status(self):
        """
            return:
            0:    stop
            1:    running
            2:    not all disk started
        """
        if self.status_proc() == 0:
            digi_debug("Node manager, Service check status stop", 3)
            return 0
        if self.status_disks():
            digi_debug("Node manager, Service check status running", 3)
            return 1
        return 2

    def extend(self, extend_file_img, version):
        """
            return code specify:
            0:    extend success
            1:    extend failed(extend volfile phrase error, need not to del_storage)
            2:    extend failed(extend time out, need to del_storage)
            3:    extend success(do not need to online)
        """
        if self.status() == 0:
#            self.set_version(version)
#            self.set_vol_file(vol_file_img)
            digi_debug("Node manager, Service extend success, but no need to online", 3)
            return 3

        if version - self.version != 1:
            self.stop()
#            self.set_version(version)
#            self.set_vol_file(vol_file_img)
#            self.start()
            digi_debug("Node manager, Service extend success, but no need to online", 3)
            return 3

        self.set_extend_file(extend_file_img)

        ret = del_storage(self.client_conf_file_path)
        digi_debug("Node manager, Service del_storage ahead return:%s"%(ret), 7)

        ret = add_storage(self.extend_file_path, self.client_conf_file_path)
        digi_debug("Node manager, Service add_storage return:%s"%(ret), 7)

        if ret == "1":
#            ret = storage_online(self.client_conf_file_path)
#            digi_debug("on_line return:%d"%(ret))
#            self.set_version(version)
#            self.set_vol_file(vol_file_img)
#            self.clean_extend_file()
            ret = 0
        elif ret == "-1":
#            ret = del_storage()
#            digi_debug("del_storage after return:%s"%(ret))
            ret = 1
        elif ret == "-2":
#            ret = del_storage()
#            digi_debug("del_storage after return:%s"%(ret))
            ret = 2
#        ret = del_storage()
        else:
            ret = 2
        return ret

    def undo_extend():
        ret == "1"
        if self.status() != 0:
            ret = del_storage(self.client_conf_file_path)
            digi_debug("Node manager, Service del_storage after return:%s"%(ret), 7)
        return ret == "1"

    def online_extend(self, version, vol_file_img):
        if self.status() != 0:
            ret = storage_online(self.client_conf_file_path)
            digi_debug("Node manager, Service online_storage after return:%s"%(ret), 7)
        self.set_version(version)
        self.set_vol_file(vol_file_img)
        self.clean_extend_file()
        return True

    def restart(self):
        for adisk in self.disks:
            if not adisk.restart():
                digi_debug("Node manager, service restart disk:%s failed"%(adisk.get_dev_id()),3)

    def cifs_start(self):
        if os.path.isfile(self.cifs_conf_path):
            cifs_file = open(self.cifs_conf_path, 'r')
            cifs_file_content = cifs_file.readlines()
            cifs_file.close()
        else:
            get_config_file(self.cifs_conf_path)
            cifs_file = open(self.cifs_conf_path, 'r')
            cifs_file_content = cifs_file.readlines()
            cifs_file.close()
        if len(cifs_file_content) >= 1:
            old_samba_conf_img = get_config_file(self.cifs_conf_path)
        else:
            old_samba_conf_img = None
        
        if not old_samba_conf_img:
            samba_conf_img = samba_gen_config_file(mount_dir_prefix, self.get_name())
        else:
            samba_conf_img = old_samba_conf_img
        set_config_file(self.cifs_conf_path, samba_conf_img)
        if not samba_add_service(self.cifs_conf_path):
            return False
        samba_start()
        return True

    def cifs_stop(self):
        """
            1:cifs stop success
            2:cifs stop failed
            3:cifs in use
        """
        if self.cifs_status() == 2:
            digi_debug("Node manager, Service stop cifs found cifs in use", 3)
            return 3
        if samba_del_service(self.cifs_conf_path):
            return 1
        digi_debug("Node manager, Service stop cifs found cifs in use", 3)
        return 2

    def cifs_status(self):
        """
            return code specify:
            1:    ok
            2:    used by link
            3:    service not start
            4:    process not exist
        """
        if self.status() == 0:
            digi_debug("Node manager, Service check cifs status found service not start", 3)
            return 3
        
        if not samba_check_service(self.cifs_conf_path):
            digi_debug("Node manager, Service check cifs status found service samba configure file not added in system samba configure file", 3)
            return 3
        
        if samba_status_service(self.name):
            digi_debug("Node manager, Service check cifs status found cifs use by link", 3)
            return 2
        
        if not samba_status_process():
            return 4
        return 1
    
    def cifs_restart_service(self):
        if not samba_check_service(self.cifs_conf_path):
            digi_debug("Node manager, Service check cifs status found service samba configure file not added in system samba configure file", 3)
            samba_add_include(self.cifs_conf_path)
        else:
            samba_del_include(self.cifs_conf_path)
            samba_add_include(self.cifs_conf_path)
        digi_debug("Node manager, Service cifs restart success", 6)
        #if not samba_status_process():
        #    digi_debug("smb process not exist")
        #    samba_start()
        return True
    
    def cifs_restart_node(self):
        samba_force_stop()
        samba_start()
        return True
    
    def cifs_add_user(self,user_name, passwd, uid):
        if not samba_check_service(self.cifs_conf_path):
            digi_debug("Node manager, Service check cifs status found service samba configure file not added in system samba configure file", 3)
            return 3
        if not add_user(user_name, passwd, uid):
            digi_debug("Node manager, Service cifs add user to system %s failed" % (user_name), 3)
            return 2
        else:
            if not add_user2smbconf(self.name, user_name):
                digi_debug("Node manager, Service cifs add user %s to smb conf failed" % user_name, 3)
                return 4
            else:
                digi_debug("Node manager, Service cifs add user success", 6)
                return 1

    def cifs_add_user_rollback(self, user_name):
        if not samba_check_service(self.cifs_conf_path):
            digi_debug("Node manager, Service check cifs status found service samba configure file not added in system samba configure file", 3)
            return 3
        #del user from smb config file
        ret = del_userfromsmbconf(self.name, user_name)
        digi_debug("Node manager, Service cifs add user rollback: del user from smb config file return %s" % (ret), 5)
        #del user from system
        del_user(self.name, user_name)
        digi_debug("Node manager, Service cifs add user rollback: del user from system return %s" % (ret), 5)
        return 1

    def cifs_del_user(self, user_name):
        if not samba_check_service(self.cifs_conf_path):
            digi_debug("Node manager, Service check cifs status found service samba configure file not added in system samba configure file", 3)
            return 3
        if not check_user_links(user_name):
            digi_debug("Node manager, Service del cifs user found %s is busy, can not be remove" % (user_name), 3)
            return 4
        else:
            if not del_userfromsmbconf(self.name, user_name):
                digi_debug("Node manager, Service del cifs user %s not found, can not be remove" %(user_name), 3)
                return 2
            else:
                ret = del_user(self.name, user_name)
                if ret == 1 or ret == 4:
                    digi_debug("Node manager, Service cifs del user %s from %s system" % (user_name, self.name), 7)
                    return 1
                else:
                    digi_debug("Node manager, Serivce cifs del user %s from %s system" % (user_name, self.name), 7)
                    return 2
                    
    
    def cifs_del_user_rollback(self, user_name):
        if not samba_check_service(self.cifs_conf_path):
            digi_debug("Node manager, Service check cifs status found service samba configure file not added in system samba configure file", 3)
            return 3
        #del user from system
        ret = add_user(user_name)
        digi_debug("Node manager, Service cifs del user rollback: add user to system without password return %s" % (ret), 5)
        #del user from smb config file
        ret = add_user2smbconf(self.name, user_name)
        digi_debug("Node manager, Service cifs del user rollback: add user to smb config file return %s" % (ret), 5)
        return 1    

    def nfs_start(self):
        return nfs_add_service(self.mount_dir)

    def nfs_stop(self):
        service_nfs_status = nfs_status_service(self.mount_dir)
        digi_debug("Node manager, Service stop nfs with status:%d"%(service_nfs_status), 7)
        if service_nfs_status == 1:
            return nfs_del_service(self.mount_dir)
        elif service_nfs_status == 2:
            return False
        return True

    def nfs_add_user(self, service_name, user_ip):
        service_nfs_status = nfs_status_service(self.mount_dir)
        digi_debug("Node manager, Service add user get nfs with status:%d"%(service_nfs_status), 7)
        if service_nfs_status == 3:
            return 4
        ret = nfs_config_add_user(service_name, user_ip)
        return ret
        
    def nfs_add_user_rollback(self, service_name, user_ip):
        ret = nfs_config_del_user(service_name, user_ip)
        digi_debug("Node manager, Service nfs add user rollback return:%s" % ret, 5)
        return ret
    
    def nfs_del_user(self, service_name, user_ip):
        service_nfs_status = nfs_status_service(self.mount_dir)
        digi_debug("Node manager, Service del get nfs with status:%d"%(service_nfs_status), 7)
        if service_nfs_status == 3:
            return 3
        ret = nfs_config_del_user(service_name, user_ip)
        return ret

    def nfs_del_user_rollback(self, service_name, user_ip):
        ret = nfs_config_add_user(service_name, user_ip)
        digi_debug("Node manager, Service nfs del user rollback return:%s" % ret, 5)
        return ret

    def nfs_list_user(self, service_name):
        return nfs_config_list_user(service_name)

    def afr_info_execute_cmd(self, path = ''):
        execute('ls -alR %s &' % (self.mount_dir), shell=True)
        if not path:
            roor_dir = self.mount_dir
        #th = threading.Thread(target=execute, name='writemem', args=('python /usr/share/digioceanfs_manager/utils/access.py',None,True,False,))
        th = threading.Thread(target=execute, name='writemem', args=('get_asi -m %s %s -s %s %s -f %s' % (SHM_KEY_0, SHM_KEY_1, SP_KEY_0, SP_KEY_1, self.asi_conf_file_path,),None,True,False,))
        th.start()
        #th.join()
        #ret = execute('python ../utils/access.py',shell=True)
        #ret = execute('/usr/bin/get_asi -m 6901028037910 6901028037920',shell=True)
        #if ret != 0:
        #    print 'error2'

    def afr_info(self, opendir, disks_dict):
        my_root = {}
        data = []
        thd = None
        for th in threading.enumerate():
            if th.getName() == 'writemem':
                thd = th
        data = getData(SHM_KEY_0, thd)
        digi_debug("Node manager, Service get afr info get shm data %s" % (data[:-1]), 7)
        if data[:-1]:
            digi_debug("Node manager, Service get afr info get disks_dict is %s" % (disks_dict), 7)
            my_root = lstree(self.mount_dir, self.mount_dir, data, disks_dict, unquote_list(opendir), 0)
        else:
            digi_debug("Node manager, Service get afr info get disks_dict is %s" % (disks_dict), 7)
            my_root = lstree(self.mount_dir, self.mount_dir, data, disks_dict, opendir, 0)
            my_root['data'] = False
        my_root_str = getTreeStr(my_root) + '\n'
        if not my_root_str:
            digi_debug("Node manager, Service get afr info raise error", 3)
            return None
        return my_root_str

    def afr_info_topage(self):
        my_root = afr_info_tree_topage('../utils/test.txt')
        #my_root = lstree(6901028037920, '/root/myget-0.1.2')
        #digi_debug(my_root)
        if not my_root:
            digi_debug("Node manager, Service get afr info to pages raise error", 3)
            return None
        return my_root

    def afr_info_topage_search(self, opendir, disks_dict):
        my_root = {}
        data = []
        thd = None
        for th in threading.enumerate():
            if th.getName() == 'writemem':
                thd = th
        data = getData(SHM_KEY_0, thd)
        digi_debug("Node manager, get shm data %s" % (data[:-1]),5)
        if data[:-1]:
            digi_debug("Node manager, Service get afr info get disks_dict is %s" % (disks_dict), 7)
            my_root = lstree(self.mount_dir, self.mount_dir, data, disks_dict, unquote_list(opendir), 0)
        else:
            digi_debug("Node manager, Service get afr info get disks_dict is %s" % (disks_dict), 7)
            my_root = lstree(self.mount_dir, self.mount_dir, data, disks_dict, unquote_list(opendir), 0)
            my_root['data'] = False
        #digi_debug(my_root)
        if not my_root:
            return None
        return my_root

    def afr_diff(self):
        """
            return code specify:
            [
              ["disk_id", "used_space",],
              ["disk_id", "used_space",],
              ["disk_id", "used_space",],
            ]
        """
        disk_list = []
        for adisk in self.disks:
            disk_list.append([adisk.get_dev_id(), adisk.get_used_size()])

        return disk_list

    def afr_syn(self, disk_dev, syn_mode, passive_addr):
        """
            return code specify:
            1:    afr syn success
            2:    afr syn start already
            3:    afr syn do thread start already
            4:    disk not found
        """
        adisk = self.get_disk_by_name(disk_dev)
        if not adisk:
            return 4

        ret = adisk.afr_syn(self.mount_dir, syn_mode, passive_addr)

        return ret
#        for adisk in self.disks:
#            ret = adisk.afr_syn(self.mount_dir)
#            digi_debug("disk:%s syn status:%d"%(adisk.get_dev_id(), ret))
#        return 1

    def afr_expand(self, vol_file_img):
        self.stop()
        self.set_vol_file(vol_file_img)
        return True

    def afr_shrink(self, vol_file_img):
        self.stop()
        self.set_vol_file(vol_file_img)
        return True

    def nfs_status(self):
        if self.status() == 0:
            return 3
        return nfs_status_service(self.mount_dir)

    def replace(self, volumes):
        for avolume in volumes:
            cmd = []
            cmd.append("/usr/bin/digi_replace")
            cmd.append("-n")
            cmd.append(avolume)
            cmd.append("-f")
            cmd.append(self.client_conf_file_path)
            ret = execute(cmd)
            digi_debug("Node manager, replace for volume:%s, return:%d"%(avolume, ret),5)

    def __str__(self):
        return self.name

    def __eq__ (self, other):
        return self.name.__eq__(other.__str__())



class node_manager():
    """manage all operations on an node"""
    #build sharedmemory
    def build_sharedmemory(self):
        try:
            shm_0 = SharedMemory(SHM_KEY_0, 0, 0600, MSIZE)
            digi_debug('Node manager, removing sharedmemory 0', 7)
            shm_0.remove()
            shm_0 = SharedMemory(SHM_KEY_0, IPC_CREAT, 0600, MSIZE)
        except:
            shm_0 = SharedMemory(SHM_KEY_0, IPC_CREAT, 0600, MSIZE)
            digi_debug('Node manager, building sharedmemory 0', 7)
        try:
            shm_1 = SharedMemory(SHM_KEY_1, 0, 0600, MSIZE)
            digi_debug('Node manager, removing sharedmemory 1', 7)
            shm_1.remove()
            shm_1 = SharedMemory(SHM_KEY_1, IPC_CREAT, 0600, MSIZE)
        except:
            shm_1 = SharedMemory(SHM_KEY_1, IPC_CREAT, 0600, MSIZE)
            digi_debug('Node manager, building sharedmemory 1', 7)

    def build_semaphore(self):
        try:
            sp_0 = Semaphore(SP_KEY_0, 0, 0600)
            digi_debug('Node manager, removing semaphore 0', 7)
            sp_0.remove()
            sp_0 = Semaphore(SP_KEY_0, IPC_CREAT, 0600, 0)
        except:
            sp_0 = Semaphore(SP_KEY_0, IPC_CREAT, 0600, 0)
            digi_debug('Node manager, building semaphore 0', 7)
        try:
            sp_1 = Semaphore(SP_KEY_1, 0, 0600)
            digi_debug('Node manager, removing semaphore 1', 7)
            sp_1.remove()
            sp_1 = Semaphore(SP_KEY_1, IPC_CREAT, 0600, 0)
        except:
            sp_1 = Semaphore(SP_KEY_1, IPC_CREAT, 0600, 0)
            digi_debug('Node manager, building semaphore 1', 7)
        try:
            sp_plug = Semaphore(SP_KEY_PLUG, 0, 0600)
            digi_debug('Node manager, removing semaphore for disk plug', 7)
            sp_plug.remove()
            sp_plug = Semaphore(SP_KEY_PLUG, IPC_CREAT, 0600, 0)
        except:
            sp_plug = Semaphore(SP_KEY_PLUG, IPC_CREAT, 0600, 0)
            digi_debug('Node manager, building semaphore for disk plug', 7)

    def add_all_disks(self):
        """this function should be called when the manager is initialed"""
        disk_name_list = get_system_disks()

        for disk_name in disk_name_list:

            adisk = disk(disk_name[0])
            adisk.set_dev(disk_name[1])
            ret = adisk.init_disk()
            print ret, 'disk init: ', adisk.dev
            if ret == 66:
                digi_debug("Node manager, Disk id %s check size file path raise error" % adisk.__str__(), 3)
                exit()
            elif ret == 67:
                digi_debug("Node manager, init disk %s, add it to no disk list" % adisk.__str__(), 5)
                self.no_disk.append(adisk)
                continue
            elif ret == 68:
                digi_debug("Node manager, init disk %s, add it to no port list" % adisk.__str__(), 5)
                self.no_port.append(adisk)
                continue
            elif ret == 69:
                digi_debug("Node manager, init disk %s, add it to no user list" % adisk.__str__(), 5)
                self.no_user.append(adisk)
                pass
            elif ret == 70:
                self.no_start.append(adisk)
                digi_debug("Node manager, init disk %s, add it to no start list" % adisk.__str__(), 5)
                pass
            elif ret == 71:
                digi_debug("**DEBUG: Node manager, init disk %s, add it to no user list, cluster spare disk" % adisk.__str__(), 5)
                self.no_user.append(adisk)
                pass
            elif ret == 72:
                digi_debug("Node manager, /sys/block/%s/size was empty or value<=0" % adisk.__str__(), 3)
                exit()
            elif ret == 0:
                self.started.append(adisk)
                digi_debug("Node manager, init disk %s, add it to started list" % adisk.__str__(), 5)
                pass
            else:
                digi_debug("Node manager, init disk %s error" % adisk.__str__(), 3)
                exit()
            
            if int(adisk.get_port()) >= self.max_port:
                self.max_port = int(adisk.get_port()) + 1


        init_dir(config_dir_prefix)
        config_disks = dircache.listdir(config_dir_prefix)
        digi_debug("Node manager, configed disks:%s"%(config_disks),5)

        for disk_name in config_disks:
            if not self.get_disk_by_name(disk_name):
                adisk = disk(disk_name)
                adisk.init_disk()
                self.no_disk.append(adisk)
                digi_debug("Node manager, Node manager add no disk %s" % disk_name, 5)

        digi_debug("Node manager, init disk no disk: %s" % self.no_disk, 7)
        digi_debug("Node manager, init disk no port: %s" % self.no_port, 7)
        digi_debug("Node manager, init disk no user: %s" % self.no_user, 7)
        digi_debug("Node manager, init disk no start: %s" % self.no_start, 7)
        digi_debug("Node manager, init disk no started: %s" % self.started, 7)

        digi_debug("Node manager, max port is:%d"%(self.max_port),5)

    def remove_no_disk(self):
        tmp_list = []
        for adisk in self.no_disk:
            if not adisk.get_user():
                adisk.destroy()
                tmp_list.append(adisk)

        for adisk in tmp_list:
            self.no_disk.remove(adisk)
            digi_debug("Node manager, remove no disk %s" % adisk.__str__(), 5)

    def init_no_port(self):
        tmp_list = []
        for adisk in self.no_port:
            digi_debug("Node manager, set port %d to %s"%(self.max_port, adisk.get_dev_id()), 7)
            if adisk.set_port(self.max_port) == 0:
#                adisk.partition()
                self.max_port = self.max_port +1
                tmp_list.append(adisk)
            else:
                digi_debug("Node manager, set port to %s failed!!" % (adisk.get_dev_id()), 3)
                adisk.set_port("")

        for adisk in tmp_list:
            self.no_port.remove(adisk)
            self.no_user.append(adisk)

    def init_no_start(self):
        tmp_list = []
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(self.no_start))
            node_thread_pool.initPool(data=self.no_start, target_info=('start', [], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #for adisk in self.no_start:
        for result in thread_result:
            obj = result[0]
            ret = result[1]
            if ret == 0:
                tmp_list.append(obj)

        for adisk in tmp_list:
            self.no_start.remove(adisk)
            self.started.append(adisk)

    def service_list_init(self):
        init_dir(service_dir_prefix)
        services_name = list_service_name_all()
        if len(services_name) > 0:
            for service_name in services_name:
                aservice = service(self, service_name)
                self.service_list.append(aservice)
        #kill all the procs while we start for the first time
        else:
            cmd = []
            cmd.append("/usr/bin/killall")
            cmd.append("digioceanfs")
            ret = execute(cmd, err_ignore=True)
#            proc = subprocess.Popen(["/usr/bin/killall",
#                                     "digioceanfs"])
#            ret = proc.wait()
            digi_debug("Node manager, kill all digioceanfs return: %d"%(ret),5)
            cmd = []
            cmd.append("/usr/bin/killall")
            cmd.append("digioceanfsd")
            ret = execute(cmd, err_ignore=True)
#            proc = subprocess.Popen(["/usr/bin/killall",
#                                     "digioceanfsd"])
#            ret = proc.wait()
            digi_debug("Node manager, kill all digioceanfsd return: %d"%(ret),5)
            init_dir(mount_dir_prefix)
            mount_dirs = dircache.listdir(mount_dir_prefix)
            for mount_dir in mount_dirs:
                ret = 0
                while ret == 0:
                    cmd = []
                    cmd.append("/bin/umount")
                    cmd.append("-lf")
                    cmd.append("%s/%s"%(mount_dir_prefix, mount_dir))
                    ret = execute(cmd, err_ignore=True)
                cmd = []
                cmd.append("/bin/rm")
                cmd.append("-rf")
                cmd.append("%s/%s"%(mount_dir_prefix, mount_dir))
                ret = execute(cmd, err_ignore=True)
#                proc = subprocess.Popen(["/bin/rm",
#                                         "-rf",
#                                         "%s/%s"%(mount_dir_prefix, mount_dir)])
#                ret = proc.wait()
                digi_debug("Node manager, rm dir %s/%s return: %d"%(mount_dir_prefix, mount_dir, ret),5)
        for aservice in self.service_list:
            digi_debug("Node manager, initied service: %s"%(aservice.get_name()),5)
            # mount started service
            service_status = list_service_status(aservice.get_name())
            if service_status == 'Started':
                if not os.path.ismount(aservice.mount_dir):
                    ret = self.service_mount(aservice.get_name())
                    if ret:
                        digi_debug('Node manager, Service list init : service %s mount failed' % aservice.get_name(), 3)
                
    def init_digioceand(self):
        #check digioceand restart or not
        if not check_digioceand():
            digi_debug("Node Manager, found digioceand not started, start it", 3)
            start_digioceand()

        for adisk in self.no_start:
            servicename = adisk.get_user()
            adisk.mount()
            if servicename:
                service_status = list_service_status(servicename)
                if service_status == 'Started':
                    for i in range(60):
                        disk_pid = adisk.get_pid()
                        if int(disk_pid):
                            digi_debug("Node Manager, found disk %s digioceanfsd started" % adisk.dev, 3)
                            self.no_start.remove(adisk)
                            self.started.append(adisk)
                            break
                        else:
                            digi_debug("Node Manager, found disk %s digioceanfsd not started, startd volume force"% adisk.dev, 3)
                            ret = os.system("digiocean vol start %s force" % servicename)
                            digi_debug("Node Manager, start volume %s force return %s" % (servicename, ret))
                            time.sleep(2)
                            continue

    def init_hostname(self):
        if os.path.exists(settings.PRIHOSTNAMEPATH):
            os.system("hostname -F %s" % settings.PRIHOSTNAMEPATH)
        else:
            os.system("touch %s" % settings.PRIHOSTNAMEPATH)
            
    def node_manager_command_lock(self):
        command = "msg_handler_lock"
        host_info_list = get_all_nodes()
        data = simplejson.dumps([])
        if self.message_handler_lock.acquire(False):
            send_command(host_info_list, command, data)
            digi_debug("Node Manager, MESSAGE HANDLER lock acquired")
        else:
            digi_debug("Node Manager, MESSAGE HANDLER lock acquire")
            self.message_handler_lock.acquire()
        
    def node_manager_command_unlock(self):
        command = "msg_handler_unlock"
        host_info_list = get_all_nodes()
        data = simplejson.dumps([])
        send_command(host_info_list, command, data)
        digi_debug("Node Manager, MESSAGE HANDLER lock released")
            
    def init_heal_disperse(self):
        time.sleep(10)
        
        command = 'service_get_command_status'
        host_info_list = get_all_nodes()
        service_name_list = list_service_name_all()
        partten = 'trusted.ec.heal'
        data = simplejson.dumps([service_name_list, partten])
        '''
        anode = send_command(host_info_list, command, data)
        if not anode:
            self.service_heal_disperse(data)
        else:
            send_command([(anode.get_name(),anode.ip_addr)], 'service_heal_disperse', data)
        '''
        self.service_heal_disperse(data)
            
    def auto_replace_disk(self, node_name, error_disk_name):
        host_info_list = get_all_nodes()
        for host_info in host_info_list:
            if node_name == host_info[0]:
                target_node_info = host_info
        
        all_service_disk = self.no_disk + self.no_start + self.started
        error_disk_id = None
        service_name = None
        print "all service disk: ",all_service_disk
        for d in all_service_disk:
            print d.dev_id, d.dev, '-------------------'
            if error_disk_name == d.dev:
                error_disk_id = d.dev_id
                service_name = d.get_user()
            elif error_disk_name and d.dev == 'no_disk':
                error_disk_id = d.dev_id
                service_name = d.get_user()
        print error_disk_id , service_name
        if error_disk_id and service_name:
            data = simplejson.dumps([node_name, service_name, error_disk_id])
            check_command('replace-brick')
            send_command([target_node_info], 'service_auto_replace_disk', data)
        else:
            digi_debug('Node Manager, no need auto replace',7)

    def service_info_clear(self):
        for aservice in self.service_list:
            if os.path.exists(aservice.mount_dir) and os.path.ismount(aservice.mount_dir):
                ret = self.service_umount(aservice.get_name())
                if ret:
                    digi_debug('Node manager, Service info clear : service %s umount failed' % aservice.get_name(), 3)
        return "1"
    
    def init_raid(self):
        self.init_pending_raid()
        cmd = []
        cmd.append("/usr/bin/digi_partition")
        cmd.append("--init-raid")
        tmp_img = tempfile.TemporaryFile()
        execute(cmd,tmp_img, err_ignore=True)
        os.system("mdadm -Ds > /etc/mdadm/mdadm.conf 2>/dev/null")

    def destroy_all(self):
        all_disk = self.no_disk + self.no_port + self.no_user + self.no_start + self.started
        for adisk in all_disk:
            adisk.destroy()

    def __init__(self):
        self.no_disk = [] #with return status 67
        self.no_port = [] #with return status 68
        self.no_user = [] #with return status 69
        self.no_start = [] #with return status 70
        self.started = [] #with return status 0

        self.service_list = []
        
        self.dynamic_info = ''
        self.static_inio = ''

        self.max_port = DISK_PORT_BASE

        self.net_lock = thread.allocate_lock()
        self.msg_lock = thread.allocate_lock()
        self.message_handler_lock = thread.allocate_lock()

        self.post_opts = { post_opt_type["none"]      :None,
                           post_opt_type["fake_ip_set"]    :self.nic_fake_ip_set_post,
                           post_opt_type["ip_set"]    :self.nic_ip_set_post,
                           post_opt_type["bond_set"]  :self.bond_set_post,
                           post_opt_type["bond_del"]  :self.bond_del_post}
        self.post_opt_code = post_opt_type["none"]
        self.post_opt_args = None
        
        self.healing_queue = Queue.Queue()   # 纠删码修复队列

        self.build_sharedmemory()
        self.build_semaphore()
        self.init_raid()
        self.add_all_disks()
        self.remove_no_disk()
        self.init_no_port()
        self.init_no_start()

        self.init_digioceand()
        self.service_list_init()
        self.init_hostname()
        #self.init_heal_disperse()  # 初始化纠删码修复队列

        #digi_debug(self.no_disk)
        #digi_debug(self.no_port)
        #digi_debug(self.no_user)
        #digi_debug(self.no_start)
        #digi_debug(self.started)
        digi_debug("Node manager, disks max port is:%d"%(self.max_port), 7)

        #TODO:check and start samba
        samba_status_process()
        #TODO:this is for add_storage and on_line, this is not right
        init_config_file(server_conf_file_path)
        init_dir(add_storage_log_file_path)

    def update_disk_replug_in(self, replug_in_list):
        for adisk in replug_in_list:
            adisk.start()
            self.no_disk.remove(adisk)
            digi_debug("Node manager, disk no disk list remove disk %s" % adisk.__str__(), 5)
            self.started.append(adisk)
            digi_debug("Node manager, disk started list add disk %s" % adisk.__str__(), 5)

    def update_disk_plug_in(self, plug_in_list):
        for disk_name in plug_in_list:
            adisk = disk(disk_name)
            ret = adisk.init_disk()
            self.no_port.append(adisk)
            digi_debug("Node manager, disk no port list add disk %s" % adisk.__str__(), 5)
        self.init_no_port()

    def update_disk_pop_out(self, pop_out_list):
        """
            1.for disk in no_disk: do nothing
            2.for disk in no_user: destroy it
            3.for disk in no_start: move to no_disk
            4.for disk in started: stop and move to no_disk
        """
        for disk_name in pop_out_list:
            try:
                index = self.no_disk.index(disk_name)
                continue
            except ValueError:
                digi_debug("Node manager, update_disk_pop_out cought exception", 3)
                pass
            try:
                index = self.no_user.index(disk_name)
                adisk = self.no_user.pop(index)
                adisk.destroy()
                continue
            except ValueError:
                digi_debug("Node manager, update_disk_pop_out cought exception", 3)
                pass
            try:
                index = self.no_start.index(disk_name)
                adisk = self.no_start.pop(index)
                digi_debug("Node manager, update disk no start remove disk %s" % adisk.__str__(), 5)
                self.no_disk.append(adisk)
                digi_debug("Node manager, update disk no disk add disk %s" % adisk.__str__(), 5)
            except ValueError:
                digi_debug("Node manager, update_disk_pop_out cought exception", 3)
                pass
            try:
                index = self.started.index(disk_name)
                adisk = self.started.pop(index)
                digi_debug("Node manager, update disk started remove disk %s" % adisk.__str__(), 5)
                adisk.stop()
                self.no_disk.append(adisk)
                digi_debug("Node manager, update disk no disk add disk %s" % adisk.__str__(), 5)
            except ValueError:
                digi_debug("Node manager, update_disk_pop_out cought exception", 3)
                pass

    def update_disk_status(self):
        try:
            digi_debug("Node manager, init disk no disk: %s" % '--'.join([i.dev for i in self.no_disk]), 7)
            digi_debug("Node manager, init disk no port: %s" % '--'.join([i.dev for i in self.no_port]), 7)
            digi_debug("Node manager, init disk no user: %s" % '--'.join([i.dev for i in self.no_user]), 7)
            digi_debug("Node manager, init disk no start: %s" % '--'.join([i.dev for i in self.no_start]), 7)
            digi_debug("Node manager, init disk started: %s" % '--'.join([i.dev for i in self.started]), 7)
        except Exception,e:
            digi_debug(e,7)

    def init_pending_raid(self):
        raiddev = ''
        flag = False
        f = open('/proc/mdstat','r')
        result = f.readlines()
        f.close()
        for i in range(len(result)):
	    m = re.search('(md\d+)\s+:\s+.*',result[i])
	    if m:
                raiddev = '/dev/' + m.group(1)
	        if "inactive" in result[i]:
		    os.system("mdadm -S %s" % raiddev)
            m = re.search('(md\d+)\s+:\s+.*raid\d+\s+.*',result[i])
            if m:
                raiddev = '/dev/' + m.group(1)
                if result[i].find('read-only') >= 0:
                    flag = True
                for line in result[i+1:]:
                    if re.search('(md\d+)\s+:\s+.*raid\d+\s+.*',line):
                        break
                    if flag or line.find("resync=PENDING") >= 0:
                        if os.path.exists(raiddev):
                            os.system("mdadm -w %s" % raiddev)
                            os.system("mdadm -S %s" % raiddev)
                        flag = False
                        break

    def check_and_init_raid(self, plug_in_list):
        array_info = {}
        for dev_id in plug_in_list:
            array_uuid = ''
            raid_devices = 0
            adisk = disk(dev_id)
            dev_path = '/dev/' + adisk.get_dev()
            if os.path.exists(dev_path):
                cmd = []
                cmd.append('mdadm')
                cmd.append('-E')
                cmd.append(dev_path)
                tmp_img = tempfile.TemporaryFile()
                ret = execute(cmd,tmp_img)
                if ret != 0:
                    continue
                result = tmp_img.readlines()
                for line in result:
                    m = re.search('Array UUID : (.*)',line)
                    if m:
                        array_uuid = m.group(1)
                    if line.find('Raid Devices') >= 0:
                        raid_devices = int(line.split(':')[1])
                if array_uuid not in array_info:
                    array_info[array_uuid] = (raid_devices,[])
                    array_info[array_uuid][1].append(dev_id)
                else:
                    array_info[array_uuid][1].append(dev_id)
        for uuid in array_info:
            if array_info[uuid][0] == len(array_info[uuid][1]):
                self.init_raid()
                break

    def update_disks(self):
        """find all hard disks in system, and update their status"""
        #first find the disk replug in, add them to no_start
        #(because disk of this status must be used by some service)
        #collect_result("[Processing]: Update disk ...")
        disk_name_list = []
        disk_replug_in = []
        disk_plug_in   = []
        disk_pop_out   = []

        #collect_result("[Processing]: Finding system disk ...")
        #time.sleep(1)

        disk_name_list = get_system_disks()
        #self.add_all_disks()
        for disk_name in disk_name_list:
            if disk_name[1].find('md') >= 0:
                adisk = self.get_disk_by_name(disk_name[0])
                if not adisk:
                    adisk = disk(disk_name[0])
                    adisk.set_dev(disk_name[1])
                    adisk.init_disk()
                #digi_debug(adisk)
                (adisk.raid_level, adisk.raid_status, adisk.raid_sub_disks) = get_raid_disks(adisk.get_dev())
                digi_debug("Node manager, update disk info in raid %s "% disk_name[1], 7)#adisk.get_raid_sub_disk())
            #else:
            adisk = self.get_no_disk_disk_by_name(disk_name[0])
            if adisk:
                disk_replug_in.append(adisk)
            
        digi_debug("Node manager, disk replug in:%s"%(disk_replug_in), 7)
        self.update_disk_replug_in(disk_replug_in)

        #time.sleep(1)

        #start disks that should be started(in list 'no_start' and started)
        disk_list = []
        for adisk in self.started:
            if adisk.status() != 0:
                disk_list.append(adisk)
        digi_debug("Node manager, disk to start:%s"%(disk_list), 7)
        for adisk in disk_list:
            self.started.remove(adisk)
            digi_debug("Node manager, update disk started remove disk %s" % adisk.__str__(), 5)
            self.no_start.append(adisk)
            digi_debug("Node manager, update disk no disk add disk %s" % adisk.__str__(), 5)
        self.init_no_start()
        
        # update no user disk
        for adisk in self.no_user:
            adisk.check_spare()

        all_disk = self.no_disk + self.no_port + self.no_user + self.no_start + self.started
        for disk_name in disk_name_list:
            try:
                all_disk.index(disk_name[0])
                continue
            except ValueError:
                pass
            disk_plug_in.append(disk_name[0])

        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(all_disk))
            node_thread_pool.initPool(data=all_disk, target_info=('get_position', [get_position_by_dev()], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            digi_debug("Node manager, multi threading caught exception: %d" % e, 3)
        else:
            pass
        finally:
            pass

        for adisk in all_disk:
            for disk_name in disk_name_list:
                if adisk.__eq__(disk_name[0]):
                    break
            else:
                disk_pop_out.append(adisk)

        #time.sleep(1)

        digi_debug("Node manager, disk plug in:%s"%(disk_plug_in), 7)
        digi_debug("Node manager, disk pop out:%s"%(disk_pop_out), 7)
        #collect_result("[Processing]: Finding plug in disk ...")
        self.update_disk_plug_in(disk_plug_in)
        #collect_result("[Processing]: Finding plug out disk ...")
        self.update_disk_pop_out(disk_pop_out)
        digi_debug("Node manager, update disk", 7)
        self.update_disk_status()
        if disk_plug_in:
            self.check_and_init_raid(disk_plug_in)
        return "0"
    
    def get_dynamic_info(self):
        try:
            digi_debug(time.time())
            xml_str = self.dynamic_info
            xml_dom = minidom.parseString(xml_str)
            all_disk = self.started + self.no_disk + self.no_start + self.no_user + self.no_port
            for adisk in all_disk:
                disk_name = adisk.dev
                service_name = adisk.get_user()
                position = adisk.get_position()
                latency = commands.getoutput('iostat -dx %s|grep %s' % (disk_name,disk_name)).split()[10]
                #print latency
                dom = xml_dom.getElementsByTagName(disk_name)
                if dom and service_name:
                    dom[0].setAttribute('SERVICE', service_name)
                if dom and position:
                    dom[0].setAttribute('POSITION', position)
                if dom and latency:
                    dom[0].setAttribute('LATENCY', latency)
                    
            all_nic = simplejson.loads(getNICinfo())
            for nic in all_nic:
                nic_name = nic[1]
                nic_mac = nic[3]
                nic_ip = nic[4]
                speed = commands.getoutput('ethtool %s |grep Speed' % nic_name).strip().split(": ")[1].replace('Mb/s','')
                net_dom = xml_dom.getElementsByTagName('NET')[0]
                dev_dom = net_dom.getElementsByTagName(nic_name)
                if dev_dom and nic_mac:
                    dev_dom[0].setAttribute('MAC', nic_mac)
                if dev_dom and nic_ip:
                    dev_dom[0].setAttribute('IP', nic_ip)
                if dev_dom and speed:
                    dev_dom[0].setAttribute('SPEED', speed)
                                
            self.dynamic_info = xml_dom.toxml()
        except Exception,e:
            print traceback.print_exc(e)
            digi_debug("Node Manager, get dynamic info caught exception: %s" % traceback.print_exc(e),3)
        
        digi_debug(time.time())
        return str(self.dynamic_info)

    def retrieve_all_disk_info(self):
        """
            protocol:
            retrieve all information of initialed disks, the format is
            | disk_status dev_id dev | type size port | user status | pid |
            |<------- no_disk ------>|                |             |     |
            |<-------------- no_user ---------------->|             |     |
            |<--------------------- no_start ---------------------->|     |
            |<------------------------ started -------------------------->|
                     disk_status
            no_disk      1
            no_user      2
            used         3

            For disk of type 'no_user', there is one more element after data segment 'port'.
            If that disk belong to an md array not actived, that segment is the UUID of the
            md array, otherwise an None type instead
        """
        disk_list = []
        for disk in self.no_disk:
            adisk = []
            adisk.append('-2')
            adisk.append(disk_status_type["no_disk"])
            adisk.append(disk.get_dev_id())
            adisk.append(','.join([disk.get_dev(),disk.get_type(),disk.get_model()]))
            adisk.append(disk.get_port())
            disk_list.append(adisk)
        for disk in self.no_user:
            adisk = []
            adisk.append(disk.position)
            #if disk.cluster_spare == '"spare"':
            #    adisk.append(disk_status_type["cluster_spare_disk"])
            #elif disk.cluster_spare == '"replaced"':
            #    adisk.append(disk_status_type["cluster_replaced_disk"])
            #else:
            adisk.append(disk_status_type["no_user"])
            adisk.append(disk.get_dev_id())
            #adisk.append(disk.get_dev())
            adisk.append(','.join([disk.get_dev(),disk.get_type(),disk.get_model()]))
            adisk.append(disk.is_raid())
            if disk.is_raid():
                adisk.append(disk.get_raid_level())
                adisk.append(disk.get_raid_status())
                adisk.append(disk.get_raid_progress())
                adisk.append(disk.get_raid_sub_disk())
            adisk.append(disk.get_size())
            adisk.append(disk.get_port())
            #add-ons, IF ANY, the UUID of the disk array it belongs.
            try:
                disk_raid_info = disk.get_disk_raid_info()
                digi_debug(disk_raid_info, 7)
                if disk_raid_info:
                    adisk.append(disk_raid_info['MD_UUID'].replace(':','-'))
                    adisk.append('md'+disk_raid_info['MD_NAME'].split(':')[1])
                    adisk.append('clean')
                    adisk.append(disk_raid_info['MD_DEVICES'])
                else:
                    adisk.append(None)
                    adisk.append(None)
                    adisk.append(None)
                    adisk.append(None)
            except Exception, e:
                adisk.append(None)
                adisk.append(None)
                adisk.append(None)
                adisk.append(None)
            disk_list.append(adisk)
        for disk in self.no_start:
            adisk = []
            adisk.append(disk.position)
            adisk.append(disk_status_type["used"])
            adisk.append(disk.get_dev_id())
            #adisk.append(disk.get_dev())
            adisk.append(','.join([disk.get_dev(),disk.get_type(),disk.get_model()]))
            adisk.append(disk.is_raid())
            if disk.is_raid():
                adisk.append(disk.get_raid_level())
                adisk.append(disk.get_raid_status())
                adisk.append(disk.get_raid_progress())
                adisk.append(disk.get_raid_sub_disk())
            adisk.append(disk.get_size())
            adisk.append(disk.get_port())
            adisk.append(disk.get_user())
            adisk.append(disk_start_status_type["no_start"])
            disk_list.append(adisk)
        for disk in self.started:
            adisk = []
            adisk.append(disk.position)
            adisk.append(disk_status_type["used"])
            adisk.append(disk.get_dev_id())
            #adisk.append(disk.get_dev())
            adisk.append(','.join([disk.get_dev(),disk.get_type(),disk.get_model()]))
            adisk.append(disk.is_raid())
            if disk.is_raid():
                adisk.append(disk.get_raid_level())
                adisk.append(disk.get_raid_status())
                adisk.append(disk.get_raid_progress())
                adisk.append(disk.get_raid_sub_disk())
            adisk.append(disk.get_size())
            adisk.append(disk.get_port())
            adisk.append(disk.get_user())
            adisk.append(disk_start_status_type["started"])
            adisk.append(disk.get_pid())
            disk_list.append(adisk)

        #digi_debug(disk_list)
        return simplejson.dumps(disk_list)
    
    def set_spare_disk(self, data):
        argument = simplejson.loads(data, encoding='ascii')
        disk_name = argument[0]
        service_info = argument[1]
        adisk = self.get_disk_by_name(disk_name)
        if not adisk:
            return None
        else:
            return adisk.set_spare(service_info)

    def reset_disk(self, data):
        disk_list = simplejson.loads(data, encoding='ascii')
        for disk_str in disk_list:
            adisk = self.get_disk_by_name(disk_str)
            if not adisk:
                print "Disk not found ..."
                return "2"
            ret0 = adisk.reset()
            ret1 = adisk.clear_disk_glusterfs_attr()
            if ret0 or ret1:
                print "Disk reset failed ..."
                return "3"
            else:
                try:
                    if find_in_list(self.started, adisk):
                        self.started.remove(adisk)
                        self.no_user.append(adisk)
                    if find_in_list(self.no_start, adisk):
                        self.no_start.remove(adisk)
                        self.no_user.append(adisk)
                except Exception,e:
                    traceback.print_exc(e)
                    
        return "1"

    def format_disk(self, data):
        disk_list = simplejson.loads(data, encoding='ascii')
        disks_to_format = []
        format_disk_result = {}
        #print disk_list
        for disk_str in disk_list:
            adisk = self.get_disk_by_name(disk_str)
            if adisk.user:
		format_disk_result[adisk.dev] = "2"
            else:
                disks_to_format.append(adisk)
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(disks_to_format))
            node_thread_pool.initPool(data=disks_to_format, target_info=('format', [], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            digi_debug("Node manager, multi threading caught exception: %d" % e, 3)
        else:
            pass
        finally:
            pass
            #ret = adisk.format()
        failed_list = []
        for ret_t in thread_result:
            adisk = ret_t[0]
            ret = ret_t[1]
            if ret:
                digi_debug("Node manager format disk %s failed" % adisk.dev, 3) 
                format_disk_result[adisk.dev] = "2"
                #return "3"
            else:
                digi_debug("Node manager format disk %s success" % adisk.dev, 7) 
		format_disk_result[adisk.dev] = "1"
                continue
        return simplejson.dumps(format_disk_result)

    def smart_enable(self, data): 
        package = simplejson.loads(data)
        disk_name = package[0]
        ret = SmartEnable(disk_name)
        return simplejson.dumps(ret)
         
    def smart_disable(self, data): 
        package = simplejson.loads(data)
        disk_name = package[0]
        ret = SmartDisable(disk_name)
        return simplejson.dumps(ret)

    def smart_status(self, data): 
        package = simplejson.loads(data)
        disk_name = package[0]
        ret = SmartStatus(disk_name)
        return simplejson.dumps(ret)

    def smart_start(self, data): 
        package = simplejson.loads(data)
        disk_name = package[0]
        smart_type = package[1]
        ret = SmartStart(disk_name,smart_type)
        return simplejson.dumps(ret)

    def smart_stop(self, data): 
        package = simplejson.loads(data)
        disk_name = package[0]
        ret = SmartStop(disk_name)
        return simplejson.dumps(ret)

    def smart_info(self, data): 
        disk_list = simplejson.loads(data, encoding='ascii')
        ret = SmartInfo(disk_list)
        return simplejson.dumps(ret)

    def get_hostname(self):
        hostname_img_new = StringIO.StringIO()
        hostname_img_new = get_config_file(settings.PRIHOSTNAMEPATH)
        '''
        hostname_line = hostname_img_new.readlines()
        for l in hostname_line:
            if l.find("HOSTNAME") >= 0:
                hname = l.strip().split("=")[1]
            else:
                digi_debug("**NOTICE: Node manager found hostname failed", 5)
                hname = 'localhost'
        '''
        try:
            hname = hostname_img_new.readline().strip()
        except Exception,e:
            digi_debug('Node Manager, get hostname caught exception: %s' % e, 3)
            import commands
            hname = commands.getoutput('hostname').strip()
        return hname
        
    def set_hostname(self, data):
        #pass
        hostname_img_new = StringIO.StringIO()
        hostname_img_new.write('NETWORKING=yes\nHOSTNAME='+data)
        set_config_file(settings.HOSTNAMEFILE, hostname_img_new)

        hostname_img = StringIO.StringIO()
        hostname_img.write(data)
        set_config_file(settings.PRIHOSTNAMEPATH, hostname_img)

        domainname = re.sub(data.split('.')[0] + '\.','',data)
        domainname_img = StringIO.StringIO()
        domainname_img.write(domainname)
        set_config_file(settings.PRIDOMAINPATH, domainname_img)

        os.system("hostname %s >/dev/null 2>&1"%data)
        return 1

    def set_hosts(self, data):
        hosts_img = simplejson.loads(data, encoding='ascii')
        ret = set_hosts_img(hosts_img)
        if not ret:
            digi_debug("Node manager, set hosts failed", 3)
            raise DigioceanfsError
        else:
            return "1"

    def get_hosts(self):
        hosts_img = get_hosts_img()
        return hosts_img

    def node_get_ipmi_ip_info(self):
        ret = get_ipmi_ip_info()
        return simplejson.dumps(ret)

    def node_issue_ipmi_conf(self, data):
        ipmilist = simplejson.loads(data)
        ret = issue_ipmi_conf(ipmilist)
        if not ret:
            digi_debug("Node manager, issue ipmi conf failed", 3)
            raise DigioceanfsError
        else:
            return "1"

    def node_set_ipmi_ip(self, data):
        package = simplejson.loads(data, encoding='ascii')
        ipaddress = package[0]
        netmask = package[1]
        gateway = package[2]
        # ipmitool lan set 1 ipsrc static
        cmd = []
        cmd.append(settings.COMMANDS['ipmitool'])
        cmd.append('lan')
        cmd.append('set')
        cmd.append('1')
        cmd.append('ipsrc')
        cmd.append('static')
        try:
            tmp_img = tempfile.TemporaryFile()
            ret = execute(cmd, tmp_img)
            digi_debug("Node ipmi ip set ipsrc, %s return %d" % (' '.join(cmd),ret),5)
            tmp_img.seek(0)
            result = tmp_img.read()
            if ret:
                digi_debug("Node ipmi ip set ipsrc, %s" % result,3)
                return "2"   
        except Exception,e:
            digi_debug("Node ipmi ip set ipsrc, caught exception: %s" % e,3)
            return "3"
        # ipmitool lan set 1 ipaddress 10.10.110.19
        cmd = []
        cmd.append(settings.COMMANDS['ipmitool'])
        cmd.append('lan')
        cmd.append('set')
        cmd.append('1')
        cmd.append('ipaddress')
        cmd.append(ipaddress)
        try:
            tmp_img = tempfile.TemporaryFile()
            ret = execute(cmd, tmp_img)
            digi_debug("Node ipmi ip set ipaddress, %s return %d" % (' '.join(cmd),ret),5)
            tmp_img.seek(0)
            result = tmp_img.read()
            if ret:
                digi_debug("Node ipmi ip set ipaddress, %s" % result,3)
                return "2"     
        except Exception,e:
            digi_debug("Node ipmi ip set ipaddress, caught exception: %s" % e,3)
            return "3"
        # ipmitool lan set 1 netmask 255.255.0.0
        cmd = []
        cmd.append(settings.COMMANDS['ipmitool'])
        cmd.append('lan')
        cmd.append('set')
        cmd.append('1')
        cmd.append('netmask')
        cmd.append(netmask)
        try:
            tmp_img = tempfile.TemporaryFile()
            ret = execute(cmd, tmp_img)
            digi_debug("Node ipmi ip set netmask, %s return %d" % (' '.join(cmd),ret),5)
            tmp_img.seek(0)
            result = tmp_img.read()
            if ret:
                digi_debug("Node ipmi ip set netmask, %s" % result,3)
                return "2"     
        except Exception,e:
            digi_debug("Node ipmi ip set netmask, caught exception: %s" % e,3)
            return "3"
        # ipmitool lan set 1 defgw ipaddr 10.10.10.1
        cmd = []
        cmd.append(settings.COMMANDS['ipmitool'])
        cmd.append('lan')
        cmd.append('set')
        cmd.append('1')
        cmd.append('defgw')
        cmd.append('ipaddr')
        cmd.append(gateway)
        try:
            tmp_img = tempfile.TemporaryFile()
            ret = execute(cmd, tmp_img)
            digi_debug("Node ipmi ip set gateway, %s return %d" % (' '.join(cmd),ret),5)
            tmp_img.seek(0)
            result = tmp_img.read()
            if ret:
                digi_debug("Node ipmi ip set gateway, %s" % result,3)
                return "2"     
        except Exception,e:
            digi_debug("Node ipmi ip set gateway, caught exception: %s" % e,3)
            return "3"
        return "1"

    def destroy(self, data):
        service_list_t = list(self.service_list)
        for aservice in service_list_t:
            self.service_destroy(aservice.get_name())
        
        hosts_img = get_config_file(settings.HOSTFILE)
        hosts_lines = hosts_img.readlines()
        hosts_img_new = StringIO.StringIO()
        hname = get_hostname().strip()

        if hostname :
            for a_line in hosts_lines:
                if not ((hname in a_line) and (NODEMARK in a_line)) :
                    hosts_img_new.write(a_line)

        
        set_config_file(settings.HOSTFILE, hosts_img_new)

    def service_init(self, data):
        """
            protocol:
            ["1"]            service init success
            ["2"]            service already exist
            ["3",{disk_name}]        disk has been pop out
            ["4",{disk_name}]        disk not exist
        """
        #collect_result("[Processing]: Init service ...")
        package = simplejson.loads(data, encoding='ascii')
        service_name = package[0]
        version      = package[1]
        mserver_port = package[2]
        vol_file_img = package[3]
        disks        = package[4]
        node_name    = package[5]
        disks_to_add = []

        digi_debug("Node manager, service init: %s"%(service_name), 7)
        
        aservice = self.get_service_by_name(service_name)
        if aservice:
            return simplejson.dumps(["2"])

        aservice = service(self, service_name)
        
        # self.service_list.append(aservice)
        #in case the service has existed, make sure it was stopped
        aservice.stop()

        aservice.set_vol_file(vol_file_img)
        aservice.set_mserver_port(mserver_port)
        aservice.set_version(version)

        for disk_name in disks:
            adisk = self.get_no_user_disk_by_name(disk_name)
            if adisk:
                disks_to_add.append(adisk)
                continue
            
            adisk = self.get_no_disk_disk_by_name(disk_name)
            if adisk:
                return simplejson.dumps(["3", disk_name])
        
            return simplejson.dumps(["4", disk_name])

        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(disks_to_add))
            node_thread_pool.initPool(data=disks_to_add, target_info=('partition', [], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            digi_debug("Node manager, multi threading caught exception: %d" % e, 3)
        else:
            pass
        finally:
            pass

        for adisk in disks_to_add:
            #adisk.partition()
            adisk.set_user(aservice.get_name())
            adisk.set_node(node_name)
            aservice.add_disk(adisk)
            self.no_user.remove(adisk)
            self.no_start.append(adisk)
        self.init_no_start()

        self.service_list.append(aservice)
        add_to_fstab(service_name)
        return simplejson.dumps(["1"])
    
    def service_set_spare_disk(self, data):
        package = simplejson.loads(data)
        print package
        node_disk_dict = package[0]
        node_name = package[1]
        service_name = package[2]
        format = package[3]
        disk_list = []
        if node_name in node_disk_dict:
            disk_list = node_disk_dict[node_name]
        print disk_list
        adisk_list = [self.get_disk_by_name(disk) for disk in disk_list]
        print adisk_list
        if format:
            thread_result = []
            try:
                node_thread_pool = ClusterThreadPool(len(adisk_list))
                node_thread_pool.initPool(data=adisk_list, target_info=('format', [], dict()))
                node_thread_pool.start_threads()
                node_thread_pool.clear_threads()
                thread_result = node_thread_pool.get_results()
            except Exception, e:
                digi_debug("Node manager, multi threading caught exception: %d" % e, 3)
            else:
                pass
            finally:
                pass
            for result in thread_result:
                adisk = result[0]
                ret = result[1]
                if ret:
                    digi_debug("Service set spare: %s failed due to disk format failed" % adisk.dev, 3)
                    return 3
        else:
            print 11111
        

    def service_create_pre(self, data):
        """
        Check disks mount status before volume create by gluster-3.4
        """
        package = simplejson.loads(data)
        node_disk_dict = package[0]
        node_name = package[1]
        try:
            disk_list = []
            if node_name in node_disk_dict:
                disk_list = node_disk_dict[node_name]
            adisk_list = [self.get_disk_by_name(disk) for disk in disk_list]
            thread_result = []
            try:
                node_thread_pool = ClusterThreadPool(len(adisk_list))
                node_thread_pool.initPool(data=adisk_list, target_info=('format', [], dict()))
                node_thread_pool.start_threads()
                node_thread_pool.clear_threads()
                thread_result = node_thread_pool.get_results()
            except Exception, e:
                digi_debug("Node manager, multi threading caught exception: %d" % e, 3)
            else:
                pass
            finally:
                pass
            for result in thread_result:
                adisk = result[0]
                ret = result[1]
                if ret:
                    digi_debug("Mount disk: %s failed due to disk format failed, service won't be created" % adisk.dev, 3)
                    return 3
            for adisk in adisk_list:
                #adisk = self.get_disk_by_name(disk)
                adisk.set_dev(adisk.dev)
                adisk.init_disk()
                if adisk.port:
                    adisk.set_port(adisk.port)
                if os.path.ismount(adisk.export_dir):
                    # Check export_dir status
                    try:
                        os.stat(adisk.export_dir)
                    except OSError:
                        digi_debug("Node manager, Disk %s check dev id path raise error" % self.dev, 3)
                        return "2"
                    # check attr exist on disks
                    ret = self.service_disk_check_attr(adisk)
                    if ret: 
                        digi_debug("Check disk: %s attr exist, service won't be created" % adisk.dev, 3)
                        return "4"
                else:
                    # Check disk filesystem
                    #cmd = []
                    #tmp_img = tempfile.TemporaryFile()
                    #cmd.append(settings.COMMANDS['blkid'])
                    #ret = execute(cmd, tmp_img)
                    #if tmp_img.read().find(adisk.dev) < 0:
                    #    # disk not format
                    #    # mkfs.xfs on this disk
                    #    ret = self.service_disk_mkfs(adisk.dev_id_path)
                    #    if ret:
                    #        digi_debug("Mount disk: %s failed due to disk format failed, service won't be created" % adisk.dev, 3)
                    #        return 3
                    #else:
                    #    ret = self.service_disk_mkfs(adisk.dev_id_path)
                    #    if ret:
                    #        digi_debug("Mount disk: %s failed due to disk format failed, service won't be created" % adisk.dev, 3)
                    #        return 3
                    # format disk anyway
                    #ret = self.service_disk_mkfs(adisk.dev_id_path)
                    digi_debug("Node manager, Service create pre, Disk %s not mounted " % adisk.dev, 5)
                    try:
                        init_dir(adisk.export_dir,True,0444)
                    except:
                        digi_debug("**Notice: Node manager, Service create pre, Disk init dir", 5)
                   # cmd = []
                   # cmd.append(settings.COMMANDS['mount'])
                   # cmd.append(adisk.dev_id_path)
                   # cmd.append(adisk.export_dir)
                   # ret = execute(cmd)
                    ret = adisk.mount()
                    if ret:
                        digi_debug("Node manager, Service create: Mount disk: %s failed, service won't be created" % adisk.dev, 3)
                        return "3"
                    ret = self.service_disk_mount_add_to_fstab(adisk.dev_id_path,adisk.export_dir)
                    # check attr exist on disks
                    ret = self.service_disk_check_attr(adisk)
                    if ret:
                        digi_debug("Node manager, Check disk: %s attr exist, service won't be created" % adisk.dev, 3)
                        return "4"
        except Exception, e:
            digi_debug("Node manager, Service create pre: caught exception: %s" % e,3)
            print e
        return "1"

    def service_replace_pre(self, data):
        """
        Check disks mount status before volume replace by gluster-3.4
        """
        try:
            package = simplejson.loads(data)
            disk_dict = package[0]
            format = package[1]
            node_name = package[2]
            if node_name in disk_dict:
                disk_list = disk_dict[node_name]['new_disk']
            if not disk_list:
                digi_debug("**NOTICE: No new disk given, need not to replace",5)
            for disk in disk_list:
            #if len(disk_list) >= 2:
                #disk = disk_list[1]
                adisk = self.get_disk_by_name(disk)
                adisk.set_dev(adisk.dev)
                adisk.init_disk()
                if not adisk.status():
                    digi_debug("Node manager service replace disk, disk %s not start, replacing abort"% adisk.dev, 7)
                    return "5"
                if adisk.port:
                    adisk.set_port(adisk.port)
                if os.path.ismount(adisk.export_dir):
                    # Check export_dir status
                    try:
                        os.stat(adisk.export_dir)
                    except OSError:
                        digi_debug("Node manager, Disk %s check dev id path raise error" % self.dev, 3)
                        return "2"
                    # check attr exist on disks
                    ret = self.service_disk_check_attr(adisk)
                    if ret: 
                        adisk.clear_disk_glusterfs_attr()
                        digi_debug("Check disk: %s attr exist, service disk won't be replaced" % adisk.dev, 3)
                        if format:
                            adisk.format()
                            #create link to mount dir
                            #print os.path.ismount(adisk.export_dir), '1-----------------------------------'
                            adisk.mount()
                            while not os.path.ismount(adisk.export_dir):
                                time.sleep(1)
                                #print 'wait for mount'
                                if os.path.ismount(adisk.export_dir):
                                    break
                            try:
                                target_dir = '%s/%s' % (adisk.export_dir, '.digioceanfs/00/00')
                                ret = os.system('mkdir -p %s; cd %s; ln -s ../../.. %s' % (target_dir, target_dir, '00000000-0000-0000-0000-000000000001'))
                                digi_debug("Node manager, Service replace pre, create link on disk: %s return %s" % (adisk.dev, ret), 3)
                            except Exception,e:
                                print e
                            #"cluster.heal-timeout": "60"
                else:
                    # Check disk filesystem
                    digi_debug("Node manager, Service replace pre, Disk %s not mounted " % adisk.dev, 5)
                    adisk.format()
                    try:
                        init_dir(adisk.export_dir,True,0444)
                    except:
                        digi_debug("**Notice: Node manager, Service replace pre, Disk init dir", 5)
                   # cmd = []
                   # cmd.append(settings.COMMANDS['mount'])
                   # cmd.append(adisk.dev_id_path)
                   # cmd.append(adisk.export_dir)
                   # ret = execute(cmd)
                    ret = adisk.mount()
                    if ret:
                        digi_debug("Node manager, Service replace disk: Mount disk: %s failed, service won't be replaced" % adisk.dev, 3)
                        return "3"
                    # check attr exist on disks
                    ret = self.service_disk_check_attr(adisk)
                    if ret:
                        adisk.clear_disk_glusterfs_attr()
                        digi_debug("Node manager, Check disk: %s attr exist, service won't be replaced" % adisk.dev, 3)
                        if format:
                            #adisk.clear_disk_glusterfs_attr()
                            adisk.format()
                            #create link to mount dir
                            #print os.path.ismount(adisk.export_dir), '2-----------------------------------'
                            adisk.mount()
                            while not os.path.ismount(adisk.export_dir):
                                time.sleep(1)
                                #print 'wait for mount'
                                if os.path.ismount(adisk.export_dir):
                                    break
                                
                            try:
                                target_dir = '%s/%s' % (adisk.export_dir, '.digioceanfs/00/00')
                                ret = os.system('mkdir -p %s; cd %s; ln -s ../../.. %s' % (target_dir, target_dir, '00000000-0000-0000-0000-000000000001'))
                                digi_debug("Node manager, Service create pre, create link on disk: %s return %s" % (adisk.dev, ret), 3)
                            except Exception,e:
                                print e
            #else:
            #    digi_debug("Node manager, Service replace disk new disk not given", 3)
            #    return "2"
        except Exception, e:
            digi_debug("Node manager, Service replace pre: caught exception: %s" % e,3)
            print e
        return "1"

    def service_disk_mkfs(self, dev_id_path):
        """
        Prepare for service create
        """
        # mkfs.xfs on this disk
        cmd = []
        cmd.append(settings.COMMANDS['mkfs.xfs'])
        cmd.append("-s")
        cmd.append("size=512")
        cmd.append(dev_id_path)
        cmd.append('-f')
        ret = execute(cmd)
        if ret:
            return 1
        else:
            return 0

    def service_disk_check_attr(self, adisk):
        """
        Prepare for service create
        """
        cmd = []
        cmd.append(settings.COMMANDS['attr'])
        cmd.append("-R")
        cmd.append("-l")
        cmd.append(adisk.export_dir)
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, tmp_img)
        result_str = tmp_img.read()
        if result_str.find("digioceanfs.volume-id") >= 0:
            return 1 
        else:
            return 0
        

    def service_create_post(self, data):
        """
        Update disks status after volume create by gluster-3.4
        """
        package = simplejson.loads(data)
        service_name = package[0]
        node_disk_dict = package[1]
        node_name = package[2]
        digi_debug('%s---%s---%s'% (service_name, node_disk_dict, node_name), 7)
        digi_debug("Node manager, Service create service:%s" % (service_name), 7)
        try:
            disk_list = []
            if node_name in node_disk_dict:
                disk_list = node_disk_dict[node_name]
            for disk in disk_list:
                adisk = self.get_disk_by_name(disk)
                if not adisk:
                    print "%s not found ..." % adisk 
                    digi_debug('Node manager, Service Create : Disk %s not found' % adisk.dev, 3)
                else:
                    adisk.set_user(service_name)
                    adisk.set_node(node_name)
                    self.no_user.remove(adisk)
                    self.no_start.append(adisk)
        except Exception, e:
            digi_debug("Node manager, Service create post: caught exception: %s" % e,3)
            print e
        self.service_list.append(service(self, service_name))
        # besure volume id sync on disk 
        os.system('sync')
        #digi_debug("Chmod 777 %s" % ("/cluster2/" + service_name))
        #os.system('chmod 777 %s  >/dev/null 2>&1' % ("/cluster2/" + service_name))
        #digi_debug("Chmod 777 %s" % ("/cluster2/" + service_name))
        return "1"

    def service_replace_post(self, data):
        """
        Update disks status after volume create by gluster-3.4
        """
        package = simplejson.loads(data)
        digi_debug(package, 7)
        service_name = package[0]
        node_disk_dict = package[1]
        node_name = package[2]
        digi_debug('%s---%s---%s'% (service_name, node_disk_dict, node_name), 7)
        digi_debug("Node manager, Service replace service:%s" % (service_name), 7)
        try:
            old_disk_list = []
            new_disk_list = []
            if node_name in node_disk_dict:
                old_disk_list = node_disk_dict[node_name]['old_disk']
                new_disk_list = node_disk_dict[node_name]['new_disk']
            for disk in old_disk_list:
            #if len(disk_list) >= 2:
                adisk = self.get_disk_by_name(disk)
                if not adisk:
                    digi_debug('Node manager, Service replace: Disk %s not found' % adisk.dev, 3)
                else:
                    adisk.set_user(service_name)
                    adisk.set_node(node_name)
                    if adisk in self.no_start:
                        self.no_start.remove(adisk)
                    if adisk in self.started:
                        self.started.remove(adisk)
                    if adisk in self.no_disk:
                        self.no_disk.remove(adisk)
                    self.no_user.append(adisk)
                    adisk.set_replaced()
                    adisk.destroy()
                    ret = self.service_disk_mount_del_from_fstab(adisk.export_dir)
            for disk in new_disk_list:
            #if len(disk_list) >= 2:
                adisk = self.get_disk_by_name(disk)
                if not adisk:
                    digi_debug('Node manager, Service replace: Disk %s not found' % adisk.dev, 3)
                else:
                    adisk.set_user(service_name)
                    adisk.set_node(node_name)
                    self.no_user.remove(adisk)
                    adisk.start()
                    self.started.append(adisk)
                    ret = self.service_disk_mount_add_to_fstab(adisk.dev_id_path,adisk.export_dir)
            #else:
            #    digi_debug('Node manager, Service replace: Disk not given', 3)
        except Exception, e:
            digi_debug("Node manager, Service replace post: caught exception: %s" % e,3)
            print e
        os.system('chmod 777 %s  >/dev/null 2>&1' % (mount_dir_prefix + "/" + service_name))
        return "1"
    
    def service_get_command_status(self, data):
        package = simplejson.loads(data)
        service_name_list = package[0]
        partten = package[1]
        try:
            #partten = 'trusted.ec.heal'
            if NProcessManager().getProcessByLabel(partten):
                return '1'
            else:
                return '0'
        except Exception, e:
            traceback.print_exc(e)
            return '0'
        
    def service_heal_disperse(self, data):
        package = simplejson.loads(data)
        service_name_list = package[0]
        partten = package[1]
        for service_name in service_name_list:
            #cmd = 'find /cluster2/%s/ -d -exec getfattr -h -n %s {} \;' % (service_name, partten)
            cmd = '%s volume heal %s full' % (settings.COMMANDS['digiocean'], service_name)
            try:
                sip = socket.gethostbyaddr(hostname)[2][0]
            except:
                sip = '0.0.0.0'
            hostname = self.get_hostname()
            host_info = get_all_nodes()
            for host in host_info:
                if hostname == host[0]:
                    sip = host[1]
            if NProcessManager().getProcessByLabel(partten):
                NProcessManager().addWait(cmd, service_name, partten)
                #NProcessManager().notify('heal', {'heal':'HealAppend','SourceNode': hostname, 'ErrNode': hostname, 'ServiceName':service_name,'SourceIp': sip, 'Pid':None})
                SNMSG_QUEUE.put_nowait((get_all_nodes(),{'FileEvent':'HealStart','SourceNode': hostname, 'ErrNode': hostname, 'ServiceName':service_name,'SourceIp': sip, 'Pid':None, 'OP':'FileSystemEvent', 'CTime':time.time()}))
            else:
                #proc,pid=NProcessManager().update()
                nProcess = NProcess(cmd, service_name)
                digi_debug("-------------------------------- Heal Command --------------------------------------")
                proc, pid = nProcess.execute()
                digi_debug("-------------------------------- Heal Command --------------------------------------")
                #NProcessManager().notify('heal', {'heal':'HealStart','SourceNode': hostname, 'ErrNode': hostname, 'ServiceName':service_name,'SourceIp': sip, 'Pid':pid})
                SNMSG_QUEUE.put_nowait((get_all_nodes(),{'FileEvent':'HealStart','SourceNode': hostname, 'ErrNode': hostname, 'ServiceName':service_name,'SourceIp': sip, 'Pid':pid, 'OP':'FileSystemEvent', 'CTime':time.time()}))
                digi_debug("Node Manager, notice: heal started ...")
        else:
            return '1'
        
    def service_auto_replace_disk(self, data):
        package = simplejson.loads(data)
        node_name = package[0]
        service_name = package[1]
        error_disk_id = package[2]
        disk_dict = {}
        disk_dict[node_name] = {'old_disk': [], 'new_disk': []}
        disk_dict[node_name]['old_disk'].append('%s' %  (error_disk_id))
        # update disk info 
        self.update_disks()
        if len(self.no_user) > 0:
            disk_dict[node_name]['new_disk'].append('%s' % (self.no_user[0].dev_id))
        else:
            digi_debug("Node Manager, no valiable disk to replace, wait for new disk to plugin")
            return '-1'
        #replace disk pre
        data = simplejson.dumps([disk_dict, True, node_name])
        ret = self.service_replace_pre(data)
        #replace brick
        if ret == '1':
            # go on replace
            option = 'commit'
            force = True
            try: 
                tmp_img = tempfile.TemporaryFile()
                cmd = []
                cmd.append(settings.COMMANDS['digiocean'])
                cmd.append('volume')
                cmd.append('replace-brick')
                cmd.append(service_name)
                cmd.append(node_name+':/digioceanfs/'+disk_dict[node_name]['old_disk'][0])
                cmd.append(node_name+':/digioceanfs/'+disk_dict[node_name]['new_disk'][0])
                cmd.append(option)
                if force:
                    cmd.append("force")

                debug_flag = False
                for i in range(10):
                    ret = execute(cmd, tmp_img)
                    if ret:
                        time.sleep(1)
                        continue
                    else:
                        debug_flag = True
                        break

                host_info = get_all_nodes()
                for host in host_info:
                    if node_name == host[0]:
                        sip = host[1]
                if debug_flag:
                    digi_debug("Node Manager, service replace brick commit success")
                    #send_message(host_info, {'ErrNode': node_name, 'SourceNode': node_name, 'CTime': time.time(), 'ServiceName': service_name, 'FileEvent': 'ReplaceBrick', 'Status': 'Successed', 'SourceIp': sip, 'OP': 'FileSystemEvent'})
                    SNMSG_QUEUE.put_nowait((host_info, {'ErrNode': node_name, 'SourceNode': node_name, 'CTime': time.time(), 'ServiceName': service_name, 'FileEvent': 'ReplaceBrick', 'Status': 'Successed', 'SourceIp': sip, 'OP': 'FileSystemEvent'}))
                else:
                    digi_debug("Node Manager, service replace brick commit failed: %s" % tmp_img.read().strip())
                    #send_message(host_info, {'ErrNode': node_name, 'SourceNode': node_name, 'CTime': time.time(), 'ServiceName': service_name, 'FileEvent': 'ReplaceBrick', 'Status': 'Failed', 'SourceIp': sip, 'OP': 'FileSystemEvent'})
                    SNMSG_QUEUE.put_nowait((host_info, {'ErrNode': node_name, 'SourceNode': node_name, 'CTime': time.time(), 'ServiceName': service_name, 'FileEvent': 'ReplaceBrick', 'Status': 'Failed', 'SourceIp': sip, 'OP': 'FileSystemEvent'}))
            except Exception, e:
                digi_debug("Node Manager, service auto replace failed: %s" % traceback.print_exc(e))
        else:
            # replace pre failed, quit
            digi_debug("Node Manager, service auto replace pre failed")
        #replace disk post
        data = simplejson.dumps([service_name, disk_dict, node_name])
        ret = self.service_replace_post(data)
        if ret == '1':
            digi_debug("Node Manager, service auto replace post success")
        else:
            digi_debug("Node Manager, service auto replace post failed, return %s" % ret)
            
        #do heal
        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append("volume")
        cmd.append("info")
        cmd.append(service_name)
        ret = execute(cmd, tmp_img)
        digi_debug("Service list single, %s return %d" % (' '.join(cmd),ret),5)
        result_str = tmp_img.read()
        service_type = get_service_type_info(service_name,result_str)
        if service_type['replica']:
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('heal')
            cmd.append(service_name)
            if format:
                cmd.append('full')
            ret = execute(cmd, tmp_img)
        elif service_type['disperse']:
            self.service_heal_disperse(simplejson.dumps([[service_name],'trusted.ec.heal']))

    def service_start_pre(self, data):
        """
        Check disks status before volume start by gluster-3.4
        """
        package = simplejson.loads(data)
        service_name = package[0]
        node_disk_dict = package[1]
        node_name = package[2]
        digi_debug("Node manager, Service start service:%s" % (service_name), 7)
        try:
            ret = self.service_umount(service_name)
            if ret:
                digi_debug('Node manager, Service start : service %s umount failed' % service_name, 3)

            disk_list = []
            if node_name in node_disk_dict:
                disk_list = node_disk_dict[node_name]
            for disk in disk_list:
                adisk = self.get_disk_by_name(disk)
                if not adisk:
                    print "%s not found ..." % adisk 
                    digi_debug('Node manager, Service start : Disk %s not found' % adisk.dev, 3)
                    return '2'
                else:
                    if os.path.exists(adisk.export_dir):
                        if not os.path.ismount(adisk.export_dir):
                            digi_debug("**NOTICE: Disk %s not mount ..." % adisk.dev, 5)
                           # cmd = []
                           # cmd.append(settings.COMMANDS['mount'])
                           # cmd.append(adisk.dev_id_path)
                           # cmd.append(adisk.export_dir)
                           # ret = execute(cmd)
                            ret = adisk.mount()
                            if ret:
                                digi_debug('Node manager, Service start : Disk %s not mount' % adisk.dev, 3)
                                return '4' 
                    else:
                        print " Disk export dir %s not exist ..." % adisk.export_dir
                        digi_debug('Node manager, Service start : Disk export dir %s not exist' % adisk.export_dir, 3)
                        return '3'
        except Exception, e:
            digi_debug("Node manager, Service start pre: caught exception: %s" % e,3)
            print e
        return "1"

    def service_start_post(self, data):
        """
        Update disks status after volume start by gluster-3.4
        """
        package = simplejson.loads(data)
        service_name = package[0]
        node_disk_dict = package[1]
        node_name = package[2]
        digi_debug("Node manager, Service start service:%s" % (service_name), 7)
        try:
            ret = self.service_mount(service_name)
            digi_debug("Chmod 777 %s" % ("/cluster2/" + service_name))
            cmd = ['chmod','777','/cluster2/'+service_name]
            tmp_img = tempfile.TemporaryFile()
            ret = execute(cmd, tmp_img)
            digi_debug("Chmod 777 %s" % ("/cluster2/" + service_name))
            if ret:
                digi_debug('Node manager, Service start : service %s mount failed' % service_name, 3)
            disk_list = []
            if node_name in node_disk_dict:
                disk_list = node_disk_dict[node_name]
            for disk in disk_list:
                adisk = self.get_disk_by_name(disk)
                if not adisk:
                    print "%s not found ..." % adisk 
                    digi_debug('Node manager, Service start : Disk %s not found' % adisk.dev, 3)
                else:
                    self.no_start.remove(adisk)
                    self.started.append(adisk)
                    adisk.start()
        except Exception, e:
            digi_debug("Node manager, Service start post: caught exception: %s" % e,3)
            print e
        return "1"

    def service_stop_pre(self, data):
        """
        Umount service before volume stop by gluster-3.4
        """
        package = simplejson.loads(data)
        service_name = package[0]
        node_disk_dict = package[1]
        node_name = package[2]
        digi_debug("Node manager, Service stop service:%s" % (service_name), 7)
        try:
            ret = self.service_umount(service_name)
            if ret:
                digi_debug('Node manager, Service stop : service %s umount failed' % service_name, 3)
        except Exception,e:
            digi_debug("Node manager, Service stop pre, caught exception: %s" % e,3)
            print e

        return "1"

    def service_stop_post(self, data):
        """
        Update disks status after volume stop by gluster-3.4
        """
        package = simplejson.loads(data)
        service_name = package[0]
        node_disk_dict = package[1]
        node_name = package[2]
        digi_debug("Node manager, Service stop service:%s" % (service_name), 7)
        try:
            disk_list = []
            if node_name in node_disk_dict:
                disk_list = node_disk_dict[node_name]
            for disk in disk_list:
                adisk = self.get_disk_by_name(disk)
                if not adisk:
                    print "%s not found ..." % adisk 
                    digi_debug('Node manager, Service stop : Disk %s not found' % adisk.dev, 3)
                else:
                    self.started.remove(adisk)
                    self.no_start.append(adisk)
                    #adisk.stop()
        except Exception, e:
            digi_debug("Node manager, Service stop pre: caught exception: %s" % e,3)
            print e
        return "1"

    def service_stop_pre_rollback(self, data):
        package = simplejson.loads(data)
        service_name = package[0]
        digi_debug("Node manager, Service stop pre rollback service:%s" % (service_name), 7)
        try:
            ret = self.service_mount(service_name)
            if ret:
                digi_debug('Node manager, Service stop pre rollback: service %s umount failed' % service_name, 3)
        except Exception,e:
            digi_debug("Node manager, Service stop pre rollback, caught exception: %s" % e,3)
            print e

        return "1"

    def service_destroy_post(self, data):
        """
            Update disks status after volume delete by gluster-3.4
        """
        package = simplejson.loads(data)
        service_name = package[0]
        node_disk_dict = package[1]
        node_name = package[2]
        digi_debug("Node manager, Service destroy service:%s" % (service_name), 7)
        try:
            disk_list = []
            if node_name in node_disk_dict:
                disk_list = node_disk_dict[node_name]
            for disk in disk_list:
                adisk = self.get_disk_by_name(disk)
                if not adisk:
                    print "%s not found ..." % adisk 
                    digi_debug('Node manager, Service destroy : Disk %s not found' % adisk.dev, 3)
                else:
                    #adisk.set_user("")
                    if adisk in self.no_start:
                        self.no_start.remove(adisk)
                    if adisk in self.started:
                        self.started.remove(adisk)
                    if adisk in self.no_disk:
                        self.no_disk.remove(adisk)
                    if adisk not in self.no_user:
                        self.no_user.append(adisk)
                    #adisk.clear_disk_glusterfs_attr()
                    adisk.destroy()
                    ret = self.service_disk_mount_del_from_fstab(adisk.export_dir)

            aservice = service(self, service_name)
            aservice.destroy()
            #cmd = []
            #cmd.append("/bin/rm")
            #cmd.append("-rf")
            #cmd.append("%s/%s" % (mount_dir_prefix,service_name))  
            #ret = execute(cmd, err_ignore=True)
            #digi_debug("Service destroy, %s return %d" % (' '.join(cmd),ret),5)    
        except Exception, e:
            digi_debug("Node manager, Service destroy: caught exception: %s" % e,3)
            print e
        self.service_list.remove(aservice)

        return "1"

    def service_add_disk_post(self, data):
        """
        Update disks status after volume create by gluster-3.4
        """
        package = simplejson.loads(data)
        service_name = package[0]
        node_disk_dict = package[1]
        node_name = package[2]
        digi_debug("Node manager, Service add disk service:%s" % (service_name), 7)
        try:
            status = list_service_status(service_name)
            if not status:
                print "%s not found ..." % service_name
                digi_debug('Node manager, Service add disk : service %s not found' % service_name, 3)

            if status == 'Started':
                if not os.path.ismount('/cluster2/%s' % service_name):
                    ret = self.service_mount(service_name)
                    if ret:
                        digi_debug('Node manager, Service add disk : service %s mount failed' % service_name, 3)

            disk_list = []
            if node_name in node_disk_dict:
                disk_list = node_disk_dict[node_name]
            for disk in disk_list:
                adisk = self.get_disk_by_name(disk)
                if not adisk:
                    print "%s not found ..." % adisk 
                    digi_debug('Node manager, Service add disk : Disk %s not found' % adisk.dev, 3)
                else:
                    adisk.set_user(service_name)
                    adisk.set_node(node_name)
                    self.no_user.remove(adisk)
                    if status == 'Started':
                        self.started.append(adisk)
                        adisk.start()
                    else:
                        self.no_start.append(adisk)
        except Exception, e:
            digi_debug("Node manager, Service add disk: caught exception: %s" % e,3)
            print e
        os.system('chmod 777 %s  >/dev/null 2>&1' % (mount_dir_prefix + "/" + service_name))
        return "1"
    
    def service_mount(self,service_name):
        mount_dir = mount_dir_prefix + "/" + service_name
        if not os.path.exists(mount_dir):
            os.mkdir(mount_dir) 

        try:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append("mount.digioceanfs")
            cmd.append("127.0.0.1:/%s" % (service_name))
            cmd.append(mount_dir)
            cmd.append('-o')
            cmd.append('acl')
            ret = execute(cmd, tmp_img)
            digi_debug("Service start, %s return %d" % (' '.join(cmd),ret),5)
            result = tmp_img.read()
            return 0
        except Exception,e:
            digi_debug("Service start, caught exception: %s" % e,3)
            return 1

    def service_umount(self,service_name):
        mount_dir = mount_dir_prefix + "/" + service_name
        if not os.path.exists(mount_dir):
            os.mkdir(mount_dir, 0444) 

        try:
            ret = 0
            while ret == 0:
                cmd = []
                cmd.append("/bin/umount")
                cmd.append("-lf")
                cmd.append(mount_dir)
                ret = execute(cmd, err_ignore=True)
                digi_debug("Service start, %s return %d" % (' '.join(cmd),ret),5)

            init_dir(mount_dir,True,0444)
            return 0
        except Exception,e:
            digi_debug("Service start, caught exception: %s" % e,3)
            return 1

    def service_disk_mount_add_to_fstab(self,disk_id_path,disk_export_dir):
        try:
            line_to_add = disk_id_path + " " + disk_export_dir + " " + "xfs" + " " + "defaults" + " " + "0" + " " + "0" + "\n"
            handle = open("/etc/fstab","r")
            content = handle.readlines()
            handle.close()
            for aline in content:
                if aline[0] == "#":
                    continue
                if len(aline.split()) < 2:
                    continue  
                if aline.split()[1] == disk_export_dir:
                    break
            else:
                handle = open("/etc/fstab","a")
                handle.write(line_to_add)
                handle.close()
            return 1
        except Exception,e:
            digi_debug("Node manager, caught exception:%s" % e,3)
            return -1
        
    def service_disk_mount_del_from_fstab(self,disk_mount_dir):
        try:    
            handle = open("/etc/fstab","r")
            content = handle.readlines()
            handle.close()
            for aline in content:
                if aline[0] == "#":
                    continue
                if len(aline.split()) < 2:
                    continue
                if aline.split()[1] == disk_mount_dir:
                    content.remove(aline)
                
            lines="".join(content)
            handle = open("/etc/fstab","w")
            handle.write(lines)
            handle.close()
            return 1
        except Exception,e:
            digi_debug("Node manager, caught exception:%s" % e,3)
            return -1
        
    def service_start(self, data):
        """
            protocol:
            "1":service start success
            "2":service not found
            "3":service start failed
            "4":service already started
            "5":version does not match
        """
        package = simplejson.loads(data)
        service_name = package[0]
        version = package[1]
        fsid = package[2]
        digi_debug("Node manager, starting service:%s"%(service_name), 7)
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, start service %s not exist" % service_name, 3)
            return "2"
        ret = aservice.start(version)
        if ret == 0:
            ret = os.system('/usr/bin/set_fsid %s %s >/dev/null 2>&1'%(mount_dir_prefix + "/" + service_name ,fsid))
            if ret:
                digi_debug("Node manager, set fsid to service failed", 3)
            #os.chmod(mount_dir_prefix + "/" + service_name, 0777)
            os.system('chmod 777 %s  >/dev/null 2>&1' % (mount_dir_prefix + "/" + service_name))
            return "1"
        elif ret == 2:
            digi_debug("Node manager, start service %s,but already started" % service_name, 3)
            return "4"
        elif ret == 3:
            digi_debug("Node manager, start service %s found version not match" % service_name, 3)
            return "5"
        digi_debug("Node manager, start service failed", 2)
        return "3"

    def service_stop(self, service_name):
        """
            protocol:
            "1":service stop success
            "2":service not found
            "3":service stop failed
            "4":the service already been stoped
        """
        digi_debug("Node manager, stop service:%s"%(service_name),5)
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, stop service %s, but service not found" % service_name, 3)
            return "2"
        ret = aservice.stop()
        if ret == 1:
            return "1"
        if ret == 3:
            digi_debug("Node manager, stop service %s,but already stopped" % service_name, 3)
            return "4"
        digi_debug("Node manager, stop service failed", 2)
        return "3"

    def service_restart(self, data):
        """
            protocol:
                "1":service restart success
                "2":service not exist
        """
        package      = simplejson.loads(data)
        service_name = package[0]
        version      = package[1]
        mserver_port = package[2]
        vol_file_img = package[3]
        disks        = package[4]

        digi_debug("Node manager, Service restart: %s"%(service_name), 7)
        digi_debug("Node manager, Service restart recieve service_name:%s"%(service_name), 7)
        digi_debug("Node manager, Service restart recieve version:%s"%(version), 7)
        digi_debug("Node manager, Service restart recieve mserver_port:%s"%(mserver_port), 7)
        digi_debug("Node manager, Service restart recieve disks:%s"%(disks), 7)

        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, restart service %s, but not found" % service_name, 3)
            return "2"
        aservice.restart()
        aservice.cifs_start()
        aservice.nfs_start()
        if not aservice.validate_version(version):
            aservice.stop()
            aservice.set_vol_file(vol_file_img)
            aservice.set_version(version)
            aservice.start(version)
        return "1"

    def service_destroy(self, service_name):
        """
            Update disks status after volume delete by gluster-3.4
        """
        digi_debug("Node manager, destroy service:%s"%(service_name),5)
        disks = aservice.get_disks()
        for adisk in disks:
            adisk.set_user("")
            if find_in_list(self.no_start, adisk):
                self.no_start.remove(adisk)
                digi_debug("Node manager, remove disk %s from no start" % adisk.__str__(), 5)
            if find_in_list(self.started, adisk):
                self.started.remove(adisk)
                digi_debug("Node manager, remove disk %s from started" % adisk.__str__(), 5)
            self.no_user.append(adisk)
            digi_debug("Node manager, add disk %s to no user" % adisk.__str__(), 5)

        return simplejson.dumps(["1"])

    def service_status(self, data):
        """
            protocol:
            ["1",{total_space},{used_space},{pid}]  service running:service space used
            ["2"]:                                  service not found
            ["3"]:                                  service stoped
            ["4"]:                                  service invalid
            ["5"]:                                  service version does not match
            ["6",{total_space},{used_space},{pid}]  service disk does not start
        """
        package = simplejson.loads(data)
        service_name = package[0]
        version = package[1]

        #collect_result("[Processing]: Check out service status ...")
        digi_debug("Node manager, status service: %s"%(service_name),5)
        aservice = self.get_service_by_name(service_name)

        if not aservice:
            digi_debug("Node manager, check service %s status, but service not found" % service_name, 3)
            return simplejson.dumps(["2"])

        if not aservice.validate_version(version):
            digi_debug("Node manager, check service %s status, but version not match" % service_name, 3)
            return simplejson.dumps(["5"])

        status = aservice.status()
        if status == 0:
            return simplejson.dumps(["3"])

        (ret, space_total, space_used) = aservice.get_space_used()
        pid = aservice.get_pid()
        if ret == "1":
            digi_debug("Node manager, check service %s status, but service is invalid" % service_name, 3)
            return simplejson.dumps(["4"])

        if status == 1:
            digi_debug("Node manager, check service %s status, success", 7)
            ret = "1"
        else:
            digi_debug("Node manager, check service %s status, but disks not started" % service_name, 3)
            ret = "6"

        package = [ret, space_total, space_used, pid]
        data = simplejson.dumps(package)
        return data

    def service_extend(self, data):
        """
            protocol:
            "1":     add disk success
            "2":     service not found
            "3":     add disk failed
        """
        package         = simplejson.loads(data)
        service_name    = package[0] #
        extend_file_img = package[1] #
        version         = package[2] #

        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, extend service %s, but service not found" % service_name, 3)
            return "2"

        ret = aservice.extend(extend_file_img, version)
        if ret == 1 or ret == 2:
            return "3"
        digi_debug("Node manager, extend service %s, success", 7)
        return "1"

    def service_undo_extend(self, data):
        """
            protocol:
            "1":    service del success
            "2":    service del failed
            "3":    service not found
        """
        service_name = data

        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, undo extend service %s, but service not found" % service_name, 3)
            return "3"

        if not aservice.undo_extend():
            digi_debug("Node manager, undo extend failed", 3)
            return "2"
        return "1"

    def service_online_extend(self, data):
        """
            protocol:
            "1":    service online success
            "2":    service online failed
            "3":    service not found
        """
        package         = simplejson.loads(data)
        service_name    = package[0] #
        vol_file_img    = package[1] #
        version         = package[2] #
        disks           = package[3] #
        node_name       = package[4] #

        disks_to_add = []

        for disk_name in disks:
            adisk = self.get_no_user_disk_by_name(disk_name)
            if adisk:
                disks_to_add.append(adisk)
                continue

#            adisk = self.get_no_disk_disk_by_name(disk_name)
#            if adisk:
#                return "4;%s"%(disk_name)
#
#            return "5;%s"%(disk_name)

        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, extend service %s online, but service not found" % service_name, 3)
            return "3"

        for adisk in disks_to_add:
            adisk.partition()
            adisk.set_user(aservice.get_name())
            adisk.set_node(node_name)
            aservice.add_disk(adisk)
            self.no_user.remove(adisk)
            digi_debug("Node manager, service remove disk %s from service" % adisk.__str__(), 5)
            self.no_start.append(adisk)
            digi_debug("Node manager, service add disk %s to service" % adisk.__str__(), 5)
        self.init_no_start()

        if not aservice.online_extend(version, vol_file_img):
            return "2"

        return "1"

    def service_replace(self, data):
        """
            protocol:
            "1":    replace success
            "2":    service not found
            "3":    service stoped
        """
        package      = simplejson.loads(data)
        service_name = package[0]
        volumes      = package[1]

        aservice = self.get_service_by_name(service_name)
        if not aservice:
            return "2"

        if aservice.status() != 1:
            return "3"
        aservice.replace(volumes)

        return "1"

    def service_cifs_start(self, data):
        """
            protocol:
            "1":    cifs_start success
            "2":    service not found
            "3":    cifs_start failed
        """
        service_name = data
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s start cifs, but service not found" % service_name, 3)
            return "2"

        if aservice.status() == 0:
            digi_debug("Node manager, service %s start cifs, but service not start" % service_name, 3)
            return "3"

        if aservice.cifs_start():
            digi_debug("Node manager, service %s start cifs, success", 7)
            return "1"
        digi_debug("Node manager, service %s start cifs, failed no reason given", 3)
        return "3"

    def service_cifs_stop(self, data):
        """
            protocol:
            "1":    cifs_start success
            "2":    cifs_stop failed
            "3":    in use
            "4":    service not found
        """
        service_name = data
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s stop cifs, but service not found" % service_name, 3)
            return "4"

        ret = aservice.cifs_stop()
        if ret == 1:
            digi_debug("Node manager, service stop cifs, success", 7)
            return "1"
        elif ret == 2:
            digi_debug("Node manager, service stop cifs, failed", 3)
            return "2"
        elif ret == 3:
            digi_debug("Node manager, service %s stop cifs, but service already in use", 3)
            return "3"
        digi_debug("Node manager, service stop cifs: an error occoured", 2)
        return None

    def service_cifs_status(self, data):
        """
            protocol:
            "1":    start(not_use)
            "2":    start(in_use)
            "3":    stop
            "4":    service not found
            "5":    samba on node stop 
        """
        service_name = data
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s check cifs status, but service not found" % service_name, 3)
            return "4"

        ret = aservice.cifs_status()
        if ret == 1:
            return "1"
        elif ret == 2:
            return "2"
        elif ret == 3:
            return "3"
        elif ret == 4:
            return "3"
        else:
            digi_debug("Node manager, service check cifs status: an error occoured, -- %s --" % ret, 2)
            return None
    
    def service_cifs_restart_node(self, data):
        service_name = data
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s restart cifs on node, but service not found" % service_name, 3)
            return "3"
        ret = aservice.cifs_restart_node()
        if ret:
            digi_debug("Node manager, service %s restart cifs on node, success" % service_name, 7)
            return "1"
        else:
            digi_debug("Node manager, service %s restart cifs on node, failed" % service_name, 3)
            return "2"
    
    def service_cifs_restart_service(self, data):
        service_name = data
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s restart cifs on service, but service not found" % service_name, 3)
            return "3"
        ret = aservice.cifs_restart_service()
        if ret:
            digi_debug("Node manager, service %s restart cifs on service, success" % service_name, 7)
            return "1"
        else:
            digi_debug("Node manager, service %s restart cifs on service, failed" % service_name, 3)
            return "2"
    
    def service_cifs_list_user(self, data):
        package = simplejson.loads(data, encoding='utf-8')
        service_name  = package[0]
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s list cifs user, but service not found" % service_name, 3)
            return "5"
        user_info = get_smb_user_info(service_name)
        if len(user_info) < 1:
            userinfo = ['nodata']
        return simplejson.dumps(user_info)
    
    def service_cifs_list_links(self, data):
        package = simplejson.loads(data, encoding='utf-8')
        service_name = package[0]
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s list cifs links, but service not found" % service_name, 3)
            return "5"
        links_info = get_all_samba_links()
        service_links_info = []
        for link in links_info:
            if link.values():
                if service_name in link.values():
                    service_links_info.append(link)
        return simplejson.dumps(service_links_info)
    
    def service_cifs_del_links(self, data):
        package = simplejson.loads(data, encoding='utf-8')
        pid = package[0]
        ret = force_del_samba_links(pid)
        if ret:
            digi_debug("Node manager, service %s del cifs links, success" % service_name, 7)
            return '1'
        else:
            digi_debug("Node manager, service %s del cifs links, failed" % service_name, 3)
            return '2'
        
    def service_cifs_add_user(self, data):
        """
            protocol:
            "1":    succeed
            "2":    add user_name failed
            "3":    set passwd failed
            "4":    add user to smb conf failed
            "5":    service not found
        """
        package = simplejson.loads(data, encoding='utf-8')
        service_name  = package[0]
        user_name     = package[1]
        passwd        = package[2]
        uid           = package[3]
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s add cifs user, but service not found" % service_name, 3)
            return "5"
        ret = aservice.cifs_add_user(user_name,passwd,uid)
        if ret == 1:
            return "1"
        elif ret == 2:
            return "2"
        elif ret == 3:
            return "3"
        elif ret == 4:
            return "4"
        
        digi_debug("Node manager, service cifs add user: an error occoured", 2)
        return None
    def service_cifs_add_user_rollback(self, data):
        package = simplejson.loads(data, encoding='utf-8')
        service_name  = package[0]
        user_name     = package[1]
        aservice = self.get_service_by_name(service_name)
        ret = aservice.cifs_add_user_rollback(user_name)
        if not ret:
            return False
        return True
    
    def service_cifs_del_user(self, data):
        """
            protocol:
            "1":    succeed
            "2":    user_name not exist
            "3":    service not found
        """
        package = simplejson.loads(data, encoding='utf-8')
        service_name  = package[0]
        user_name     = package[1]
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s del cifs user, but service not found" % service_name, 3)
            return "5"
        ret = aservice.cifs_del_user(user_name)
        if ret == 1:
            return "1"
        elif ret == 2:
            return "2"
        elif ret == 3:
            return "3"
        elif ret == 4:
            return "4"
        digi_debug("Node manager, service del cifs user: an error occoured",2)
        return None

    def service_cifs_del_user_rollback(self, data):
        package = simplejson.loads(data, encoding='utf-8')
        service_name  = package[0]
        user_name     = package[1]
        aservice = self.get_service_by_name(service_name)
        ret = aservice.cifs_del_user_rollback(user_name)
        if not ret:
            return False
        return True

    def service_nfs_start(self, data):
        """
            protocol:
            "1":    success
            "2":    failed
            "3":    service not found
        """
        service_name = data
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s start nfs, but service not found" % service_name, 3)
            return "3"

        if aservice.nfs_start():
            return "1"
        digi_debug("Node manager, service start nfs, failed", 3)
        return "2"

    def service_nfs_stop(self, data):
        """
            protocol:
            "1":    success
            "2":    failed
            "3":    service not found
        """
        service_name = data
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s stop nfs, but service not found" % service_name, 3)
            return "3"

        if aservice.nfs_stop():
            return "1"
        digi_debug("Node manager, service start nfs, failed", 3)
        return "2"

    def service_nfs_status(self, data):
        """
            protocol:
            "1":    start, not used
            "2":    start, used
            "3":    stop
            "4":    service not found
        """
        service_name = data
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s check nfs status, but service not found" % service_name, 3)
            return "4"

        ret = aservice.nfs_status()

        if ret == 1:
            return "1"
        elif ret == 2:
            return "2"
        elif ret == 3:
            return "3"
        digi_debug("Node manager, service check nfs status, failed", 3)
        return None

    def service_nfs_list_links(self, data):
        package = simplejson.loads(data, encoding='utf-8')
        service_name = package[0]
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s list nfs links, but service not found" % service_name, 3)
            return "5"
        links_info = get_all_nfs_links(mount_dir_prefix + '/' + service_name)
        return simplejson.dumps(links_info)
    
    def service_nfs_del_links(self, data):
        package = simplejson.loads(data, encoding='utf-8')
        service_name = package[0]
        tar_ip = package[1]
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s del nfs links, but service not found" % service_name, 3)
            return '5'
        ret = force_del_nfs_link(service_name, tar_ip)
        return '1'

    def service_nfs_add_user(self, data):
        """
            protocol:
            "1":    succeed
            "2":    already exist
            "3":    get fsid error
            "4":    nfs not start
            "5":    service_not_found
        """
        package = simplejson.loads(data, encoding='utf-8')
        service_name  = package[0]
        user_ip     = package[1]
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s add nfs user, but service not found" % service_name, 3)
            return "5"
        
        ret = aservice.nfs_add_user('/cluster2/' + service_name, user_ip)
        if ret == 1:
            return "1"
        elif ret == 2:
            return "2"
        elif ret == 3:
            return "3"
        elif ret == 4:
            return "4"
        digi_debug("Node manager, service nfs add user: an error occoured", 3)
        return None
    
    def service_nfs_add_user_rollback(self, data):
        package = simplejson.loads(data, encoding='utf-8')
        service_name  = package[0]
        user_ip     = package[1]
        aservice = self.get_service_by_name(service_name)
        ret = aservice.nfs_del_user('/cluster2/' + service_name, user_ip)
        if not ret:
            return False
        return True
    
    def service_nfs_del_user(self, data):
        """
            protocol:
            "1":    succeed
            "2":    user_ip not fouond
            "3":    nfs not start
            "4":    service_not_found
        """
        package = simplejson.loads(data, encoding='utf-8')
        service_name  = package[0]
        user_ip     = package[1]
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s del nfs user, but service not found" % service_name, 3)
            return "4"
        
        ret = aservice.nfs_del_user('/cluster2/' + service_name, user_ip)
        if ret == 1:
            return "1"
        elif ret == 2:
            return "2"
        elif ret == 3:
            return "3"
        digi_debug("Node manager, service nfs del user: an error occoured", 3)
        return None
        
    def service_nfs_del_user_rollback(self, data):
        package = simplejson.loads(data, encoding='utf-8')
        service_name  = package[0]
        user_ip     = package[1]
        aservice = self.get_service_by_name(service_name)
        ret = aservice.nfs_add_user('/cluster2/' + service_name, user_ip)
        if not ret:
            return False
        return True
        
    def service_nfs_list_user(self, data):
        service_name = data
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            return "4"
        service_name = "/cluster2/" + service_name
        ret = aservice.nfs_list_user(service_name)
        if not ret:
            return None
        elif len(ret) == 1:
            return simplejson.dumps(ret)
        else:
            return simplejson.dumps(ret)  
    
    def service_afr_info(self, data):
        """
            protocol:
            ["1", data]:   fetch afr info success, and the data
            ["2"]:         the service required is not an afr
            ["3"]:         there is no afr info on this service
        """
        package      = simplejson.loads(data)
        digi_debug("Node manager, recieve package %s" % (package),5)
        service_name = package[0]
        opendir      = package[1]
        disks_dict   = package[2]
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            return simplejson.dumps(["2"])
        #ret = self.service_afr_info_handler(aservice)
        #TODO:check wheather the service is afr.
        #for now, there is no raid level information on server side.

        aservice.afr_info_execute_cmd()
        ret = aservice.afr_info(opendir, disks_dict)
        if not ret:
            return simplejson.dumps(["3"])

        return simplejson.dumps(["1", ret])

    def service_afr_info_topage(self, data):
        """
            protocol:
            ["1", data]:   fetch afr info success, and the data
            ["2"]:         the service required is not an afr
            ["3"]:         there is no afr info on this service
        """
        service_name = data
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            return simplejson.dumps(["2"])

        #TODO:check wheather the service is afr.
        #for now, there is no raid level information on server side.
        ret = aservice.afr_info_topage()
        if not ret:
            return simplejson.dumps(["3"])
        return simplejson.dumps(["1", ret])
    def service_afr_info_topage_search(self, data):
        """
            protocol:
            ["1", data]:   fetch afr info success, and the data
            ["2"]:         the service required is not an afr
            ["3"]:         there is no afr info on this service
        """
        package      = simplejson.loads(data)
        digi_debug("Node manager, recieve package %s" % (package),5)
        service_name = package[0]
        opendir      = package[1]
        disks_dict   = package[2]
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Node manager, service %s get afr info to page, but not service found" % service_name, 3)
            return simplejson.dumps(["2"])

        #TODO:check wheather the service is afr.
        #for now, there is no raid level information on server side.

        aservice.afr_info_execute_cmd()
        ret = aservice.afr_info_topage_search(opendir, disks_dict)
        if not ret:
            return simplejson.dumps(["3"])
        return simplejson.dumps(["1", ret])

    def service_afr_diff(self, data):
        """
            protocol:
            ["1", data]:   fetch afr info success, and the data
            ["2"]:         the service required not exist
        """
        service_name = data
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            return simplejson.dumps(["2"])

        ret = aservice.afr_diff()

        return simplejson.dumps(["1", ret])

    def service_afr_syn(self, data):
        """
            protocol:
            ["1", data]:   start syn success, and the data
            ["2"]:         the service required not exist
        """
        package      = simplejson.loads(data)
        service_name = package[0]
        disk_dev     = package[1]
        syn_mode     = package[2]
        passive_addr = package[3]

        aservice = self.get_service_by_name(service_name)
        if not aservice:
            return simplejson.dumps(["2"])

        ret = aservice.afr_syn(disk_dev, syn_mode, passive_addr)

        return simplejson.dumps(["1", ret])

    def service_afr_expand(self, data):
        """
            protocol:
            "1":   expand afr success, and the data
            "2":   the service required not exist
            "3":   expand afr failed
        """
        package      = simplejson.loads(data)
        service_name = package[0]
        vol_file_img = package[1]
        disk_names   = package[2]
        node_name    = package[3]

        disk_list    = []

        aservice = self.get_service_by_name(service_name)
        if not aservice:
            return simplejson.dumps("2")

        for disk_name in disk_names:
            adisk = self.get_no_user_disk_by_name(disk_name)
            if not adisk:
                digi_debug("Node manager, can not find disk:%s while expand afr:%s" %(service_name, disk_name),3)
                continue
            disk_list.append(adisk)

        for adisk in disk_list:
            adisk.partition()
            adisk.set_user(aservice.get_name())
            adisk.set_node(node_name)
            aservice.add_disk(adisk)
            self.no_user.remove(adisk)
            self.no_start.append(adisk)
        self.init_no_start()

        ret = aservice.afr_expand(vol_file_img)

        if not ret:
            return simplejson.dumps("3")
        return simplejson.dumps("1")

    def service_afr_shrink(self, data):
        """
            protocol:
            "1":   expand afr success, and the data
            "2":   the service required not exist
            "3":   expand afr failed
        """
        package      = simplejson.loads(data)
        service_name = package[0]
        vol_file_img = package[1]
        disks_name   = package[2]
        node_name    = package[3]

        disk_list    = []

        aservice = self.get_service_by_name(service_name)
        if not aservice:
            return simplejson.dumps("2")

        for disk_name in disks_name:
            adisk = aservice.get_disk_by_name(disk_name)
            if not adisk:
                digi_debug("Node manager, can not find disk:%s while shrink afr:%s" %(service_name, disk_name),3)
                continue
            disk_list.append(adisk)

        for adisk in disk_list:
            adisk.stop()
            adisk.set_user("")
            adisk.set_node("")
            if find_in_list(self.no_start, adisk):
                self.no_start.remove(adisk)
            if find_in_list(self.started, adisk):
                self.started.remove(adisk)
            self.no_user.append(adisk)
            aservice.remove_disk(adisk)

        ret = aservice.afr_shrink(vol_file_img)

        if not ret:
            return simplejson.dumps("3")
        return simplejson.dumps("1")

    def raid_create(self, data):
        """
            protocol:
            "1":     raid create success
            "2":     a disk to create raid not exist
            "3":     a disk to create raid has been used
            "4":     raid create failed
        """
        package = simplejson.loads(data)
        level      = package[0]
        chunk      = package[1]
        disk_names = package[2]

        disk_list = []

        for disk_name in disk_names:
            adisk = self.get_disk_by_name(disk_name)
            if not adisk:
                digi_debug("Node manager, raid create with disk %s, but disk not found" % adisk.__str__(), 3)
                return "2"
            if adisk.get_user():
                digi_debug("Node manager, raid create with disk %s, but disk is in use" % adisk.__str__(), 3)
                return "3"
            disk_list.append(adisk)

        for adisk in disk_list:
            adisk.destroy()
            if find_in_list(self.no_disk, adisk):
                self.no_disk.remove(adisk)
                digi_debug("Node manager, raid create remove disk %s from no_disk list"%(adisk.__str__()), 5)
            if find_in_list(self.no_port, adisk):
                self.no_port.remove(adisk)
                digi_debug("Node manager, raid create remove disk %s from no_port list"%(adisk.__str__()), 5)
            if find_in_list(self.no_user, adisk):
                self.no_user.remove(adisk)
                digi_debug("Node manager, raid create remove disk %s from no_user list"%(adisk.__str__()), 5)

        ret = createRaid(str(level), str(chunk), disk_names)
        if ret:
            self.update_disks()
            if os.system("mdadm -Ds > /etc/mdadm/mdadm.conf 2>/dev/null"):
                digi_debug("Node manager, raid create generate RAID configure file failed", 3)
            if os.system("echo PROGRAM /usr/bin/handle_raid_event.py >> /etc/mdadm/mdadm.conf"):
                digi_debug("Node manager, raid create generate RAID event handler in conigure file failed", 3)
            #format raid
            #retval = self.service_disk_mkfs(ret)
            #if retval:
            #    digi_debug("Raid Create: Failed due to disk %s format failed" % ret, 3)
        if not ret:
            return "4"
        return "1"

    def raid_del(self, data):
        """
            protocol:
            "1":     raid del success
            "2":     raid not exist
            "3":     the disk is not a raid
            "4":     raid has been used
        """
        raid_name = data

        araid = self.get_disk_by_name(raid_name)

        if not araid:
            digi_debug("Node manager, raid del %s, but raid not found" % raid_name, 3)
            return "2"
        if not araid.is_raid():
            digi_debug("Node manager, raid del %s, but disk is not raid" % raid_name, 3)
            return "3"
        if araid.get_user():
            digi_debug("Node manager, raid del %s, but raid is in use" % raid_name, 3)
            return "4"

        araid.destroy()

        delRaid(raid_name)

        raid_sub_disk = araid.get_raid_sub_disk()
        t_disk_list = []
        for adisk in raid_sub_disk:
            partition_disk("%s/%s"%(DEV_ID_DIR, adisk[1]))
            tdisk = self.get_disk_by_name(adisk[2])
            t_disk_list.append(tdisk)

        #self.update_disks()

        #format raid disk
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(t_disk_list))
            node_thread_pool.initPool(data=t_disk_list, target_info=('format', [], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            digi_debug("Node manager, multi threading caught exception: %d" % e, 3)
        else:
            pass
        finally:
            pass
        #for adisk in raid_sub_disk:
        #    tdisk = self.get_disk_by_name(adisk[2])
        #    tdisk.format()

        digi_debug("Node manager, raid del %s, success" % raid_name, 7)
        return "1"

    def raid_hs_set(self, data):
        """
            protocol
            "1":     hs set success
            "2":     hs set raid not exist
            "3":     hs set disk is not a raid
            "4":     hs set disk not exist
            "5":     hs set disk is in use
            "6":     hs set disk failed
        """
        package    = simplejson.loads(data)
        raid_name  = package[0]
        disk_names = package[1]

        disk_list = []

        ret_sum = 0

        araid = self.get_disk_by_name(raid_name)
        if not araid:
            digi_debug("Node manager, raid set hotspare, but raid not found", 3)
            return "2"
        if not araid.is_raid():
            digi_debug("Node manager, raid set hotspare, but disk is not raid", 3)
            return "3"
        for disk_name in disk_names:
            adisk = self.get_disk_by_name(disk_name)
            if not adisk:
                digi_debug("Node manager, raid set hotspare with disk %s, but disk not found" % adisk.__str__(), 3)
                return "4"
            if adisk.get_user():
                digi_debug("Node manager, raid set hotspare with disk %s, but disk is in use" % adisk.__str__(), 3)
                return "5"
            disk_list.append(adisk)

        for adisk in disk_list:
            if find_in_list(self.no_disk, adisk):
                self.no_disk.remove(adisk)
                digi_debug("Node manager, raid set hotspare remove disk %s from no_disk list"%(adisk.__str__()), 5)
            if find_in_list(self.no_port, adisk):
                self.no_port.remove(adisk)
                digi_debug("Node manager, raid set hotspare remove disk %s from no_port list"%(adisk.__str__()), 5)
            if find_in_list(self.no_user, adisk):
                self.no_user.remove(adisk)
                digi_debug("Node manager, raid set hotspare remove disk %s from no_user list"%(adisk.__str__()), 5)
            adisk.destroy()

        for adisk in disk_list:
            ret = addHotspare(araid.get_dev_id(), adisk.get_dev_id())
            if ret == 0:
                araid.add_hs_disk([adisk])
            ret_sum = ret_sum + ret

        self.update_disks()

        if ret_sum != 0:
            digi_debug("Node manager, raid set hot spare, failed", 3)
            return "6"
        digi_debug("Node manager, raid set hot spare, success", 7)
        return "1"

    def raid_hs_del(self, data):
        """
            protocol
            "1":     hs del success
            "2":     raid not exist
            "3":     raid is not a raid
            "4":     disk is not in raid as a hs disk
            "5":     hs del failed
        """
        package    = simplejson.loads(data)
        raid_name  = package[0]
        disk_names = package[1]

        digi_debug("Node manager, revieve raid_hs_del on raid:%s, disks:%s"%(raid_name, disk_names),5)

        araid = self.get_disk_by_name(raid_name)
        if not araid:
            digi_debug("Node manager, raid del hotspare, but raid not found", 3)
            return "2"
        if not araid.is_raid():
            digi_debug("Node manager, raid del hotspare, but disk is not raid", 3)
            return "3"
        for disk_name in disk_names:
            if not araid.valid_hs_disk(disk_name):
                digi_debug("Node manager, raid del hotspare, but disk is not in raid as a hotspare", 3)
                return "4"

        ret = delHotspare(raid_name, disk_names)

        self.update_disks()

        if ret != 0:
            digi_debug("Node manager, raid del hot spare, failed", 3)
            return "5"
        araid.remove_hs_disk(disk_names)
        digi_debug("Node manager, raid del hot spare, success", 7)
        return "1"

    def raid_active(self, data):
        """
            protocol:
            "1":    raid active success
            "2":    raid active failed
        """
        package          = simplejson.loads(data)
        raid_group       = package[0]
        raid_UUID        = package[1]
        raid_device_list = package[2]

        raid_device_path_list = []

        for raid_device in raid_device_list:
            adisk = self.get_no_user_disk_by_name(raid_device)
            if adisk:
                raid_device_path_list.append(adisk.get_dev_id_path())
            else:
                digi_debug("Node manager, raid active faileld,inactive disk %s not found"%(raid_device), 3)

        ret = activeRaid(raid_group, raid_UUID, raid_device_path_list)

        if not ret:
            digi_debug("Node manager, raid active, failed", 3)
            return "2"

        self.update_disks()
        digi_debug("Node manager, raid active, success", 7)
        return "1"

    def raid_disactive_disk(self, data):
        """
            protocol:
            "1":    raid active success
            "2":    raid active failed
        """
        disk_name_list = simplejson.loads(data)

        disk_list = []

        for disk_name in disk_name_list:
            adisk = self.get_no_user_disk_by_name(disk_name)
            if not adisk:
                digi_debug("Node manager, raid disactive disk %s,but disk not exist"%(adisk.get_dev_id()), 3)
                return "2"
            if not adisk.get_disk_raid_UUID():
                digi_debug("Node manager, raid disactive disk %s,but no uuid info found"%(adisk.get_dev_id()), 3)
                return "2"
            disk_list.append(adisk)

        for adisk in disk_list:
            adisk.partition()

        self.update_disks()
        digi_debug("Node manager, raid disactive disk, success", 7)
        return "1"

    def nic_fake_ip_set(self, data):
        """
            protocol:
            "1":    ip set success
            "2":    ip set failed
        """
        package    = simplejson.loads(data)
        nic_name   = package[0]
        new_ip     = package[1]
        new_mask   = package[2]
        new_gate   = package[3]
        new_bcast  = package[4]

        self.post_opt_code = post_opt_type["fake_ip_set"]
        self.post_opt_args = [nic_name, new_ip, new_mask, new_gate, new_bcast]

        return "1"

    def set_fake_ip_addr_thread(self, nic_name, new_ip, new_mask, new_gate, new_bcast):
        self.acquire_net_lock()
        set_fake_ip_addr(nic_name, new_ip, new_mask, new_gate, new_bcast)
        self.release_net_lock()

    def nic_fake_ip_set_post(self, args):
        th = threading.Thread(target=self.set_fake_ip_addr_thread, args=(args[0], args[1], args[2], args[3], args[4],))
        th.start()
        th.join(10)

    def nic_ip_set(self, data):
        """
            protocol:
            "1":    ip set success
            "2":    ip set failed
        """
        package    = simplejson.loads(data)
        nic_name   = package[0]
        new_ip     = package[1]
        new_mask   = package[2]
        new_gate   = package[3]
        new_bcast  = package[4]

        self.post_opt_code = post_opt_type["ip_set"]
        self.post_opt_args = [nic_name, new_ip, new_mask, new_gate, new_bcast]

        return "1"

    def set_ip_addr_thread(self, nic_name, new_ip, new_mask, new_gate, new_bcast):
        self.acquire_net_lock()
        set_ip_addr(nic_name, new_ip, new_mask, new_gate, new_bcast)
        self.release_net_lock()

    def nic_ip_set_post(self, args):
        th = threading.Thread(target=self.set_ip_addr_thread, args=(args[0], args[1], args[2], args[3], args[4],))
        th.start()
        th.join(10)
        
    def node_init(self, data):
        package = simplejson.loads(data)
        init_level = package
        cmd = []
        cmd.append('/sbin/init')
        cmd.append('%s'%init_level)
        execute(cmd, nowait=True)
        return '1'

    def bond_set(self, data):
        """
            protocol:
            "1":    bond set success
            "2":    bond set failed
        """
        package     = simplejson.loads(data)
        bond_mode   = package[0]
        primary_nic = package[1]
        nic_list    = package[2]

        self.post_opt_code = post_opt_type["bond_set"]
        self.post_opt_args = [bond_mode, primary_nic, nic_list]

        return "1"

    def bond_set_thread(self, bond_mode, primary_nic, nic_list):
        self.acquire_net_lock()
        set_bond(nic_list, bond_mode, primary_nic)
        self.release_net_lock()

    def bond_set_post(self, args):
        th = threading.Thread(target=self.bond_set_thread,
                              args=(args[0], args[1], args[2],))
        th.start()

    def bond_del(self, data):
        """
            protocol:
            "1":    bond del success
            "2":    bond del failed
        """
        bond_name = data

        self.post_opt_code = post_opt_type["bond_del"]
        self.post_opt_args = [bond_name]

        return "1"

    def bond_del_thread(self, bond_name):
        self.acquire_net_lock()
        del_bond(bond_name)
        self.release_net_lock()

    def bond_del_post(self, args):
        th = threading.Thread(target=self.bond_del_thread, args=(args[0],))
        th.start()

    def sync_sms_conf(self, data):
        smsinfos = simplejson.loads(data, encoding='ascii')
        f = open(settings.SMSCONF,'w')
        pickle.dump(smsinfos,f)
        f.close()
        return "1"

    def replace_fetch_disk(self, data):
        """
            protocol:
            | old_disk_id | old_disk_node | old_disk_port | old_disk_user | old_disk_size |
        """
        used_disk_list = self.no_start + self.started
        used_disk = []
        for adisk in used_disk_list:
            used_disk.append([adisk.get_dev_id(), adisk.get_node(), adisk.get_port(), adisk.get_user(), adisk.get_size()])
        data = simplejson.dumps(used_disk)
        return data

    def replace_check_disk(self, data):
        """
            protocol:
            package: [{ret_code}, {disk_list}]
            disk_list format:
            | old_disk_id | old_disk_node | old_disk_port | old_disk_user |  new_disk_id | old_disk_size | 
        """
        ret = True
        i   = 0
        gap = 0
        dset= -1
        disks = simplejson.loads(data)
        used_disk_list = self.no_start + self.started
        no_user_disk_list = []

        #get a list of free disk names
        for adisk in self.no_user:
            no_user_disk_list.append(adisk)    
        
        #check if there is more disk than need
        if len(no_user_disk_list) < len(disks):
            ret = False
        else:
            for adisk in disks:
                for used_disk in used_disk_list:
                    if used_disk.get_port() == adisk[2]:
                        ret = False
                        
            if ret :
                for adisk in disks:
                    dset = -1
                    i    = 0
                    gap  = 0
                    adisk.insert(4, -1)
                    while i < len(no_user_disk_list):
                        nused = no_user_disk_list[i]
                        if adisk[5] == nused.get_size():
                            adisk[4] = nused.get_dev_id()
                            dset = i
                            break
                        
                        elif adisk[5] > nused.get_size():
                            if not gap or (gap > (adisk[5] - nused.get_size())):
                                gap = adisk[5] - nused.get_size()
                                adisk[4] = nused.get_dev_id()
                                dset = i
                            
                        i = i + 1 # loop
                    
                    if dset < 0 :
                        dset = 0
                        nused = no_user_disk_list[dset]
                        adisk[4] = nused.get_dev_id()
                        
                    no_user_disk_list.pop(dset)

        package = [ret, disks]
        data = simplejson.dumps(package)
        return data

    def replace_destroy_disk(self, data):
        """
            protocol:
            "1":    destroy disks succuess
            "2":    no disk to destroy
        """
        used_disk_list = self.no_start + self.started
        if len(used_disk_list) < 1:
            return "2"
        for adisk in used_disk_list:
            service_name = adisk.get_user()
            aservice = self.get_service_by_name(service_name)
            if aservice:
                aservice.remove_disk(adisk)
            else:
                digi_debug("Node manager, the service:%s of the disk:%s not found!!!"%(service_name, adisk.get_dev()),3)
            adisk.stop()
            adisk.set_user("")
            adisk.set_node("")
            if find_in_list(self.no_start, adisk):
                self.no_start.remove(adisk)
            if find_in_list(self.started, adisk):
                self.started.remove(adisk)
            self.no_user.append(adisk)
        return "1"
    
    def replace_nodisk(self, data):
        try:
            node_name = simplejson.loads(data)[0]
            service_name = simplejson.loads(data)[1]
            replace_disk = simplejson.loads(data)[2]
            aservice = self.get_service_by_name(service_name)
            if not self.no_disk:
                digi_debug("Node manager, replace nodisk, but no nodisk found", 3)
                return simplejson.dumps(['2', {}])
            adisk = self.get_disk_by_name(replace_disk)
            if not adisk:
                digi_debug("Node manager, replace nodisk,but disk %s not found" % adisk.__str__(), 3)
                return simplejson.dumps(['3', {}])
            adisk_size = adisk.get_size()
            if not adisk_size:
                digi_debug("Node manager, replace nodisk,but disk_size %s not found"%adisk_size.__str__(),3)
                return simplejson.dumps(['3', {}])
            no_disks = []
            service_nodisk = aservice.get_disks()
            for disk in self.no_disk:
                if disk in service_nodisk:
                    no_disks.append(disk)
            if no_disks:
                nodisk_num = len(no_disks)
                no_disk = no_disks[0]
                if not no_disk:
                    digi_debug("Node manager, node manager has not %s "%no_disk.__str__(),3)
                    return simplejson.dumps(['2', {}])
                no_disk_size = no_disk.get_no_disk_size()
                if not no_disk_size:
                    digi_debug("Node manager, node manager has not %s"%no_disk.__str__(),3)
                    return simplejson.dumps(['2', {}])
                #print(adisk_size)
                #print(no_disk_size)
                if adisk_size>=no_disk_size:
                    adisk.set_port(no_disk.get_port())
                    adisk.set_user(service_name)
                    adisk.set_node(node_name)
                    self.no_user.remove(adisk)
                    aservice.remove_disk(no_disk)
                    self.started.append(adisk)
                    replace_disks_id_dict = {no_disk.get_dev_id():adisk.get_dev_id()}
                    aservice.add_disk(adisk)
                    adisk.partition()
                    #aservice.disks.append(adisk)                                                   #add new disk to service
                    self.no_disk.pop(0)
                    no_disk.destroy()
                    if nodisk_num < 2:
                        aservice.start(aservice.get_version())
                    #self.init_no_start()
                else:
                    return simplejson.dumps(['4', {}])
        except Exception,e:
            digi_debug("Node manager, replace nodisk caught exception: %s" % traceback.print_exc(), 3)

        return simplejson.dumps(['1', replace_disks_id_dict])    

    def check_license(self, data):
        node_name = simplejson.loads(data)[0]
        license = simplejson.loads(data)[1]
        ret = lic_check(license)
        if ret:
            return simplejson.dumps("1")
        else:
            return simplejson.dumps("2")

    def get_device_id(self, data):
        ret = ''
        ret = getDeviceId()
        return simplejson.dumps(ret)

    def replace_initial_disk(self, data):
        replace_disks = simplejson.loads(data)

        digi_debug("Node manager, initial disks:%s"%(replace_disks),5)

        #these two variable used to caculate duplicate port number, and resolve them
        new_ports = []
        other_disk = list(self.no_user)

        for a_replace_disk in replace_disks:
            adisk = self.get_no_user_disk_by_name(a_replace_disk[0])
            if not adisk:
                digi_debug("Node manager, the disk:%s can not be found while initialize replace disk!!!"%(a_replace_disk[0]),5)
                digi_debug("Node manager, ignore and go on",5)
                continue
            other_disk.remove(adisk)
            new_ports.append(a_replace_disk[1])
            adisk.set_port(a_replace_disk[1])
            while string_compare(a_replace_disk[1], self.max_port) >= 0:
                self.max_port = self.max_port + 1
#            adisk.set_user(a_replace_disk[2])
#            adisk.set_node(a_replace_disk[3])
#            adisk.partition()
#            self.no_user.remove(adisk)
#            self.no_start.append(adisk)

#            aservice = self.get_service_by_name(a_replace_disk[2])
#            if not aservice:
#                digi_debug("the service:%s can not be found while initialize replace disk!!!"%(a_replace_disk[2]))
#                digi_debug("ignore and go on")
#                continue
#            aservice.add_disk(adisk)

        #make sure that all ports are different
        #because we have a check with 'no_start' and 'started' disks(in function 'replace_check_disk')
        #now we only need to check with 'no_user' disks
#        import pdb
#        pdb.set_trace()
        for adisk in other_disk:
            for new_port in new_ports:
                if adisk.get_port() == new_port:
                    adisk.set_port(self.max_port)
                    self.max_port = self.max_port + 1
                    break
        return "1"

    def node_login_check(self):
        if isfile(login_file_path):
            return "1"
        else:
            return "0"
        
    def cifs_status(self):
        #collect_result("[Processing]: Check out cifs status ...")
        if samba_status_process():
            return "1"
        else:
            return "0"
        
    def cifs_restart(self):
        if samba_restart():
            return "1"
        else:
            return "0"
    
    def nfs_status(self):
        #collect_result("[Processing]: Check out nfs status ...")
        if nfs_status():
            return "1"
        else:
            return "0"
    
    def nfs_restart(self):
        if nfs_restart():
            return "1"
        else:
            return "0"

    def node_ctdb_set_post(self, data):
        package = simplejson.loads(data)
        node_names = package[0].keys()
        nodes_addresses = package[0].values()
        public_addresses = package[1]

        hostname = self.get_hostname()
        if hostname in node_names:                  #ctdb set
            ###################################################
            #  ctdb volume mount
            ###################################################
            if not os.path.exists(settings.CTDBMTDIR):
                os.mkdir(settings.CTDBMTDIR)

            if os.path.ismount(settings.CTDBMTDIR):
                cmd = []
                cmd.append("/bin/umount")
                cmd.append(settings.CTDBMTDIR)
                cmd.append("-lf")
                ret = execute(cmd, err_ignore=True)
                if ret:
                    digi_debug('Node manager, Ctdb set post: volume ctdb umount failed', 3)
                    return "2"
            ret = self.service_mount('ctdb')
            if ret:
                digi_debug('Node manager, Ctdb set post : volume ctdb mount failed', 3)
                return "3"

            ###################################################
            #   ctdb conf set
            ###################################################
            ctdb_fd = open(settings.CTDBSYSCONF, 'w')                                   # /etc/sysconfig/ctdb
            ctdb_fd.write('CTDB_RECOVERY_LOCK=/cluster2/ctdb/lockfile\n')
            ctdb_fd.write('CTDB_PUBLIC_ADDRESSES=/etc/ctdb/public_addresses\n')
            ctdb_fd.write('CTDB_MANAGES_SAMBA=yes\n')
            ctdb_fd.write('CTDB_NODES=/etc/ctdb/nodes\n')
            ctdb_fd.close()
            
            if not os.path.exists('%s' % settings.CTDBCONF):
                os.mkdir('%s' % settings.CTDBCONF)

            pba_fd = open('%s/%s' % (settings.CTDBCONF,'public_addresses'), 'w')        # /etc/ctdb/public_addresses
            for pubaddr in public_addresses:
                pba_fd.write('%s\n' % pubaddr)
            pba_fd.close()

            node_fd = open('%s/%s' % (settings.CTDBCONF,'nodes'), 'w')                  # /etc/ctdb/nodes
            for node in nodes_addresses:
                node_fd.write('%s\n' % node)
            node_fd.close()

            ###################################################
            #  ctdb service start
            ###################################################
            cmd = []
            cmd.append('service')
            cmd.append('ctdb')
            cmd.append('restart')
            tmp_img = tempfile.TemporaryFile()
            ret = execute(cmd, tmp_img)
            result = tmp_img.read()
            if result.find('FAILED') >= 0:
                digi_debug('Node manager, Ctdb set post : service ctdb start failed', 3)
                return "4"
        else:        #remove ctdb conf and ctdb service stop
            if os.path.exists(settings.CTDBSYSCONF):
                os.remove(settings.CTDBSYSCONF)
            if os.path.exists('%s/%s' % (settings.CTDBCONF,'public_addresses')):
                os.remove('%s/%s' % (settings.CTDBCONF,'public_addresses'))
            if os.path.exists('%s/%s' % (settings.CTDBCONF,'nodes')):
                os.remove('%s/%s' % (settings.CTDBCONF,'nodes'))

            cmd = []
            cmd.append('service')
            cmd.append('ctdb')
            cmd.append('stop')
            ret = execute(cmd)
            if ret:
                digi_debug('Node manager, Ctdb set post : service ctdb stop failed', 3)

        return '1'

    def node_ctdb_list(self):
        ctdb_info = {}
        if os.path.exists(settings.CTDBCONF + '/nodes'):
            fd = open(settings.CTDBCONF + '/nodes','r')
            ctdb_info['nodes'] = fd.read().strip().split('\n')
        if os.path.exists(settings.CTDBCONF + '/public_addresses'):
            fd = open(settings.CTDBCONF + '/public_addresses','r')
            ctdb_info['public_addresses'] = fd.read().strip().split('\n')
        return simplejson.dumps(ctdb_info)

    def post_option(self):
        opt = self.post_opts[self.post_opt_code]
        if opt:
            opt(self.post_opt_args)
        self.post_opt_code = post_opt_type["none"]
        self.post_opt_args = None

    def get_disk_by_name(self, disk_name):
        all_disk = self.no_disk + self.no_port + self.no_user + self.no_start + self.started
        return find_in_list(all_disk, disk_name)

    def get_no_user_disk_by_name(self, disk_name):
        return find_in_list(self.no_user, disk_name)

    def get_no_disk_disk_by_name(self, disk_name):
        return find_in_list(self.no_disk, disk_name)

    def get_no_start_disk_by_name(self, disk_name):
        return find_in_list(self.no_start, disk_name)
    
    def get_no_port_disk_by_name(self, disk_name):
        return find_in_list(self.no_port, disk_name)
    
    def get_started_disk_by_name(self, disk_name):
        return find_in_list(self.started, disk_name)

    def get_service_by_name(self, service_name):
        return find_in_list(self.service_list, service_name)

    def start_all_disk(self, user_name):
        """start all disks belong to a user"""
        digi_debug("Node manager, not implement")

    def start_disk(self, disk_name):
        digi_debug("Node manager, not implement")

    def disk_set_user(self, disk_name, user):
        digi_debug("Node manager, not implement")

    def acquire_net_lock(self):
        self.net_lock.acquire()

    def release_net_lock(self):
        self.net_lock.release()

    def acquire_msg_lock(self):
        self.msg_lock.acquire()

    def release_msg_lock(self):
        self.msg_lock.release()
        
    def node_msg_lock(self):
        self.message_handler_lock.acquire()
        
    def node_msg_unlock(self):
        self.message_handler_lock.release()

    #Thess methond is for node messager use.
    #NOTE:Since it is in another thread, you should do some
    #thread safe operation here.
    def nm_afr_passive_unlock(self, data):
        """
            protocol:
            "1":    success
            "2":    disk not found
        """
        disk_name = data
        adisk = self.get_disk_by_name(disk_name)
        if not adisk:
            return "2"

        adisk.afr_syn_release_passive_lock()
        return "1"
    
    def msg_handler_lock(self, payload):
        if self.message_handler_lock.acquire(False):
            return '1'
        else:
            return '0'
        
    def msg_handler_unlock(self, payload):
        try:
            self.message_handler_lock.release()
        except Exception,e:
            digi_debug("Node Manager, release msg handler unlock caught exception: %s" % traceback.print_exc(e))
        return '1'
    
    def message_handler(self, payload):
        try:
            msg = simplejson.loads(payload)[0]
            digi_debug('Message Handler, receive message: msg: %s' % msg, 7)
            print msg, type(msg)
        except Exception,e:
            digi_debug("Node Manager, message handle error: %s" % traceback.print_exc(e))
            print traceback.print_exc(e)
            print '============================'
        try:
            #self.msg_handler_lock.acquire()
            nhostname = self.get_hostname()
            if 'OP' in msg and 'FileEvent' in msg:
                if msg['FileEvent'] == "failure":
                    node_name = msg['ErrNode']
                    disk_Name = msg['ErrDiskName']
                    self.update_disks()
                    digi_debug('disk replace will happen automaticely...', 7)
                    if nhostname == node_name or node_name == 'localhost':
                        #self.node_manager_command_lock()
                        self.auto_replace_disk(node_name, disk_name)
                        #self.node_manager_command_unlock()
                    else:
                        digi_debug('Message Handler, receive disk remove, but not no this node...', 7)
                #self.msg_handler_lock.release()
                elif msg['FileEvent'].find('Heal') >= 0:
                    digi_debug(" -------- %s -----------" % msg['FileEvent'])
                    fd = open('/etc/digioceanfs_manager/reports/%s' % msg['ErrNode']+str(time.time()), 'w+')
                    fd.write(simplejson.dumps(msg))
                    fd.close()
                elif msg['FileEvent'] == 'ReplaceBrick':
                    fd = open('/etc/digioceanfs_manager/reports/%s' % msg['ErrNode']+str(time.time()), 'w+')
                    fd.write(simplejson.dumps(msg))
                    fd.close()
            elif 'OP' in msg and 'DiskEvent' in msg:
                if msg['DiskEvent'] == "remove":
                    node_name = msg['ErrNode']
                    disk_name = msg['DiskName']
                    self.update_disks()
                    digi_debug('disk replace will happen automaticely...', 7)
                    if nhostname == node_name or node_name == 'localhost':
                        #self.node_manager_command_lock()
                        self.auto_replace_disk(node_name, disk_name)
                        #self.node_manager_command_unlock()
                    else:
                        digi_debug('Message Handler, receive disk remove, but not no this node...', 7)
                    #self.msg_handler_lock.release()
                elif msg['DiskEvent'] == "add":
                    node_name = msg['ErrNode']
                    self.update_disks()
                    if nhostname == node_name or node_name == 'localhost':
                        if self.no_disk:
                            digi_debug("Node Manager, found %s no_disk need to replace" % len(self.no_disk), 7)
                            for nodisk in self.no_disk:
                                #self.node_manager_command_lock()
                                self.auto_replace_disk(node_name, 'no_disk')
                                #self.node_manager_command_unlock()
                                digi_debug("Node Manager, no_disk not found, no need to replace, just heal disperse")
                                self.init_heal_disperse()
                        else:
                            #print 'command acquire lock', '------', time.time()
                            #self.node_manager_command_lock()
                            print 'no_disk not found, no need to replace, just heal disperse'
                            digi_debug("Node Manager, no_disk not found, no need to replace, just heal disperse")
                            self.init_heal_disperse()
                            #self.node_manager_command_unlock()
                    else:
                        digi_debug('Message Handler, receive disk remove, but not no this node...', 7)
                    #self.msg_handler_lock.release()                        
                else:
                    print msg
                    #self.node_manager_command_unlock()
                    #digi_debug("Node Manager, MESSAGE HANDLER lock released", 7)
            elif 'OP' in msg and 'Event' in msg:
                node_name = msg['ErrNode']
                if msg['Event'] == 'On-line':
                    digi_debug('Node manager, detect some node return, just heal disperse', 7)
                    self.init_heal_disperse()
                    digi_debug('Node manager, detect some node return ...', 7)
                    
                if msg['OP'] == 'Net-Link' and msg['Event'] == 'yes':
                    digi_debug('Node manager, detect some node return, just heal disperse', 7)
                    self.init_heal_disperse()
                    digi_debug('Node manager, detect some node return ...', 7)
                    #self.node_manager_command_unlock()
                    #digi_debug("Node Manager, MESSAGE HANDLER lock released", 7)
                #else:
                    #self.node_manager_command_unlock()
                    #digi_debug("Node Manager, MESSAGE HANDLER lock released", 7)
            else:
                #self.msg_handler_lock.release()
                #self.node_manager_command_unlock()
                #digi_debug("Node Manager, MESSAGE HANDLER lock released", 7)
                print msg
        except Exception,e:
            digi_debug("Node Manager, message handler error: %s" % traceback.print_exc(e), 3)
            #self.msg_handler_lock.release()
            #self.node_manager_command_unlock()
    
    
        

#if __name__ == "__main__":
#
#    amanager = node_manager()
#
#    if len(sys.argv) < 2:
#        print "require at least 1 argument"
#        exit()
#
#    command = sys.argv[1]
#
#    if command == "start":
#        adisk = disk(sys.argv[2])
#        ret = adisk.start()
#        print ret
#    elif command == "stop":
#        adisk = disk(sys.argv[2])
#        ret = adisk.stop()
#        print ret
#    elif command == "status":
#        adisk = disk(sys.argv[2])
#        ret = adisk.status()
#        print ret
#    elif command == "pid":
#        adisk = disk(sys.argv[2])
#        print adisk.get_pid()
#    elif command == "destroy":
#        amanager.destroy_all()
#    elif command == "update":
#        amanager.update_disks()
#    else:
#        print "no command specified"


def protocol_parse(type, payload):
    re_data = ''
    cmd = ''
    params = []
    try:
        if type == protocol_request_type["node_list_cpu"]:
            digi_debug("Node manager, receive message: %s"%("node_list_cpu"), 7)
            try:
                re_data = str(getCPUinfo())
            except:
                raise DigioceanfsError
        elif type == protocol_request_type["node_list_nic"]:
            digi_debug("Node manager, receive message: %s"%("node_list_nic"), 7)
            try:
                re_data = str(getNICinfo())
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["node_list_disk"]:
            digi_debug("Node manager, receive message: %s"%("node_list_disk"), 7)
            try:
                re_data = str(amanager.retrieve_all_disk_info())
                #collect_result(re_data)
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["node_reset_disk"]:
            digi_debug("Node manager receive message: %s"%("node_reset_disk"), 7)
            try:
                re_data = str((amanager.reset_disk(payload)))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["node_format_disk"]:
            digi_debug("Node manager receive message: %s"%("node_format_disk"), 7)
            try:
                re_data = str((amanager.format_disk(payload)))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["node_smart_enable"]:
            digi_debug("Node manager, receive message: %s"%("node_smart_enable"), 7)
            try:
                re_data = str(amanager.smart_enable(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["node_smart_disable"]:
            digi_debug("Node manager, receive message: %s"%("node_smart_disable"), 7)
            try:
                re_data = str(amanager.smart_disable(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["node_smart_status"]:
            digi_debug("Node manager, receive message: %s"%("node_smart_status"), 7)
            try:
                re_data = str(amanager.smart_status(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["node_smart_start"]:
            digi_debug("Node manager, receive message: %s"%("node_smart_start"), 7)
            try:
                re_data = str(amanager.smart_start(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["node_smart_stop"]:
            digi_debug("Node manager, receive message: %s"%("node_smart_stop"), 7)
            try:
                re_data = str(amanager.smart_stop(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["node_smart_info"]:
            digi_debug("Node manager, receive message: %s"%("node_smart_info"), 7)
            try:
                re_data = str(amanager.smart_info(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["node_list_staticsysinfo"]:
            digi_debug("Node manager, receive message: %s"%("node_list_staticsysinfo"), 7)
            try:
                re_data = str(getStaticSYSinfo())
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["node_list_dynamicsysinfo"]:
            digi_debug("Node manager, receive message: %s"%("node_list_dynamicsysinfo"), 7)
            try:
                re_data = str(getDynamicSYSinfo())
                #digi_debug(amanager.get_dynamic_info())
                #re_data = amanager.get_dynamic_info()
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["node_update_disk"]:
            digi_debug("Node manager, receive message: %s"%("node_update_disk"), 7)
            try:
                re_data = str(amanager.update_disks())
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["node_set_hosts"]:
            digi_debug("Node manager, receive message: %s"%("node_set_hosts"), 7)
            try:
                re_data = str(amanager.set_hosts(payload))
            except:
                raise DigioceanfsError
           
        elif type == protocol_request_type["node_set_hostname"]:
            digi_debug("Node manager, receive message: %s"%("node_set_hostname"), 7)
            try:
                re_data = str(amanager.set_hostname(payload))
            except:
                raise DigioceanfsError        
            
        elif type == protocol_request_type["node_cifs_status"]:
            digi_debug("Node manager, receive message: %s"%("node_cifs_status"), 7)
            try:
                re_data = str(amanager.cifs_status())
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["node_cifs_restart"]:
            digi_debug("Node manager, receive message: %s"%("node_cifs_restart"), 7)
            try:
                re_data = str(amanager.cifs_restart())
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["node_nfs_status"]:
            digi_debug("Node manager, receive message: %s"%("node_nfs_status"), 7)
            try:
                re_data = str(amanager.nfs_status())
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["node_nfs_restart"]:
            digi_debug("Node manager, receive message: %s"%("node_nfs_restart"), 7)
            try:
                re_data = str(amanager.nfs_restart())
            except:
                raise DigioceanfsError    

        elif type == protocol_request_type["node_ctdb_set_post"]:
            digi_debug("Node manager, receive message: %s"%("node_ctdb_set_post"), 7)
            try:
                re_data = str(amanager.node_ctdb_set_post(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["node_ctdb_list"]:
            digi_debug("Node manager, receive message: %s"%("node_ctdb_list"), 7)
            try:
                re_data = str(amanager.node_ctdb_list())
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["node_get_hosts"]:
            digi_debug("Node manager, receive message: %s"%("node_get_hosts"), 7)
            re_data = str(amanager.get_hosts())

        elif type == protocol_request_type["node_get_ipmi_ip_info"]:
            digi_debug("Node manager, receive message: %s"%("node_get_ipmi_ip_info"), 7)
            re_data = str(amanager.node_get_ipmi_ip_info())

        elif type == protocol_request_type["node_issue_ipmi_conf"]:
            digi_debug("Node manager, receive message: %s"%("node_issue_ipmi_conf"), 7)
            try:
                re_data = str(amanager.node_issue_ipmi_conf(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["node_set_ipmi_ip"]:
            digi_debug("Node manager, receive message: %s"%("node_set_ipmi_ip"), 7)
            try:
                re_data = str(amanager.node_set_ipmi_ip(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["node_destroy"]:
            digi_debug("Node manager, receive message: %s"%("node_destroy"), 7)
            try:
                re_data = str(amanager.destroy(payload))
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["node_replace_nodisk"]:
            digi_debug("Node manager, receive message: %s"%("node_replace_nodisk"), 7)
            try:
                re_data = str(amanager.replace_nodisk(payload))
            except:
                raise DigioceanfsError            
    
        elif type == protocol_request_type["node_check_license"]:
            digi_debug("Node manager, receive message: %s"%("node_check_license"), 7)
            try:
                re_data = str(amanager.check_license(payload))
            except:
                raise DigioceanfsError            
    
        elif type == protocol_request_type["node_get_device_id"]:
            digi_debug("Node manager, receive message: %s"%("node_get_device_id"), 7)
            try:
                re_data = str(amanager.get_device_id(payload))
            except:
                raise DigioceanfsError            
    
        elif type == protocol_request_type["node_service_list_init"]:
            digi_debug("Node manager, receive message: %s"%("node_service_list_init"), 7)
            try:
                amanager.service_list_init()
                re_data = "1"
            except:
                raise DigioceanfsError            
    
        elif type == protocol_request_type["node_service_info_clear"]:
            digi_debug("Node manager, receive message: %s"%("node_service_info_clear"), 7)
            try:
                re_data = amanager.service_info_clear()
            except:
                raise DigioceanfsError            
    
        elif type == protocol_request_type["service_init"]:
            digi_debug("Node manager, receive message: %s"%("service_init"), 7)
            try:
                re_data = str(amanager.service_init(payload))
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["service_set_spare"]:
            digi_debug("Node manager receive message: %s"%("service_set_spare"), 7)
            try:
                re_data = str((amanager.service_set_spare_disk(payload)))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["service_create_pre"]:
            digi_debug("Node manager, receive message: %s"%("service_create_pre"), 7)
            try:
                re_data = str(amanager.service_create_pre(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["service_create_post"]:
            digi_debug("Node manager, receive message: %s"%("service_create_post"), 7)
            try:
                re_data = str(amanager.service_create_post(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["service_replace_pre"]:
            digi_debug("Node manager, receive message: %s"%("service_replace_pre"), 7)
            try:
                re_data = str(amanager.service_replace_pre(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["service_replace_post"]:
            digi_debug("Node manager, receive message: %s"%("service_replace_post"), 7)
            try:
                re_data = str(amanager.service_replace_post(payload))
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["service_get_command_status"]:
            digi_debug("Node manager, receive message: %s"%("service_get_command_status"), 7)
            try:
                re_data = str(amanager.service_get_command_status(payload))
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["service_heal_disperse"]:
            digi_debug("Node manager, receive message: %s"%("service_heal_disperse"), 7)
            try:
                re_data = str(amanager.service_heal_disperse(payload))
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["service_auto_replace_disk"]:
            digi_debug("Node manager, receive message: %s"%("service_auto_replace_disk"), 7)
            try:
                re_data = str(amanager.service_auto_replace_disk(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["service_start_pre"]:
            digi_debug("Node manager, receive message: %s"%("service_start_pre"), 7)
            try:
                re_data = str(amanager.service_start_pre(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["service_start_post"]:
            digi_debug("Node manager, receive message: %s"%("service_start_post"), 7)
            try:
                re_data = str(amanager.service_start_post(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["service_stop_pre"]:
            digi_debug("Node manager, receive message: %s"%("service_stop_pre"), 7)
            try:
                re_data = str(amanager.service_stop_pre(payload))
            except:
                raise DigioceanfsError
       
        elif type == protocol_request_type["service_stop_post"]:
            digi_debug("Node manager, receive message: %s"%("service_stop_post"), 7)
            try:
                re_data = str(amanager.service_stop_post(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_stop_pre_rollback"]:
            digi_debug("Node manager, receive message: %s"%("service_stop_pre_rollback"), 7)
            try:
                re_data = str(amanager.service_stop_pre_rollback(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_destroy_post"]:
            digi_debug("Node manager, receive message: %s"%("service_destroy_post"), 7)
            try:
                re_data = str(amanager.service_destroy_post(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_add_disk_post"]:
            digi_debug("Node manager, receive message: %s"%("service_add_disk_post"), 7)
            try:
                re_data = str(amanager.service_add_disk_post(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_start"]:
            digi_debug("Node manager, receive message: %s"%("service_start"), 7)
            try:
                re_data = str(amanager.service_start(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_stop"]:
            digi_debug("Node manager, receive message: %s"%("service_stop"), 7)
            try:
                re_data = str(amanager.service_stop(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_destroy"]:
            digi_debug("Node manager, receive message: %s"%("service_destroy"), 7)
            try:
                re_data = str(amanager.service_destroy(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_status"]:
            digi_debug("Node manager, receive message: %s"%("service_status"), 7)
            try:
                re_data = str(amanager.service_status(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_extend"]:
            digi_debug("Node manager, receive message: %s"%("service_extend"), 7)
            try:
                re_data = str(amanager.service_extend(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_undo_extend"]:
            digi_debug("Node manager, receive message: %s"%("service_undo_extend"), 7)
            try:
                re_data = str(amanager.service_undo_extend(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_online_extend"]:
            digi_debug("Node manager, receive message: %s"%("service_online_extend"), 7)
            try:
                re_data = str(amanager.service_online_extend(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_restart"]:
            digi_debug("Node manager, receive message: %s"%("service_restart"), 7)
            try:
                re_data = str(amanager.service_restart(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_replace"]:
            digi_debug("Node manager, receive message: %s"%("service_replace"), 7)
            try:
                re_data = str(amanager.service_replace(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_cifs_start"]:
            digi_debug("Node manager, receive message: %s"%("service_cifs_start"), 7)
            try:
                re_data = str(amanager.service_cifs_start(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_cifs_stop"]:
            digi_debug("Node manager, receive message: %s"%("service_cifs_stop"), 7)
            try:
                re_data = str(amanager.service_cifs_stop(payload))
            except:
                raise DigioceanfsError        
                    
        elif type == protocol_request_type["service_cifs_status"]:
            digi_debug("Node manager, receive message: %s"%("service_cifs_status"), 7)
            try:
                re_data = str(amanager.service_cifs_status(payload))
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["service_cifs_restart_node"]:
            digi_debug("Node manager, receive message: %s"%("service_cifs_restart_node"), 7)
            re_data = str(amanager.service_cifs_restart_node(payload))
            try:
                re_data = str(amanager.service_cifs_restart_node(payload))
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["service_cifs_restart_service"]:
            digi_debug("Node manager, receive message: %s"%("service_cifs_restart_service"), 7)
            try:
                re_data = str(amanager.service_cifs_restart_service(payload))
            except:
                raise DigioceanfsError    
            
        elif type == protocol_request_type["service_cifs_list_user"]:
            digi_debug("Node manager, receive message: %s"%("service_cifs_list_user"), 7)
            try:
                re_data = str(amanager.service_cifs_list_user(payload))
            except:
                raise DigioceanfsError
        
        elif type == protocol_request_type["service_cifs_list_links"]:
            digi_debug("Node manager, receive message: %s"%("service_cifs_list_links"), 7)
            try:
                re_data = str(amanager.service_cifs_list_links(payload))
            except:
                raise DigioceanfsError
        
        elif type == protocol_request_type["service_cifs_del_links"]:
            digi_debug("Node manager, receive message: %s"%("service_cifs_del_links"), 7)
            try:
                re_data = str(amanager.service_cifs_del_links(payload))
            except:
                raise DigioceanfsError
        
        elif type == protocol_request_type["service_cifs_add_user"]:
            digi_debug("Node manager, receive message: %s"%("service_cifs_add_user"), 7)
            try:
                re_data = str(amanager.service_cifs_add_user(payload))
            except:
                raise DigioceanfsError    
    
        elif type == protocol_request_type["service_cifs_add_user_rollback"]:
            digi_debug("Node manager, receive message: %s"%("service_cifs_add_user_rollback"), 7)
            try:
                re_data = str(amanager.service_cifs_add_user_rollback(payload))
            except:
                raise DigioceanfsError    
    
        elif type == protocol_request_type["service_cifs_del_user"]:
            digi_debug("Node manager, receive message: %s"%("service_cifs_del_user"), 7)
            try:
                re_data = str(amanager.service_cifs_del_user(payload))
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["service_cifs_del_user_rollback"]:
            digi_debug("Node manager, receive message: %s"%("service_cifs_del_user_rollback"), 7)
            try:
                re_data = str(amanager.service_cifs_del_user_rollback(payload))
            except:
                raise DigioceanfsError    
    
        elif type == protocol_request_type["service_nfs_start"]:
            digi_debug("Node manager, receive message: %s"%("service_nfs_start"), 7)
            try:
                re_data = str(amanager.service_nfs_start(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_nfs_stop"]:
            digi_debug("Node manager, receive message: %s"%("service_nfs_stop"), 7)
            try:
                re_data = str(amanager.service_nfs_stop(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_nfs_status"]:
            digi_debug("Node manager, receive message: %s"%("service_nfs_status"), 7)
            try:
                re_data = str(amanager.service_nfs_status(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_nfs_list_user"]:
            digi_debug("Node manager, receive message: %s"%("service_nfs_list_user"), 7)
            try:
                re_data = str(amanager.service_nfs_list_user(payload))
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["service_nfs_list_links"]:
            digi_debug("Node manager, receive message: %s"%("service_nfs_list_links"), 7)
            try:
                re_data = str(amanager.service_nfs_list_links(payload))
            except:
                raise DigioceanfsError
        
        elif type == protocol_request_type["service_nfs_del_links"]:
            digi_debug("Node manager, receive message: %s"%("service_nfs_del_links"), 7)
            try:
                re_data = str(amanager.service_nfs_del_links(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["service_nfs_add_user"]:
            digi_debug("Node manager, receive message: %s"%("service_nfs_add_user"), 7)
            try:
                re_data = str(amanager.service_nfs_add_user(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_nfs_add_user_rollback"]:
            digi_debug("Node manager, receive message: %s"%("service_nfs_add_user_rollback"), 7)
            try:
                re_data = str(amanager.service_nfs_add_user_rollback(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_nfs_del_user"]:
            digi_debug("Node manager, receive message: %s"%("service_nfs_del_user"), 7)
            try:
                re_data = str(amanager.service_nfs_del_user(payload))
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["service_nfs_del_user_rollback"]:
            digi_debug("Node manager, receive message: %s"%("service_nfs_del_user_rollback"), 7)
            try:
                re_data = str(amanager.service_nfs_del_user_rollback(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_afr_info"]:
            digi_debug("Node manager, receive message: %s"%("service_afr_info"), 7)
            try:
                re_data = str(amanager.service_afr_info(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_afr_info_topage"]:
            digi_debug("Node manager, receive message: %s"%("service_afr_info_topage"), 7)
            try:
                re_data = str(amanager.service_afr_info_topage(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_afr_info_topage_search"]:
            digi_debug("Node manager, receive message: %s"%("service_afr_info_topage_search"), 7)
            try:
                re_data = str(amanager.service_afr_info_topage_search(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_afr_diff"]:
            digi_debug("Node manager, receive message: %s"%("service_afr_diff"), 7)
            try:
                re_data = str(amanager.service_afr_diff(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_afr_syn"]:
            digi_debug("Node manager, receive message: %s"%("service_afr_syn"), 7)
            try:
                re_data = str(amanager.service_afr_syn(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_afr_expand"]:
            digi_debug("Node manager, receive message: %s"%("service_afr_expand"), 7)
            try:
                re_data = str(amanager.service_afr_expand(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["service_afr_shrink"]:
            digi_debug("Node manager, receive message: %s"%("service_afr_shrink"), 7)
            try:
                re_data = str(amanager.service_afr_shrink(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["raid_create"]:
            digi_debug("Node manager, receive message: %s"%("raid_create"), 7)
            try:
                re_data = str(amanager.raid_create(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["raid_del"]:
            digi_debug("Node manager, receive message: %s"%("raid_del"), 7)
            try:
                re_data = str(amanager.raid_del(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["raid_hs_set"]:
            digi_debug("Node manager, receive message: %s"%("raid_hs_set"), 7)
            try:
                re_data = str(amanager.raid_hs_set(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["raid_hs_del"]:
            digi_debug("Node manager, receive message: %s"%("raid_hs_del"), 7)
            try:
                re_data = str(amanager.raid_hs_del(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["raid_active"]:
            digi_debug("Node manager, receive message: %s"%("raid_active"), 7)
            try:
                re_data = str(amanager.raid_active(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["raid_disactive_disk"]:
            digi_debug("Node manager, receive message: %s"%("raid_disactive_disk"), 7)
            try:
                re_data = str(amanager.raid_disactive_disk(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["nic_fake_ip_set"]:
            digi_debug("Node manager, receive message: %s"%("nic_fake_ip_set"), 7)
            try:
                re_data = str(amanager.nic_fake_ip_set(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["nic_ip_set"]:
            digi_debug("Node manager, receive message: %s"%("nic_ip_set"), 7)
            try:
                re_data = str(amanager.nic_ip_set(payload))
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["node_init"]:
            digi_debug("Node manager, receive message: %s"%("node_init"), 7)
            try:
                re_data = str(amanager.node_init(payload))
            except Exception, e:
                print traceback.print_exc(e)
                digi_debug(e, 3)
                raise DigioceanfsError
        
        elif type == protocol_request_type["bond_set"]:
            digi_debug("Node manager, receive message: %s"%("bond_set"), 7)
            try:
                re_data = str(amanager.bond_set(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["bond_del"]:
            digi_debug("Node manager, receive message: %s"%("bond_del"), 7)
            try:
                re_data = str(amanager.bond_del(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["node_sync_sms_conf"]:
            digi_debug("Node manager, receive message: %s"%("node_sync_sms_conf"), 7)
            try:
                re_data = str(amanager.sync_sms_conf(payload))
            except:
                raise DigioceanfsError

        elif type == protocol_request_type["get_GSM_message_center_number"]:
            digi_debug("Node manager, receive message: %s"%("get_GSM_message_center_number"), 7)
            try:
                re_data = str(getGSMMessageCenterNumber())
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["replace_fetch_disk"]:
            digi_debug("Node manager, receive message: %s"%("replace_fetch_disk"), 7)
            try:
                re_data = str(amanager.replace_fetch_disk(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["replace_check_disk"]:
            digi_debug("Node manager, receive message: %s"%("replace_check_disk"), 7)
            try:
                re_data = str(amanager.replace_check_disk(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["replace_destroy_disk"]:
            digi_debug("Node manager, receive message: %s"%("replace_destroy_disk"), 7)
            try:
                re_data = str(amanager.replace_destroy_disk(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["replace_initial_disk"]:
            digi_debug("Node manager, receive message: %s"%("replace_initial_disk"), 7)
            try:
                re_data = str(amanager.replace_initial_disk(payload))
            except:
                raise DigioceanfsError
    
        elif type == protocol_request_type["node_login_check"]:
            digi_debug("Node manager, receive message: %s"%("node_login_check"), 7)
            try:
                re_data = str(amanager.node_login_check())
            except:
                raise DigioceanfsError
            
        elif type == protocol_request_type["msg_handler_lock"]:
            digi_debug("Node manager, receive message: %s"%("msg_handler_lock"), 7)
            try:
                re_data = str(amanager.msg_handler_lock(payload))
            except  Exception,e:
                print traceback.print_exc(e)
                raise DigioceanfsError
            
        elif type == protocol_request_type["msg_handler_unlock"]:
            digi_debug("Node manager, receive message: %s"%("msg_handler_unlock"), 7)
            try:
                re_data = str(amanager.msg_handler_unlock(payload))
            except Exception,e:
                print traceback.print_exc(e)
                raise DigioceanfsError
            
        elif type == protocol_request_type[RSYSLOG_REQUEST]:
            digi_debug("Node manager, receive message: %s"%(RSYSLOG_REQUEST),7)
            try:
                package = simplejson.loads(payload)
                cmd     = package[0]
                params  = []
                for pack in package[1] :
                    params.append(str(pack))
                    
                re_data = str(rsyslog_utils.rsyslog_adapter(str(cmd), params))
                
                digi_debug("Node manager, return value: %s"%(re_data),7)
            except Exception:
                # exc_type, exc_value, exc_traceback = sys.exc_info()
                # print "*** print_tb:"
                # traceback.print_tb(exc_traceback, limit = 1, file=sys.stdout)
                # print "*** print_exception:"
                # traceback.print_exception(exc_type, exc_value, exc_traceback, limit = 2, file=sys.stdout)
                # print "*** print_exc:"
                # traceback.print_exc()
                # print "*** format_exc, first and last line:"
                # formatted_lines = traceback.format_exc().splitlines()
                # print formatted_lines[0]
                # print formatted_lines[-1]
                # print "*** format_exception:"
                # print repr(traceback.format_exception(exc_type, exc_value, exc_traceback))
                # print "*** extract_tb:"
                # print repr(traceback.extract_tb(exc_traceback))
                # print "*** format_tb:"
                # print repr(traceback.format_tb(exc_traceback))
                # print "*** tb_lineno:", exc_traceback.tb_lineno
                                                                                    
                digi_debug("Node manager, receive message: %s raise exception"%(RSYSLOG_REQUEST),3)
                raise DigioceanfsError
        elif type == protocol_request_type["clear_management_node"]:
            digi_debug("Node manager, receive message: %s"%("clear_management_node"), 7)
            try:
                clear_management_node()
                re_data = "1"
            except Exception:
                digi_debug("Node manager, receive message: %s raise exception"%("clear_management_node"), 3)
                raise DigioceanfsError
        elif type == protocol_request_type["clear_hosts"]:
            digi_debug("Node manager, receive message: %s"%("clear_hosts"),7)
            try:
                clear_hosts()
                re_data = "1"
            except Exception:
                digi_debug("Node manager, receive message: %s raise exception"%("clear_hosts"), 3)
                raise DigioceanfsError
        elif type == protocol_request_type["set_config_file"]:
            digi_debug("Node manager, receive message: %s"%("set_config_file"),7)
            try:
                package = simplejson.loads(payload, encoding='ascii')
                file_path = package[0]
                data_img = StringIO.StringIO(package[1])
                set_config_file(file_path, data_img)
                re_data = "1"
            except Exception:
                digi_debug("Node manager, receive message: %s raise exception"%("set_config_file"), 3)
                raise DigioceanfsError 
        else:
            digi_debug("Node manager, receive message: %s, unhandle ..." % type, 5)
            re_data = ''
    except DigioceanfsError,e:
        digi_debug(e.value, 3)
        re_data = e.value
    print re_data
    collect_result(re_data)
    #return re_data

#def proc_queue_handler():
#    print "handle processing queue"

def protocol_post():
    amanager.post_option()

def msg_lock_acquire ():
    amanager.acquire_msg_lock()

def msg_lock_release ():
    amanager.release_msg_lock()

def collect_result(result):
    PROC_QUEUE.put(result)

def collect_msg(result):
    MSG_QUEUE.put(result)
#amanager = node_manager()


#these methods provide an way to communicate between nodes
def node_messager_parse(type, payload):
    re_data = None
    digi_debug('receive message: %s -----------------%s' % (type, payload), 3)
    try:
        if type == node_messager_type["remote_get_management_info"]:
            digi_debug("Node manager, receive message: %s"%("remote_get_management_info"), 7)
            tmp_data = get_management_node()
            re_data = ' '.join(tmp_data)
        elif type == node_messager_type["remote_set_manager_ip"]:
            digi_debug("Node manager, receive message: %s"%("remote_set_manager_ip"), 7)
            host_name = payload.split()[0]
            host_ip = payload.split()[1]
            re_data = set_management_node(host_name, host_ip)
        elif type == node_messager_type["afr_passive_unlock"]:
            digi_debug("Node manager, receive message: %s"%("afr_passive_unlock"), 7)
            re_data = amanager.nm_afr_passive_unlock(payload)
        elif type == node_messager_type["send_message"]:
            digi_debug("Node messager, receive message: %s"%(payload), 7)
            re_data = amanager.message_handler(payload)
            re_data = '1'
        else:
            re_data = ""
    except Exception, e:
        print traceback.print_exc(e)
        raise DigioceanfsError
    digi_debug("Node messager, return date: %s" % re_data)
    collect_msg(re_data)
    #return re_data

def node_messager_post():
    amanager.post_option()

def node_messager_lock():
    amanager.node_msg_lock()

def node_messager_unlock():
    amanager.node_msg_unlock()

def node2digi_messager_thread():
    try:
        s = DigiServer(('0.0.0.0', 9997),
                       protocol_parse,
                       protocol_post,
                       msg_lock_acquire,
                       msg_lock_release,
                       proc_queue_handler)

        s.start_loop()
    except Exception, e:
        digi_debug("Threading: digi_mesaager caught exception: %s" % traceback.print_exc(e), 3)
        return None 

def node2node_messager_thread():
    try:
        s = DigiServer(('0.0.0.0', NODE_MESSAGER_PORT),
                   node_messager_parse,
                   node_messager_post,
                   node_messager_lock,
                   node_messager_unlock,
                   msg_queue_handler)
                   #'node_messager')

        s.start_loop()
    except Exception, e:
        digi_debug("Threading: node_mesaager caught exception: %s" % traceback.print_exc(e), 3)
        return None 

def proc_queue_handler():
    try:
        return (PROC_QUEUE.empty(), PROC_QUEUE.get())
    except Exception, e:
        digi_debug("Node manager, caught expection: %s when collect result to queue" % e, 3)
        return (False, "error raise in queue") 

def msg_queue_handler():
    try:
        return (MSG_QUEUE.empty(), MSG_QUEUE.get())
    except Exception, e:
        digi_debug("Node manager, caught expection: %s when collect result to queue" % e, 3)
        return (False, "error raise in queue")
     
def id_to_name(key_id):
    return "node-" + key_id
        
def name_to_id(name):
    return name[5:]

def create_id_ip_dict():
    #hosts_fd = open(HOSTS_FILE, "r")
    hosts_fd = open(settings.HOSTFILE, "r")
    contents = hosts_fd.readlines()
    query_dict = {}
    for line in contents:
        if NODEMARK in line:
            ip = line.split()[0]
            name = line.split()[1]
            key_id = name_to_id(name)
            query_dict[key_id] = ip
    return query_dict

def sort_dict_dec(query_dict):
    return sorted(query_dict.items(), cmp=lambda x,y: cmp(string.atoi(x), string.atoi(y)),key=lambda query_dict:query_dict[0], reverse=True)
    
def get_management_node():
    manage_fd = open(MANAGEMENT_NODE_FILE_PATH, "r")
    contents = manage_fd.readlines()
    node_tuple = ()
    for line in contents:
        if NODEMARK in line:
            node_name = line.split()[0]
            ip = line.split()[1]
            node_tuple = (node_name, ip)
    return node_tuple     
        
def set_management_node(name, ip):
    manage_fd = file(MANAGEMENT_NODE_FILE_PATH, "w")
    a_line = name+" "+ip+" "+NODEMARK
    manage_fd.write(a_line)
    manage_fd.close()
    digi_debug("Node manager, set_management_node %s %s"%(name, ip), 7)
    return "1"

def clear_management_node():
    os.system("cat /dev/null > /etc/digioceanfs/management_node")
    digi_debug("Node manager, clear management info on node", 5)
    
def clear_hosts():
    #rfd = open("/etc/hosts", "r")
    rfd = open(settings.HOSTFILE, "r")
    lines = rfd.readlines()
    new_lines = []
    for aline in lines:
        if NODEMARK not in aline:
            new_lines.append(aline)
    rfd.close()
    rst_str = ''.join(new_lines)
    #wfd = open("/etc/hosts", "w")
    wfd = open(settings.HOSTFILE, "w")
    wfd.write(rst_str)
    wfd.close()
    
    if os.path.exists(settings.IPMICONF):
        os.system("rm -rf %s" % settings.IPMICONF)
    
def remote_get_management_info(node_name,ip_addr):
    anode = digi_manager.node(None,
                node_name,
                ip_addr = ip_addr,
                connect_ahead = False)
    ret = anode.remote_call(protocol_request_type["get_management_info"], None)
    anode.disconnect()
    return ret

def remote_set_manager_ip(node_name, ip_addr, arg):
    anode = digi_manager.node(None,
                node_name,
                ip_addr = ip_addr,
                connect_ahead = False)
    ret = anode.remote_call(protocol_request_type["set_manager_ip"], arg)
    anode.disconnect()
    return ret

def check_command(partten):
    NProcessManager().init(partten)
    digi_debug("Node Manager, check partten %s commands" % partten)
    #for p in NProcessManager().getProcessByLabel(partten):
    #    print p.pid, p.label

def send_command(host_info_list, command, data):
    print 'send command: %s' % command
    node_obj_list = []
    node_obj_list = [digi_manager.node(None, node_name, ip_addr = ip, connect_ahead = False) for (node_name, ip) in host_info_list]
    try:
        node_thread_pool = ClusterThreadPool(len(node_obj_list))
        node_thread_pool.initPool(data=node_obj_list, target_info=('remote_call', [protocol_request_type["%s" % command], data], dict()))
        node_thread_pool.start_threads()
        node_thread_pool.clear_threads()
        thread_result = node_thread_pool.get_results()
    except Exception, e:
        print traceback.print_exc(e)
        digi_debug("Send Command, Node manager multi threading tought exception: %s" % e,3)
    else:
        pass
    finally:
        pass
    print thread_result
    for result in thread_result:
        anode = result[0]
        ret = result[1]
        print command, anode ,ret, data
        if anode:
            anode.disconnect()
        print '------------------------------- aaaaa'
        if ret == '1':
            digi_debug("Node manager, %s return %s on node: %s" % (command, ret, anode), 7)
            return anode
    digi_debug("Node manager, %s return %s" % (command, None))
    return None

def send_message(host_info_list, msg):
    nclient_obj_list = [NClient(ip,node_name) for (node_name, ip) in host_info_list]
    try:
        node_thread_pool = ClusterThreadPool(len(nclient_obj_list))
        node_thread_pool.initPool(data=nclient_obj_list, target_info=('send_notify_message', [msg], dict()))
        node_thread_pool.start_threads()
        node_thread_pool.clear_threads()
        thread_result = node_thread_pool.get_results()
    except Exception, e:
        print traceback.print_exc(e)
        digi_debug("Send Message, Node manager multi threading tought exception: %s" % e,3)
    else:
        pass
    finally:
        pass
    for result in thread_result:
        aclient = result[0]
        ret = result[1]
        if not ret:
            digi_debug("Node manager send message to %s failed" % aclient.ip, 3)
        else:
            continue

class LocalBreak(Exception): 
    pass

class NClient(object):
    def __init__(self, ip, node_name=''):
        self.ip = ip
        self.node_name = node_name

    def send_notify_message(self, message):
        data = simplejson.dumps([message], encoding='ascii', ensure_ascii=True)
        transport = DigiClient((self.ip, NODE_MESSAGER_PORT))
        if not transport.connected:
            ret = transport.connect()
            if ret != 0:
                digi_debug("Node manager send notify message, can not connect to node:%s, return:%d"%(self.node_name, ret),5)
                digi_debug("Node manager send notify message, got error message from transport:%s"%(transport.get_error_message()),3)
                return None
        ret = transport.submit(1003, data)
        if not ret:
            digi_debug("Node manager send notify message, transport submit to node:%s failed, return %s"%(self.node_name, ret),5)
            return None
        try:
            ret = transport.receive()
        except Exception,e:
            digi_debug("Node manager send notify message, caught expception: %s" %(e), 3)
            return None
        transport.disconnect()
        return ret


def recover_configures():
    tar_name = latest_pack()
    if tar_name == None:
        digi_debug("Node manager, call latest_pack() return None",3)
    else:
        #curr = os.getcwd()
        #os.chdir("/")
        os.system("rm -rf /etc/digioceanfs_manager/* &> /dev/null")
        os.system("tar zxvf %s -C / &> /dev/null"%(tar_name))
        #os.chdir(curr)
        digi_debug("Node manager, recover_configures() succeed",5)

def heart_beat_thread():
    sleep_time = 1
    failed_times = 0
    max_failed_times = 3
    print_flag = True
    
    while True:
        time.sleep(sleep_time)
        try:
            node_tuple = get_management_node()
            if node_tuple == ():
                if print_flag == True:
                    digi_debug("Node manager, does not specify the management node", 3)
                query_dict = create_id_ip_dict()
                if query_dict == {}:
                    if print_flag == True:
                        #digi_debug("There isn't any node information in /etc/hosts")
                        digi_debug("Node manager, there isn't any node information in %s" % settings.HOSTFILE, 3)
                        print_flag = False
                    continue
                sorted_list = sort_dict_dec(query_dict)
                for key_id in sorted_list:
                    name = id_to_name(key_id[0])
                    ipaddr = key_id[1]
                    ret_data = remote_get_management_info(name, ipaddr)
                    if ret_data and (ret_data != 'none') and (len(ret_data) != 0):
                        node_name = ret_data.split()[0]
                        node_ip = ret_data.split()[1]
                        set_management_node(node_name, node_ip)
                        break
            else:
                print_flag = True
                while True:
                    time.sleep(sleep_time)
                    node_tuple = get_management_node() 
                    if node_tuple != ():  
                        if not PING(node_tuple[1]):
                            failed_times = failed_times + 1
                            if failed_times >= max_failed_times:
                                current_id = name_to_id(node_tuple[0])
                                query_dict = create_id_ip_dict()
                                if query_dict == {}:
                                    if print_flag == True:
                                        #digi_debug("There isn't any node information in /etc/hosts")
                                        digi_debug("Node manager, there isn't any node information in %s" % settings.HOSTFILE, 3)
                                        print_flag = False
                                else:
                                    if query_dict.has_key(current_id):
                                        del query_dict[current_id]
                                        if query_dict == {}:
                                            if print_flag == True:
                                                #digi_debug("There isn't any other node information in /etc/hosts")
                                                digi_debug("Node manager, there isn't any node information in %s" % settings.HOSTFILE, 3)
                                                print_flag = False
                                            continue
                                    sorted_list = sort_dict_dec(query_dict)
                                    for key_id in sorted_list:
                                        node_name = id_to_name(key_id[0])
                                        if PING(node_name):
                                            set_management_node(node_name, query_dict[key_id[0]])
                                            print_flag = True
                                            #handle = os.popen("hostname")
                                            #host_name = handle.read().strip()
                                            #handle.close()
                                            #if host_name == node_name:
                                            recover_configures()
                                            raise LocalBreak()
                                    else:
                                        if print_flag == True:
                                            digi_debug("Node manager, there isn't any node can be connected", 3)
                                            print_flag = False
                        else:
                            failed_times = 0
        except LocalBreak:
            pass
       
def add_to_fstab(service_name):
    try:
        volfile = service_dir_prefix + "/" + service_name + "/" + service_name + ".vol"
        mountpoint = mount_dir_prefix + "/" + service_name
        options="rw,allow_other,default_permissions,max_read=131072"
        line_to_add = volfile + " " + mountpoint + " " + "digioceanfs" + " " + options + " " + "0" + " " + "0" + "\n"
        handle = open("/etc/fstab","r")
        content = handle.readlines()
        handle.close()
        for aline in content:
            if aline[0] == "#":
                continue
            if len(aline.split()) < 2:
                continue
            if aline.split()[1] == mountpoint:
                break
        else:
            handle = open("/etc/fstab","a")
            handle.write(line_to_add)
            handle.close()
        return 1
    except Exception,e:
        digi_debug("Node manager, caught exception:%s" % e,3)
        return -1
        
def del_from_fstab(service_name): 
    try:    
        mountpoint = mount_dir_prefix + "/" + service_name
        handle = open("/etc/fstab","r")
        content = handle.readlines()
        handle.close()
        for aline in content:
            if aline[0] == "#":
                continue
            if len(aline.split()) < 2:
                continue
            if aline.split()[1] == mountpoint:
                content.remove(aline)
            
        lines="".join(content)
        handle = open("/etc/fstab","w")
        handle.write(lines)
        handle.close()
        return 1
    except Exception,e:
        digi_debug("Node manager, caught exception:%s" % e,3)
        return -1

node_manager_usage = \
'''
  %prog [options] [service_args]
'''

def node_manager_setup_parser ():
    parser = OptionParser(usage=node_manager_usage)
#    parser.add_option("-f", "--file",
#                      dest="filename", help="filename to write")
    parser.add_option("-L", "--debug-level", type="string", default='Normal',
                      dest="debug_lvl", help="number of subvolumes of a afr")
    parser.add_option("-M", "--mem-test", action="store_true", dest="mem", help="test process mem", default=False)
    return parser

def digioceand_monitor():
    crontime = 60
    while True:
        time.sleep(crontime)
        status = check_digioceand()
        if not status:
            digi_debug("Node Manager, found digioceand not started, start it", 3)
            start_digioceand()
        else:
            digi_debug("Node Manager, found digioceand started", 7)
        check_service_mountpoint()

def notify_message_monitor():
    while True:
        try:
            host_info_list, msg = SNMSG_QUEUE.get()
            send_message(host_info_list,msg)
        except Exception,e:
            digi_debug('notify message monitor, caught exception : %s' % e)

def get_sms_message_str(msg):
    msg_type = ''
    msg_str = ''
    Time = 'CTime' in msg and msg['CTime'] or ''
    if Time:
        Time = time.strftime('%Y-%m-%d %A %X',time.localtime(float(Time)))
    SourceIP = 'SourceIp' in msg and msg['SourceIp'] or ''
    OP = 'OP' in msg and msg['OP'] or ''
    if OP == 'RaidEvent':
        msg_type = 'RaidEvent' in msg and msg['RaidEvent'] or ''
        ErrorNode = 'ErrNode' in msg and msg['ErrNode'] or ''
        RaidName = 'RaidName' in msg and msg['RaidName'] or ''
        if msg_type == 'FailSpare':
            msg_str = "%s %s(%s) raid %s set spare failed" %(Time,ErrorNode,SourceIP,RaidName)
        elif msg_type == 'RebuildStarted':
            msg_str = "%s %s(%s) raid %s rebuild started" %(Time,ErrorNode,SourceIP,RaidName)
        elif msg_type == 'RebuildFinished':
            msg_str = "%s %s(%s) raid %s rebuild finished" %(Time,ErrorNode,SourceIP,RaidName)
        elif msg_type == 'SpareActive':
            msg_str = "%s %s(%s) raid %s spare active" %(Time,ErrorNode,SourceIP,RaidName)
        elif msg_type == 'NewArray':
            msg_str = "%s %s(%s) raid %s has been created" %(Time,ErrorNode,SourceIP,RaidName)
        elif msg_type == 'DeviceDisappeared':
            msg_str = "%s %s(%s) raid %s has been deleted" %(Time,ErrorNode,SourceIP,RaidName)
        elif msg_type == 'degraded':
            msg_str = "%s %s(%s) raid %s has been degraded" %(Time,ErrorNode,SourceIP,RaidName)
        elif msg_type == 'FAILED':
            msg_str = "%s %s(%s) raid %s failed" %(Time,ErrorNode,SourceIP,RaidName)
        else:
            msg_str = "%s %s(%s) %s %s" %(Time,ErrorNode,SourceIP,RaidName,msg_type)
    elif OP == 'NetLink':
        msg_type = 'Event' in msg and msg['Event'] or ''
        ErrorNode = 'ErrNode' in msg and msg['ErrNode'] or ''
        Eth = 'Eth' in msg and msg['Eth'] or ''
        if msg_type == 'SpeedDown':
            msg_str = "%s %s(%s) NIC %s speed down" %(Time,ErrorNode,SourceIP,Eth)
        if msg_type == 'SpeedResume':
            msg_str = "%s %s(%s) NIC %sspeed resume" %(Time,ErrorNode,SourceIP,Eth)
        else:
            msg_str = "%s %s(%s) %s %s" %(Time,ErrorNode,SourceIP,Eth,msg_type)
    elif OP == "Ping":
        msg_type = 'Event' in msg and msg['Event'] or ''                       #Off-line/On-line'
        ErrorNode = 'ErrNode' in msg and msg['ErrNode'] or ''
        PingIP = 'PingIP' in msg and msg['PingIP'] or ''
        msg_str = "%s %s(%s) network status: %s" % (Time,ErrorNode,PingIP,msg_type)
    elif OP == 'Systemdisk':
        msg_type = 'Falg' in msg and msg['Falg'] or ''
        SourceNode = 'SourceNode' in msg and msg['SourceNode'] or ''
        DirName = 'DirName' in msg and msg['DirName'] or ''
        Used = 'Used' in msg and msg['Used'] or ''
        msg_str = "%s %s(%s) directory %s has been used %s is %s" %(Time,SourceNode,SourceIP,DirName,Used,msg_type)
    elif OP == 'SysMsg':
        msg_type = 'MsgName' in msg and msg['MsgName'] or ''
        ErrorNode = 'ErrNode' in msg and msg['ErrNode'] or ''
        Falg = 'Falg' in msg and msg['Falg'] or ''
        if msg_type == 'usedcpu':
            msg_str = "%s %s (%s) cpu used %s" %(Time,ErrorNode,SourceIP,Falg)
        elif msg_type == 'cputemp':
            msg_str = "%s %s(%s) cpu temperature %s" %(Time,ErrorNode,SourceIP,Falg)
        elif msg_type == 'usedmem':
            msg_str = "%s %s(%s) memery used %s" %(Time,ErrorNode,SourceIP,Falg)
        elif msg_type == 'cpufan':
            msg_str = "%s %s(%s) cpu fan %s" %(Time,ErrorNode,SourceIP,Falg)
        else:
            msg_str = "%s %s(%s) %s %s" %(Time,ErrorNode,SourceIP,msg_type,Falg)
    elif OP == 'DiskTemp':
        msg_type = 'DiskTemp'
        ErrorNode = 'ErrNode' in msg and msg['ErrNode'] or ''
        Temp = 'Temp' in msg and msg['Temp'] or ''
        Falg = 'Falg' in msg and msg['Falg'] or ''
        DiskName = 'DiskName' in msg and msg['DiskName'] or ''
        msg_str = "%s %s(%s) %s %s %s" %(Time,ErrorNode,SourceIP,DiskName,Temp,Falg)
    elif OP == 'DiskEvent':
        msg_type = 'DiskEvent' in msg and msg['DiskEvent'] or ''                 #add/remove
        ErrorNode = 'ErrNode' in msg and msg['ErrNode'] or ''
        DiskID = 'DiskID' in msg and msg['DiskID'] or ''
        DiskName = 'DiskName' in msg and msg['DiskName'] or ''
        msg_str = "%s %s(%s) Disk: %s(position: %s) %s" %(Time,ErrorNode,SourceIP,DiskName,DiskID,msg_type)
    #elif OP == 'FileSystemEvent':
    #    SourceNode = 'SourceNode' in msg and msg['SourceNode'] or ''
    #    FileEvent = 'FileEvent' in msg and msg['FileEvent'] or ''
    #    ErrDiskName = 'ErrDiskName' in msg and msg['ErrDiskName'] or ''
    #    FileMountPoint = 'FileMountPoint' in msg and msg['FileMountPoint'] or ''
    #    msg_str = "%s %s %s file system mount point:%s, error disk:%s is %s" %(Time,SourceNode,SourceIP,FileMountPoint,ErrDiskName,FileEvent)
    else:
        msg_str = ''
    return msg_type,msg_str

def send_sms_message(msg):
    msgstr = ''
    msg = simplejson.loads(msg)
    CTRADDR = ''
    MOBADDR = []
    SMSSTATUS = False
    notify_types = []
    msg_type,msgstr = get_sms_message_str(msg)
    digi_debug("Node Manager,Send sms message: %s" % msgstr,3)
    if os.path.exists('/dev/ttyGSM'):
        if os.path.exists(settings.SMSCONF):
            f = open(settings.SMSCONF,'r')
            smsinfos = pickle.load(f)
            f.close()
            if smsinfos:
                if 'smsp' in smsinfos and smsinfos['smsp']:
                    CTRADDR = str(smsinfos['smsp'])
                if 'mobp' in smsinfos and smsinfos['mobp']:
                    MOBADDR = smsinfos['mobp']
                if 'inuse' in smsinfos and smsinfos['inuse']:
                    SMSSTATUS = smsinfos['inuse']
                if 'ntype' in smsinfos and smsinfos['ntype']:
                    notify_types = smsinfos['ntype']
        if msg_type in notify_types and msgstr:
            if SMSSTATUS:
                if CTRADDR:
                    if MOBADDR:
                        for MOB in MOBADDR:
                            os.system("python /usr/local/digioceanfs_manager/scripts/send_sms.py %s %s %s %s" % (0,CTRADDR,MOB,msgstr))
                    else:
                        digi_debug("Node Manager, Mob number not be set",3)
                        pass
                else:
                    digi_debug("Node Manager, Message Center Number not be set",3)
                    pass
            else:
                digi_debug("Node Manager, SMS Disabled",3)
                pass
        else:
            digi_debug("Node Manager, Message won't be send",3)
            pass
    else:
        digi_debug('Node Manager, GSM Modem not found',3)
        pass


def get_all_nodes():
    nodes_list = []
    nodes_img = get_config_file(settings.HOSTFILE)
    nodes_lines = nodes_img.readlines()
    for line in nodes_lines:
        try:
            if line.find("####DigioceanfsNode####") >= 0:
                ip, qhostname, hostname, flag = line.split()
                node_name = qhostname
                nodes_list.append((node_name, ip))
        except Exception,e:
            digi_debug("Node Manager, parse node list error: %s" % traceback.print_exc(e))
            continue
    return nodes_list

class proc_evt(ProcessEvent):
    
    def __init__(self):
        self.record_size = 0
        self.STline = ''
        self.header_line = ''
        
    def init_header(self, filepath):
        try:
            h_lines = ''
            fd = open(filepath, 'r')
            #rawdata = fd.readlines()
            line_data = fd.readline()
            head_lines = ''
            while line_data:
                line_data = fd.readline()
                if 'BBB' in line_data:
                    break
                if 'AAA' in line_data:
                    #fd.seek(len(line_data))
                    print line_data, '===000000'
                else:
                    h_lines += line_data
            fd.close()
        except Excpetion,e :
            fd.close()
            print e
        self.header_line = h_lines
        #return head_lines
        
    def process_IN_CREATE(self, event):  
        file_path = event.path + '/' + event.name
        try:
            fd = open(file_path, 'r')
            #timest = String(time.time())
            #settings.rqueue.put({'timest': timest,'file_content':fd.read(), 'isread':'N'})
            time.sleep(0.1)
            msg = fd.read()
            digi_debug("Node Manager, send message: %s" % msg)
            send_sms_message(msg)
            node_name = amanager.get_hostname()
            j_msg = simplejson.loads(msg)
            if 'OP' in j_msg and 'FileEvent' in j_msg:
                if j_msg['FileEvent'].find("Heal") >= 0:
                    pass
                elif j_msg['FileEvent'] == 'ReplaceBrick':
                    pass
                else:
                    #send_message([host_info for host_info in get_all_nodes() if node_name == host_info[0]], j_msg)
                    SNMSG_QUEUE.put_nowait(([host_info for host_info in get_all_nodes() if node_name == host_info[0]],j_msg))
            else:
                #send_message([host_info for host_info in get_all_nodes() if node_name == host_info[0]], j_msg)
                SNMSG_QUEUE.put_nowait(([host_info for host_info in get_all_nodes() if node_name == host_info[0]],j_msg))
            fd.close()
            #os.system("sudo mv %s %s"%(file_path, file_path+'-r'))
        except Exception,e:
            fd.close()
            print traceback.print_exc(e)
            #os.system("sudo mv %s %s"%(file_path, file_path+'-r'))
            digi_debug("Node Manager, send message error: %s" % traceback.print_exc(e))
    
    def process_IN_MODIFY(self, event):
        print '------------------------------------'
        filepath = os.path.join(event.path, event.name)
        try:
            if not self.header_line:
                self.init_header(filepath)
        except Exception,e:
            print traceback.print_exc(e)
        #print self.header_line, '=============='
        print '------------------------------------'
        now_size = os.stat(filepath).st_size
        if self.record_size:
            increment_size = now_size - self.record_size
            fd = open(filepath, 'r')
            fd.seek(self.record_size)
            increment_content = fd.read()
            fd.close()
            if increment_size and increment_size > 100:
                print increment_content
                time.sleep(0.1)
                # parse nmon result
                try:
                    dynamic = self.header_line+self.STline+increment_content
                    pyNP = pyNmonParser(dynamic)
                    dynamicDict = pyNP.parse()
                    amanager.dynamic_info = pyNP.outputXML()
                except Exception,e:
                    print traceback.print_exc(e)
            elif increment_size <= 100:
                self.STline = increment_content
                print self.STline, '000000-----------00000000'
                time.sleep(0.1)
            else:
                time.sleep(0.1)
        else:
            increment_size = 0
        print 'increment_size: ', increment_size
        print '------------------------------------'
        self.record_size = now_size
        
def notify_handler():
    
    try:
        wm = WatchManager() 
        path_report = "/etc/digioceanfs_manager/reports"
        path_nmon = NMON_PATH
        mask_report = IN_CREATE
        mask_nmon = IN_MODIFY
        notifier = ThreadedNotifier(wm, proc_evt())
        wm.add_watch(path_report, mask_report,rec=True)
        wm.add_watch(path_nmon, mask_nmon,rec=True)
        notifier.start()
    except Exception, e:
        print traceback.print_exc(e)
        
def nmon_handler():
    print '===-=-=-=-=-=-='
    try:
        nty = notify(NMON_PATH, proc_evt())
        nty.run()
    except Exception, e:
        print traceback.print_exc(e)  

if __name__ == "__main__":
    node_lock_file = open("/var/lock/node_manager_lock","w")
    try:
        fcntl.flock(node_lock_file,fcntl.LOCK_EX | fcntl.LOCK_NB)
    except:
        print "Already have a program is running!"
        sys.exit()
    argv = sys.argv[1:]
    parser = node_manager_setup_parser()
    (options, args) = parser.parse_args(argv)
    os.system("cat /dev/null > %s"%(MANAGEMENT_NODE_FILE_PATH))
    digi_debug("Node manager, init settings, checkout path and command need")
    settings._path_check()
    amanager = node_manager()
    try:
        th1 = threading.Thread(name="DMessager",target=node2digi_messager_thread)
        th2 = threading.Thread(name="NMessager",target=node2node_messager_thread)
        th1.start()
        th2.start()
        if th1.isAlive() and th2.isAlive():
            pass
            #i_daemon()
        else:
            digi_debug("Thread node messager not started, exiting now ...", 3)
            exit()
        #if options.mem:
        digi_debug('Node Manager, start mem test ...', 3)
        #import top
        from top_new import NProcessManager, NProcess
        #NProcessManager().init('digiocean')
        NProcessManager().init('trusted.ec.heal')
        #print NProcessManager()._processes
        th3 = threading.Thread(name="NPManager", target=NProcessManager().cron)
        th3.setDaemon(True)
        th3.start()
        th4 = threading.Thread(name="DGMonitor", target=digioceand_monitor)
        th4.setDaemon(True)
        th4.start()
        th5 = threading.Thread(name="DGClient", target=notify_message_monitor)
        th5.setDaemon(True)
        th5.start()
        amanager.init_heal_disperse()
        notify_handler()
        #message_handler()
        #nmon_handler()
        

    except Exception, e:
        #digi_debug("Node manager, caught excepion: %s" % traceback.format_exc(), 3)
        digi_debug("Node manager, exit with expception: %s" %(e), 3)
        exit()



