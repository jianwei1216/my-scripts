import os
import sys
import threading
import tempfile
import urllib
import urllib2
import simplejson

sys.path.append('/usr/local/digioceanfs_manager')

#import settings
import port_invoke

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)

utilspath = os.path.join(currpath[:currpath.rfind('manager')],'utils')
if not utilspath in sys.path:
    sys.path.append(utilspath)

from manager_utils import *
from libcommon import clusnodelib
from libcommon import clusservicelib
from libcommon import clusindex

URLPRE = port_invoke.URLPRE

class ClusterDaemon(threading.Thread):
    def __init__(self,options=[]):
        threading.Thread.__init__(self)
        self.options = options[:-1]
        self.actionID = options[-1]
    def run(self):
        try:
            self.handler()
        except Exception, e:
            print traceback.print_exc(e)
    def handler(self):
        if 'node' == self.options[0]:
            if 'list' == self.options[1]:
                retinfo = clusnodelib.func_node_list_all(' '.join(self.options))
            elif 'list_nic' == self.options[1]:
                retinfo = clusnodelib.func_node_iface_info(' '.join(self.options))
            elif 'add' == self.options[1]:
                retinfo = clusnodelib.func_node_create(' '.join(self.options))
            elif 'del' == self.options[1]:
                retinfo = clusnodelib.func_node_delete(' '.join(self.options))
            elif 'status' == self.options[1]:
                retinfo = clusnodelib.func_node_status(' '.join(self.options))
            elif 'cifs_status' == self.options[1]:
                retinfo = clusnodelib.func_node_cifs_status(' '.join(self.options))
            elif 'cifs_restart' == self.options[1]:
                retinfo = clusnodelib.func_node_cifs_restart(' '.join(self.options))
            elif 'ctdb_set' == self.options[1]:
                retinfo = clusnodelib.func_node_ctdb_set(' '.join(self.options))
            elif 'list_cpu' == self.options[1]:
                retinfo = clusnodelib.func_node_list_cpu(' '.join(self.options))
            elif 'list_disk' == self.options[1]:
                retinfo = clusnodelib.func_node_disk_info(' '.join(self.options))
            elif 'reset_disk' == self.options[1]:
                retinfo = clusnodelib.func_node_disk_muti_op(' '.join(self.options))
            elif 'format_disk' == self.options[1]:
                retinfo = clusnodelib.func_node_disk_muti_op(' '.join(self.options))
            elif 'list_static_info' == self.options[1]:
                retinfo = clusnodelib.func_node_static_info(' '.join(self.options))
            elif 'list_dynamic_info' == self.options[1]:
                retinfo = clusnodelib.func_node_dynamic_info(' '.join(self.options))
            elif 'list_raid' == self.options[1]:
                retinfo = clusnodelib.func_node_raid_info(' '.join(self.options))
            elif 'list_inactive' == self.options[1]:
                retinfo = clusnodelib.func_node_list_inactive(' '.join(self.options))
            elif 'update_disk' == self.options[1]:
                retinfo = clusnodelib.func_node_disk_update(' '.join(self.options))
            elif 'raid_create' == self.options[1]:
                retinfo = clusnodelib.func_node_raid_create(' '.join(self.options))
            elif 'raid_del' == self.options[1]:
                retinfo = clusnodelib.func_node_raid_del(' '.join(self.options))
            elif 'raid_info' == self.options[1]:
                retinfo = clusnodelib.func_node_raid_progress(' '.join(self.options))
            elif 'raid_hs_set' == self.options[1]:
                retinfo = clusnodelib.func_node_raid_set_hs(' '.join(self.options))
            elif 'raid_hs_del' == self.options[1]:
                retinfo = clusnodelib.func_node_raid_del_hs(' '.join(self.options))
            elif 'raid_disactive ' == self.options[1]:
                retinfo = clusnodelib.func_node_disk_active(' '.join(self.options))
            elif 'ip_set' == self.options[1]:
                retinfo = clusnodelib.func_node_ipaddr_set(' '.join(self.options))
            elif 'bond_set' == self.options[1]:
                retinfo = clusnodelib.func_node_bond_set(' '.join(self.options))
            elif 'bond_del' == self.options[1]:
                retinfo = clusnodelib.func_node_bond_del(' '.join(self.options))
            elif 'check_license' == self.options[1]:
                retinfo = clusnodelib.func_node_check_license(' '.join(self.options))
            elif 'get_device_id' == self.options[1]:
                retinfo = clusnodelib.func_node_get_device_id(' '.join(self.options))
            else:
                retinfo = '-1'
        elif 'service' == self.options[0]:
            if 'create' == self.options[1]:
                retinfo = clusservicelib.func_service_create(' '.join(self.options))
            elif 'set_spare' == self.options[1]:
                retinfo = clusservicelib.func_service_set_spare(' '.join(self.options))
            elif 'replace_disk' == self.options[1]:
                retinfo = clusservicelib.func_service_replace_disk(' '.join(self.options))
            elif 'list' == self.options[1]:
                retinfo = clusservicelib.func_service_list_all(' '.join(self.options))
            elif 'list_disk' == self.options[1]:
                retinfo = clusservicelib.func_service_list_disk(' '.join(self.options))
            elif 'start' == self.options[1]:
                retinfo = clusservicelib.func_service_start(' '.join(self.options))
            elif 'stop' == self.options[1]:
                retinfo = clusservicelib.func_service_stop(' '.join(self.options))
            elif 'destroy' == self.options[1]:
                retinfo = clusservicelib.func_service_destroy(' '.join(self.options))
            elif 'quota_setup' == self.options[1]:
                retinfo = clusservicelib.func_service_quota_setup(' '.join(self.options))
            elif 'client_add' == self.options[1]:
                retinfo = clusservicelib.func_client_node_create(' '.join(self.options))
            elif 'client_destroy' == self.options[1]:
                retinfo = clusservicelib.func_client_node_delete(' '.join(self.options))
            elif 'client_list' == self.options[1]:
                retinfo = clusservicelib.func_client_node_list_all(' '.join(self.options))
            elif 'client_start' == self.options[1]:
                retinfo = clusservicelib.func_client_node_start(' '.join(self.options))
            elif 'client_stop' == self.options[1]:
                retinfo = clusservicelib.func_client_node_stop(' '.join(self.options))
            elif 'add_disk' == self.options[1]:
                retinfo = clusservicelib.func_service_extend(' '.join(self.options))
            elif 'export_cifs' == self.options[1]:
                retinfo = clusservicelib.func_service_cifs_export(' '.join(self.options))
            elif 'cifs_list_user' == self.options[1]:
                retinfo = clusservicelib.func_service_cifs_list_user(' '.join(self.options))
            elif 'cifs_list_links' == self.options[1]:
                retinfo = clusservicelib.func_service_list_cifs_links(' '.join(self.options))
            elif 'cifs_del_links' == self.options[1]:
                retinfo = clusservicelib.func_service_del_cifs_links(' '.join(self.options))
            elif 'cifs_add_user' == self.options[1]:
                retinfo = clusservicelib.func_service_cifs_add_user(' '.join(self.options))
            elif 'cifs_del_user' == self.options[1]:
                retinfo = clusservicelib.func_service_cifs_del_user(' '.join(self.options))
            elif 'export_nfs' == self.options[1]:
                retinfo = clusservicelib.func_service_nfs_export(' '.join(self.options))
            elif 'nfs_list_user' == self.options[1]:
                retinfo = clusservicelib.func_service_nfs_list_user(' '.join(self.options))
            elif 'nfs_add_user' == self.options[1]:
                retinfo = clusservicelib.func_service_nfs_add_user(' '.join(self.options))
            elif 'nfs_del_user' == self.options[1]:
                retinfo = clusservicelib.func_service_nfs_del_user(' '.join(self.options))
            else:
                retinfo = '-1'
        elif 'domain_set' == self.options[0]: 
            retinfo = clusindex.func_domain_set(' '.join(self.options))
        elif 'domain_get' == self.options[0]:
            retinfo = clusindex.func_domain_get()
        else: 
            retinfo = '-1'

        urllib.urlopen(URLPRE + self.actionID,urllib.urlencode({'params':simplejson.dumps(retinfo)}))

        
if __name__ == "__main__":
    options = sys.argv[1:]
    t = ClusterDaemon(options)
    t.start()
    t.join()
