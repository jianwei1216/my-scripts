# -*- coding: utf-8 -*-
#!/usr/bin/python
import os
import random
import sys
import math
import re
import getpass
from os.path  import *
from optparse import OptionParser
from optparse import Values
from xml.dom.minidom import Document
from xml.dom import minidom
import StringIO
import subprocess
import threading
import thread
import time
import simplejson
import dircache
import tempfile
import fcntl
import string
import traceback
import pickle
import xml.etree.ElementTree as etree
from Digioceanfs_error import ERRDICT as ED 

sys.path.append('/usr/local/digioceanfs_manager')

import settings

import traceback

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)

transportpath = os.path.join(currpath[:currpath.rfind('manager')],'transport')
if not transportpath in sys.path:
    sys.path.append(transportpath)

utilspath = os.path.join(currpath[:currpath.rfind('manager')],'utils')
if not utilspath in sys.path:
    sys.path.append(utilspath)

from manager_utils import *
from afr_utils import *
from raid_utils import *
from nfs_utils import *
from samba_utils import *

from net_utils_tool import checkIP
from net_utils_tool import PING

from digiclient import DigiClient

from manager_protocol import *
import node_manager 
#from node_manager import remote_set_manager_ip 
#from node_manager import get_management_node 
#from node_manager import set_management_node 
from net_utils import * 

from vol_file_utils import *

import rsyslog_utils
import backup_utils

from localthread import *

#set_log_file("/var/log/digioceanfs_manager/client.log")

manager_config_dir                       = "/etc/digioceanfs_manager"
node_info_dir                            = manager_config_dir + "/nodes"
service_info_dir                         = manager_config_dir + "/services"
groups_file                              = manager_config_dir + "/groups"
command_lock_file                        = manager_config_dir + "/command_lock"
login_lock_file                          = manager_config_dir + "/login_lock"
manager_node_config_file                 = manager_config_dir + "/management_node"
#service_dir_prefix                       = "/etc/digioceanfs/services"
service_dir_prefix                       = settings.SMBCONFPREFIX

command_lock_fd    = None
login_lock_fd    = None

mount_dir_prefix   = "/cluster2"


orphanage_group_name = "none"

MANAGER_PORT = 9997
NODE_MESSAGER_PORT = 9998
CLIENT_PORT = 9996

MSERVER_PORT_BASE = 60001

VERSION_NUMBER_BASE = 1


threads_pool = []

TMP_NODE_NAME = "\177\176\175"

def EXIT(status=0, err_str=''):
    command_unlock()
    if err_str:
        print "%s: %s" % (str(status), err_str)
    else:
        if status != 0:
            print "%s: %s" % (str(status), ED[status])
    exit(status)

class nic ():
    def parse_nic_line(self, nic_info):
        self.type = nic_info[0]
        if len(nic_info) < 3:
            self.status = nic_status_type["stop"]
        else:
            self.status = nic_status_type["start"]
        self.name    = nic_info[1]
        if self.status != nic_status_type["start"]:
            return
        self.encap   = nic_info[2]
        self.hwaddr  = nic_info[3]
        self.ip      = nic_info[4]
        self.bcast   = nic_info[5]
        self.mask    = nic_info[6]
        self.gateway = nic_info[7]

        if self.type == nic_type["bonding"]:
            self.sub_nics = nic_info[8:]

    def __init__(self, nic_info):
        self.type     = int()
        self.status   = int()

        self.name     = str()
        self.encap    = str()
        self.hwaddr   = str()
        self.ip       = str()
        self.bcast    = str()
        self.mask     = str()
        self.gateway  = str()

        #only for bond
        self.sub_nics = []

        self.parse_nic_line(nic_info)

    def list(self, output_img):
        if self.type == nic_type["normal"]:
            output_img.write("  normal\t")
        elif self.type == nic_type["bonding"]:
            output_img.write(" bonding\t")
        elif self.type == nic_type["sub_nic"]:
            output_img.write(" sub_nic\t")
        output_img.write("%s\t"%(self.name))
        if self.status != nic_status_type["start"]:
            output_img.write("\n")
            return
        output_img.write("%s\t"%(self.encap))
        output_img.write("%s\t"%(self.hwaddr))
        output_img.write("%s\t"%(self.ip))
        output_img.write("%s\t"%(self.bcast))
        output_img.write("%s\t"%(self.mask))
        output_img.write("%s\t"%(self.gateway))
        if self.type == nic_type["bonding"]:
            for a_sub_nic in self.sub_nics:
                output_img.write("%s\t"%(a_sub_nic))
        output_img.write("\n")

    def get_ip(self):
        return self.ip

    def get_type(self):
        return self.type

    def get_name(self):
        return self.name

    def __str__(self):
        return self.name

    def __eq__ (self, other):
        return self.name.__eq__(other.__str__())

class disk ():
    def parse_disk_line(self, disk_info_list):
        n = 0
        self.position = disk_info_list[0]
        self.disk_status = disk_info_list[1]
        self.dev_id      = disk_info_list[2] #dev name
        self.dev, self.type, self.model = disk_info_list[3].split(',')

        if self.disk_status == disk_status_type["no_disk"]:
            self.port = disk_info_list[4]
            return

        self.disk_is_raid = disk_info_list[4] #disk type, raid or normal disk

        if self.disk_is_raid:
            self.raid_level = disk_info_list[5]
            self.raid_status = disk_info_list[6]
            self.raid_progress = disk_info_list[7]
            self.raid_sub_disks = disk_info_list[8]
            n = 8
        else:
            n = 4

        self.size        = disk_info_list[n+1] #disk size
        self.port        = disk_info_list[n+2] #disk port

        if self.disk_status == disk_status_type["no_user"]:
            self.disk_raid_UUID    = disk_info_list[n+3]
            self.disk_raid_group   = disk_info_list[n+4]
            self.disk_raid_state   = disk_info_list[n+5]
            self.disk_raid_devices = disk_info_list[n+6]
            return

        self.user        = disk_info_list[n+3] #disk user
        self.status      = disk_info_list[n+4] #disk status, start or not

        if self.status == disk_start_status_type["no_start"]:
            return

        self.pid         = disk_info_list[n+5] #disk pid, if started

    def __init__(self, options, node_belong, disk_info_list):
        self.options = options
        self.node = node_belong

        self.disk_status    = int()
        self.dev_id         = ""
        self.dev            = ""
        self.disk_is_raid   = bool #raid or normal disk
        self.size           = long()
        self.port           = ""
        self.user           = ""
        self.status         = int()
        self.pid            = int()
        self.position       = int()
        
        self.type           = ''
        self.model          = ''

        #only for disks in inactive raid
        self.disk_raid_UUID     = ""
        self.disk_raid_group    = ""
        self.disk_raid_state    = ""
        self.disk_raid_progress = ""
        self.disk_raid_devices  = ""

        #only for type "raid"
        self.raid_level = ""
        self.raid_status = ""
        self.raid_sub_disks = []

        #only for subdisk of service of type afr
        self.afr_status = ""
        self.used_size  = long()

        self.parse_disk_line(disk_info_list)

    def get_node(self):
        return self.node

    def get_disk_status(self):
        return self.disk_status

    def get_dev_id(self):
        return self.dev_id

    def get_dev(self):
        return self.dev

    def is_raid(self):
        return self.disk_is_raid

    def is_in_raid(self):
        if self.disk_raid_UUID or self.disk_raid_group:
            return True
        return False

    def get_type(self):
        if self.is_raid():
            return "raid"
        return self.type

    def get_model(self):
        if self.is_raid():
            return None
        return self.model

    def get_serial(self):
        if self.is_raid():
            return None
        return get_serial_from_id(self.dev_id)


    def get_size(self):
        return self.size

    def get_port(self):
        return self.port

    def get_user(self):
        return self.user

    #these 3 methods only for type "raid"
    def get_raid_level(self):
        return self.raid_level

    def get_raid_status(self):
        return self.raid_status

    def get_raid_sub_disks(self):
        return self.raid_sub_disks

    def get_raid_progress(self):
        return self.raid_progress

    #these 4 methods only for disks in inactive raid
    def get_disk_raid_UUID(self):
        return self.disk_raid_UUID

    def get_disk_raid_group(self):
        return self.disk_raid_group

    def get_disk_raid_state(self):
        return self.disk_raid_state

    def get_disk_raid_devices(self):
        return self.disk_raid_devices

    #these 4 method only for subdisk of service of type afr
    def set_afr_status(self, afr_status):
        self.afr_status = afr_status

    def get_afr_status(self):
        return self.afr_status

    def set_used_size(self, used_size):
        self.used_size = used_size

    def get_used_size(self):
        return self.used_size


    def valid_hs_disk(self, disk_name):
        for disk_info in self.raid_sub_disks:
            try:
                _disk_name = disk_info[1].split(',')[0]
            except:
                _disk_name = ""
            if _disk_name == disk_name:
                if disk_info[4] == "spare":
                    return (True, _disk_name)
        return (False, "")

    def list_raid_info(self, output_img):
        if not self.is_raid():
            return
        output_img.write("raid name: %s\n"%(self.get_dev()))
        output_img.write("raid level: %s\n"%(self.get_raid_level()))
        output_img.write("raid status: %s\n"%(self.get_raid_status()))
        if not self.get_raid_progress():
            output_img.write("raid progress: 100\n")
        else:
            output_img.write("raid progress: %s%%\n"%(self.get_raid_progress()))
        for adisk in self.raid_sub_disks:
            dev, disk_type, disk_model = adisk[1].split(',')
            output_img.write("%s\t"%(disk_type))
            output_img.write("%s\t"%(disk_model))
            output_img.write("%s\t"%(get_serial_from_id(adisk[2])))
            output_img.write("%s\t"%(adisk[3]))
            output_img.write("%s\t"%(adisk[4]))
            output_img.write("\n")

    def list_disk_raid_info(self, output_img):
        if self.is_raid():
            return
        if not self.disk_raid_UUID and not self.disk_raid_group:
            return
        output_img.write("%s\t"%(self.get_disk_raid_group()))
        output_img.write("%s\t"%(self.get_disk_raid_devices()))
        output_img.write("%s\t"%(self.get_dev()))
        if self.get_disk_raid_state() == "active":
            output_img.write("normal    ")
        elif self.get_disk_raid_state() == "spare":
            output_img.write("hot_spare ")
        else:
            output_img.write("%-10s"%(self.get_disk_raid_state()))
        output_img.write("%s\t"%(self.get_type()))
        output_img.write("%s\t"%(self.get_model()))
        output_img.write("%s\t"%(self.get_serial()))
        output_img.write("%s\t"%(self.get_size()))
        output_img.write("%s\t"%(self.get_disk_raid_UUID()))
        output_img.write("\n")

    def list(self, output_img):
        while True:
            if self.position:
                output_img.write(str(self.position)+"\t")
            if self.disk_status == 1:
                output_img.write(" no_disk\t")
            if self.disk_status == 6:
                output_img.write("  cspare\t")
            if self.disk_status == 7:
                output_img.write("  unused\t")
            if self.disk_status == 2:
                if self.is_in_raid() and not self.is_raid():
                    output_img.write("inactive\t")
                else:
                    if self.is_raid():
                        if self.raid_level == 'NaN' and self.raid_status == 'inactive':
                            output_img.write("raid_broken\t")
                        else:
                            output_img.write("  unused\t")
                    else:
                        output_img.write("  unused\t")
            if self.disk_status == 3:
                output_img.write("    used\t")

            if self.get_dev():
                output_img.write("%s\t"%(self.get_dev()))
            else:
                output_img.write("%s\t"%('nodisk'))
#            output_img.write("%s\t"%(self.dev_id))

            if self.disk_status == disk_status_type["no_disk"]:
                output_img.write(" \t \t \t \t \t \t\n")
                break

            output_img.write("%s\t"%(self.get_type()))
            if self.is_raid():
                output_img.write("%s\t"%(self.get_raid_level()))
                output_img.write("%s\t"%(self.get_raid_status()))
            else:
                output_img.write("%s\t"%(self.get_model()))
                output_img.write("%s\t"%(self.get_serial()))
            output_img.write("%12d\t"%(self.size))
            output_img.write("%10s\t"%(self.port))
            if self.disk_status == disk_status_type["no_user"] or self.disk_status == disk_status_type["cluster_replaced_disk"] or self.disk_status == disk_status_type["cluster_spare_disk"]:
                output_img.write(" \t \t \t\n")
                break

            if self.user:
                output_img.write("%s\t"%(self.user))
            else:
                output_img.write('\n')
                break

            if self.status == disk_start_status_type["started"] and self.pid != "0":
                output_img.write("start\t")
                output_img.write("%s\t\n"%(self.pid))
            else:
                output_img.write("stop\t \t\n")
            break

        if self.is_raid():
            for a_sub_disk in self.raid_sub_disks:
                disk_dev, disk_type, disk_model = a_sub_disk[1].split(',')
                output_img.write("%s\t" % (a_sub_disk[0]))
                output_img.write(" in_raid\t%s\t"%(disk_dev))
                output_img.write("%s\t"%(disk_type))
                output_img.write("%s\t"%(disk_model))
                output_img.write("%s\t"%(get_serial_from_id(a_sub_disk[2])))
                output_img.write("%12s\t"%(a_sub_disk[3]))
                output_img.write("%10s\t"%(a_sub_disk[4]))
                output_img.write("%s\t"%(self.dev))
                output_img.write("\n")


    def __str__(self):
        return self.dev_id

    def __eq__ (self, other):
        return self.dev_id.__eq__(other.__str__())
        """
        if type(other) == str:
            return self.dev_id.__eq__(other.__str__())
        else:
            return (self.dev_id + self.node.__str__()).__eq__(other.__str__() + other.node.__str__())
        """

class client(object):
    def __init__ (self, options={},service_name = '',ipaddr="",mask=""):
        self.ipaddr = ipaddr
        self.mask = mask
        self.service_name = service_name
        self.options = options
    def node_event (self, options, node_ip, cmd, data=""):
        anode = node(options,"",None,node_ip)
        if not PING(node_ip):
            # del_host(anode.get_name(), anode.get_ip_addr())
            anode.destroy()
            return "11098"

        ret = anode.remote_call(protocol_request_type[cmd], data, isclient=True)
        anode.disconnect()
        return ret
    
    def client_ip_match(self,anic):
        if (self.mask == anic.mask):
            cli_mask = list(self.mask.split("=."))
            cli_mask = cli_mask[-1].split(".")
            cli_ip = list(self.ipaddr.split("=."))
            cli_ip = cli_ip[-1].split(".")

            anic_mask = list(anic.mask.split("=."))
            anic_mask = anic_mask[-1].split(".")
            anic_ip = list(anic.ip.split("=."))
            anic_ip = anic_ip[-1].split(".")

            for i in (0,1,2,3):
                cli_ip_bin =  '{0:08b}'.format(int(cli_ip[i]))
                anic_mask_bin =  '{0:08b}'.format(int(anic_mask[i]))
                anic_ip_bin =  '{0:08b}'.format(int(anic_ip[i]))
                for j in (0,1,2,3):
                    if(anic_mask_bin[j] == '1'):
                        if(cli_ip_bin[j] == anic_ip_bin[j]):
                            continue
                        else:
                            return
            return anic.ip
        return
				
    def get_data_ip(self,node_name):
        host_img = open('/etc/hosts')
        line = host_img.readline()
        while (line != ''):
            if line.find('####DigioceanfsNode####')>0:
                if line[0] not in '#':
                    str = line.replace('\n'," ")
                    str = str.rstrip(' ')
                    list = str.split(",")
                    str = ('').join(list)
                    str = str.split(" ")
                    for str_0 in str:
                        if (str_0 == node_name):
                            return str[0]
            line = host_img.readline()
        host_img.close()
				
    def client_add(self):
        hosts_img = get_hosts_img()
        amanager = manager(self.options)
        for node_name in amanager.node_list:
            data_ip = self.get_data_ip(node_name)
            anode = amanager.get_node_by_name(node_name)
            anode.update_nic()
            for anic in anode.nics:
                match_ip = self.client_ip_match(anic)
                if (match_ip != None):
                    hosts_img = hosts_img.replace(data_ip,match_ip)
                    break
            if (match_ip == None):
                digi_debug("Client add failed, matching the same network segment failed at %s"%(node_name),3)
                EXIT(13511)
				
        data = simplejson.dumps(hosts_img, encoding='ascii', ensure_ascii=True)
        ret = self.node_event(self.options,self.ipaddr,"client_add",data)
        if ret == '1':
            cmd = [settings.COMMANDS['digiocean'], 'peer', 'probe', self.ipaddr]
            tmp_img = tempfile.TemporaryFile()
            ret = execute(cmd, tmp_img)
            result = tmp_img.read()
            if ret:
                #print "Probe client peer failed"
                EXIT(13503, result)
            else:
                return "0"
        elif ret == '11098':
            EXIT(11098)
        else:
            EXIT(11132)
        
    def client_destroy(self):
        cmd = [settings.COMMANDS['digiocean'], 'peer', 'detach', self.ipaddr]
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, tmp_img)
        result = tmp_img.read()
        if ret:
            if result.find("One of the peers is probably down") >= 0:
                EXIT(13501)
            else:
                EXIT(13502,result)
        else:
            # delete content in hosts with DigioceanfsNode
            hosts_img = get_hosts_img()
            ret = self.node_event(self.options,self.ipaddr,"client_destroy",[])
            return ret
        
    def client_list (self, options):
        clients = []
        peer = self.peer_list()
        allclients = self.get_client_addr()
        for client_ip in allclients:
            if client_ip not in peer:
                clients.append(client_ip)
        package = [self.service_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        output_string = ''
        for ip in clients:
            ret = self.node_event(self.options,ip ,"client_status",data)
            if ret == '1':
                output_string += '%s\t%s\n' % (ip, 'started')
            else:
                output_string += '%s\t%s\n' % (ip, 'stop')
        output_img = StringIO.StringIO(output_string)
        return output_img
        
    def client_start (self):
        status = list_service_status(self.service_name)
        if status != 'Started':
            EXIT(13504)
        else:
            package = [self.service_name]
            data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
            ret = self.node_event(self.options,self.ipaddr,"client_start",data)
            digi_debug("Digi manager client %s start return : %s" % (self.ipaddr,ret), 3)
            if ret != '0':
                if ret == '-1':
                    EXIT(13506)
                elif ret == '-2':
                    EXIT(13507)
                else:
                    EXIT(13508)
            return ret

    def client_stop (self):
        package = [self.service_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.node_event(self.options,self.ipaddr,"client_stop",data)
        digi_debug("Digi manager client %s stop return : %s" % (self.ipaddr,ret), 3)
        if ret != '0':
            if ret == '-3':
                EXIT(13509)
            else:
                EXIT(13510)
        return ret

    '''
        package = [self.name,peer]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        rtn = []
        for client_addr in clients:
            ret = self.node_event(self.options,client_addr,"client_list",data)
            a = simplejson.loads(ret)
            n = []
            for m in a:
                if m['mount_ip'] == '127.0.0.1':
                    m['mount_ip'] = client_addr
                m['client_ip'] = client_addr
                n.append(m)
            rtn.append(n)
        return simplejson.dumps(rtn, encoding='ascii', ensure_ascii=True)
    '''

    def get_client_addr (self):
        cmd = []
        clients = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append('peer')
        cmd.append('status')
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd,tmp_img)
        results = tmp_img.readlines()
        if results:
            for ret in results:
                if ret.find("Hostname: ") >= 0:
                    client_ip = ret.replace('Hostname: ','').strip()
                    if client_ip not in clients:
                        clients.append(client_ip)
                #print n
        return clients

    def peer_list (self):
        rtn = []
        cmd = []
        cmd.append('cat')
        cmd.append('/etc/hosts')
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd,tmp_img)
        result = tmp_img.readlines()
        for data in result:
            if data.find('####DigioceanfsNode####') != -1:
                rtn.append(data.split(' ')[0])
                rtn.append(data.split(' ')[1])
        return rtn


class service(object):
    def init_file_path(self):
        self.config_dir         = "%s/%s"%(service_info_dir, self.name)
        self.mount_dir          = "%s/%s"%(mount_dir_prefix, self.name)
        #self.vol_file_path      = "%s/%s.vol"%(self.config_dir, self.name)
        #self.disk_file_path     = "%s/disks"%(self.config_dir)
        #self.mserver_file_path  = "%s/mserver"%(self.config_dir)
        #self.raid_file_path     = "%s/raid"%(self.config_dir)
        #self.local_prioritize_file_path     = "%s/local_prioritize"%(self.config_dir)
        #self.stripe_file_path   = "%s/stripe"%(self.config_dir)
        #self.afr_file_path      = "%s/afr"%(self.config_dir)
        #self.afr_time_file_path = "%s/afr_time"%(self.config_dir)
        #self.version_file_path  = "%s/version"%(self.config_dir)
        #self.extend_file_path   = "%s/%s-ext.vol"%(self.config_dir, self.name)
        #self.asi_conf_file_path = "%s/asi.conf"%(self.config_dir)
        #self.fsid_file_path = "%s/%s/fsid.conf"%(service_dir_prefix, self.name)

    def init_from_file(self):
        init_dir(self.config_dir)

        disk_file_lines = get_config_file(self.disk_file_path).readlines()
        for line_s in disk_file_lines:
            node_name = ""
            if line_s[0] == '#':
                continue
            elif len(line_s) < 2:
                continue
            line = line_s.split('\n')[0]
            node_name = line.split(':', 1)[0]
            anode = self.manager.get_node_by_name(node_name)
            if not anode:
                digi_debug("Digi manager get node obj failed:%s not exist!!!"%(node_name), 3)
                EXIT()

            disks_package = line.split(':', 1)[1]
            disks_name = simplejson.loads(disks_package)
            for disk_name in disks_name:
                #if not anode.get_disk_by_name(disk_name):
                #    digi_debug("Digi manager raise error while lookup disk:%s in %s"%(disk_name, anode.get_name()), 3)
#                    EXIT()
                self.sub_nodes[anode].append(disk_name)

    #def __init__(self, options, manager, service_name=""):
    def __init__(self, manager, service_name=""):
        self.manager = manager
        #self.options = options
        self.name = service_name
        self.raid_level = None        #str
        self.local_prioritize = None  #str
        self.stripe_num = None        #int
        self.afr_num = None           #int
        self.property_afr_time = None #property package
        self.mserver_port = None      #int
        self.size = None              #long
        self.sub_nodes = dict()
        self.version = None           #int
        self.fsid = None              #str

        #these 2 attribute should be used after status() was called, and status was started
        self.used_size = None         #str
        self.pid = ""

        self.config_dir = ""
        self.mount_dir = ""
        self.vol_file_path = ""
        self.fsid_file_path = ""
        self.disk_file_path = ""
        self.mserver_file_path = ""
        self.raid_file_path = ""
        self.stripe_file_path = ""
        self.afr_file_path = ""
        self.afr_time_file_path = ""
        self.version_file_path = ""
        self.extend_file_path = ""
        self.asi_conf_file_path = ""
        
        node_list = self.manager.get_all_node()
        #init thread pool
        self.service_thread_pool = ClusterThreadPool(len(node_list))
        
        for anode in node_list:
            self.sub_nodes[anode] = []

        if self.name:
            self.init_file_path()
        #    self.init_from_file()
            
    def init_fsid(self):
        self.fsid = str(random.randint(1,18446744073709551615)) 
        package = [self.fsid_file_path, self.fsid]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        node_list = self.manager.get_all_node()
        for anode in node_list:
            anode.remote_set_config_file(data)
        
    def get_fsid(self):
        if self.fsid is None:
            fsid_file_line = get_config_file(self.fsid_file_path).readline()
            self.fsid = fsid_file_line.split('\n')[0]    
        return self.fsid       
########################
#   support functions  #
########################
    def init_file(self):
        init_dir(self.config_dir)
        #init_config_file(self.disk_file_path)
        #init_config_file(self.mserver_file_path)
        #init_config_file(self.raid_file_path)
        #init_config_file(self.local_prioritize_file_path)

    def init_mserver_port(self, mserver_port):
        self.mserver_port = mserver_port
        mserver_port_img = StringIO.StringIO(mserver_port)
        set_config_file(self.mserver_file_path, mserver_port_img)

    def init_raid_level(self, raid_level):
        self.raid_level = raid_level
        raid_level_img = StringIO.StringIO(raid_level)
        set_config_file(self.raid_file_path, raid_level_img)
        
    def init_local_prioritize(self, local_prioritize):
        self.local_prioritize = local_prioritize
        local_prioritize_img = StringIO.StringIO(local_prioritize)
        set_config_file(self.local_prioritize_file_path, local_prioritize_img)

    def init_stripe_num(self, stripe_num):
        self.stripe_num = stripe_num
        stripe_num_img = StringIO.StringIO("%d"%(stripe_num))
        set_config_file(self.stripe_file_path, stripe_num_img)

    def init_afr_time(self, disks):
        for adisk in disks:
            self.set_afr_time(adisk.get_dev_id())

    def init_asi_conf(self, nodes):
        asi_conf_str = ""
        for anode in nodes:
            asi_conf_str += ("%s:%d\n" % (anode.get_ip_addr(), self.mserver_port))
        asi_conf_img = StringIO.StringIO(asi_conf_str)
        set_config_file(self.asi_conf_file_path, asi_conf_img)

    def __update_disks_file(self):
        disks_img = StringIO.StringIO()
        for anode in self.sub_nodes:
            disks_img.write("%s:"%(anode.get_name()))
            disk_list = self.sub_nodes[anode]
            disk_package = simplejson.dumps(disk_list)
            disks_img.write("%s\n"%(disk_package))
        disks_img.seek(0)
        set_config_file(self.disk_file_path, disks_img)

    def __add_disk(self, disks):
        for adisk in disks:
            add_in_list(self.sub_nodes[adisk.get_node()], adisk.get_dev_id())
        self.__update_disks_file()
        
    def nodisk_add_disk(self, disks):
        self.__add_disk(disks)

    def __del_disk(self, disks):
        for adisk in disks:
            del_in_list(self.sub_nodes[adisk.get_node()], adisk.get_dev_id())
        self.__update_disks_file()
        
    def nodisk_del_disk(self, disks):
        self.__del_disk(disks)

    def __add_node(self, anode, disk_dev_ids=[]):
        #TODO:check the node's existence here
        self.sub_nodes[anode] = disk_dev_ids
        self.__update_disks_file()
        return True

    def __del_node(self, anode):
        #TODO:check the node's existence here
        self.sub_nodes.pop(anode)
        self.__update_disks_file()
        return True

    def init_version(self):
        self.version = VERSION_NUMBER_BASE
        version_img = StringIO.StringIO("%d"%(self.version))
        set_config_file(self.version_file_path, version_img)

    def get_name(self):
        return self.name

    def set_name(self, name):
        self.name = name

    def get_size(self):
        if self.size is None:
            return 0
        return self.size

    def set_size(self, size):
        self.size = size

    def get_used_size(self):
        return self.used_size

    def set_used_size(self, used_size):
        self.used_size = used_size

    def get_raid_level(self):
        if self.raid_level is None:
            raid_file_line = get_config_file(self.raid_file_path).readline()
            self.raid_level = raid_file_line.split('\n')[0]

        return self.raid_level
    
    def get_local_prioritize(self):
        if self.local_prioritize is None:
            local_prioritize_file_line = get_config_file(self.local_prioritize_file_path).readline()
            self.local_prioritize = local_prioritize_file_line.split('\n')[0]

        return self.local_prioritize

    def get_version(self):
        if self.version is None:
            version_file_line = get_config_file(self.version_file_path).readline()
            if len(version_file_line) > 0:
                self.version = int(version_file_line.split('\n')[0])

        return self.version

    def increase_version(self):
        self.version = self.version + 1
        version_img = StringIO.StringIO("%d"%(self.version))
        set_config_file(self.version_file_path, version_img)

    def decrease_version(self):
        self.version = self.version - 1
        version_img = StringIO.StringIO("%d"%(self.version))
        set_config_file(self.version_file_path, version_img)

    def get_mserver_port(self):
        if self.mserver_port is None:
            mserver_file_line = get_config_file(self.mserver_file_path).readline()
            if len(mserver_file_line) > 1:
                self.mserver_port = int(mserver_file_line.split('\n')[0])

        return self.mserver_port

    def get_stripe_num(self):
        if self.stripe_num is None:
            if self.get_raid_level() != "0" and self.get_raid_level() != "01":
                return None
            stripe_file_line = get_config_file(self.stripe_file_path).readline()
            self.stripe_num = int(stripe_file_line.split("\n")[0])
        return self.stripe_num

    def set_afr_num(self, afr_num):
        self.afr_num = afr_num
        afr_num_img = StringIO.StringIO("%d"%(afr_num))
        set_config_file(self.afr_file_path, afr_num_img)

    def get_afr_num(self):
        if self.afr_num is None:
            if os.path.isfile(self.afr_file_path):
                afr_file_line = get_config_file(self.afr_file_path).readline()
                self.afr_num = int(afr_file_line.split("\n")[0])
            else:
                self.afr_num = 0
        return self.afr_num

    def set_afr_time(self, disk_id, time_now=None):
        if not self.property_afr_time:
            self.property_afr_time = property_init(self.afr_time_file_path)
        if not time_now:
            time_now = int(time.time())
        property_set(self.property_afr_time, disk_id, time_now)

    def get_afr_time(self, disk_id):
        if not self.property_afr_time:
            self.property_afr_time = property_init(self.afr_time_file_path)
        return property_get(self.property_afr_time, disk_id)

    def get_nodes(self):
        return list(self.sub_nodes.keys())

    def get_node_by_name(self, node_name):
        node_list = self.sub_nodes.keys()
        return find_in_list(node_list, node_name)

    #get disk by node_name and port_num
    def get_disk_by_np(self, node_name, port_num):
        node = self.get_node_by_name(node_name)
        if not node:
            return None
        disk = node.get_disk_by_port(port_num)
        if not disk:
            return None
        return disk

    def get_afr_disk_pair(self):
        mirror_all    = {}
        mirror_single = ()
        mirror_name   = ""
        disk_np_list  = []
        disk_np       = []
        disk_list     = []
        mirror_pod    = {}

        if self.get_raid_level() != "1" and self.get_raid_level() != "01":
            return None

        mirror_all = vol_afr_mirror(self.vol_file_path)
        while len(mirror_all) != 0:
            mirror_single = mirror_all.popitem()
            mirror_name = mirror_single[0]
            disk_np_list = mirror_single[1]
            disk_list = []
            for disk_np in disk_np_list:
                adisk = self.get_disk_by_np(disk_np[0], disk_np[1])
                disk_list.append(adisk)
            mirror_pod[mirror_name] = disk_list

        return mirror_pod

    def add_node(self, anode):
        vol_file_img = get_config_file(self.vol_file_path).read()
        self.__add_node(anode)
        anode.service_init(self.get_name(),
                           self.get_version(),
                           self.get_mserver_port(),
                           vol_file_img,
                           self.sub_nodes[anode])
        anode.update_disk()

    def del_node(self, anode):
        """
            return code specify:
            1:    node del successful
            2:    the node has disk on this service, can not del
            3:    the node does not exist on this service
        """
        if not self.sub_nodes.__contains__(anode):
            return 3
        if len(self.sub_nodes[anode]) < 1:
            self.__del_node(anode)
            return 1
        return 2

    def node_has_disk(self, anode):
        """
            return code specify:
            1:    the node has disk in this service
            2:    the node does not have disk in this service
            3:    the node not exist
        """
        if not self.sub_nodes.__contains__(anode):
            return 3
        if len(self.sub_nodes[anode]) < 1:
            return 2
        return 1

########################
#   volfile related    #
########################
    def init_vol_file(self, disks):
        """
            the command format are
            digioceanfs-volgen --vol-type mount   (vol type:mount/export)
                               -r 1               (raid level:1/0)
                               -n sdb             (vol name)
                               -c test/           (vol file store dir)
                               -m /cluster        (mount point)
                               -s 60001           (mserver port)
                               --layout-version 1 (layout version)
                               --afr-num 2        (volumes in one afr)
                               --afr-byhand       (weather to specify volumes in afr)
                               --stripe-num 4     (volumes in one stripe)
                               group1:10.10.12.110:10001/digioceanfs/sdd
                               group1:10.10.12.110:10002/digioceanfs/sde
                               group2:10.10.12.140:10001/digioceanfs/sdf
                               group2:10.10.12.140:10002/digioceanfs/sdb
        """
        cmd = []
        cmd.append("/usr/bin/digioceanfs-volgen")
        cmd.append("--vol-type")
        cmd.append("mount")
        cmd.append("-r%s"%(self.get_raid_level()))
        cmd.append("-l%s"%(self.get_local_prioritize()))
        cmd.append("-n%s"%(self.get_name()))
        cmd.append("-c%s"%(self.config_dir))
        cmd.append("-m%s"%(self.mount_dir))
        cmd.append("-s%d"%(self.get_mserver_port()))
        cmd.append("--layout-version")
        cmd.append("%d"%(self.get_version()))
        cmd.append("--stripe-num")
        cmd.append("%d"%(self.options.stripe_num))
        cmd.append("--afr-num")
        cmd.append("%d"%(self.options.afr_num))
        if self.options.manual_afr:
            cmd.append("--afr-byhand")
        for adisk in disks:
            cmd.append("%s:%s:%s/digioceanfs/%s"
                        %(adisk.get_node().get_group().get_name(),
                          adisk.get_node().get_name(),
                          adisk.get_port(),
                          adisk.get_dev_id()))
        execute(cmd)
        vol_file_img = get_config_file(self.vol_file_path).read()
        digi_debug("Digi manager found vol file:\n %s" % vol_file_img, 7)
        return vol_file_img

    def generate_extend_file(self, disks):
        """
            the command format are
            digioceanfs-volgen --vol-type extend  (vol type:mount/export)
                               -r 1               (raid level:0/1/2)
                               -n sdb             (vol name)
                               -c test/           (vol file store dir)
                               --layout-version   (new layout-version)
                               group1:10.10.12.110:10001/digioceanfs/sdd
                               group1:10.10.12.110:10002/digioceanfs/sde
                               group2:10.10.12.140:10001/digioceanfs/sdf
                               group2:10.10.12.140:10002/digioceanfs/sdb
        """
        cmd = []
        cmd.append("/usr/bin/digioceanfs-volgen")
        cmd.append("--vol-type")
        cmd.append("extend")
        cmd.append("-r%s"%(self.get_raid_level()))
        cmd.append("-l%s"%(self.get_local_prioritize()))
        cmd.append("-n%s"%(self.get_name()))
        cmd.append("-c%s"%(self.config_dir))
        cmd.append("--layout-version")
        cmd.append("%d"%(self.get_version()))
        cmd.append("--afr-num")
        cmd.append("%d"%(self.get_afr_num()))
        for adisk in disks:
            cmd.append("%s:%s:%s/digioceanfs/%s"
                        %(adisk.get_node().get_group().get_name(),
                          adisk.get_node().get_name(),
                          adisk.get_port(),
                          adisk.get_dev_id()))
        ret = execute(cmd)
        #print ret
        extend_file_img = get_config_file(self.extend_file_path).read()
        digi_debug("Digi manager found extend vol file:\n %s" % extend_file_img, 7)
        #print extend_file_img
        return extend_file_img

    def combine_vol_file(self):
        """
            the command format are
            digioceanfs-volgen --vol-type combine            (vol type:mount/export/combine/apart)
                               --old-vol-file {file_path}    (old vol file path)
                               --extend-vol-file {file_path} (extend vol file path)
        """
        cmd = []
        cmd.append("/usr/bin/digioceanfs-volgen")
        cmd.append("--vol-type")
        cmd.append("combine")
        cmd.append("--old-vol-file")
        cmd.append("%s"%(self.vol_file_path))
        cmd.append("--extend-vol-file")
        cmd.append("%s"%(self.extend_file_path))
        execute(cmd)
        return get_config_file(self.vol_file_path).read()

    def afr_expand_volfile(self, mirror_pod):
        cmd = []
        cmd.append("/usr/bin/digioceanfs-afrgen")
        cmd.append("-m")
        cmd.append("expand")
        cmd.append(self.vol_file_path)
        cmd.append(self.vol_file_path)
        for mirror in mirror_pod:
            for adisk in mirror_pod[mirror]:
                cmd.append("%s:%s:%s"%(mirror,
                                       adisk.get_node().get_name(),
                                       adisk.get_port()))
        if not execute(cmd):
            return None
        afr_expand_file_img = get_config_file(self.vol_file_path).read()
        return afr_expand_file_img

    def afr_shrink_volfile(self, mirror_pod):
        cmd = []
        cmd.append("/usr/bin/digioceanfs-afrgen")
        cmd.append("-m")
        cmd.append("shrink")
        cmd.append(self.vol_file_path)
        cmd.append(self.vol_file_path)
        for mirror in mirror_pod:
            for adisk in mirror_pod[mirror]:
                cmd.append("%s:%s:%s"%(mirror,
                                       adisk.get_node().get_name(),
                                       adisk.get_port()))
        digi_debug("shrink vol file")
        execute(cmd)
        afr_shrink_file_img = get_config_file(self.vol_file_path).read()
        return afr_shrink_file_img

    def save_vol_file(self):
        self.old_vol_file_img = get_config_file(self.vol_file_path)

    def recover_vol_file(self):
        set_config_file(self.vol_file_path, self.old_vol_file_img)
        self.old_vol_file_img.close()

    def discard_saved_vol_file(self):
        self.old_vol_file_img.close()

########################
#   functions          #
########################
    def create(self, service_name, raid_type, local_prioritize, disks, mserver_port, ):
        """
            return code:
            1:     success
            2:     failed because of some node can not be connected
            3:     raid type not exist
            4:     number of disk does not match raid level require
        """
        self.set_name(service_name)
        if not find_in_list(service_raid_type, raid_type):
            self.destroy()
            return 3

        if raid_type == "0":
            if self.options.stripe_num != 0:
                if len(disks)%self.options.stripe_num != 0:
                    self.destroy()
                    digi_debug("Digi manager: create service found number of disk does not match raid level require", 5)
                    return 4
            else:
                self.destroy()
                digi_debug("Digi manager: create service found number of disk does not match raid level require", 5)
                return 4

        if raid_type == "1":
            if self.options.afr_num != 0:
                if len(disks)%self.options.afr_num != 0:
                    self.destroy()
                    digi_debug("Digi manager: create service found number of disk does not match raid level require", 5)
                    return 4
            else:
                self.options.afr_num = len(disks)
                if self.options.afr_num < 2:
                    self.destroy()
                    digi_debug("Digi manager: create service found number of disk does not match raid level require", 5)
                    return 4

        if raid_type == "01":
            if self.options.afr_num*self.options.stripe_num != 0:
                if len(disks)%(self.options.afr_num*self.options.stripe_num) != 0:
                    self.destroy()
                    digi_debug("Digi manager: create service found number of disk does not match raid level require", 5)
                    return 4
            else:
                self.destroy()
                return 4

        # if raid_type is afr or default,disable the option '-m' ---fixed by ly-2011-08-11
        if raid_type == "2" or raid_type == "0":
            if self.options.manual_afr:
                self.destroy()
                digi_debug("Digi manager: create service found number of disk does not match raid level require", 5)
                return 4

        # if raid_type is '2',disable the option '-a','-s','-m'  ---fixed by ly-2011-08-11
        if raid_type == "2" and self.options.afr_num + self.options.stripe_num != 0:
            self.destroy()
            digi_debug("Digi manager: create service found number of disk does not match raid level require", 5)
            return 4

        # if raid_type is '1',disable the option '-s'       ---fixed by ly-2011-08-11
        if raid_type == "1" and self.options.stripe_num != 0:
            self.destroy()
            digi_debug("Digi manager: create service found number of disk does not match raid level require", 5)
            return 4

        # if raid_type is '0',disable the option '-a','-m'            ---fixed by ly-2011-08-11
        if raid_type == "0" and self.options.afr_num != 0 and self.options.manual_afr != None:
            self.destroy()
            digi_debug("Digi manager: create service found number of disk does not match raid level require", 5)
            return 4

        self.init_file_path()
        self.init_file()
        self.init_fsid()
        self.init_mserver_port(mserver_port)
        self.init_raid_level(raid_type)
        self.init_local_prioritize(local_prioritize)
        nodes = self.manager.get_all_node()
        self.init_asi_conf(nodes)
        start_time = time.time()
        if raid_type == "0" or raid_type == "01":
            self.init_stripe_num(self.options.stripe_num)
        if raid_type == "1" or raid_type == "01":
            self.set_afr_num(self.options.afr_num)
            self.init_afr_time(disks)
        self.init_version()
        vol_file_img = self.init_vol_file(disks)
        self.__add_disk(disks)

        th_pool = []
        start_time = time.time()
        for anode in self.sub_nodes:
            if not anode.remote_connect():
                if len(self.sub_nodes[anode]) > 0:
                    digi_debug("Digi manager: node %s can not be connected"%(anode.get_name()), 5)
                    self.destroy()
                    return 2
        for anode in self.sub_nodes:
#            digi_debug("init service in node %s"%(anode.get_name()))
#            anode.service_init(self.get_name(),
#                               self.get_version(),
#                               self.get_mserver_port(),
#                               vol_file_img,
#                               self.sub_nodes[anode])
#            anode.update_disk()
            th = threading.Thread(target=self.create_thread, args=(anode, vol_file_img,))
            th.start()
            th_pool.append(th)

        for th in th_pool:
            th.join()
        start_time = time.time()
        for anode in self.sub_nodes:
            anode.update_disk(update_disk_change="y")

        return 1

    def create_thread(self, anode, vol_file_img):
        ret = anode.service_init(self.get_name(),
                                 self.get_version(),
                                 self.get_mserver_port(),
                                 vol_file_img, self.sub_nodes[anode])
        digi_debug("Digi manager service create recieve %s from node %s"%(ret[0], anode.get_name()), 7)
        if ret[0] == "2":
            digi_debug("Digi manager service %s exist on node %s, re create it"%(self.get_name(), anode.get_name()), 5)
            anode.service_destroy(self.get_name())
            anode.service_init(self.get_name(),
                               self.get_version(),
                               self.get_mserver_port(),
                               vol_file_img,
                               self.sub_nodes[anode])

    def start(self):
        """
            return code specify
            ret[0]:service start success node count
            ret[1]:service start failed node count
            ret[2]:service not found node count
            ret[3]:service already started node count
            ret[4]:the node can not connected
            ret[5]:service version does not match node count
        """
        ret = [0, 0, 0, 0, 0, 0]
        nodes = self.get_nodes()
        thread_result = []
        try:    
            self.service_thread_pool = ClusterThreadPool(len(nodes))
            self.service_thread_pool.initPool(data=nodes, target_info=('service_start', [self.get_name(), self.get_version(), self.get_fsid()], dict()))
            self.service_thread_pool.start_threads()
            self.service_thread_pool.clear_threads()
            thread_result = self.service_thread_pool.get_results()
        except Exception, e:
            digi_debug("Digi manager service start caught exception: %s" % traceback.print_exc(e), 5)
        else:
            pass
        finally:
            pass
        for result in thread_result:
            anode = result[0]
            r = result[1]
        #for anode in nodes:
        #    r = anode.service_start(self.get_name(), self.get_version(), self.get_fsid())
            if r == "-1":
                ret[4] = ret[4] + 1
            elif r == "1":
                ret[0] = ret[0] + 1
            elif r == "2":
                ret[2] = ret[2] + 1
            elif r == "3":
                ret[1] = ret[1] + 1
            elif r == "4":
                ret[3] = ret[3] + 1
            elif r == "5":
                ret[5] = ret[5] + 1
            else:
                digi_debug("Digi manager service start raise an error on node %s"%(anode.get_name()), 2)
        return ret

    def stop(self):
        """
            return code specify
            ret[0]:start success node count
            ret[1]:start failed node count
            ret[2]:service not exist node count
            ret[3]:node can not connected
            ret[4]:whether the service is in use
        ret[5]:the service already been stoped
        """
        ret = [0, 0, 0, 0, False,0]
        cifs_status = []
        nfs_status = []
        nodes = self.get_nodes()

        #first check whether the service is in use
        cifs_status = self.export_cifs_status()
        if cifs_status[1] > 0:
            ret[4] = True
            return ret
        elif cifs_status[0] > 0:
            self.export_cifs_stop()

        nfs_status = self.export_nfs_status()
        if nfs_status[1] > 0:
            ret[4] = True
            return ret
        elif nfs_status[0] > 0:
            self.export_nfs_stop()

        nfsmountpath = '/usr/local/ivcs-data/vmc/nfsmount/'
        if os.path.exists(nfsmountpath):
            filelist = os.listdir(nfsmountpath)
            for file in filelist:
                if os.path.islink(nfsmountpath + file) and os.path.realpath(nfsmountpath + file) == self.mount_dir:
                    ret[4] = True
                    return ret

        thread_result = []
        try:    
            self.service_thread_pool = ClusterThreadPool(len(nodes))
            self.service_thread_pool.initPool(data=nodes, target_info=('service_stop', [self.get_name()], dict()))
            self.service_thread_pool.start_threads()
            self.service_thread_pool.clear_threads()
            thread_result = self.service_thread_pool.get_results()
        except Exception, e:
            digi_debug("Digi manager service stop caught exception: %s" % traceback.print_exc(e), 5)
        else:
            pass
        finally:
            pass
        for result in thread_result:
            anode = result[0]
            r = result[1]
        #for anode in nodes:
        #    r = anode.service_stop(self.get_name())
            if r == "-1":
                ret[3] = ret[3] + 1
            elif r == "1":
                ret[0] = ret[0] + 1
            elif r == "2":
                ret[2] = ret[2] + 1
            elif r == "3":
                ret[1] = ret[1] + 1
            elif r == "4":
                ret[5] = ret[5] + 1
            else:
                digi_debug("Digi manager service stop raise an error on node %s"%(anode.get_name()), 2)
        return ret

    def destroy(self):
        """
            return code specify:
            ret[0]:destroy success node count
            ret[1]:destroy failed node count
            ret[2]:service not exist node count
            ret[3]:whether the service is in use
        """
        ret = [0, 0, 0, False]
        cifs_status = []
        nfs_status = []
        nodes = self.get_nodes()

        #first check whether the service is in use
        cifs_status = self.export_cifs_status()
        if cifs_status[1] > 0:
            ret[3] = True
            return ret
        elif cifs_status[0] > 0:
            self.export_cifs_stop()

        nfs_status = self.export_nfs_status()
        if nfs_status[1] > 0:
            ret[3] = True
            return ret
        elif nfs_status[0] > 0:
            self.export_nfs_stop()

        nfsmountpath = '/usr/local/ivcs-data/vmc/nfsmount/'
        if os.path.exists(nfsmountpath):
            filelist = os.listdir(nfsmountpath)
            for file in filelist:
                if os.path.islink(nfsmountpath + file) and os.path.realpath(nfsmountpath + file) == self.mount_dir:
                    ret[3] = True
                    return ret

        thread_result = []
        try:    
            self.service_thread_pool = ClusterThreadPool(len(nodes))
            self.service_thread_pool.initPool(data=nodes, target_info=('service_destroy', [self.get_name()], dict()))
            self.service_thread_pool.start_threads()
            self.service_thread_pool.clear_threads()
            thread_result = self.service_thread_pool.get_results()
        except Exception, e:
            digi_debug("Digi manager service destroy caught exception: %s" % traceback.print_exc(e), 5)
        else:
            pass
        finally:
            pass
        for result in thread_result:
            anode = result[0]
            r = result[1]

        #for anode in nodes:
        #    r = anode.service_destroy(self.get_name())
            if r == "-1":
                digi_debug("destroy service:%s, on node:%s, failed because of transport"%(self.get_name(), anode.get_name()))
            elif r == "1":
                ret[0] = ret[0] + 1
            elif r == "2":
                ret[2] = ret[2] + 1
            elif r == "3":
                ret[1] = ret[1] + 1
            else:
                digi_debug("Digi manager service destroy raise an error on node %s"%(anode.get_name()), 5)
            anode.update_disk()
        cmd = []
        cmd.append("/bin/rm")
        cmd.append("-rf")
        cmd.append(self.config_dir)
        r = execute(cmd)

        return ret

    def restart(self):
        """
            return code specify:
            1:    service restart success
            2:    service need not to be restart
            3:    service restart failed
        """
        (status, status_message) = self.status()
        if status == 1 or status == 2:
            return 2

        nodes = self.get_nodes()
        thread_result = []
        try:    
            self.service_thread_pool = ClusterThreadPool(len(nodes))
            self.service_thread_pool.initPool(data=nodes, target_info=('service_status', [self.get_name(), self.get_version()], dict()))
            self.service_thread_pool.start_threads()
            self.service_thread_pool.clear_threads()
            thread_result = self.service_thread_pool.get_results()
        except Exception, e:
            digi_debug("Digi manager service destroy raise an error on node %s"%(anode.get_name()), 5)
        else:
            pass
        finally:
            pass
        for result in thread_result:
            anode = result[0]
            r = result[1]
        #for anode in nodes:
            #r = anode.service_status(self.get_name(), self.get_version())
            if r[0] == "1":
                continue
            elif r[0] == "2":
                vol_file_img = get_config_file(self.vol_file_path).read()
                anode.service_init(self.get_name(),
                                   self.get_version(),
                                   self.get_mserver_port(),
                                   vol_file_img,
                                   self.sub_nodes[anode])
                anode.service_start(self.get_name(), self.get_version(), self.get_fsid())
            elif r[0] == "3": #case service stoped
                ret = anode.service_start(self.get_name(), self.get_version(), self.get_fsid())
                if ret == "3": #only the condition service start failed needs to be considored
                    #print "restart failed ..."
                    digi_debug("Digi manager service restart failed on node %s"%(self.get_name(), anode.get_name()), 2)
            elif r[0] == "4": #case service invalid
                anode.service_stop(self.get_name())
                anode.service_start(self.get_name(), self.get_version(), self.get_fsid())
            elif r[0] == "5" or r[0] == "6": #case service version do not match
                vol_file_img = get_config_file(self.vol_file_path).read()
                anode.service_restart(self.get_name(),
                                  self.get_version(),
                                  self.get_mserver_port(),
                                  vol_file_img,
                                  self.sub_nodes[anode])

        #wait for seconds to checkout the status is ready
        i = 0
        while i < 10:
            (status_code, status_message) = self.status()
            if status_code == 1 or status_code == 2:
                return 1
            else:
                time.sleep(0.1)
                i += 1

        return 3

    def status(self):
        """
            return code specify:
            (1, status_message):    all service on nodes start(self.used_size and self.pid was set)
            (2, status_message):    all service on nodes stop
            (3, status_message):    some start and some stop, no invalid
            (4, status_message):    some service has an invalid status
        """
        not_connect_count       = int(0)
        start_count             = int(0)
        stop_count              = int(0)
        not_found_count         = int(0)
        invalid_count           = int(0)
        version_not_match_count = int(0)
        disk_not_start_count    = int(0)

        service_size = long(0)

        status_message = ""

        self.set_used_size("0")
        self.pid = ""

        nodes = self.get_nodes()
        thread_result = []
        try:
            self.service_thread_pool.initPool(data=nodes, target_info=('service_status', [self.get_name(), self.get_version()], dict()))
            self.service_thread_pool.start_threads()
            self.service_thread_pool.clear_threads()
            thread_result = list(self.service_thread_pool.get_results())
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            r = result[1]
        #for anode in nodes:
        #    anode.threadtest(anode.get_name())
        #    r = anode.service_status(self.get_name(), self.get_version())
            if r[0] == "-1":
                status_message = "%s%s: node can not connect\n"%(status_message,
                                                                 anode.get_name())
                not_connect_count = not_connect_count + 1
            elif r[0] == "1" or r[0] == "6":
                digi_debug("service:%s on node:%s has space:%s"%(self.get_name(),
                                                                 anode.get_name(),
                                                                 r[1]))
                if string_compare(r[1], self.get_size()) > 0:
                    self.set_size(long(r[1]))
                if string_compare(r[2], self.get_used_size()) > 0:
                    self.set_used_size(r[2])
                self.pid = r[3]
                if r[0] == "1":
                    status_message = "%s%s: started, total_size: %s, used_size: %s, pid:%s\n"%(
                                      status_message, anode.get_name(), r[1], r[2], r[3])
                    start_count = start_count + 1
                else:
                    status_message = "%s%s: disk not start, total_size: %s, used_size: %s, pid:%s\n"%(
                                      status_message, anode.get_name(), r[1], r[2], r[3])
                    disk_not_start_count = disk_not_start_count + 1
            elif r[0] == "2":
                status_message = "%s%s: service not found\n"%(status_message, anode.get_name())
                not_found_count = not_found_count + 1
            elif r[0] == "3":
                status_message = "%s%s: stoped\n"%(status_message, anode.get_name())
                stop_count = stop_count + 1
            elif r[0] == "4":
                status_message = "%s%s: invalid\n"%(status_message, anode.get_name())
                invalid_count = invalid_count + 1
            elif r[0] == "5":
                status_message = "%s%s: version not match\n"%(status_message, anode.get_name())
                version_not_match_count = version_not_match_count + 1

        #print start_count, stop_count, invalid_count, "############"
        if start_count == len(nodes):
            return (1, status_message)
        elif stop_count == len(nodes):
            return (2, status_message)
        elif invalid_count == 0:
            return (3, status_message)
        else:
            return (4, status_message)

    def add_disk(self, disks):
        """
            return code specify:
            ret[0]:    add disk success count
            ret[1]:    service not found count
            ret[2]:    add disk failed count
            ret[3]:    the disk to add has been pop out count
            ret[4]:    the disk to add not exist count
            ret[5]:    failed because of a node can not connected
            ret[6]:    add disk failed or not(bool)
        """
        ret = [0, 0, 0, 0, 0, 0, False]
        add_disk_sub_nodes = dict()
        new_vol_file_img   = ""
        extend_file_img    = ""
        service_size       = long()

        service_add_list   = []
        backtrace          = False

        if self.get_raid_level() == "0":
            if len(disks)%self.get_stripe_num() != 0:
                return None
        #if self.get_raid_level() == "1":
        #    if len(disks)%2 != 0:
        #        return None

        if self.get_raid_level() == "01":
            if len(disks)%(2*self.get_stripe_num()) != 0:
                return None

        self.save_vol_file()
        self.version = self.get_version()
        self.increase_version()
        extend_file_img = self.generate_extend_file(disks)
        new_vol_file_img = self.combine_vol_file()

        #initialize a relationship between node and disk
        nodes = self.get_nodes()
        for anode in nodes:
            add_disk_sub_nodes[anode] = []
        for adisk in disks:
            add_disk_sub_nodes[adisk.get_node()].append(adisk.get_dev_id())

        #first check wheather the node can be connect
        for anode in nodes:
            if not anode.remote_connect():
                if len(add_disk_sub_nodes[anode]) > 0:
                    digi_debug("the node: %s can not be connected"%(anode.get_name()))
                    return ret

        thread_result = []
        try:
            self.service_thread_pool.initPool(data=nodes, target_info=('service_extend', [self.get_name(), extend_file_img, self.get_version()], dict()))
            self.service_thread_pool.start_threads()
            self.service_thread_pool.clear_threads()
            thread_result = list(self.service_thread_pool.get_results())
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            r = result[1]

        #for anode in nodes:
        #    r = anode.service_extend(self.get_name(),
        #                             extend_file_img,
        #                             self.get_version())
            digi_debug("service add disk on node: %s return: %s"%(anode.get_name(), r))
            service_add_list.append(anode)
            if r == "-1":
                ret[5] = ret[5] + 1
                continue
            elif r == "1":
                ret[0] = ret[0] + 1
            elif r == "2":
                ret[1] = ret[1] + 1
                continue
            elif r == "3":
                ret[2] = ret[2] + 1
                backtrace = True
                break
            anode.update_disk()

        if backtrace:
            for anode in service_add_list:
                anode.service_undo_extend(self.get_name())
            self.decrease_version()
            self.recover_vol_file()
            ret[6] = True
            return ret

        thread_result = []
        try:
            self.service_thread_pool.initPool(data=nodes, target_info=('service_online_extend', [self.get_name(), new_vol_file_img, self.get_version(), add_disk_sub_nodes], dict()))
            self.service_thread_pool.start_threads()
            self.service_thread_pool.clear_threads()
            thread_result = list(self.service_thread_pool.get_results())
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            r = result[1]

        #for anode in nodes:
        #    anode.service_online_extend(self.get_name(),
        #                                new_vol_file_img,
        #                                self.get_version(),
        #                                add_disk_sub_nodes[anode])
            anode.update_disk()
        else:
            os.system('df -h /cluster2/%s >/dev/null 2>&1' % self.get_name())
            os.system('/usr/bin/set_fsid %s %s'%(mount_dir_prefix + "/" + self.get_name() ,self.get_fsid()))
#        digi_debug("after add_disk, size now is: %d"%(self.get_size()))
#        self.init_size_file(self.get_size())

        #add new disks to config file
        self.__add_disk(disks)
        if self.get_raid_level() == "1" or self.get_raid_level() == "01":
            self.init_afr_time(disks)

        self.discard_saved_vol_file()

        return ret

#    def replace(self, old_node, replace_node, volumes, replace_disk_names):
    def replace(self, old_node, replace_node, replace_disk_ports_user):
        """
            return code specify:
            1:    replace success
            2:    no sub disks, no need to replace
        """
        if len(self.sub_nodes[old_node]) < 1:
            return 2
        
        replace_disk_names = []    
        volumes = []
        rnode_disks = []
        
        for adisk in replace_disk_ports_user :
            volumes.append("%s-%s"%(adisk[3], adisk[1]))
            replace_disk_names.append(adisk[0])
            if self.get_name() == adisk[2] :
                rnode_disks.append(adisk[0])

        self.__del_node(old_node)
        self.__add_node(replace_node, rnode_disks)

        vol_file_img = get_config_file(self.vol_file_path).read()
        replace_node.service_init(self.get_name(),
                                  self.get_version(),
                                  self.get_mserver_port(),
                                  vol_file_img,
                                  rnode_disks)

        nodes = self.get_nodes()
        thread_result = []
        try:
            service_thread_pool = ClusterThreadPool(len(nodes))
            service_thread_pool.initPool(data=nodes, target_info=('service_replace', [self.get_name(), volumes], dict()))
            service_thread_pool.start_threads()
            #print "###############################"
            thread_result = service_thread_pool.get_results()
            #print service_thread_pool.ret_pool.get()
            #print "###############################"
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            ret = result[1]
        #for anode in nodes:
        #    anode.service_replace(self.get_name(), volumes)

        return 1

    def export_cifs_start(self, node_names=None):
        """
            return code specify:
            ret[0]:    sucess count
            ret[1]:    not found count
            ret[2]:    failed count
        """
        success   = int(0)
        not_found = int(0)
        failed    = int(0)
        node_list = []

        if node_names:
            for node_name in node_names:
                anode = self.get_node_by_name(node_name)
                if not anode:
                    not_found = not_found+1
                    continue
                node_list.append(anode)
        else:
            node_list = self.get_nodes()

        thread_result = []
        try:
            service_thread_pool = ClusterThreadPool(len(node_list))
            service_thread_pool.initPool(data=node_list, target_info=('service_cifs_start', [self.get_name()], dict()))
            service_thread_pool.start_threads()
            #print "###############################"
            thread_result = service_thread_pool.get_results()
            #print service_thread_pool.ret_pool.get()
            #print "###############################"
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            ret = result[1]
        #for anode in node_list:
            if ret:#anode.service_cifs_start(self.get_name()):
                success = success + 1
                continue
            failed = failed + 1

        return [success, not_found, failed]

    def export_cifs_stop(self, node_names=None):
        """
            return code specify:
            ret[0]:    sucess count
            ret[1]:    failed count
            ret[2]:    in use count
            ret[3]:    service not found count
            ret[4]:    node not found count
            ret[5]:    node not connect count
        """
        success           = int(0)
        failed            = int(0)
        in_use            = int(0)
        service_not_found = int(0)
        node_not_found    = int(0)
        node_not_connect  = int(0)

        node_list = []

        if node_names:
            for node_name in node_names:
                anode = self.get_node_by_name(node_name)
                if not anode:
                    node_not_found = node_not_found + 1
                    continue
                node_list.append(anode)
        else:
            node_list = self.get_nodes()

        thread_result = []
        try:
            service_thread_pool = ClusterThreadPool(len(node_list))
            service_thread_pool.initPool(data=node_list, target_info=('service_cifs_stop', [self.get_name()], dict()))
            service_thread_pool.start_threads()
            #print "###############################"
            thread_result = service_thread_pool.get_results()
            #print service_thread_pool.ret_pool.get()
            #print "###############################"
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            ret = result[1]
        #for anode in node_list:
        #    ret = anode.service_cifs_stop(self.get_name())
            if ret == "-1":
                node_not_connect = node_not_connect + 1
            elif ret == "1":
                success = success + 1
            elif ret == "2":
                failed = failed + 1
            elif ret == "3":
                in_use = in_use + 1
            elif ret == "4":
                service_not_found = service_not_found + 1

        return [success, failed, in_use, service_not_found, node_not_found, node_not_connect]

    def export_cifs_status(self, output_img=None, node_names=None):
        """
            return code specify:
            ret[0]:    start count(not_in_use)
            ret[1]:    start count(in_use)
            ret[2]:    stop count
            ret[3]:    service not found(on node)
            ret[4]:    node not found count
            ret[5]:    node not connect count
        """
        start_not_use     = int(0)
        start_in_use      = int(0)
        stop              = int(0)
        service_not_found = int(0)
        node_not_found    = int(0)
        node_not_connect  = int(0)

        node_list = []

        if node_names:
            for node_name in node_names:
                anode = self.get_node_by_name(node_name)
                if not anode:
                    node_not_found = node_not_found + 1
                    continue
                node_list.append(anode)
        else:
            node_list = self.get_nodes()

        thread_result = []
        try:
            service_thread_pool = ClusterThreadPool(len(node_list))
            service_thread_pool.initPool(data=node_list, target_info=('service_cifs_status', [self.get_name()], dict()))
            service_thread_pool.start_threads()
            #print "###############################"
            thread_result = service_thread_pool.get_results()
            #print service_thread_pool.ret_pool.get()
            #print "###############################"
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            ret = result[1]
        #for anode in node_list:
        #    ret = anode.service_cifs_status(self.get_name())
            if ret == "-1":
                node_not_connect = node_not_connect + 1
            elif ret == "1":
                start_not_use = start_not_use + 1
            elif ret == "2":
                start_in_use = start_in_use + 1
            elif ret == "3":
                stop = stop + 1
            elif ret == "4":
                service_not_found = service_not_found + 1
            if output_img:
                output_img.write("%s\t%s\n"%(anode.get_name(), cifs_status_type[ret]))

        return [start_not_use, start_in_use, stop, service_not_found, node_not_found, node_not_connect]
    
    def export_cifs_restart_node(self):
        node_not_found = int(0)
        node_not_connect = int(0)
        success = int(0)
        failed = int(0)
        node_list = []
        
        node_list = self.get_nodes()
        
        thread_result = []
        try:
            service_thread_pool = ClusterThreadPool(len(node_list))
            service_thread_pool.initPool(data=node_list, target_info=('service_cifs_restart_node', [self.get_name()], dict()))
            service_thread_pool.start_threads()
            #print "###############################"
            thread_result = service_thread_pool.get_results()
            #print service_thread_pool.ret_pool.get()
            #print "###############################"
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            ret = result[1]

        #for anode in node_list:
        #    ret = anode.service_cifs_restart_node(self.get_name())
            if ret == "-1":
                node_not_connect = node_not_connect + 1
            elif ret == "1":
                success = success + 1
            elif ret == "2":
                failed = failed + 1
        return [success, failed, node_not_connect]
    
    def export_cifs_restart_service(self):
        node_not_found = int(0)
        node_not_connect = int(0)
        success = int(0)
        failed = int(0)
        node_list = []
        
        node_list = self.get_nodes()
            
        thread_result = []
        try:
            service_thread_pool = ClusterThreadPool(len(node_list))
            service_thread_pool.initPool(data=node_list, target_info=('service_cifs_restart_service', [self.get_name()], dict()))
            service_thread_pool.start_threads()
            #print "###############################"
            thread_result = service_thread_pool.get_results()
            #print service_thread_pool.ret_pool.get()
            #print "###############################"
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            ret = result[1]

        #for anode in node_list:
        #    ret = anode.service_cifs_restart_service(self.get_name())
            if ret == "-1":
                node_not_connect = node_not_connect + 1
            elif ret == "1":
                success = success + 1
            elif ret == "2":
                failed = failed + 1
        return [success, failed, node_not_connect]
    
    def export_cifs_list_user(self, output_img):
        node_list = self.get_nodes()

        thread_result = []
        try:
            service_thread_pool = ClusterThreadPool(len(node_list))
            service_thread_pool.initPool(data=node_list, target_info=('service_cifs_list_user', [self.get_name()], dict()))
            service_thread_pool.start_threads()
            #print "###############################"
            thread_result = service_thread_pool.get_results()
            #print service_thread_pool.ret_pool.get()
            #print "###############################"
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            ret = result[1]
        #for anode in node_list:
        #    ret = anode.service_cifs_list_user(self.get_name())
            if ret == "-1":
                output_img.write("error\n")
                break
            elif not ret:
                output_img.write("nouser\n")
                break
            else:
                user_list = ret
                for user in user_list:
                    output_img.write("%s\n" % (user))
                break

        return output_img
        
    def export_cifs_list_links(self, output_img):
        node_list = self.get_nodes()
        thread_result = []
        try:
            service_thread_pool = ClusterThreadPool(len(node_list))
            service_thread_pool.initPool(data=node_list, target_info=('service_cifs_list_links', [self.get_name()], dict()))
            service_thread_pool.start_threads()
            #print "###############################"
            thread_result = service_thread_pool.get_results()
            #print service_thread_pool.ret_pool.get()
            #print "###############################"
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            ret = result[1]
        #for anode in node_list:
        #    ret = anode.service_cifs_list_links(self.get_name())
            if ret == "-1":
                output_img.write("%s\tcifs_not_start\n" % (anode.get_name()))
            elif not ret:
                output_img.write("%s\tnolink\n" % (anode.get_name()))
            else:
                links_list = ret
                for link in links_list:
                    output_img.write("%s\t%s\t%s\t%s\n" % (anode.get_name(), link['username'],link['pid'],link['logintime']))
        else:
            return output_img

    def export_cifs_del_links(self, node_name, pid):
        anode = self.get_node_by_name(node_name)
        ret = anode.service_cifs_del_links(pid)
        if ret == '1':
            return True
        else:
            return False
    
    def export_cifs_add_user(self, user_name, passwd, output_img=None, node_names=None):
        """
            ret[0]:    add success count
            ret[1]:    add failed count
            ret[2]:    service_not_found count
            ret[3]:    node_not_found count
            ret[4]:    node_not-connect count
        """
        succeed           = int(0)
        failed            = int(0)
        service_not_found = int(0)
        node_not_found    = int(0)
        node_not_connect  = int(0)
        node_list = []
        #-----------------------------------------
        uid = self.get_new_uid()
        #-----------------------------------------
        if node_names:
            for node_name in node_names:
                anode = self.get_node_by_name(node_name)
                if not anode:
                    node_not_found = node_not_found + 1
                    continue
                node_list.append(anode)
        else:
            node_list = self.get_nodes()
        succlist = []
        thread_result = []
        try:
            service_thread_pool = ClusterThreadPool(len(node_list))
            service_thread_pool.initPool(data=node_list, target_info=('service_cifs_add_user', [self.get_name(), user_name, passwd, uid], dict()))
            service_thread_pool.start_threads()
            #print "###############################"
            thread_result = service_thread_pool.get_results()
            #print service_thread_pool.ret_pool.get()
            #print "###############################"
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            ret = result[1]
        #for anode in node_list:
        #    ret = anode.service_cifs_add_user(self.get_name(), user_name, passwd)
            if ret == "1":
                succlist.append(anode)
            else:
                break
        else:
            succlist = []
        if succlist:
            for aanode in succlist:
                aanode.service_cifs_add_user_rollback(self.get_name(), user_name)
            else:
                return False
        return True
            
    def export_cifs_del_user(self, user_name, output_img=None, node_names=None):
        """
            ret[0]:    del success count
            ret[1]:    del failed count
            ret[2]:    service_not_found count
            ret[3]:    node_not_found count
            ret[4]:    node_not_connect count
        """
        succeed           = int(0)
        failed            = int(0)
        service_not_found = int(0)
        node_not_found    = int(0)
        node_not_connect  = int(0)
        
        node_list = []
        if node_names:
            for node_name in node_names:
                anode = self.get_node_by_name(node_name)
                if not anode:
                    node_not_found = node_not_found + 1
                    continue
                node_list.append(anode)
        else:
            node_list = self.get_nodes()
        succlist = []
        thread_result = []
        try:
            service_thread_pool = ClusterThreadPool(len(node_list))
            service_thread_pool.initPool(data=node_list, target_info=('service_cifs_del_user', [self.get_name(),user_name], dict()))
            service_thread_pool.start_threads()
            #print "###############################"
            thread_result = service_thread_pool.get_results()
            #print service_thread_pool.ret_pool.get()
            #print "###############################"
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            ret = result[1]
        #for anode in node_list:
        #    ret = anode.service_cifs_del_user(self.get_name(), user_name)
            if ret == "1":
                succlist.append(anode)
            else:
                digi_debug("find failed on %s" % (anode.get_name()))
                break
        else:
            succlist = []
        digi_debug(succlist)
        if succlist:
            for aanode in succlist:
                aanode.service_cifs_del_user_rollback(self.get_name(), user_name)
            else:
                return False
            #if ret == "-1":
            #    node_not_connect = node_not_connect + 1
            #elif ret == "1":
            #    succeed = succeed + 1
            #elif ret == "2":
            #    failed = failed + 1
            #elif ret == "3":
            #   failed = failed + 1
            #elif ret == "4":
            #    failed = failed + 1
            #elif ret == "5":
            #    service_not_found = service_not_found + 1
        return True

    def export_nfs_start(self, node_names=None):
        try:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('set')
            cmd.append(self.name)
            cmd.append('nfs.disable')
            cmd.append('off')
            ret = execute(cmd, tmp_img)
            digi_debug("Service nfs start, %s return %d" % (' '.join(cmd),ret),5)    
            result = tmp_img.read()
            if ret:
                digi_debug("Service nfs start, %s" % result,3)
                EXIT(13239)
        except Exception,e:
            digi_debug("Service nfs start, caught exception: %s" % e,3)
            EXIT(-1)
        return 0

    def export_nfs_stop(self, node_names=None):
        try:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('set')
            cmd.append(self.name)
            cmd.append('nfs.disable')
            cmd.append('on')
            ret = execute(cmd, tmp_img)
            digi_debug("Service nfs stop, %s return %d" % (' '.join(cmd),ret),5)    
            result = tmp_img.read()
            if ret:
                digi_debug("Service nfs stop, %s" % result,3)
                EXIT(13240)
        except Exception,e:
            digi_debug("Service nfs stop, caught exception: %s" % e,3)
            EXIT(-1)
        return 0

    def export_nfs_status(self, output_img=None, node_names=None):
        try:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('status')
            cmd.append(self.name)
            cmd.append('nfs')
            cmd.append('clients')
            ret = execute(cmd, tmp_img)
            digi_debug("Service nfs status, %s return %d" % (' '.join(cmd),ret),5)    
            result = tmp_img.read()
            if output_img:
                if result.find('is not started') >= 0:
                    output_img.write(result)
                else:
                    if result.find('NFS server is disabled for volume') >= 0:
                        output_img.write("Volume %s NFS status : Stoped\n" % self.name)
                    else:
                        output_img.write("Volume %s NFS status : Started\n\n" % self.name)
                        output_img.write(result)
        except Exception,e:
            digi_debug("Service nfs status, caught exception: %s" % e,3)
            EXIT(-1)
        return 0

    def export_nfs_list_user(self, output_img):
        try:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('info')
            cmd.append(self.name)
            ret = execute(cmd, tmp_img)
            digi_debug("Service nfs list user, %s return %d" % (' '.join(cmd),ret),5)    
            result = tmp_img.read()
            m = re.search("nfs.rpc-auth-allow: (\S+)", result)
            if m:
                output_img.write(m.group(1))
            else:
                output_img.write('None')
        except Exception,e:
            digi_debug("Service nfs list user, caught exception: %s" % e,3)
            EXIT(-1)

        return output_img
    
    def export_nfs_list_links(self, output_img):
        node_list = self.get_nodes()
        thread_result = []
        try:
            service_thread_pool = ClusterThreadPool(len(node_list))
            service_thread_pool.initPool(data=node_list, target_info=('service_nfs_list_links', [self.get_name()], dict()))
            service_thread_pool.start_threads()
            #print "###############################"
            thread_result = service_thread_pool.get_results()
            #print service_thread_pool.ret_pool.get()
            #print "###############################"
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        #print thread_result
        for result in thread_result:
            anode = result[0]
            ret = result[1]
        #for anode in node_list:
        #    ret = anode.service_nfs_list_links(self.get_name())
            if ret == "-1":
                output_img.write("%s\tnfs_not_start\n" % (anode.get_name()))
            elif not ret:
                output_img.write("%s\tnolink\n" % (anode.get_name()))
            else:
                links_list = ret
                for link in links_list:
                    output_img.write("%s\t%s\n" % (anode.get_name(), link))
        else:
            return output_img
        
    def export_nfs_del_links(self, node_name, tar_ip=''):
        anode = self.get_node_by_name(node_name)
        ret = anode.service_nfs_del_links(self.get_name(), tar_ip)
        if ret == '1':
            return True
        else:
            return False
    
    def export_nfs_add_user(self, user_ip, output_img=None, node_names=None):
        curr_user_ip_list = []
        try:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('info')
            cmd.append(self.name)
            ret = execute(cmd, tmp_img)
            digi_debug("Service nfs add user, %s return %d" % (' '.join(cmd),ret),5)    
            result = tmp_img.read()
            m = re.search("nfs.rpc-auth-allow: (\S+)", result)
            if m:
                curr_user_ip_list = m.group(1).split(',')

            user_ip_list = user_ip.split(',')
            for user in user_ip_list:
                if user not in curr_user_ip_list:
                    curr_user_ip_list.append(user)

            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            if not curr_user_ip_list:
                cmd.append('reset')
                cmd.append(self.name)
                cmd.append('nfs.rpc-auth-allow')
            else:
                cmd.append('set')
                cmd.append(self.name)
                cmd.append('nfs.rpc-auth-allow')
                cmd.append(','.join(curr_user_ip_list))
            ret = execute(cmd, tmp_img)
            digi_debug("Service nfs add user, %s return %d" % (' '.join(cmd),ret),5)    
            if ret:
                return False
            if re.search("nfs.rpc-auth-reject: \*.\*.\*.\*", result):
                tmp_img = tempfile.TemporaryFile()
                cmd = []
                cmd.append(settings.COMMANDS['digiocean'])
                cmd.append('volume')
                cmd.append('reset')
                cmd.append(self.name)
                cmd.append('nfs.rpc-auth-reject')
                ret = execute(cmd, tmp_img)
                digi_debug("Service nfs add user, %s return %d" % (' '.join(cmd),ret),5)    
                if ret:
                    return False
        except Exception,e:
            digi_debug("Service nfs add user, caught exception: %s" % e,3)
            EXIT(-1)
        return True
    
    def export_nfs_del_user(self, user_ip, output_img=None, node_names=None):
        curr_user_ip_list = []
        try:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('info')
            cmd.append(self.name)
            ret = execute(cmd, tmp_img)
            digi_debug("Service nfs del user, %s return %d" % (' '.join(cmd),ret),5)    
            result = tmp_img.read()
            m = re.search("nfs.rpc-auth-allow: (\S+)", result)
            if m:
                curr_user_ip_list = m.group(1).split(',')

            user_ip_list = user_ip.split(',')
            for user in user_ip_list:
                if user in curr_user_ip_list:
                    curr_user_ip_list.remove(user)

            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            if not curr_user_ip_list:
                cmd.append('reset')
                cmd.append(self.name)
                cmd.append('nfs.rpc-auth-allow')
            else:
                cmd.append('set')
                cmd.append(self.name)
                cmd.append('nfs.rpc-auth-allow')
                cmd.append(','.join(curr_user_ip_list))
            ret = execute(cmd, tmp_img)
            digi_debug("Service nfs del user, %s return %d" % (' '.join(cmd),ret),5)    
            if ret:
                return False
            if not curr_user_ip_list:
                tmp_img = tempfile.TemporaryFile()
                cmd = []
                cmd.append(settings.COMMANDS['digiocean'])
                cmd.append('volume')
                cmd.append('set')
                cmd.append(self.name)
                cmd.append('nfs.rpc-auth-reject')
                cmd.append('*.*.*.*')
                ret = execute(cmd, tmp_img)
                digi_debug("Service nfs add user, %s return %d" % (' '.join(cmd),ret),5)    
                if ret:
                    return False
        except Exception,e:
            digi_debug("Service nfs del user, caught exception: %s" % e,3)
            EXIT(-1)
        return True   

    def normal_list_disk(self, output_img):
        nodes = self.get_nodes()
        for anode in nodes:
            if len(self.sub_nodes[anode]) < 1:
                continue
            disks = self.sub_nodes[anode]
            for adisk in disks:
                if anode.get_disk_by_name(adisk):
                    output_img.write("%s:%s\t\n"%(anode.get_name(), anode.get_disk_by_name(adisk).get_dev()))
                else:
                    output_img.write("%s:%s\t\n"%(anode.get_name(), 'nodisk'))
            
    #-----------------------------------
    # get new user id
    #-----------------------------------
    def get_new_uid(self):
        #retcode,proc = utils.cust_popen("cat %s | awk -F\: '{print $3}'|sort -n" % settings.PASSWD)
        proc = os.popen("cat %s | awk -F\: '{print $3}'|sort -n" % settings.PASSWD)
        uids = [line.strip() for line in proc.readlines()]
        uid = settings.SMBBASEUID
        while True:
            if uid in uids:
                uid = str(int(uid) + 1)
            else:
                break  
        return uid

    def afr_list_disk(self, output_img):
        mirror_list = self.get_afr_disk_pair()

        while len(mirror_list) != 0:
            str = ""
            mirror_single = mirror_list.popitem()
            mirror_name = mirror_single[0]
            disk_list = mirror_single[1]
            for adisk in disk_list:
                if adisk:
                    if str:
                        str="%s <=> %s:%s"%(str, adisk.get_node().get_name(), adisk.get_dev())
                    else:
                        str="%s:%s"%(adisk.get_node().get_name(), adisk.get_dev())
                else:
                    if str:
                        str="%s <=> %s:%s"%(str, 'nolink', 'nodisk')
                    else:
                        str="%s:%s"%('nolink', 'nodisk')
            output_img.write("mirror: %s\n"%(mirror_name))
            output_img.write("%s\n"%(str))

    def list_disk(self, output_img):
        output_img.write("service name: %s\n"%(self.get_name()))
        output_img.write("service raid level: %s\n"%(self.get_raid_level()))
        output_img.write("service size: %d\n"%(self.get_size()))
        if self.get_raid_level() != "1" and self.get_raid_level() != "01":
            self.normal_list_disk(output_img)
        else:
            self.afr_list_disk(output_img)
        output_img.write("\n")

    def list(self, output_img):
        (status_code, status_message) = self.status()
        ret = self.export_cifs_status()
        if ret[0] + ret[1] == 0:
            cifs_status = "stop"
        elif ret [2] + ret[3] + ret[4] + ret[5] == 0:
            cifs_status = "start"
        else:
            cifs_status = "Warnning"
        ret = self.export_nfs_status()
        if ret[0] + ret[1] == 0:
            nfs_status = "stop"
        elif ret [2] + ret[3] + ret[4] + ret[5] == 0:
            nfs_status = "start"
        else:
            nfs_status = "Warnning"

        output_img.write("service name: %s\n"%(self.get_name()))
        output_img.write("service total size: %s\n"%(self.get_size()))
        output_img.write("service used size: %s\n"%(self.get_used_size()))
        output_img.write("service raid level: %s\n"%(self.get_raid_level()))
        output_img.write("service export cifs status: %s\n"%(cifs_status))
        output_img.write("service export nfs status: %s\n"%(nfs_status))
        if status_code == 1:
            output_img.write("service status: start\n\n")
        elif status_code == 2:
            output_img.write("service status: stop\n\n")
        else:
            output_img.write("service status: Warnning\n")
            output_img.write("%s\n"%(status_message))

    def afr_diff(self):
        for anode in self.sub_nodes:
            anode.service_afr_diff(self.get_name())

    def afr_info(self, output_img, opendir=''):

        """
            return code specify:
            1:    fetch afr info success
            2:    service is not an afr
        """
        cmd = [settings.COMMANDS['digiocean'],'volume','heal', self.name, 'info']
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd,tmp_img)
        result = tmp_img.read()
        p = 'Number of entries: \d+'
        file_num_source = re.findall(p, result)
        file_num = 0
        file_list = []
        for f in file_num_source:
            file_num += int(f.replace('Number of entries: ',''))
        afr_num = list_service_afr_num(self.name)
        result_list = result.split('\n')
        if afr_num == file_num:
            for i in range(len(result_list)):
                m = re.match('Number of entries:(.*)',result_list[i])
                if m:
                    fix_num = int(m.group(1).strip())
                    for j in range(fix_num):
                        file_list.append(result_list[i+1+j])
            file_list.sort()
            if file_list[0] == file_list[-1]:
                file_num = 0
        output_img.write(str(file_num))
        return 1

    def afr_info_topage(self, output_img, opendir):

        """
            return code specify:
            1:    fetch afr info success
            2:    service is not an afr
        """
        #info_all_nodes = []
        info = ""

        if self.get_raid_level() != "1" and self.get_raid_level() != "01":
            return 2

        #self.afr_diff()

        nodes = self.get_nodes()
        for anode in nodes:
            ret = anode.service_afr_info_topage(self.get_name(), opendir)
            if not ret:
                digi_debug("can not get afr info from node:%s, not connect"%
                           anode.get_name())
                continue
            elif ret[0] == '2':
                digi_debug("can not get afr info from node:%s, service not exist on node"%
                           anode.get_name())
                continue
            elif ret[0] == '3':
                digi_debug("can not get afr info from node:%s, no syn on that service"%
                           anode.get_name())
                continue
            elif ret[0] == '1':
                #info_all_nodes.append(ret[1])
                #info = simplejson.dumps(ret[1])
                if 'data' in ret[1]:
                    del ret[1]['data']
                    info = ret[1]
                    continue
                else:
                    info = ret[1]
                    break
        output_img.write(info)
        return 1

    def afr_info_topage_search(self, output_img, opendir):

        """
            return code specify:
            1:    fetch afr info success
            2:    service is not an afr
        """
        #info_all_nodes = []
        info = ""

        if self.get_raid_level() != "1" and self.get_raid_level() != "01":
            return 2

        #self.afr_diff()

        nodes = self.get_nodes()
        nodes_obj = self.sub_nodes.keys()
        disk_port = ''
        disk_name = ''
        disks_dict = {}
        for anode in nodes_obj:
            anode_name = anode.get_name()
            for adisk in self.sub_nodes[anode]:
                disk_name = anode.get_disk_by_name(adisk).get_dev()
                disk_port = anode.get_disk_by_name(adisk).get_port()
                if disk_name and disk_port:
                    if disk_name not in disks_dict:
                        disks_dict[anode_name + '-' + str(disk_port)] = anode_name + '-' +disk_name

        for anode in nodes:
            ret = anode.service_afr_info_topage_search(self.get_name(), opendir, disks_dict)
            if not ret:
                digi_debug("can not get afr info from node:%s, not connect"%
                           anode.get_name())
                continue
            elif ret[0] == '2':
                digi_debug("can not get afr info from node:%s, service not exist on node"%
                           anode.get_name())
                continue
            elif ret[0] == '3':
                digi_debug("can not get afr info from node:%s, no syn on that service"%
                           anode.get_name())
                continue
            elif ret[0] == '1':
                #info_all_nodes.append(ret[1])
                #info = simplejson.dumps(ret[1])
                if 'data' in ret[1]:
                    del ret[1]['data']
                    info = ret[1]
                    continue
                else:
                    info = ret[1]
                    break
        output_img.write(info)
        return 1

    def afr_syn(self):
        disk_np_pairs = vol_afr_mirror(self.vol_file_path)
        for disk_np_pair in disk_np_pairs:
            disk_1 = self.get_disk_by_np(disk_np_pair[1][0], disk_np_pair[1][1])
            disk_2 = self.get_disk_by_np(disk_np_pair[2][0], disk_np_pair[2][1])

            if not disk_1.get_node().remote_connect() or not disk_2.get_node().remote_connect():
                continue

            passive_addr = [disk_2.get_node().get_name(), disk_2.get_dev_id()]

            disk_1.get_node().service_afr_syn(self.get_name(),
                                            disk_1.get_dev_id(),
                                            "active",
                                            passive_addr)
            disk_2.get_node().service_afr_syn(self.get_name(),
                                            disk_2.get_dev_id(),
                                            "passive",
                                            [])

        nodes = self.get_nodes()
#        for anode in nodes:
#            ret = anode.service_afr_syn(self.get_name())
#            if ret:
#                digi_debug("syn on node:%s return:%s"%(anode.get_name(), ret[0]))

    def afr_expand(self, disk_pod):
        """
            return code specify:
            1:    afr expand success.
            2:    mirror missing.
            3:    disk number & expand degree not match.
            4:    unkown mirror.
            5:    afr expand failed
            6:    some node can not connect.
            7:    create expand volfile error.
        """
        mirror_pod = {}
        disk_node_pod  = {}
        disk_list = []
        mirror_list = self.get_afr_disk_pair().keys()
        expand_degree = int(self.options.afr_expand_degree)

        for mirror in mirror_list:
            if not disk_pod.__contains__(mirror):
                digi_debug("mirror %s missing!!!"%(mirror))
                return 2
            if len(disk_pod[mirror]) != expand_degree:
                digi_debug("not enough disk for mirror %s!!!"%(mirror))
                return 3
            for adisk in disk_pod[mirror]:
                disk_list.append(adisk)
                if not disk_node_pod.__contains__(adisk.get_node().get_name()):
                    disk_node_pod[adisk.get_node().get_name()] = []
                disk_node_pod[adisk.get_node().get_name()].append(adisk.get_dev_id())
            mirror_pod[mirror] = disk_pod.pop(mirror)
        if len(disk_pod) > 0:
            digi_debug("unkown mirror exist!!!")
            return 4

        backtrace = False
        node_list = self.get_nodes()

        #first check wheather the node can be connect
        for anode in node_list:
            if not anode.remote_connect():
                digi_debug("node: %s can not be connected"%(anode.get_name()))
                return 6

        self.save_vol_file()
        new_vol_file_img = self.afr_expand_volfile(mirror_pod)
        if not new_vol_file_img:
            digi_debug("generate expand volfile error!!!")
            return 7

        self.stop()
        for anode in node_list:
            if not disk_node_pod.__contains__(anode.get_name()):
                disk_node_pod[anode.get_name()] = []
            ret = anode.service_afr_expand(self.get_name(),
                                           new_vol_file_img,
                                           disk_node_pod[anode.get_name()])
            if ret != "1":
                digi_debug("operation on node %s error!!!"%(anode.get_name()))
                backtrace = True

        if backtrace:
            #TODO:There is still some dirty things on node.
            self.recover_vol_file()
            return 5

        self.discard_saved_vol_file()
        self.__add_disk(disk_list)
        self.set_afr_num((self.get_afr_num()+expand_degree))

        return 1

    def afr_shrink(self, disk_pod):
        """
            return code specify:
            1:    afr expand success.
            2:    mirror missing.
            3:    disk number & shrink degree not match.
            4:    disk not exist in the mirror
            5:    unkown mirror.
            6:    some node can not be connected current.
            7:    create shrink volfile error.
            8:    afr shrink failed
            9:    shrink degree should not bigger than afr subvolumes.
        """
        shrink_pod = {}
        shrink_degree = int(self.options.afr_shrink_degree)

        mirror_pod = self.get_afr_disk_pair()
        mirror_list = mirror_pod.keys()

        disk_node_pod = {}
        disk_list = []

        if (self.get_afr_num() - shrink_degree) < 1:
            digi_debug("current afr degree is:%d, can not shrink %d degree"
                       %(self.get_afr_num(), shrink_degree))
            return 9

        for mirror in mirror_list:
            if not disk_pod.__contains__(mirror):
                digi_debug("mirror %s missing!!!"%(mirror))
                return 2
            if len(disk_pod[mirror]) != shrink_degree:
                digi_debug("not enough disks for mirror %s!!!"%(mirror))
                return 3
            for adisk in disk_pod[mirror]:
                if not find_in_list(mirror_pod[mirror], adisk):
                    digi_debug("mirror %s not have disk %s!!!"%(mirror, adisk.get_dev()))
                    return 4
                if not disk_node_pod.__contains__(adisk.get_node().get_name()):
                    disk_node_pod[adisk.get_node().get_name()] = []
                disk_node_pod[adisk.get_node().get_name()].append(adisk.get_dev_id())
                disk_list.append(adisk)
            shrink_pod[mirror] = disk_pod.pop(mirror)
        if len(disk_pod) > 0:
            digi_debug("there is unkown mirror in arguments!!!")
            return 5

        backtrace = False
        node_list = self.get_nodes()

        #first check wheather the node can be connect
        for anode in node_list:
            if not anode.remote_connect():
                digi_debug("node: %s can not be connected"%(anode.get_name()))
                return 6

        self.save_vol_file()
        new_vol_file_img = self.afr_shrink_volfile(shrink_pod)
        if not new_vol_file_img:
            digi_debug("generate shrink volfile error!!!")
            return 7

        self.stop()

        import pdb
        pdb.set_trace()

        for anode in node_list:
            if not disk_node_pod.__contains__(anode.get_name()):
                disk_node_pod[anode.get_name()] = []
            ret = anode.service_afr_shrink(self.get_name(),
                                           new_vol_file_img,
                                           disk_node_pod[anode.get_name()])
            if ret != "1":
                backtrace = True


        if backtrace:
            #TODO:There is still some dirty things on node.
            digi_debug("doing recovery!!!")
            self.recover_vol_file()
            return 8

        self.discard_saved_vol_file()
        self.__del_disk(disk_list)
        self.set_afr_num((self.get_afr_num()-shrink_degree))

        return 1


    def __str__ (self):
        return self.name

    def __eq__ (self, other):
        return self.name.__eq__(other.__str__())





class node (object):
    """object to indicate one node"""

    def parse_cpu_info(self):
        cache_file_content = get_config_file(self.cache_file_cpu)
        #check if the config file is generated for the first time
        if cache_file_content.len < 2:
            return
        self.cache_cpu_stamp = float(cache_file_content.readline())
        self.cpu_info = cache_file_content.readline()

    def find_connected_nic(self):
        for anic in self.nics:
            if anic.get_ip() == self.ip_addr:
                self.connected_nic = anic

    def parse_nic_info(self):
        self.nics = []
        cache_file_content = get_config_file(self.cache_file_nic)
        if cache_file_content.len < 2:
            return
        self.cache_nic_stamp = float(cache_file_content.readline())
        nic_line = cache_file_content.readline()
        if len(nic_line) > 2:
            nic_info = simplejson.loads(nic_line)
            for anic_info in nic_info:
                if not anic_info:
                    continue
                anic = nic(anic_info)
                self.nics.append(anic)
            self.find_connected_nic()
        else:
            self.nics = []

    def parse_disk_info(self):
        self.disks = []
        cache_file_content = get_config_file(self.cache_file_disk)
        if cache_file_content.len < 2:
            return
        self.cache_disk_stamp = float(cache_file_content.readline())
        disk_line = cache_file_content.readline()
        try:
            if len(disk_line) > 2:
                all_disks_info = simplejson.loads(disk_line)
                for adisk_info in all_disks_info:
                    adisk = disk(self.options, self, adisk_info)
                    self.disks.append(adisk)
            else:
                self.disks = []
        except Exception, e:
            print traceback.print_exc(e)
            self.disks = []
    #new
    def parse_static_sys_info(self):
        self.static_sysinfo = {}
        cache_file_content = get_config_file(self.cache_file_staticsysinfo)
        if cache_file_content.len < 2:
            return
        self.cache_static_sysinfo_stamp = float(cache_file_content.readline())
        sysinfo_line = ''.join(cache_file_content.readlines())
        #dom_sysinfo = minidom.parseString(sysinfo_line)
        dom_root = etree.fromstring(sysinfo_line)
        self.static_sysinfo = self.xml_to_dict(dom_root)

    def parse_dynamic_sys_info(self):
        self.dynamic_sysinfo = {}
        cache_file_content = get_config_file(self.cache_file_dynamicsysinfo)
        if cache_file_content.len < 2:
            return
        sysinfo_line = ''.join(cache_file_content.readlines())
        try:
            dom_root = etree.fromstring(sysinfo_line)
            self.dynamic_sysinfo = self.xml_to_dict(dom_root)
        except:
            return
    def xml_to_dict(self,element):
        c_length = len(element._children)
        xml_dict = {'tagname':'','attrib':'','children_list':[]}
        xml_dict['tagname'] = element.tag
        xml_dict['attrib'] = element.attrib
        if c_length != 0:
            for e in element:
                xml_dict['children_list'].append(self.xml_to_dict(e))
        return xml_dict

    def connect_backgroud(self):
        print 'connect background ...'
        th = threading.Thread(target=self.remote_connect, args=())
        th.start()
        threads_pool.append(th)

    def generate_cache_file_path(self):
        self.cache_file_cpu   = "%s/%s_cpu"%(node_info_dir, self.node_name)
        self.cache_file_nic   = "%s/%s_nic"%(node_info_dir, self.node_name)
        self.cache_file_disk  = "%s/%s_disk"%(node_info_dir, self.node_name)
        self.cache_file_staticsysinfo = "%s/%s_staticsysinfo"%(node_info_dir, self.node_name)
        self.cache_file_dynamicsysinfo = "%s/%s_dynamicsysinfo"%(node_info_dir, self.node_name)

    def rm_cache_file(self):
        if isfile(self.cache_file_cpu):
            os.remove(self.cache_file_cpu)
        if isfile(self.cache_file_nic):
            os.remove(self.cache_file_nic)
        if isfile(self.cache_file_disk):
            os.remove(self.cache_file_disk)
        if isfile(self.cache_file_staticsysinfo):
            os.remove(self.cache_file_staticsysinfo)
        if isfile(self.cache_file_dynamicsysinfo):
            os.remove(self.cache_file_dynamicsysinfo)

    def check_login_file(self):
        ret = self.remote_call(protocol_request_type["node_login_check"], "")
        if not ret:
            digi_debug("Node check_login_file, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node check_login_file, error raise in node_manager",3)
            return False
        else:
            if ret != '0':
                return False
            else:
                return True
            
    def remote_clear_management_node(self):
        ret = self.remote_call(protocol_request_type["clear_management_node"], "")
        if not ret:
            digi_debug("Node remote_clear_management_node, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node remote_clear_management_node, error raise in node_manager",3)
            return False
        else:
            if ret != '0':
                return False
            else:
                return True
            
    def remote_clear_hosts(self):
        ret = self.remote_call(protocol_request_type["clear_hosts"], "")
        if not ret:
            digi_debug("Node remote_clear_hosts, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node remote_clear_hosts, error raise in node_manager",3)
            return False
        else:
            if ret != '0':
                return False
            else:
                return True
            
    def __init__(self, options, node_name="", group_belong=None, ip_addr="", hosts_syn="1", connect_ahead=False):
        self.options       = options
        self.node_name     = node_name
        self.group_belong  = group_belong
        self.ip_addr       = ip_addr
        self.hosts_syn     = hosts_syn
        self.connect_ahead = connect_ahead

        self.cpu_info = ""
        self.nics     = []
        self.disks    = []
        self.cache_file_cpu   = ""
        self.cache_file_nic   = ""
        self.cache_file_disk  = ""
        self.cache_file_staticsysinfo = ""
        self.cache_file_dynamicsysinfo = ""
        self.cache_cpu_stamp  = float()
        self.cache_nic_stamp  = float()
        self.cache_disk_stamp = float()
        self.cache_static_sysinfo_stamp = float()

        self.transport = None
        self.transport_lock = thread.allocate_lock()
        self.select_lock = thread.allocate_lock()
        self.message_lock = thread.allocate_lock()

        # to indicate the nic that hostname stand for
        self.connected_nic = None

        #only used in ip_set_by_nic, to store new ip addr for a while
        self.ip_addr_new   = ""

        if self.node_name:
            self.generate_cache_file_path()
            self.parse_cpu_info()
            self.parse_nic_info()
            self.parse_disk_info()
            self.parse_static_sys_info()
            self.parse_dynamic_sys_info()

#            self.transport = DigiClient((self.node_name, MANAGER_PORT))

        if self.connect_ahead:
            self.connect_backgroud()

    def get_name (self):
        return self.node_name

    #NOTE:this method should not be called, except in function replace node
    def set_name (self, new_name):
        self.node_name = new_name
        self.rm_cache_file()
        self.generate_cache_file_path()

    def set_group (self, group):
        self.group_belong = group

    def get_group (self):
        return self.group_belong

    def get_ip_addr(self):
        return self.ip_addr

    def set_ip_addr(self, ip_addr):
        self.ip_addr = ip_addr

    def get_disks(self):
        return self.disks

    def set_hostname(self, node_name):
        ret = self.remote_call(protocol_request_type["node_set_hostname"], node_name)
        return ret

    def set_hosts(self, host_img):
        data = simplejson.dumps(host_img, encoding='ascii', ensure_ascii=True)

        ret = self.remote_call(protocol_request_type["node_set_hosts"], data)
        if not ret:
            digi_debug("Node set_hosts, remote call not return",3)
            self.unset_hosts_syn()
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node set_hosts, error raise in node_manager",3)
            self.unset_hosts_syn()
            return False
        digi_debug("Node set_hosts on node:%s return:%s" % (self.node_name, ret),5)
        self.set_hosts_syn()

        return True

    def get_ipmi_ip_info(self):
        ret = self.remote_call(protocol_request_type["node_get_ipmi_ip_info"], "")
        if not ret:
            digi_debug("Node get_ipmi_ip_info, remote_call not return",3)
            return False
        digi_debug("Node get_ipmi_ip_info on node:%s return:%s" % (self.node_name, ret),5)
        return simplejson.loads(ret)

    def remote_issue_ipmi_conf(self, ipmilist):
        data = simplejson.dumps(ipmilist, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["node_issue_ipmi_conf"], data)
        if not ret:
            digi_debug("Node issue_ipmi_conf, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node issue_ipmi_conf, error raise in node_manager",3)
            return False
        digi_debug("Node issue_ipmi_conf on node:%s return:%s" % (self.node_name, ret),5)

        return True

    def remote_set_ipmi_ip(self, address, netmask, gateway):
        package = [address, netmask, gateway]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["node_set_ipmi_ip"], data)
        if not ret:
            digi_debug("Node set_ipmi_ip, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node set_ipmi_ip, error raise in node_manager",3)
            return False
        digi_debug("Node set_ipmi_ip on node:%s return:%s" % (self.node_name, ret),5)

        return ret

    def remote_set_config_file(self, data):
        ret = self.remote_call(protocol_request_type["set_config_file"], data)
        if not ret:
            digi_debug("Node remote_set_config_file, remote_call not return",3)
            return False
        digi_debug("Node remote_set_config_file on node:%s return:%s" % (self.node_name, ret),5)
        return ret

    def get_hosts(self):
        ret = self.remote_call(protocol_request_type["node_get_hosts"], "")
        if not ret:
            digi_debug("Node get_hosts, remote_call not return",3)
            return False
        digi_debug("Node get_hosts on node:%s return:%s" % (self.node_name, ret),5)
        return ret
    
    def get_hosts_syn(self):
        return self.hosts_syn == "1"

    def set_hosts_syn(self):
        self.hosts_syn = "1"

    def unset_hosts_syn(self):
        self.hosts_syn = "0"

    def acquire_transport_lock(self):
        self.transport_lock.acquire()

    def release_transport_lock(self):
        self.transport_lock.release()

    def destroy (self):
        """
            return code:
            True:     success
            False:    failed
        """
        if not self.remote_connect():
            self.rm_cache_file()
            return True
        self.update_disk()
        for adisk in self.disks:
            if adisk.get_user():
                return False
        self.rm_cache_file()
        digi_debug("Node destroy, node: %s destroy itself" % (self.node_name),3)
        return self.destroy_on_node()

    def destroy_on_node(self):
        """
            return code:
            True:     success
            False:    failed
        """
        ret = self.remote_call(protocol_request_type["node_destroy"], "")
        if not ret:
            digi_debug("Node destroy_on_node, remote_call not return",3)
            return True
        elif ret == 'digioceanfserror':
            digi_debug("Node destroy_on_node, error raise in node_manager",3)
            return True
        digi_debug("Node destroy_on_node on node:%s return:%s"%(self.node_name, ret),5)
        return True

    def status (self):
        """
            return code:
            True:    node start
            False:   node stop
        """
        return self.remote_connect()
    
    def send_msg(self, msg):
        #package = [msg]
        data = simplejson.dumps([msg], encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(node_messager_type["send_message"], data)
        if not ret:
            digi_debug("Node send_message, remote_call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node send_message, error raise in node_manager",3)
            return False
        return True
    
    def cifs_status(self):
        ret = self.remote_call(protocol_request_type["node_cifs_status"], "")
        if not ret:
            digi_debug("Node cifs_status, remote_call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node cifs_status, error raise in node_manager",3)
            return False
        if ret == "1":
            return True
        else:
            return False
        return True
    
    def cifs_restart(self):
        ret = self.remote_call(protocol_request_type["node_cifs_restart"], "")
        if not ret:
            digi_debug("Node cifs_restart, remote_call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node cifs_restart, error raise in node_manager",3)
            return False
        return True
    
    def nfs_status(self):
        ret = self.remote_call(protocol_request_type["node_nfs_status"], "")
        if not ret:
            digi_debug("Node nfs_status, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node nfs_status, error raise in node_manager",3)
            return False
        if ret == "1":
            return True
        else:
            return False
        return True
    
    def nfs_restart(self):
        ret = self.remote_call(protocol_request_type["node_nfs_restart"], "")
        if not ret:
            digi_debug("Node nfs_restart, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node nfs_restart, error raise in node_manager",3)
            return False
        return True

    def node_ctdb_set_post(self, nodes_addresses_dict, public_addresses):
        package = [nodes_addresses_dict, public_addresses]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type['node_ctdb_set_post'], data)
        if not ret:
            digi_debug("Node ctdb set post, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node ctdb set post, error raise in node_manager",3)
            return "-1"
        return ret

    def node_ctdb_list(self):
        ret = self.remote_call(protocol_request_type["node_ctdb_list"], "")
        if not ret:
            digi_debug("Node ctdb list, remote_call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node ctdb list, error raise in node_manager",3)
            return "-1"
        return simplejson.loads(ret)


    def sync_sms_conf(self, smsconfinfos):
        data = simplejson.dumps(smsconfinfos, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["node_sync_sms_conf"], data)
        if not ret:
            digi_debug("Node sync_sms_conf, remote_call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node sync_sms_conf, error raise in node_manager",3)
            return "-1"
        return ret

    def get_GSM_message_center_number(self):
        ret = self.remote_call(protocol_request_type["get_GSM_message_center_number"], "")
        if not ret:
            digi_debug("Node GSM message center number get, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node GSM message center number get, error raise in node_manager",3)
            return False
        return simplejson.loads(ret)

    def overdue_check(self, time_stamp):
        """
            return code:
            True:     success
            False:    failed
        """
        time_pass = time.time()-time_stamp
        if time_pass > 20:
            return True
        return False

    def update_cpu_info(self):
        """
            return code:
            True:     success
            False:    failed
        """
        ret = self.remote_call(protocol_request_type["node_list_cpu"], "")
        if not ret:
            digi_debug("Node update_cpu_info, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node update_cpu_info, error raise in node_manager",3)
            return False

        time_stamp = time.time()
        cpu_info_img = StringIO.StringIO("%f\n%s"%(time_stamp, ret))
        set_config_file(self.cache_file_cpu, cpu_info_img)
        return True

    def list_cpu(self, output_img):
        """
            return code:
            True:     success
            False:    failed
        """
        if self.overdue_check(self.cache_cpu_stamp):
            if not self.update_cpu_info():
                return False
            self.parse_cpu_info()
        output_img.write(self.cpu_info)
        return True

    def update_nic_info(self):
        """
            return code:
            True:     success
            False:    failed
        """
        digi_debug("Node update_nic_info on node:%s" % (self.node_name),5)
        ret = self.remote_call(protocol_request_type["node_list_nic"], "")
        if not ret:
            digi_debug("Node update_nic_info, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node update_nic_info, error raise in node_manager",3)
            return False

        time_stamp = time.time()
        nic_info_img = StringIO.StringIO("%f\n%s"%(time_stamp, ret))
        set_config_file(self.cache_file_nic, nic_info_img)
        return True

    def reset_disk(self, disk_list):
        """
            return code:
            True:     success
            False:    failed
        """
        data = simplejson.dumps(disk_list, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["node_reset_disk"], data) 
        if not ret:
            digi_debug("remote call not return")
            return False
        elif ret == 'digioceanfserror':
            digi_debug("error raise in node_manager")
            return False
        return True

    def format_disk(self, disk_list):
        """
            return code:
            True:     success
            False:    failed
        """
        data = simplejson.dumps(disk_list, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["node_format_disk"], data) 
        if not ret:
            digi_debug("remote call not return")
            return False
        elif ret == 'digioceanfserror':
            digi_debug("error raise in node_manager")
            return False
        #return True
        return simplejson.loads(ret) 

    def smart_enable(self, disk_name):
        package = [disk_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["node_smart_enable"], data)
        if not ret:
            digi_debug("Node smart_enable, remote_call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node smart_enable, error raise in node_manager",3)
            return False
        return simplejson.loads(ret)

    def smart_disable(self, disk_name):
        package = [disk_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["node_smart_disable"], data)
        if not ret:
            digi_debug("Node smart_disable, remote_call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node smart_disable, error raise in node_manager",3)
            return False
        return simplejson.loads(ret)

    def smart_status(self, disk_name):
        package = [disk_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["node_smart_status"], data)
        if not ret:
            digi_debug("Node smart_status, remote_call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node smart_status, error raise in node_manager",3)
            return "-1"
        return simplejson.loads(ret)

    def smart_start(self, disk_name,smart_type):
        package = [disk_name,smart_type]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["node_smart_start"], data)
        if not ret:
            digi_debug("Node smart_start, remote_call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node smart_start, error raise in node_manager",3)
            return False
        return simplejson.loads(ret)

    def smart_stop(self, disk_name):
        package = [disk_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["node_smart_stop"], data)
        if not ret:
            digi_debug("Node smart_stop, remote_call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node smart_stop, error raise in node_manager",3)
            return False
        return simplejson.loads(ret)

    def smart_info(self, disk_dev):
        data = simplejson.dumps(disk_dev, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["node_smart_info"], data)
        if not ret:
            digi_debug("Node smart_info, remote_call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node smart_info, error raise in node_manager",3)
            return "-1"
        return simplejson.loads(ret)

    def list_nic(self, output_img):
        """
            return code:
            True:     success
            False:    failed
        """
        if self.overdue_check(self.cache_nic_stamp):
            if not self.update_nic_info():
                return False
            self.parse_nic_info()
        for anic in self.nics:
            anic.list(output_img)
        return True

    def update_nic(self):
        """
            return code:
            True:     success
            False:    failed
        """
        if not self.update_nic_info():
            return False
        self.parse_nic_info()
        return True

# Edit by ly 2011-05-16
    def list_static_info(self, output_img):
        """
            return code:
            True:     success
            False:    failed
        """
        if self.overdue_check(self.cache_static_sysinfo_stamp):
            if not self.update_static_sys_info():
                return False
            self.parse_static_sys_info()
        self.dict_to_str(self.static_sysinfo, output_img)
        return True

#Edit by ly 2011-08-24
    def list_dynamic_info(self, output_img):
        """
            return code:
            True:     success
            False:    failed
        """
        #if self.overdue_check(self.cache_sysinfo_stamp):
        #if not self.update_dynamic_sys_info():
        #    return False
        self.parse_dynamic_sys_info()
        self.dict_to_str(self.dynamic_sysinfo, output_img)
        return True

    def dict_to_str(self, dict, output_img, depth=1):
        attrib = {}
        children_list = []
        """
        SYSINFO
            Network
                Drops   Errors      Name    RxBytes     TxBytes
                00      00          lo      859649      859649
                00      00          lo      859649      859649
            Hardware
                PCI
                    Name:   ISA bridge: Intel Corporation 82801IR
                    Name:   ISA bridge: Intel Corporation 82801IR
                    Name:   ISA bridge: Intel Corporation 82801IR
                    Name:   ISA bridge: Intel Corporation 82801IR
                    Name:   ISA bridge: Intel Corporation 82801IR
                IDE
                    None
                SCSI
                    ATA WDC WD5000AAKS-7 (Direct-Access)
                    ATA WDC WD5000AAKS-7 (Direct-Access)
                CPU
                    Bogomips    BusSpeed    Cache   CpuTemp     Load            Model                                               Virt
                    5985.35     None        6291456 None        10.101010101    Intel(R) Core(TM)2 Duo CPU     E8400  @ 3.00GHz     None
                    5985.35     None        6291456 None        10.101010101    Intel(R) Core(TM)2 Duo CPU     E8400  @ 3.00GHz     None
            FileSystem
                FSType      Free            Inodes      MountPoint      MountPointID    Name        Percent     Total           Used
                nfs         137282895872    57          /               2               /dev/sda3   57          332519858176    178345938944
                xfs         37282895872     57          /               2               /dev/sda3   57          332519858176    178345938944
                cifs        137282895872    57          /               2               /dev/sda3   57          332519858176    178345938944

        """
        tagname = ''
        key = dict.keys()
        if 'tagname' in key:
            if len(dict['children_list']) != 0 and depth != 1 :
                output_img.write('\t' * (depth - 1))
                tagname = dict['tagname']
                output_img.write(tagname)
            elif len(dict['children_list']) == 0 and not dict['attrib']:
                output_img.write('\t' * (depth - 1))
                tagname = dict['tagname']
                output_img.write(tagname + '\n')
                output_img.write('\t' * depth)
                output_img.write('No Device')
            elif depth == 1:
                output_img.write('\t' * (depth - 1))
                output_img.write('SYSINFO\n')
            elif depth == 2:
                output_img.write('\t' * (depth - 1))
                tagname = dict['tagname']
                output_img.write(tagname + '\n')
        if 'attrib'in key and dict['attrib'] != '' and depth != 1:
            output_img.write('\t' * (depth - 1))
            attrib = dict['attrib']
            for attr_k in attrib:
                output_img.write(attrib[attr_k] + '\t')
            output_img.write('\n')
        if 'children_list' in key:
            children_list = dict['children_list']
            depth += 1
            for child in children_list:
                self.dict_to_str(child, output_img, depth)


    def update_static_sys_info(self):
        """
            return code:
            True:     success
            False:    failed
        """
        ret = self.remote_call(protocol_request_type["node_list_staticsysinfo"], "")
        if not ret:
            digi_debug("Node update_static_sys_info, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node update_static_sys_info, error raise in node_manager",3)
            return False

        time_stamp = time.time()
        sys_info_img = StringIO.StringIO("%f\n%s"%(time_stamp, ret))
        set_config_file(self.cache_file_staticsysinfo, sys_info_img)
        return True

    def update_dynamic_sys_info(self):
        """
            return code:
            True:     success
            False:    failed
        """
        ret = self.remote_call(protocol_request_type["node_list_dynamicsysinfo"], "")
        if not ret:
            digi_debug("Node update_dynamic_sys_info, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node update_dynamic_sys_info, error raise in node_manager",3)
            return False

        time_stamp = time.time()
        sys_info_img = StringIO.StringIO("%f\n%s"%(time_stamp, ret))
        set_config_file(self.cache_file_dynamicsysinfo, sys_info_img)
        return True

    def update_disk_info(self):
        """
            return code:
            True:     success
            False:    failed
        """
        digi_debug("Node update_disk_info on node:%s" % (self.node_name),5)
        ret = self.remote_call(protocol_request_type["node_list_disk"], "")
        if not ret:
            digi_debug("Node update_disk_info, remote call not return, try to format no disk",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node update_disk_info, error raise in node_manager",3)
            return False

        time_stamp = time.time()
        disk_info_img = StringIO.StringIO("%f\n%s"%(time_stamp, ret))
        if ret.find('error') >= 0:
            return False
        else:
            set_config_file(self.cache_file_disk, disk_info_img)
        return True

    def list_disk(self, output_img, type=None):
        """
            return code:
            True:     success
            False:    failed
        """
        #if self.overdue_check(self.cache_disk_stamp):
        #    if not self.update_disk_info():
        #        return False
        self.parse_disk_info()
        for adisk in self.disks:
            if type:
                if adisk.get_type() == type:
                    adisk.list(output_img)
            else:
                adisk.list(output_img)
        return True

    def list_inactive_raid(self, output_img):
        """
            return code:
            True:     success
            False:    failed
        """
        if self.overdue_check(self.cache_disk_stamp):
            if not self.update_disk_info():
                return False
            self.parse_disk_info()
        for adisk in self.disks:
            if adisk.is_in_raid():
                adisk.list_disk_raid_info(output_img)
        return True

    def update_disk(self, update_disk_change=""):
        """
            return code:
            True:     success
            False:    failed
        """
        if update_disk_change:
            ret = self.remote_call(protocol_request_type["node_update_disk"], "")
            if not ret:
                digi_debug("Node update_disk, remote call not return",3)
                node_name = self.get_name()
                disk_in_service = []
                no_disk_list = []
                for service_name in list_service_name_all():
                    disk_in_service += service_list_disk_cache(service_name)
                for disk in disk_in_service:
                    no_disk = []
                    if disk.find(node_name) >= 0:
                        try:
                            disk_id = disk.replace('%s:/digioceanfs/' % node_name,'')
                            no_disk.append('-2') # disk position
                            no_disk.append(disk_status_type["no_disk"])
                            no_disk.append(disk_id)
                            no_disk.append(','.join(['no_disk','UNKNOWN','UNKNOWN']))
                            no_disk.append(-9999) # disk port
                            no_disk_list.append(no_disk)
                        except Exception,e:
                            digi_debug('Digi Manager, format nodisk cuaght error: %s' % traceback.print_exc(e))
                            continue
                try:
                    time_stamp = time.time()
                    disk_info_img = StringIO.StringIO("%f\n%s"%(time_stamp, simplejson.dumps(no_disk_list)))
                    set_config_file(self.cache_file_disk, disk_info_img)
                    return True
                except Exception,e :
                    print traceback.print_exc(e)
                    return False
            elif ret == 'digioceanfserror':
                digi_debug("Node update_disk, error raise in node_manager",3)
                return False

        if not self.update_disk_info():
            return False
        self.parse_disk_info()
        return True
    
    def replace_nodisk(self, service_name, disk):
        package = [self.node_name, service_name, disk]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)

        ret = self.remote_call(protocol_request_type["node_replace_nodisk"], data)
        if not ret:
            digi_debug("Node replace_nodisk, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node replace_nodisk, error raise in node_manager",3)
            return "-1"
        digi_debug("Node replace_nodisk on node:%s return:%s" % (self.node_name, ret),5)
        return simplejson.loads(ret)

    def check_license(self, license):
        package = [self.node_name, license]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)

        ret = self.remote_call(protocol_request_type["node_check_license"], data)

        if not ret:
            digi_debug("Node check_license, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node check_license, error raise in node_manager",3)
            return "-1"

        digi_debug("Node check_license on node:%s return:%s" % (self.node_name, ret),5)
        return simplejson.loads(ret)

    def get_device_id(self):
        package = [self.node_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)

        ret = self.remote_call(protocol_request_type["node_get_device_id"], data)

        if not ret:
            digi_debug("Node get_device_id, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node get_device_id, error raise in node_manager",3)
            return "-1"

        digi_debug("Node get_device_id on node:%s return:%s" % (self.node_name, ret),5)
        return simplejson.loads(ret)


    def service_init(self, service_name, version, mserver_port, vol_file_img, disks):
        package = [service_name, version, mserver_port, vol_file_img, disks, self.node_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)

        ret = self.remote_call(protocol_request_type["service_init"], data)
        if not ret:
            digi_debug("Node service_init, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_init, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_init on node:%s return:%s" % (self.node_name, ret),5)

        return simplejson.loads(ret)

    def service_create_pre(self, node_disk_dict):
        """
        This function is to update disks status on each node after volume create by gluster-3.4
        """
        package = [node_disk_dict, self.node_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_create_pre"], data)
        if not ret:
            digi_debug("Service create, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service create, error raise in node_manager",3)
            return "-1"
        digi_debug("Service create, volume create pre on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)
 
    def service_create_post(self, service_name, node_disk_dict):
        """
        This function is to update disks status on each node after volume create by gluster-3.4
        """
        package = [service_name, node_disk_dict, self.node_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_create_post"], data)
        if not ret:
            digi_debug("Service create, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service create, error raise in node_manager",3)
            return "-1"
        digi_debug("Service create, volume create post on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)
    
    def service_set_spare(self, disk_dict,  service_name, format):
        package = [disk_dict, self.node_name, service_name, format] 
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_set_spare"], data)
        if not ret:
            digi_debug("Service replace, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service replace, error raise in node_manager",3)
            return "-1"
        digi_debug("Service replace, volume replace pre on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)

    def service_replace_pre(self, disk_dict, format):
        """
        This function is to update disks status after volume disk replaced by gluster-3.4
        """
        package = [disk_dict, format, self.node_name] 
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_replace_pre"], data)
        if not ret:
            digi_debug("Service replace, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service replace, error raise in node_manager",3)
            return "-1"
        digi_debug("Service replace, volume replace pre on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)
 
    def service_replace_post(self, service_name, node_disk_dict):
        """
        This function is to update disks status on each node after volume create by gluster-3.4
        """
        package = [service_name, node_disk_dict, self.node_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_replace_post"], data)
        if not ret:
            digi_debug("Service replace, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service replace, error raise in node_manager",3)
            return "-1"
        digi_debug("Service replace, volume create post on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)
    
    def service_get_healing_status(self, service_name, partten):
        package = [service_name,partten]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_get_command_status"], data)
        if not ret:
            digi_debug("Service get heal disperse status, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service get heal disperse status, error raise in node_manager",3)
            return "-1"
        digi_debug("Service get heal disperse status, on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)
    
    def service_heal_disperse(self, service_name, partten):
        package = [service_name, partten]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_heal_disperse"], data)
        if not ret:
            digi_debug("Service heal disperse, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service heal disperse, error raise in node_manager",3)
            return "-1"
        digi_debug("Service heal disperse, on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)

    def service_start_pre(self, service_name, node_disk_dict):
        """
        This function is to check disks status on each node before volume start by gluster-3.4
        """
        package = [service_name, node_disk_dict, self.node_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_start_pre"], data)
        if not ret:
            digi_debug("Service start, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service start, error raise in node_manager",3)
            return "-1"
        digi_debug("Service start, volume start pre on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)

    def service_start_post(self, service_name, node_disk_dict):
        """
        This function is to update disks status on each node after volume start by gluster-3.4
        """
        package = [service_name, node_disk_dict, self.node_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_start_post"], data)
        if not ret:
            digi_debug("Service start, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service start, error raise in node_manager",3)
            return "-1"
        digi_debug("Service start, volume start post on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)

    def service_stop_pre(self, service_name, node_disk_dict):
        """
        This function is to umount service before volume stop by gluster-3.4
        """
        package = [service_name, node_disk_dict, self.node_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_stop_pre"], data)
        if not ret:
            digi_debug("Service stop, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service stop, error raise in node_manager",3)
            return "-1"
        digi_debug("Service stop, volume stop pre on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)

    def service_stop_post(self, service_name, node_disk_dict):
        """
        This function is to update disks status on each node after volume stop by gluster-3.4
        """
        package = [service_name, node_disk_dict, self.node_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_stop_post"], data)
        if not ret:
            digi_debug("Service stop, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service stop, error raise in node_manager",3)
            return "-1"
        digi_debug("Service stop, volume stop post on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)

    def service_stop_pre_rollback(self, service_name):
        package = [service_name]
        data = simplejson.dumps(package)
        digi_debug("Node service_stop_pre_rollback service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_stop_pre_rollback"], data)
        if not ret:
            digi_debug("Node service_stop_pre_rollback, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_stop_pre_rollback, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_stop_pre_rollback service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_destroy_post(self, service_name, node_disk_dict):
        """
        This function is to update disks status on each node after volume destroy by gluster-3.4
        """
        package = [service_name, node_disk_dict, self.node_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_destroy_post"], data)
        if not ret:
            digi_debug("Service destroy, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service destroy, error raise in node_manager",3)
            return "-1"
        digi_debug("Service destroy, volume destroy post on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)

    def service_add_disk_post(self, service_name, node_disk_dict):
        """
        This function is to update disks status on each node after volume add-brick by gluster-3.4
        """
        package = [service_name, node_disk_dict, self.node_name]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)
        ret = self.remote_call(protocol_request_type["service_add_disk_post"], data)
        if not ret:
            digi_debug("Service add disk, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Service add disk, error raise in node_manager",3)
            return "-1"
        digi_debug("Service add disk, volume add disk post on node:%s return:%s"%(self.node_name, ret),5)
        return simplejson.loads(ret)

    def service_start(self, service_name, version, fsid):
        package = [service_name, version, fsid]
        data = simplejson.dumps(package)
        digi_debug("Node service_start service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_start"], data)
        if not ret:
            digi_debug("Node service_start, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_start, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_start service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_stop(self, service_name):

        digi_debug("Node service_stop service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_stop"], service_name)
        if not ret:
            digi_debug("Node service_stop, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_stop, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_stop service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_restart(self, service_name, version, mserver_port, vol_file_img, disks):
        package = [service_name, version, mserver_port, vol_file_img, disks]
        data = simplejson.dumps(package, encoding='ascii', ensure_ascii=True)

        ret = self.remote_call(protocol_request_type["service_restart"], data)
        if not ret:
            digi_debug("Node service_restart, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_restart, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_restart service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)
        return ret

    def service_status(self, service_name, version):
        package = [service_name, version]
        data = simplejson.dumps(package)
        #time.sleep(2)
        digi_debug("Node service_status service:%s on node:%s"%(service_name, self.node_name),5)
        #print "remote call start at %s ..." % str(time.time())
        ret = self.remote_call(protocol_request_type["service_status"], data)
        #print "remote call end at %s ..."% str(time.time())
        #time.sleep(2)
        if not ret:
            digi_debug("Node service_status, remote call not return",3)
            return ["-1"]
        elif ret == 'digioceanfserror':
            digi_debug("Node service_status, error raise in node_manager",3)
            return ["-1"]
        digi_debug("Node service_status service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        #print ret

        package = simplejson.loads(ret)
        return package

    def threadtest(self, node_name):
        print "%s test start ..." % node_name
        #os.system('dd if=/dev/zero of=/root/threadtest/%s bs=1M count=256' % (node_name))
        time.sleep(2)
        print "%s test ends ..." % node_name
        return 'test'

    def service_destroy(self, service_name):

        digi_debug("Node service_destroy service:%s on node:%s" % (service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_destroy"], service_name)
        if not ret:
            digi_debug("Node service_destroy, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_destroy, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_destroy service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_extend(self, service_name, extend_file_img, version):
        package = [service_name, extend_file_img, version]
        data = simplejson.dumps(package)

        digi_debug("Node service_extend service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_extend"], data)
        if not ret:
            digi_debug("Node service_extend, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_extend, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_extend service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_undo_extend(self, service_name):
        digi_debug("Node service_undo_extend service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_undo_extend"], service)
        if not ret:
            digi_debug("Node service_undo_extend, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_undo_extend, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_undo_extend service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_online_extend(self, service_name, vol_file_img, version, disks):
        package = [service_name, vol_file_img, version, disks, self.get_name()]
        data = simplejson.dumps(package)

        digi_debug("Node service_online_extend service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_online_extend"], data)
        if not ret:
            digi_debug("Node service_online_extend, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_online_extend, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_online_extend service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_cifs_start(self, service_name):
        digi_debug("Node service_cifs_start service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_cifs_start"], service_name)
        if not ret:
            digi_debug("Node service_cifs_start, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node service_cifs_start, error raise in node_manager",3)
            return False
        digi_debug("Node service_cifs_start service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        if ret == "1":
            return True
        return False

    def service_cifs_stop(self, service_name):
        digi_debug("Node service_cifs_stop service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_cifs_stop"], service_name)
        if not ret:
            digi_debug("Node service_cifs_stop, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_cifs_stop, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_cifs_stop service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_cifs_status(self, service_name):
        digi_debug("Node service_cifs_status service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_cifs_status"], service_name)
        if not ret:
            digi_debug("Node service_cifs_status, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_cifs_status, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_cifs_status service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret
    
    def service_cifs_restart_node(self, service_name):
        digi_debug("Node service_cifs_restart_node service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_cifs_restart_node"], service_name)
        if not ret:
            digi_debug("Node service_cifs_restart_node, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_cifs_restart_node, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_cifs_restart_node service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret
    
    def service_cifs_restart_service(self, service_name):
        digi_debug("Node service_cifs_restart_service service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_cifs_restart_service"], service_name)
        if not ret:
            digi_debug("Node service_cifs_restart_service, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_cifs_restart_service, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_cifs_restart_service service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret    
    
    def service_cifs_list_user(self, service_name):
        package = [service_name]
        data = simplejson.dumps(package)
        digi_debug("Node service_cifs_list_user service:%s on node: %s" % (service_name,self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_cifs_list_user"], data)
        if not ret:
            digi_debug("Node service_cifs_list_user, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_cifs_list_user, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_cifs_list_user service:%s on node:%s return:%s" % (service_name,self.node_name, ret),5)

        return simplejson.loads(ret)
    
    def service_cifs_list_links(self, service_name):
        package = [service_name]
        data = simplejson.dumps(package)
        digi_debug("Node service_cifs_list_links service:%s on node:%s" % (service_name,self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_cifs_list_links"], data)
        if not ret:
            digi_debug("Node service_cifs_list_links, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_cifs_list_links, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_cifs_list_links service:%s on node:%s return:%s" % (service_name,self.node_name, ret),5)

        return simplejson.loads(ret)
    
    def service_cifs_del_links(self, pid):
        package = [pid]
        data = simplejson.dumps(package)
        #digi_debug('Node service_cifs_del_links service:%s on node:%s' % (service_name,self.node_name),5)
        ret = self.remote_call(protocol_request_type['service_cifs_del_links'], data)
        if not ret:
            digi_debug("Node service_cifs_del_links, remote call not return",3)
            return '-1'
        elif ret == 'digioceanfserror':
            digi_debug("Node service_cifs_del_links, error raise in node_manager",3)
            return '-1'
        #digi_debug("Node service_cifs_del_links service:%s on node:%s return:%s" % (service_name,self.node_name, ret),5)
        return ret
    
    def service_cifs_add_user(self, service_name, username, passwd, uid):
        package = [service_name, username, passwd, uid]
        data = simplejson.dumps(package)
        digi_debug("Node service_cifs_add_user service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_cifs_add_user"], data)
        if not ret:
            digi_debug("Node service_cifs_add_user, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_cifs_add_user, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_cifs_add_user service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret
    
    def service_cifs_add_user_rollback(self, service_name, user_name):
        package = [service_name, user_name]
        data = simplejson.dumps(package)
        digi_debug("Node service_cifs_add_user_rollback service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_cifs_add_user_rollback"], data)
        if not ret:
            digi_debug("Node service_cifs_add_user_rollback, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_cifs_add_user_rollback, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_cifs_add_user_rollback service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret
    
    def service_cifs_del_user(self, service_name, username):
        package = [service_name, username]
        data = simplejson.dumps(package)
        digi_debug("Node service_cifs_del_user service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_cifs_del_user"], data)
        if not ret:
            digi_debug("Node service_cifs_del_user, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_cifs_del_user, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_cifs_del_user service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_cifs_del_user_rollback(self, service_name, user_name):
        package = [service_name, user_name]
        data = simplejson.dumps(package)
        digi_debug("Node service_cifs_del_user_rollback service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_cifs_del_user_rollback"], data)
        if not ret:
            digi_debug("Node service_cifs_del_user_rollback, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_cifs_del_user_rollback, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_cifs_del_user_rollback service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret
        

    def service_nfs_start(self, service_name):
        digi_debug("Node service_nfs_start service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_nfs_start"], service_name)
        if not ret:
            digi_debug("Node service_nfs_start, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_nfs_start, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_nfs_start service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_nfs_stop(self, service_name):
        digi_debug("Node service_nfs_stop service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_nfs_stop"], service_name)
        if not ret:
            digi_debug("Node service_nfs_stop, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_nfs_stop, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_nfs_stop service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_nfs_status(self, service_name):
        digi_debug("Node service_nfs_status service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_nfs_status"], service_name)
        if not ret:
            digi_debug("Node service_nfs_status, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_nfs_status, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_nfs_status service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_nfs_list_user(self, service_name):
        digi_debug("Node service_nfs_list_user service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_nfs_list_user"], service_name)
        if not ret:
            digi_debug("Node service_nfs_list_user, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_nfs_list_user, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_nfs_list_user service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return simplejson.loads(ret)
    
    def service_nfs_list_links(self, service_name):
        package = [service_name]
        data = simplejson.dumps(package)
        digi_debug("Node service_nfs_list_links service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_nfs_list_links"], data)
        if not ret:
            digi_debug("Node service_nfs_list_links, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_nfs_list_links, error raise in node_manager",3)
            return "-1"
        digi_debug("Node service_nfs_list_links service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return simplejson.loads(ret)    
    
    def service_nfs_del_links(self, service_name, tar_ip=''):
        package = [service_name, tar_ip]
        data = simplejson.dumps(package)
        digi_debug("Node service_nfs_del_links service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type['service_nfs_del_links'], data)
        if not ret:
            digi_debug("Node service_nfs_del_links, remote call not return",3)
            return '-1'
        elif ret == 'digioceanfserror':
            digi_debug("Node service_nfs_del_links, error raise in node_manager",3)		
            return '-1'
        digi_debug("Node service_nfs_del_links service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret
    
    def service_nfs_add_user(self, service_name, user_ip):
        package = [service_name, user_ip]
        data = simplejson.dumps(package)
        digi_debug("Node service_nfs_add_user service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_nfs_add_user"], data)
        if not ret:
            digi_debug("Node service_nfs_add_user, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_nfs_add_user, error raise in node_manager",3)		
            return "-1"
        digi_debug("Node service_nfs_add_user service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret
    
    def service_nfs_add_user_rollback(self, service_name, user_ip):
        package = [service_name, user_ip]
        data = simplejson.dumps(package)
        digi_debug("Node service_nfs_add_user_rollback service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_nfs_add_user_rollback"], data)
        if not ret:
            digi_debug("Node service_nfs_add_user_rollback, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_nfs_add_user_rollback, error raise in node_manager",3)	
            return "-1"
        digi_debug("Node service_nfs_add_user_rollback service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret
    
    def service_nfs_del_user(self, service_name, user_ip):
        package = [service_name, user_ip]
        data = simplejson.dumps(package)
        digi_debug("Node service_nfs_del_user service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_nfs_del_user"], data)
        if not ret:
            digi_debug("Node service_nfs_del_user, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_nfs_del_user, error raise in node_manager",3)	
            return "-1"
        digi_debug("Node service_nfs_del_user service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_nfs_del_user_rollback(self, service_name, user_ip):
        package = [service_name, user_ip]
        data = simplejson.dumps(package)
        digi_debug("Node service_nfs_del_user_rollback service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_nfs_del_user_rollback"], data)
        if not ret:
            digi_debug("Node service_nfs_del_user_rollback, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_nfs_del_user_rollback, error raise in node_manager",3)	
            return "-1"
        digi_debug("Node service_nfs_del_user_rollback service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_replace(self, service_name, volumes):
        package = [service_name, volumes]
        data = simplejson.dumps(package)

        digi_debug("Node service_replace service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_replace"], data)
        if not ret:
            digi_debug("Node service_replace, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_replace, error raise in node_manager",3)	
            return "-1"
        digi_debug("Node service_replace service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return ret

    def service_afr_info(self, service_name, opendir, disks_dict):
        digi_debug("Node service_afr_info service:%s on node:%s"%(service_name, self.node_name),5)
        package = [service_name, opendir, disks_dict]
        data = simplejson.dumps(package)
        ret = self.remote_call(protocol_request_type["service_afr_info"], data)
        if not ret:
            digi_debug("Node service_afr_info, remote call not return",3)
            return None
        elif ret == 'digioceanfserror':
            digi_debug("Node service_afr_info, error raise in node_manager",3)	
            return None
        digi_debug("Node service_afr_info service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return simplejson.loads(ret)

    def service_afr_info_topage(self, service_name):
        digi_debug("Node service_afr_info_topage service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_afr_info_topage"], service_name)
        if not ret:
            digi_debug("Node service_afr_info_topage, remote call not return",3)
            return None
        elif ret == 'digioceanfserror':
            digi_debug("Node service_afr_info_topage, error raise in node_manager",3)	
            return None
        digi_debug("Node service_afr_info_topage service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return simplejson.loads(ret)

    def service_afr_info_topage_search(self, service_name, opendir, disks_dict):
        digi_debug("Node service_afr_info_topage_search service:%s on node:%s"%(service_name, self.node_name),5)
        package = [service_name, opendir, disks_dict]
        data = simplejson.dumps(package)
        ret = self.remote_call(protocol_request_type["service_afr_info_topage_search"], data)
        if not ret:
            digi_debug("Node service_afr_info_topage_search, remote call not return",3)
            return None
        elif ret == 'digioceanfserror':
            digi_debug("Node service_afr_info_topage_search, error raise in node_manager",3)	
            return None
        digi_debug("Node service_afr_info_topage_search service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return simplejson.loads(ret)

    def service_afr_syn(self, service_name, disk_dev, syn_mode, passive_addr):
        package = [service_name, disk_dev, syn_mode, passive_addr]
        data = simplejson.dumps(package)

        digi_debug("Node service_afr_syn service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_afr_syn"], data)
        if not ret:
            digi_debug("Node service_afr_syn, remote call not return",3)
            return None
        elif ret == 'digioceanfserror':
            digi_debug("Node service_afr_syn, error raise in node_manager",3)	
            return None
        digi_debug("Node service_afr_syn service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return simplejson.loads(ret)

    def service_afr_diff_internal(self, service_name):
        digi_debug("Node service_afr_diff_internal service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_afr_diff"], service_name)
        if not ret:
            digi_debug("Node service_afr_diff_internal, remote call not return",3)
            return ["-1"]
        elif ret == 'digioceanfserror':
            digi_debug("Node service_afr_diff_internal, error raise in node_manager",3)	
            return ["-1"]
        digi_debug("Node service_afr_diff_internal service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return simplejson.loads(ret)

    def service_afr_diff(self, service_name):
        ret = self.service_afr_diff_internal(service_name)
        if ret[0] != "1":
            return False

        disk_lines = ret[1]

        for disk_line in disk_lines:
            adisk = self.get_disk_by_name(disk_line[0])
            if adisk:
                adisk.set_used_size(long(disk_line[1]))
            else:
                digi_debug("Node service_afr_diff disk:%s not found on node:%s" % (disk_line[0],self.get_name()),3)

        return True

    def service_afr_expand(self, service_name, volfile_img, disks):
        package = [service_name, volfile_img, disks, self.node_name]
        data = simplejson.dumps(package)

        digi_debug("Node service_afr_expand service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_afr_expand"], data)
        if not ret:
            digi_debug("Node service_afr_expand, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_afr_expand, error raise in node_manager",3)	
            return "-1"
        digi_debug("Node service_afr_expand service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return simplejson.loads(ret)

    def service_afr_shrink(self, service_name, volfile_img, disks):
        package = [service_name, volfile_img, disks, self.node_name]
        data = simplejson.dumps(package)

        digi_debug("Node service_afr_shrink service:%s on node:%s"%(service_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["service_afr_shrink"], data)
        if not ret:
            digi_debug("Node service_afr_shrink, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node service_afr_shrink, error raise in node_manager",3)	
            return "-1"
        digi_debug("Node service_afr_shrink service:%s on node:%s return:%s"%(service_name, self.node_name, ret),5)

        return simplejson.loads(ret)


    def raid_create_internal(self, level, chunk, disk_names):
        digi_debug("Node raid_create_internal, not implement")

    def raid_create(self, level, chunk, disk_dev_names):
        self.update_disk()
        disk_names = []
        for disk_dev_name in disk_dev_names:
            adisk = self.get_disk_by_dev(disk_dev_name)
            if not adisk:
                ##print "14002" #return errno 122, disk to create raid not exist
                EXIT(14002)

            disk_names.append(adisk.get_dev_id())

            if adisk.get_disk_status() != disk_status_type["no_user"]:
                ##print "14003"  #return errno 123, disk to create raid has been used or poped
                EXIT(14003)

        #fix raid_level check
        if not (level == '0' or level == '1' or level == '10' or level == '5' or level == '6'):
            ##print "14007"
            EXIT(14007)
        #fix chunk size check
        if not chunk.isdigit():
            ##print "14008"
            EXIT(14008)
        if str(math.log(int(chunk), 2)).split('.')[1] != '0':           #check if chunk is 2^n
            #print "14008"
            EXIT(14008)
        #fix raid6 disks num err_num
        if level == '6' or level == '10':
            if level == '6' and len(disk_names) < 4:
                ##print "14009"
                EXIT(14009)
            if level == '10' and len(disk_names) < 4:
                ##print "14010"
                EXIT(14010)
            if level == '10' and len(disk_names) % 2 != 0:
                ##print "14011"
                EXIT(14011)
        if level == '5':
            if len(disk_names) < 3:
                ##print "14012"
                EXIT(14012)

        package = [level, chunk, disk_names]
        data = simplejson.dumps(package)

        ret = self.remote_call(protocol_request_type["raid_create"], data)
        if not ret:
            digi_debug("Node raid_create, remote call not return",3)
            EXIT()
        elif ret == 'digioceanfserror':
            digi_debug("Node raid_create, error raise in node_manager",3)
            EXIT()
        digi_debug("Node raid_create on node:%s with disk:%s, return:%s" % (self.node_name, disk_names, ret),5)

        self.update_disk()

        if ret == "1":
            return
        if ret == "2":
            ##print "14004" #return errno 124, disk to create raid not exist, on node
            EXIT(14004)
        elif ret == "3":
            ##print "14005" #return errno 125, disk to create raid has been used, on node
            EXIT(14005)
        elif ret == "4":
            ##print "14013" #return errno 126, disk to create raid has been used, on node
            EXIT(14013)

    def raid_del_internal(self, raid_dev_id):
        digi_debug("Node raid_del_internal, not implement")

    def raid_del(self, raid_name):
        self.update_disk()
        araid = self.get_disk_by_dev(raid_name)
        if not araid:
            ##print "14108" #return errno 128, raid to del not exist
            EXIT(14108)
        if not araid.is_raid():
            #print "14109" #return errno 129, the disk is not a raid
            EXIT(14109)
        if araid.get_user():
            #print "14110" #return errno 130, the raid has been used
            EXIT(14110)

        digi_debug("Node raid_del raid: %s on node:%s" % (araid.get_dev_id(), self.get_name()),5)
        ret = self.remote_call(protocol_request_type["raid_del"], araid.get_dev_id())
        if not ret:
            digi_debug("Node raid_del, remote call not return",3)
            #print "14500"
            EXIT(14500)
        elif ret == 'digioceanfserror':
            digi_debug("Node raid_del, error raise in node_manager",3)
            #print "14501"
            EXIT(14501)
        digi_debug("Node raid_del raid: %s on node:%s, return:%s"%(araid.get_dev_id(), self.get_name(), ret),5)

        self.update_disk()

        if ret == "1":
            return
        if ret == "2":
            #print "14111" #return errno 131, raid to del not exist
            EXIT(14111)
        elif ret == "3":
            #print "14112" #return errno 132, raid to del is not a raid disk
            EXIT(14112)
        elif ret == "4":
            #print "14113" #return errno 133, raid to del has been used
            EXIT(14113)

    def raid_info(self, raid_name, output_img):
        self.update_disk()
        araid = self.get_disk_by_dev(raid_name)
        if not araid:
            #print "14215" #return errno 135, raid to info not exist
            EXIT(14215)
        if not araid.is_raid():
            #print "14216" #return errno 136, raid to info is not a raid disk
            EXIT(14216)

        araid.list_raid_info(output_img)

    def raid_hs_set_internal(self, raid_dev_id, disk_ids):
        digi_debug("Node raid_hs_set_internal, not implement")

    def raid_hs_set(self, raid_name, disk_names):
        disk_ids = []

        self.update_disk()

        araid = self.get_disk_by_dev(raid_name)
        if not araid:
            #print "14318" #return errno 138, raid not exist
            EXIT(14318)
        if not araid.is_raid():
            #print "14319" #return errno 139, rai is not a raid disk
            EXIT(14319)
        if araid.get_raid_level() == "0":
            #print "14326"
            EXIT(14326)

        for disk_name in disk_names:
            adisk = self.get_disk_by_dev(disk_name)
            if not adisk:
                #print "14320"
                EXIT(14320)
            if adisk.get_user():
                #print "14321"
                EXIT(14321)
            disk_ids.append(adisk.get_dev_id())

        package = [araid.get_dev_id(), disk_ids]
        data = simplejson.dumps(package)

        digi_debug("Node raid_hs_set raid: %s hs set on node:%s"%(araid.get_dev_id(), self.get_name()),5)
        ret = self.remote_call(protocol_request_type["raid_hs_set"], data)
        if not ret:
            digi_debug("Node raid_hs_set, remote call not return",3)
            #print "14500"
            EXIT(14500)
        elif ret == 'digioceanfserror':
            digi_debug("Node raid_hs_set, error raise in node_manager",3)
            #print "14501"
            EXIT(14501)
        digi_debug("Node raid_hs_set raid: %s hs set on node:%s, return:%s"%(araid.get_dev_id(),self.get_name(),ret),5)

        self.update_disk()

        if ret == "1":
            return
        if ret == "2":
            #print "14322" #return errno 142, raid hs set raid not exist
            EXIT(14322)
        elif ret == "3":
            #print "14323" #return errno 143, raid hs set disk is not a raid
            EXIT(14323)
        elif ret == "4":
            #print "14324" #return errno 144, raid hs set disk not exist
            EXIT(14324)
        elif ret == "5":
            #print "14325" #return errno 145, raid hs set disk is in use
            EXIT(14325)
        elif ret == "6":
            #print "14326" #return errno 146, raid hs set disk failed
            EXIT(14326)

    def raid_hs_del_internal(self, raid_dev_id, disk_ids):
        digi_debug("Node raid_del_internal, not implement")        

    def raid_hs_del(self, raid_name, disk_names):
        disk_ids = []
        self.update_disk()
        araid = self.get_disk_by_dev(raid_name)
        if not araid:
            #print "14428" #return errno 148, raid not exist
            EXIT(14428)
        if not araid.is_raid():
            #print "14429" #return errno 149, rai is not a raid disk
            EXIT(14429)
        for disk_name in disk_names:
            (ret, disk_id) = araid.valid_hs_disk(disk_name)
            if not ret:
                #print "14430"
                EXIT(14430)
            disk_ids.append(disk_id)

        package = [araid.get_dev_id(), disk_ids]
        data = simplejson.dumps(package)

        digi_debug("Node raid_hs_del raid: %s hs del on node:%s"%(araid.get_dev_id(), self.get_name()),5)
        ret = self.remote_call(protocol_request_type["raid_hs_del"], data)
        if not ret:
            digi_debug("Node raid_hs_del, remote call not return",3)
            #print "14500"
            EXIT(14500)
        elif ret == 'digioceanfserror':
            digi_debug("Node raid_hs_del, error raise in node_manager",3)
            #print "14501"
            EXIT(14501)
        digi_debug("Node raid_hs_del raid:%s hs del on node:%s, return:%s"%(araid.get_dev_id(), self.get_name(), ret),5)

        self.update_disk()

        if ret == "1":
            return
        if ret == "2":
            #print "14431" #return errno 151, raid not exist
            EXIT(14431)
        elif ret == "3":
            #print "14432" #return errno 152, raid is not a raid
            EXIT(14432)
        elif ret == "4":
            #print "14433" #return errno 153, disk is not in raid as a hs disk
            EXIT(14433)
        elif ret == "5":
            #print "14434" #return errno 154, hs del failed
            EXIT(14434)

    def raid_active_internal(self, raid_group, raid_UUID, raid_device_list):
        package = [raid_group, raid_UUID, raid_device_list]
        data = simplejson.dumps(package)

        digi_debug("Node raid_active_internal active raid: %s on node:%s"%(raid_group, self.get_name()),5)
        ret = self.remote_call(protocol_request_type["raid_active"], data)
        if not ret:
            digi_debug("Node raid_active_internal, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node raid_active_internal, error raise in node_manager",3)
            return "-1"
        digi_debug("Node raid_active_internal active raid: %s on node:%s, return:%s"%(raid_group, self.get_name(), ret),5)
        return ret

    def raid_active(self, raid_name):
        """
            1:    raid active success
            2:    raid active, can not active it
            3:    no such inactive raid
            4:    not enough inactive devices to active raid
            5:    raid active failed
        """
        raid_device_count = int()
        raid_device_list  = []
        raid_UUID         = str()
        raid_group        = str()

        self.update_disk()

        araid = self.get_disk_by_dev(raid_name)
        if not araid:
            pass
        elif araid.get_disk_status() == disk_status_type["no_disk"]:
            pass
        else:
            return 2

        for adisk in self.disks:
            if not adisk.is_in_raid():
                continue
            if not adisk.get_disk_raid_group() == raid_name:
                continue
            raid_device_list.append(adisk.get_dev_id())
            if not raid_UUID:
                raid_UUID = adisk.get_disk_raid_UUID()
            if not raid_group:
                raid_group = adisk.get_disk_raid_group()
            if raid_device_count == 0:
                raid_device_count = int(adisk.get_disk_raid_devices())

        if len(raid_device_list) == 0:
            return 3

        if len(raid_device_list) < raid_device_count:
            return 4

        ret = self.raid_active_internal(raid_group, raid_UUID, raid_device_list)

        if ret != "1":
            return 5

        self.update_disk()
        return 1

    def raid_disactive_disk_internal(self, disk_name_list):
        data = simplejson.dumps(disk_name_list)

        digi_debug("Node raid_disactive_disk_internal disactive raid_disks:%s on node:%s"%(disk_name_list, self.get_name()),5)
        ret = self.remote_call(protocol_request_type["raid_disactive_disk"], data)
        if not ret:
            digi_debug("Node raid_disactive_disk_internal, remote call not return",3)
            return "-1"
        elif ret == 'digioceanfserror':
            digi_debug("Node raid_disactive_disk_internal, error raise in node_manager",3)
            return "-1"
        digi_debug("Node raid_disactive_disk_internal disactive raid_disks:%s on node:%s, return:%s"%(disk_name_list, self.get_name(), ret),5)
        return ret

    def raid_disactive_disk(self, disk_dev_list):
        """
            1:    raid disk disactive success
            2:    raid disk of status inactive not exist
            3:    raid disk disactive failed
        """
        disk_name_list = []

        self.update_disk()

        for disk_dev in disk_dev_list:
            adisk = self.get_disk_by_dev(disk_dev)
            if not adisk:
                return 2
            elif not adisk.is_in_raid():
                return 2
            disk_name_list.append(adisk.get_dev_id())

        ret = self.raid_disactive_disk_internal(disk_name_list)

        self.update_disk()

        if ret != "1":
            return 3

        return 1

    def ip_set_by_nic_internal(self, nic_name, new_ip, new_mask, new_gate, new_bcast):
        digi_debug("Node raid_del_internal, not implement")

    def ip_set_by_nic(self, nic_name, new_ip, new_mask, new_gate, new_bcast, islocal=False):
        """
            return code specify:
            1:    ip set success, no change to host
            2:    ip set success, host changed
            3:    nic not exist
            4:    nic ip duplicate
            5:    node can not be connected at this moment
            6:    node ip set failed
        """
        is_connected_nic = False

        self.update_nic()

        anic = self.get_nic_by_name(nic_name)
        digi_debug("Node ip_set_by_nic changing ip for:%s, new_ip:%s, new_mask:%s, new_gate:%s, new_bcast:%s"%(nic_name, new_ip, new_mask, new_gate, new_bcast),5)
        if not anic:
            return 3
        #for now, if user change the address of a bonding, we retrun as if the nic is not exist
        if anic.get_type() == nic_type["bonding"]:
            return 3

        if anic == self.connected_nic:
            is_connected_nic = True
            self.ip_addr_new = new_ip

        if islocal:
            if anic == self.connected_nic:
                set_ip_addr(nic_name, new_ip, new_mask, new_gate, new_bcast)
                self.ip_addr = self.ip_addr_new
                return 2
            else:
                set_ip_addr(nic_name, new_ip, new_mask, new_gate, new_bcast)
                self.ip_addr = self.ip_addr_new
                self.update_nic()
                return 1

        package = [nic_name, new_ip, new_mask, new_gate, new_bcast]
        data = simplejson.dumps(package)

# fake ip set
        digi_debug("Node ip_set_by_nic nic: %s, fake ip set on node:%s"%(nic_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["nic_fake_ip_set"], data)

        #if not PING(new_ip):
        #    return 6

# real ip set
        digi_debug("Node ip_set_by_nic nic: %s, ip set on node:%s"%(nic_name, self.node_name),5)
        ret = self.remote_call(protocol_request_type["nic_ip_set"], data)
        if not ret:
            digi_debug("Node ip_set_by_nic, remote call not return",3)
            return 5
        elif ret == 'digioceanfserror':
            digi_debug("Node ip_set_by_nic, error raise in node_manager",3)
            return 5
        digi_debug("Node ip_set_by_nic nic: %s, ip set on node:%s, return:%s"%(nic_name, self.node_name, ret),5)
        if is_connected_nic:
            self.ip_addr = self.ip_addr_new
            return 2

        return 1

    def bond_set_internal(self, bond_mode, primary_nic, nic_list):
        package = [bond_mode, primary_nic, nic_list]
        data = simplejson.dumps(package)

        digi_debug("Node bond_set_internal bond set on node:%s"%(self.node_name),5)
        ret = self.remote_call(protocol_request_type["bond_set"], data)
        if not ret:
            digi_debug("Node bond_set_internal, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node bond_set_internal, error raise in node_manager",3)
            return False
        digi_debug("Node bond_set_internal, bond set on node:%s, return:%s"%(self.node_name, ret),5)
        if ret != "1":
            return False
        return True

    def bond_set(self, bond_mode, nic_name_list):
        """
            return code specify:
            1:    bond set success
            2:    bond set failed
            3:    nic not found
            4:    connect nic does not contained
            5:    node not connect
        """
        #after bond set, we try to connect for 30 times,
        #make the node enough time to reconfig its network.
        retry_times = 30
        if not self.update_nic():
            return 5
        nic_list = []
        for nic_name in nic_name_list:
            anic = self.get_nic_by_name(nic_name)
            if not anic:
                return 3
            nic_list.append(anic)

        ret = find_in_list(nic_list, self.connected_nic)
        if not ret:
            return 4

        if not self.bond_set_internal(bond_mode, self.connected_nic.get_name(), nic_name_list):
            return 2

        self.disconnect()
        while retry_times != 0:
            time.sleep(1)
            digi_debug("Node bond_set try to connect node:%s for:%d times"%(self.get_name(),31-retry_times),5)
            if self.remote_connect_by_ip():
                break
            retry_times = retry_times-1

        if retry_times == 0:
            digi_debug("Node bond_set max try times reached, failed to connect to node after bond set",3)
            return 2

        self.update_nic()
        for nic in self.nics:
            if nic.type == 2 and nic.sub_nics != []:
                return 1
            elif nic.type == 2 and nic.sub_nics == []:
                return 2
        else:
            return 2


        return 1
    
    def init(self, init_level):
        ret = self.remote_call(protocol_request_type['node_init'], init_level)
        if not ret:
            digi_debug("Node bond_del_internal, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node bond_del_internal, error raise in node_manager",3)
            return False
        return True

    def bond_del_internal(self, bond_name):
        digi_debug("Node bond_del_internal bond del on node:%s"%(self.node_name),5)
        ret = self.remote_call(protocol_request_type["bond_del"], bond_name)
        if not ret:
            digi_debug("Node bond_del_internal, remote call not return",3)
            return False
        elif ret == 'digioceanfserror':
            digi_debug("Node bond_del_internal, error raise in node_manager",3)
            return False
        digi_debug("Node bond_del_internal bond del on node:%s, return:%s"%(self.node_name, ret),5)
        if ret != "1":
            return False
        return True

    def bond_del(self, bond_name):
        """
            return code specify:
            1:    bond del success
            2:    bond del failed
            3:    bond not found
        """
        #after bond set, we try to connect for 30 times,
        #make the node enough time to reconfig its network.
        retry_times = 30

        abond = self.get_nic_by_name(bond_name)
        if not abond:
            return 3
        if abond.get_type() != nic_type["bonding"]:
            return 3
        ret = self.bond_del_internal(bond_name)
        if not ret:
            return 2

        self.disconnect()
        while retry_times != 0:
            time.sleep(1)
            digi_debug("Node bond_del try to connect node:%s for:%d times"%(self.get_name(),31-retry_times),5)
            if self.remote_connect_by_ip():
                break
            retry_times = retry_times-1

        if retry_times == 0:
            digi_debug("Node bond_del max try times reached, failed to connect to node after bond set",3)
            return 2

        self.update_nic()

        return 1

    def replace_fetch_disk(self):

        digi_debug("Node replace_fetch_disk on node:%s"%(self.node_name),5)
        ret = self.remote_call(protocol_request_type["replace_fetch_disk"], "")
        if not ret:
            digi_debug("Node replace_fetch_disk, remote call not return",3)
            return None
        elif ret == 'digioceanfserror':
            digi_debug("Node replace_fetch_disk, error raise in node_manager",3)
            return None
        digi_debug("Node replace_fetch_disk on node:%s return:%s"%(self.node_name, ret),5)

        disks = simplejson.loads(ret)

        return disks
    
    def replace_fetch_disk_offline(self):
        
        used_disks = []
        digi_debug("Node replace_fetch_disk_offline on node:%s"%(self.node_name),5)
        for disk in self.disks:
            if disk.disk_status == 3:
                used_disks.append([disk.dev_id, self.node_name, disk.port, disk.user, disk.size])
        return used_disks
    
    def replace_check_disk(self, disks):
        data = simplejson.dumps(disks)

        digi_debug("Node replace_check_disk on node:%s"%(self.node_name),5)
        ret = self.remote_call(protocol_request_type["replace_check_disk"], data)
        if not ret:
            digi_debug("Node replace_check_disk, remote call not return",3)
            return None
        elif ret == 'digioceanfserror':
            digi_debug("Node replace_check_disk, error raise in node_manager",3)
            return None
        digi_debug("Node replace_check_disk on node:%s return:%s"%(self.node_name, ret),5)

        r = simplejson.loads(ret)

        return (r[0], r[1])

    def replace_destroy_disk(self):

        digi_debug("Node replace_destroy_disk on node:%s"%(self.node_name),5)
        ret = self.remote_call(protocol_request_type["replace_destroy_disk"], "")
        if not ret:
            digi_debug("Node replace_destroy_disk, remote call not return",3)
            return None
        elif ret == 'digioceanfserror':
            digi_debug("Node replace_destroy_disk, error raise in node_manager",3)
            return None
        digi_debug("Node replace_destroy_disk on node:%s return:%s"%(self.node_name, ret),5)

        return int(ret)

    def replace_initial_disk(self, disks):
        data = simplejson.dumps(disks)

        digi_debug("Node replace_initial_disk on node:%s"%(self.node_name),5)
        ret = self.remote_call(protocol_request_type["replace_initial_disk"], data)
        if not ret:
            digi_debug("Node replace_initial_disk, remote call not return",3)
            return None
        elif ret == 'digioceanfserror':
            digi_debug("Node replace_initial_disk, error raise in node_manager",3)
            return None
        digi_debug("Node replace_initial_disk on node:%s return:%s"%(self.node_name, ret),5)

        return ret

    def rsyslog_request(self,cmd,params):

        digi_debug("Node rsyslog_request on node:%s sent rsyslog request"%(self.node_name),5)
        try:
            data = simplejson.dumps([cmd,params])
            ret  = self.remote_call(protocol_request_type[RSYSLOG_REQUEST], data)
            if not ret:
                digi_debug("Node rsyslog_request, remote call not return",3)
                return None
            elif ret == 'digioceanfserror':
                digi_debug("Node rsyslog_request, error raise in node_manager",3)
                return None
        except Exception:
            digi_debug("Node rsyslog_request, caught exception: %s" % e,3)
            
            # exc_type, exc_value, exc_traceback = sys.exc_info()
            # print "*** print_exception:"
            # traceback.print_exception(exc_type, exc_value, exc_traceback, limit = 2, file=sys.stdout)

        digi_debug("Node rsyslog_request on node:%s return:%s"%(self.node_name, ret),5)

        return ret
        
    def remote_call(self, _type, data, isclient=False):
        try:
            if _type >= protocol_request_type["get_management_info"]:
                ret = self.remote_connect(_type=_type,isclient=isclient)
            else:
                ret = self.remote_connect(isclient=isclient)
        except Exception,e:
            digi_debug("%s ----------- " % traceback.print_exc(e))
        if not ret:
            return None
        #digi_debug('before submit: %s ----------1-------- %s'% (_type, ret), 3)
        ret = self.transport.submit(_type, data)
        #digi_debug('%s %s ---------2--------- %s ---- %s' % (self.transport.ip_addr, _type,data,ret), 3)
        if not ret:
            return None
        self.select_lock.acquire()
        #print "remote_call acquire select lock for node:%s"%(self.node_name)
        #digi_debug("Node remote_call,type: [%s]  acquire select lock for node:%s"%(_type, self.node_name),5)
        try:
            ret = self.transport.receive()
        except Exception,e:
            traceback.print_exc(e)
        #print "remote_call release select lock for node:%s"%(self.node_name)
        #digi_debug("Node remote_call,type: [%s]  release select lock for node:%s"%(_type, self.node_name),5)
        self.select_lock.release()

        return ret

    def remote_connect(self, _type=0, isclient=False):
        #print "remote_connect acquire transport lock for node:%s"%(self.node_name)
        digi_debug("acquire transport lock for node:%s"%(self.node_name))
        self.acquire_transport_lock()
        if not self.transport:
            if _type >= protocol_request_type["get_management_info"]:
                #self.transport = DigiClient((self.node_name, NODE_MESSAGER_PORT))
                digi_debug("node messager: %s" % _type)
                self.transport = DigiClient((self.ip_addr, NODE_MESSAGER_PORT))
            else:
                #self.transport = DigiClient((self.node_name, MANAGER_PORT))
                if isclient:
                    self.transport = DigiClient((self.ip_addr, CLIENT_PORT))
                else:
                    self.transport = DigiClient((self.ip_addr, MANAGER_PORT))
        else:
            if _type >= protocol_request_type["get_management_info"]:
                #self.transport = DigiClient((self.node_name, NODE_MESSAGER_PORT))
                digi_debug("node messager: %s" % _type)
                self.transport = DigiClient((self.ip_addr, NODE_MESSAGER_PORT))

        if not self.transport.connected:     
            ret = self.transport.connect()
            if ret != 0:
                digi_debug("Node remote_connect, can not connect to node:%s, return:%d"%(self.node_name, ret),5)
                digi_debug("Node remote_connect, got error message from transport:%s"%(self.transport.get_error_message()),3)
#                digi_debug("release transport lock for node:%s"%(self.node_name))
                self.release_transport_lock()
                return False
        #print "remote_connect release transport lock for node:%s"%(self.node_name)
        digi_debug("release transport lock for node:%s"%(self.node_name))
        self.release_transport_lock()

        return True

    def remote_connect_by_ip(self):
#        digi_debug("acquire transport lock for node:%s"%(self.node_name))
        self.acquire_transport_lock()
        digi_debug("Node remote_connect_by_ip, connecte to node:%s, with ip:%s"%(self.node_name, self.ip_addr),5)
        if self.transport:
            if self.transport.connected:
                self.transport.disconnect()
        self.transport = DigiClient((self.ip_addr, MANAGER_PORT))
        ret = self.transport.connect()
        if ret != 0:
            digi_debug("Node remote_connect_by_ip, can not connect to node:%s return:%d"%(self.node_name, ret),3)
#            digi_debug("release transport lock for node:%s"%(self.node_name))
            self.release_transport_lock()
            return False
        digi_debug("Node remote_connect_by_ip, connected to node:%s, with ip:%s"%(self.node_name, self.ip_addr),5)
#        digi_debug("release transport lock for node:%s"%(self.node_name))
        self.release_transport_lock()
        return True

    def disconnect(self):
        if self.transport:
            if self.transport.connected:
#                digi_debug("acquire transport lock for node:%s"%(self.node_name))
                self.acquire_transport_lock()
                ret = self.transport.disconnect()
                ret = self.transport = None
#                digi_debug("release transport lock for node:%s"%(self.node_name))
                self.release_transport_lock()

    def get_disk_by_name(self, disk_name, offline=False):
        if self.overdue_check(self.cache_disk_stamp):
            if offline:
                return find_in_list(self.disks, disk_name)
            if not self.update_disk_info():
                return None
            self.parse_disk_info()

        return find_in_list(self.disks, disk_name)

    def get_disk_by_dev(self, disk_dev, offline=False):
        if self.overdue_check(self.cache_disk_stamp):
            if offline:
                for adisk in self.disks:
                    if adisk.get_dev() == disk_dev:
                        return adisk
            if not self.update_disk_info():
                return None
            self.parse_disk_info()

        for adisk in self.disks:
            if adisk.get_dev() == disk_dev:
                return adisk
        return None

    #def get_disk_by_dev_id(self, disk_dev_id):
    #    if self.overdue_check(self.cache_disk_stamp):
    #        if not self.update_disk_info():
    #            return None
    #        self.parse_disk_info()

    #    for adisk in self.disks:
    #        if adisk.get_dev_id() == disk_dev_id:
    #            return adisk
    #    return None

    def get_disk_by_port(self, disk_port):
        if self.overdue_check(self.cache_disk_stamp):
            if not self.update_disk_info():
                return None
            self.parse_disk_info()

        for adisk in self.disks:
            if str(adisk.get_port()) == str(disk_port):
                return adisk
        return None

    def get_nic_by_name(self, nic_name):
        if not self.nics:
            self.update_nic()

        return find_in_list(self.nics, nic_name)

    def check_disk_in_raid(self, disk_dev):
        exists = False
        node_adisk = self.get_disks()
        for tdisk in node_adisk:
            if tdisk.is_raid():
                raid_sub_diskname = [sub_disk[1].split(',')[0] for sub_disk in tdisk.get_raid_sub_disks()]
                if disk_dev in raid_sub_diskname:
                    exists = True
                    break
        return exists

    def ip_duplicate(self, ip_addr):
        if not self.nics:
            self.update_nic()
        for anic in self.nics:
            if anic.get_ip() == ip_addr:
                return True
        return False

    def print_all (self, file_img, prefix="", postfix=""):
        file_img.write(prefix)
        file_img.write(self.node_name)
        if len(self.ip_addr) > 1:
            file_img.write("\t%s"%(self.ip_addr))
        file_img.write(postfix)

    def generate_group_config (self, conf_img):
        conf_img.write("%s|%s|%s;"%(self.node_name, self.ip_addr, self.hosts_syn))

    def __str__ (self):
        return self.node_name

    def __eq__ (self, other):
        return self.node_name.__eq__(other.__str__())



class group ():
    """object to indicate one group"""

    def __init__(self, options, group_name):
        self.options = options
        self.group_name = group_name
        self.node_list = list()

    def get_name(self):
        return self.group_name

    def add_node (self, node):
        self.node_list.append(node)

    def rm_node (self, node):
        self.node_list.remove(node)

    def get_nodes (self):
        return list(self.node_list)

    def rename (self, new_name):
        self.group_name = new_name

    def status (self):
#        thread_pool = []
#        for node in self.node_list:
#            th = threading.Thread(target=node.status, args=(status_img,))
#            thread_pool.append(th)
#        for i in range(len(self.node_list)):
#            thread_pool[i].start()
#        for i in range(len(self.node_list)):
#            threading.Thread.join(thread_pool[i])
        group_status_list = []
        for anode in self.node_list:
            group_status_list.append([anode.get_name(), anode.status()])
        return group_status_list

    def print_all (self, file_img, prefix="", postfix=""):
        file_img.write(prefix+self.group_name+postfix)
        for node in self.node_list :
            node.print_all(file_img, prefix+"\t", postfix)

    def generate_config (self, conf_img):
        conf_img.write(self.group_name+":")
        for node in self.node_list :
            node.generate_group_config(conf_img)
        conf_img.write("\n")

    def __str__ (self):
        return self.group_name

    def __eq__ (self, other):
        return self.group_name.__eq__(other.__str__())

class manager ():
    """object to indicate all group"""

    def parse_groups (self, group_line):
        [group_name, nodelist_line] = group_line.split(':')
        nodelist = nodelist_line.split(';')

        agroup = group(self.options, group_name)

        for node_line in nodelist:
            if node_line[0] == '\n':
                break
            node_name      = node_line.split('|')[0]
            node_ip_addr   = node_line.split('|')[1]
            node_hosts_syn = node_line.split('|')[2]
            anode = self.get_node_by_name(node_name)
            if anode:
                #print "11101" # return errno 21, node duplicate in config file
                EXIT(11101)
            anode = node(self.options,
                         node_name,
                         group_belong  = agroup,
                         ip_addr       = node_ip_addr,
                         hosts_syn     = node_hosts_syn,
                         connect_ahead = False)
                         #connect_ahead = self.connect_ahead)
            self.node_list.append(anode)
            agroup.add_node(anode)

        self.group_list.append(agroup)

    def parse_services(self):
        try:
            #init_dir('/var/lib/digioceand/vols')
            services_name = dircache.listdir('/var/lib/digioceand/vols')
            for service_name in services_name:
                if service_name == 'ctdb':
                    continue
                aservice = service(self, service_name)
                self.service_list.append(aservice)
            #for aservice in self.service_list:
            #    port_now = int(aservice.get_mserver_port())
            #    if port_now >= self.max_mserver_port:
            #        self.max_mserver_port = port_now+1
        except Exception,e:
            digi_debug("Parse services, caught exception: %s" % e,3)

    def init_manager (self):
        #config_file_img = get_config_file(self.config_file_path)
        new_config_file_img = get_config_file(settings.HOSTFILE)
        new_lines = new_config_file_img.readlines()
        #lines = config_file_img.readlines()
        t_lines = 'none:'
        for n_line in new_lines:
            if n_line.find("####DigioceanfsNode####") >= 0:
                if n_line[0] != '#':
                    try:
                        line_list = n_line.split()
                        t_node_name = line_list[1]
                        t_node_ip = line_list[0]
                        t_node_hostsync = '1'
                        t_lines += '%s|%s|%s;' % (t_node_name, t_node_ip, t_node_hostsync)
                    except Exception, e:
                        traceback.print_exc(e)
        t_lines += '\n'
        lines = [t_lines]
        for line in lines:
            if line[0] == '#':
                continue
            elif len(line) == 1 :
                continue
            self.parse_groups(line)

        self.parse_services()

    def node_hosts_syn_check(self):
        need_reset = False
        hosts_img = get_hosts_img()
        for anode in self.node_list:
            if not anode.get_hosts_syn():
                anode.set_hosts(hosts_img)
                need_reset = True
        if need_reset:
            self.reset_config_file()

    def login_num_check(self):
        for anode in self.node_list:
            if anode.check_login_file():
                digi_debug("no digimanager user login on %s" % (anode),3)
                continue
            else:
                self.login_num += 1


    def __init__ (self, options, hosts_syn=True, connect_ahead=True):
        self.options       = options
        self.hosts_syn     = hosts_syn
        self.connect_ahead = connect_ahead

        self.config_file_path = groups_file

        self.group_list = list()
        self.node_list = list()
        self.service_list = list()
        self.max_mserver_port = MSERVER_PORT_BASE

        self.login_num = 0

        self.init_manager()

        if hosts_syn:
            self.node_hosts_syn_check()
            
        #settings._path_check()

#########################################################
#methods for group
#########################################################
    def group_add (self, group_name, nodename_list=[""]):
        if group_name.__eq__(orphanage_group_name):
            #print "10001" #return errno 1, group to add exist(the name conflict with orphanage group)
            EXIT(10001)
        agroup = self.get_group_by_name(group_name)
        if agroup:
            #print "10001" #return errno 1, group to add exist
            EXIT(10001)
        if not name_check(group_name):
            #print "10008"
            EXIT(10008)
        agroup = group (self.options, group_name)
        self.group_list.append(agroup)
        if len(nodename_list[0]) > 0:
            for nodename in nodename_list:
                self.node_set_group_by_name(nodename,group_name)

        self.reset_config_file()

        return agroup

    def group_del (self, group_name):
        if group_name.__eq__(orphanage_group_name):
            #print "10001" #return errno 2, group to del exist(the name conflict with orphanage group)
            EXIT(10001)

        group_to_del = self.get_group_by_name(group_name)
        if not group_to_del:
            #print "10002" #return errno 2, group to del not exist
            EXIT(10002)

        node_list = group_to_del.get_nodes()
        for anode in node_list:
            self.node_set_group(anode, group_to_del)

        self.group_list.remove(group_to_del)

        self.reset_config_file()

        return group_to_del

    def group_rename (self, group_name_old, group_name_new):
        group_old = self.get_group_by_name(group_name_old)
        if not group_old or group_name_old.__eq__(orphanage_group_name):
            #print "10003" #return errno 3, group before rename not exist
            EXIT(10003)

        if not name_check(group_name_new):
            #print "10008"
            EXIT(10008)
        group_new = self.get_group_by_name(group_name_new)
        if group_new or group_name_new.__eq__(orphanage_group_name):
            #print "10004" #return errno 4, group after rename exist
            EXIT(10004)

        group_old.rename(group_name_new)

        self.reset_config_file()

    def group_status (self, group_name):
        agroup = self.get_group_by_name(group_name)
        if not agroup:
            #print "10005" #return errno 5, group not exist
            EXIT(10005)

        group_status_list = agroup.status()

        output_img = StringIO.StringIO()
        for anode_status in group_status_list:
            output_img.write(anode_status[0])
            if anode_status[1]:
                output_img.write("\tstart\n")
            else:
                output_img.write("\tstop\n")
        output_img.seek(0)
        return output_img
#########################################################
#methods for node
#########################################################
    def node_add (self, node, agroup=None):
        if not agroup:
            agroup = self.get_group_by_name(orphanage_group_name)
            if not agroup:
                agroup = group(self.options, orphanage_group_name)
                self.group_list.append(agroup)

        agroup.add_node(node)
        node.set_group(agroup)
        self.node_list.append(node)

        #for aservice in self.service_list:
        #    aservice.add_node(node)

        self.reset_config_file()

        return node
    def get_ip_addr (self):
        ip_list = getAllIpAddress()
        return ip_list

    def node_send_msg(self, node_name, msg):
        if node_name:
            anode = self.get_node_by_name(node_name)
            if not anode:
                #print "11102" #return errno 22, node to add already exist
                EXIT(11107)
        ret = anode.send_msg(msg)
        return ret

    def node_add_by_host_name (self, node_ip_addr, group_name=None, node_name=None):
        allocate_hostname = False
        rip_arr = []
        
        if group_name:
            if group_name == orphanage_group_name:
                #print "11103" #return errno 23, group of the node not exist
                EXIT(11103)

            agroup = self.get_group_by_name(group_name)
            if not agroup:
                #print "11103" #return errno 23, group of the node not exist
                EXIT(11103)
        else:
            agroup = None
                
        if not checkIP(node_ip_addr):
            #print "11100" #return errno 20, ipaddr is not legal
            EXIT(11100)

        if not os.path.exists(settings.PRIDOMAINPATH):
            EXIT(11134)

        if not node_name_check(node_name):
            #print "11097"
            EXIT(11097)
        if node_name:
            anode = self.get_node_by_name(node_name)
            if anode:
                #print "11102" #return errno 22, node to add already exist
                EXIT(11102)
        else:
            allocate_hostname = True
            node_name = self.get_new_host_name()
            
        try:
            anode = node(self.options, node_name, ip_addr=node_ip_addr, connect_ahead=False)
            if not PING(node_ip_addr):
                # del_host(anode.get_name(), anode.get_ip_addr())
                anode.destroy()
                #print "11098" #return errno 11098, node network is not ready
                EXIT(11098)
    
            if not anode.remote_connect_by_ip(): #check node ipaddr can be connected
                # del_host(anode.get_name(), anode.get_ip_addr())
                anode.destroy()
                #print "11099" #return errno 11098, node can not be connected
                EXIT(11099)
                
            output_img = StringIO.StringIO()
            if not anode.list_nic(output_img):
                #print "11109" #return errno 29, connect or send or recieve message to node error
                EXIT(11109)
            
            ret = str(output_img.getvalue())
            ret = ret.strip().split('\n')
            output_img.close()
            
            for tmp in ret:
                if len(tmp.split('\t')) >= 5:
                    rip_arr.append(tmp.split('\t')[4])
    
            for tnode in self.node_list:
                if not PING(tnode.ip_addr):
                    continue
                hosts_content = tnode.get_hosts()
                if not hosts_content:
                    #print "11109" #return errno 29, connect or send or recieve message to node error
                    EXIT(11133)
                hosts_content = str(hosts_content)
                content_list = hosts_content.split('\n')
                for a_line in content_list:
                    if len(a_line) < 2:
                        continue
                    if a_line[0] == '#':
                        continue
                    host_ip = a_line.split()[0]
                    '''
                    if node_ip_addr == host_ip:
                        #print "11102" #return errno 22, node to add already exist
                        EXIT(11102)
                    '''
                    for ip in rip_arr:
                        if ip == host_ip and a_line.find('"####DigioceanfsNode####"') >= 0:
                            #print "11102" #return errno 22, node to add already exist
                            EXIT(11102)
                        
        except Exception, e:
            digi_debug("Node add, caught exception: %s" % e,3)
            print "-1"
            EXIT(-1)
        #anode = node(self.options, node_name, ip_addr=node_ip_addr, connect_ahead=True)

# -------------------------------------------------------------------------
        all_ip_list = []
        try:
            for an in self.node_list:
                an.update_nic()
                for nic in an.nics:
                    all_ip_list.append(nic.ip)
            if node_ip_addr in all_ip_list:
                EXIT(11112)
        except Exception, e:
            traceback.print_exc(e)
# -------------------------------------------------------------------------

        ret = add_host(node_name, node_ip_addr)

    #if not anode.can_be_connected:
    #    #print "11099"
    #    EXIT(11099)
        if ret == 2:
            #print "11112" #return errno 32, node ip already exist
            EXIT(11112)
        if ret == 3:
            if not allocate_hostname:
                #print "11113" #return errno 33, node hostname already exist
                EXIT(11113)
            else:
                node_indent = 1
                while add_host(node_name, node_ip_addr) == 3:
                    digi_debug("Node add, the hostname:%s node_name exist in hosts file, find a new one"%(node_name),3)
                    node_indent = node_indent + 1
                    node_name = self.get_new_host_name(node_indent)
        
        '''
        anode = node(self.options, node_name, ip_addr=node_ip_addr, connect_ahead=True)
        if not PING(node_ip_addr):
            del_host(anode.get_name(), anode.get_ip_addr())
            anode.destroy()
            #print "11098" #return errno 11098, node network is not ready
            EXIT(11098)

        if not anode.remote_connect(): #check node ipaddr can be connected
            del_host(anode.get_name(), anode.get_ip_addr())
            anode.destroy()
            #print "11099" #return errno 11098, node can not be connected
            EXIT(11099)
        '''
        
        need_check = True
        ip_list = self.get_ip_addr()
        for ip_addr in ip_list:
            if ip_addr == node_ip_addr:
                need_check = False
                break
        if need_check:
            #new_node = node(self.options, node_name, ip_addr=node_ip_addr, connect_ahead=True)
            hosts_content = anode.get_hosts()
            #new_node.disconnect()
            content_list = hosts_content.split('\n')
            for a_line in content_list:
                if len(a_line) < 2:
                    continue
                if a_line[0] == '#':
                    continue
                host_ip = a_line.split()[0]
                if node_ip_addr == host_ip:
                    hosts_img = get_config_file(settings.HOSTFILE)
                    tmp_lines = hosts_lines = hosts_img.readlines()
                    for a_line in tmp_lines:
                        if len(a_line) < 2:
                            continue
                        if a_line[0] == '#':
                            continue
                        host_ip = a_line.split()[0]
                        if node_ip_addr == host_ip:
                            hosts_lines.remove(a_line)
                    hosts_img_new = StringIO.StringIO()
                    for a_line in hosts_lines:
                        hosts_img_new.write(a_line)
                    set_config_file(settings.HOSTFILE, hosts_img_new)
                    #print "11102" #return errno 22, node to add already exist
                    EXIT(11102)

        self.node_add(anode, agroup)
        
        #fd = open('/etc/hosts', 'r')
        fd = open(settings.HOSTFILE, 'r')
        lines = fd.readlines()
        for sline in lines:
            for addr in self.get_ip_addr():
                if not cmp('127',addr[:3]):
                    continue
                if addr in sline: 
                    anode.rsyslog_request(rsyslog_utils.CMD_ADD,[addr])
        
        fd.close()
        
        ret = self.issue_hosts()
        # probe peer for gluster-3.4 cli
        if self.node_add_post(anode):
            #undo host add
            ret = del_host(node_name, node_ip_addr)
            #self.node_del(node_name)
            self.issue_hosts()
            EXIT(11132)            
        #if ret:
        anode.set_hostname(node_name)

        ret = self.issue_service_client_hosts()

        ret = anode.get_ipmi_ip_info()
        add_ipmi_to_conf(anode.node_name,ret[0],ret[1],ret[2],ret[3])
        self.issue_ipmi_conf()
            
        tmp_tuple = node_manager.get_management_node()
        ip_list = get_local_ip_list()
        if tmp_tuple == ():
            digi_debug("Node add, get_management_node get nothing, please fix up /etc/digioceanfs_manager/management_node manually",3)
        else:
            if node_ip_addr in ip_list:
                args = node_name + ' ' + node_ip_addr
                for tmp_node in self.node_list:
                    node_manager.remote_set_manager_ip(tmp_node.node_name, tmp_node.ip_addr, args)
            else:
                manager_node_name = tmp_tuple[0]
                manager_ip_addr = tmp_tuple[1]
                args = manager_node_name + ' ' + manager_ip_addr
                node_manager.remote_set_manager_ip(anode.node_name, anode.ip_addr, args)

    def node_add_post(self, anode):
        ######################################
        # Probe peer for gluster-3.4 cli
        ######################################
        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append('peer')
        cmd.append('probe')
        cmd.append(anode.get_name())
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd,tmp_img)
        digi_debug("Node add, %s return %d" % (' '.join(cmd),ret),5)
        result = tmp_img.read()        
        if ret:
            digi_debug("Node add, %s" % result,3)            
            return 1

        ret = anode.remote_call(protocol_request_type["node_service_list_init"], "")
        if not ret:
            digi_debug("Node add init_node_service_info, remote call not return",3)
            return 1
        elif ret == 'digioceanfserror':
            digi_debug("Node add init_node_service_info, error raise in node_manager",3)
            return 1

        return 0


    def get_new_host_name(self, node_indent = 1):
        
        fd = open(settings.PRIDOMAINPATH, 'r')
        domain_name = fd.read().strip()

        host_num = len(self.node_list) + node_indent
        host_name_new = "node-%d"%(host_num)
        digi_debug("get_new_host_name is:%s"%(host_name_new),5)
        while self.get_node_by_name(host_name_new+'.'+domain_name):
            host_num = host_num + 1
            host_name_new = "node-%d"%(host_num)
        '''
        host_num = str(hex(random.randint(1,18446744073709551615)))[2:-1]
        host_name_new = "node-%s"%(host_num)
        '''
        host_name_new = host_name_new + '.' + domain_name
        return host_name_new
        

    def node_del (self, node_name):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11104" #return errno 24, node to del not exist
            EXIT(11104)
        if not PING(anode.get_ip_addr()):
            connected = False
        else:
            connected = True
            #print "11129" #return errno 11098, node network is not ready
            #EXIT(11129)

    #if not anode.remote_connect(): #check node ipaddr can be connected
    #    #print "11099" #return errno 11098, node can not be connected
    #    EXIT(11099)
        if not connected:
            for aservice in self.service_list:
                disk_list_cache = service_list_disk_cache(aservice.name)
                for brick_str in disk_list_cache:
                    if brick_str.find(node_name) >= 0:
                        EXIT(11105)
            anode.destroy()
            #group_belong = anode.get_group()
            #group_belong.rm_node(anode)
        else:
            pass
            #if len(self.service_list) > 0:
            #    EXIT(11105)
                
        #print connected, self.service_list
        #exit()
        if not anode.destroy():
            #print "11105" #return errno 25, node can not be del because of some condition
            EXIT(11105)

        #for aservice in self.service_list:
        #    ret = aservice.node_has_disk(anode)
        #    if ret == 1:
        #        digi_debug("Node del, an error occoured, service file and disk file is not consistent!!!",3)
                #print "11114"
        #        EXIT(11114)

        #for aservice in self.service_list:
        #    aservice.del_node(anode)

        group_belong = anode.get_group()
        group_belong.rm_node(anode)

        if len(anode.get_ip_addr()) > 0:
            del_host(anode.get_name(), anode.get_ip_addr())
            # clear hosts info on target node
            #anode.remote_clear_hosts()
            self.issue_hosts()

        pfd = os.popen("hostname")
        host_name = pfd.readline().strip()
        if host_name != node_name:
            anode.remote_clear_hosts()         # clear hosts and ipmi.conf
            anode.remote_clear_management_node()
        
        self.reset_config_file()

        self.node_list.remove(anode)
        
        del_ipmi_from_conf(node_name)
        self.issue_ipmi_conf()

        try:
            anode.rsyslog_request(rsyslog_utils.CMD_DESTROY,[anode.ip_addr])
        except Exception:
            traceback.print_exc()

        self.node_del_post(anode)

        ret = self.issue_service_client_hosts()
        
    def node_del_post(self, anode):
        ######################################
        # Probe peer for gluster-3.4 cli
        ######################################
        ret = anode.remote_call(protocol_request_type["node_service_info_clear"], "")
        if not ret:
            digi_debug("Node add node_service_info_clear, remote call not return",3)
        elif ret == 'digioceanfserror':
            digi_debug("Node add node_service_info_clear, error raise in node_manager",3)

        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append('peer')
        cmd.append('detach')
        cmd.append(anode.get_name())
        cmd.append('force')
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd,tmp_img)
        digi_debug("Node del, %s return %d" % (' '.join(cmd),ret),5)
        result = tmp_img.read()
        if ret:
            digi_debug("Node del, %s" % result,3)
            return 1

        return 0
        

    def node_set_group (self, anode, group_old, group_new=None):

        if group_old == group_new and group_new != orphanage_group_name:
            #print "10007"
            EXIT(10007)

        if not group_new:
            group_new = self.get_group_by_name(orphanage_group_name)
            if not group_new:
                group_new = group (self.options, orphanage_group_name)
                self.group_list.append(group_new)


        group_old.rm_node(anode)
        group_new.add_node(anode)
        anode.set_group(group_new)

        self.reset_config_file()


    def node_set_group_by_name (self, node_name, group_name=orphanage_group_name):
        group_new = self.get_group_by_name(group_name)
        if not group_new:
            #print "11103" #return errno 23, group of the node not exist
            EXIT(11103)

        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11106" #return errno 26, the node not exist
            EXIT(11106)

        group_old = anode.get_group()
        if group_old.get_name() != 'none' and group_new.get_name() != 'none':
            #print "11094"
            EXIT(11094)
        self.node_set_group(anode, group_old, group_new)

    def node_status (self, node_name):
        output_img = StringIO.StringIO()
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11107" #return errno 27, the node to query not exist
            EXIT(11107)
        if anode.status():
            output_img.write("%s\tstart\n"%anode.get_name())
        else:
            output_img.write("%s\tstop\n"%anode.get_name())
        output_img.seek(0)
        return output_img
    
    def node_cifs_status(self):
        output_img = StringIO.StringIO()
        try:
            node_thread_pool = ClusterThreadPool(len(self.node_list))
            node_thread_pool.initPool(data=self.node_list, target_info=('cifs_status', [], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            print e
            digi_debug("Service create, Node manager multi threading tought exception: %s" % e,3)
        else:
            pass
        finally:
            pass
        for result in thread_result:
            node = result[0]
            ret = result[1]
            if ret:
                output_img.write("%s\tstart\n"%node.get_name())
            else:
                output_img.write("%s\tstop\n"%node.get_name())
        output_img.seek(0)
        return output_img
    
    def node_cifs_restart(self, node_name):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11107" #return errno 27, the node to query not exist
            EXIT(11107)
        if anode.cifs_restart():
            return True
        return False
    
    def node_nfs_status(self):
        output_img = StringIO.StringIO()
        for anode in self.node_list:
            if anode.nfs_status():
                output_img.write("%s\tstart\n"%anode.get_name())
            else:
                output_img.write("%s\tstop\n"%anode.get_name())
        output_img.seek(0)
        return output_img

    def node_nfs_restart(self, node_name):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11107" #return errno 27, the node to query not exist
            EXIT(11107)
        if anode.nfs_restart():
            return True
        return False

    def node_ctdb_set(self, nodes_names, public_addresses):
        #node_list = []
        nodes_addresses_dict = {}
        public_addresses = public_addresses.split(',')
        for node_name in nodes_names.split(','):
            anode = self.get_node_by_name(node_name)
            if not anode:
                digi_debug('Ctdb set, node: %s not found' % node_name,5)
                EXIT(11551)
            #node_list.append(anode)
            #nodes_addresses.append(anode.get_ip_addr())
            nodes_addresses_dict[node_name] = anode.get_ip_addr()

        #service ctdb exists and delete ctdb
        if check_service_exist('ctdb'):
            self.service_destroy('ctdb')

        #create and start ctdb volume
        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append('volume')
        cmd.append('create')
        cmd.append('ctdb')
        for node_name in nodes_names.split(','):
            cmd.append('%s:/ctdb' % node_name)
        cmd.append('force')
        tmp_img = tempfile.TemporaryFile()
        stdinput = subprocess.PIPE
        ret = execute(cmd, std=tmp_img, stdi=stdinput, communicate='y\n')
        tmp_img.seek(0)
        result = tmp_img.read()
        if ret:
            EXIT(-1, result)

        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append('volume')
        cmd.append('start')
        cmd.append('ctdb')
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, tmp_img)
        result = tmp_img.read()
        if ret:
            EXIT(-1,result)

        #thread and ctdb set post
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(self.node_list))
            node_thread_pool.initPool(data=self.node_list, target_info=('node_ctdb_set_post', [nodes_addresses_dict, public_addresses], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            print e
            digi_debug("Node ctdb set, Node manager multi threading tought exception: %s" % e,3)
        else:
            pass
        finally:
            pass
        for result in thread_result:
            node = result[0]
            ret = result[1]
            if ret == '4':
                EXIT(11552)
            elif ret == '3' or ret == '2':
                EXIT(11553)
            elif ret != '1':
                EXIT(11554)

        return True

    def node_ctdb_list(self):
        output_img = StringIO.StringIO()
        try:
            node_thread_pool = ClusterThreadPool(len(self.node_list))
            node_thread_pool.initPool(data=self.node_list, target_info=('node_ctdb_list', [], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            print e
            digi_debug("Service create, Node manager multi threading tought exception: %s" % e,3)
        else:
            pass
        finally:
            pass
        for result in thread_result:
            node = result[0]
            ret = result[1]
            output_img.write('\nnodename : %s\n' % node)
            if 'nodes' in ret:
                output_img.write('nodes : %s\n' % ' | '.join(ret['nodes']))
            if 'public_addresses' in ret:
                output_img.write('public_addresses : %s\n' % ' | '.join(ret['public_addresses']))
        output_img.seek(0)
        return output_img

    def node_status_all (self):
        output_img = StringIO.StringIO()
        try:
            node_thread_pool = ClusterThreadPool(len(self.node_list))
            node_thread_pool.initPool(data=self.node_list, target_info=('status', [], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            print e
            digi_debug("Service create, Node manager multi threading tought exception: %s" % e,3)
        else:
            pass
        finally:
            pass
        for result in thread_result:
            node = result[0]
            ret = result[1]
            if ret:
                output_img.write("%s\tstart\n"%node.get_name())
            else:
                output_img.write("%s\tstop\n"%node.get_name())
        output_img.seek(0)
        return output_img

    def node_list_cpu (self, node_name):
        output_img = StringIO.StringIO()
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11107" #return errno 27, the node to query not exist
            EXIT(11107)
        if not anode.list_cpu(output_img):
            #print "11109" #return errno 29, connect or send or recieve message to node error
            EXIT(11109)
        output_img.seek(0)
        return output_img

    def node_list_nic (self, node_name):
        output_img = StringIO.StringIO()
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11107" #return errno 27, the node to query not exist
            EXIT(11107)
        if not anode.list_nic(output_img):
            #print "11109" #return errno 29, connect or send or recieve message to node error
            EXIT(11109)
        output_img.seek(0)
        return output_img

    def node_list_nic_all (self):
        output_img = StringIO.StringIO()
        for anode in self.node_list:
            output_img.write("%s\n"%(anode.get_name()))
            if not anode.list_nic(output_img):
                output_img.write("connection to this node is not ready now\n")
        output_img.seek(0)
        return output_img

    def node_list_disk (self, node_name):
        output_img = StringIO.StringIO()
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11107" #return errno 27, the node to query not exist
            EXIT(11107)
        anode.update_disk('Y')
        if not anode.list_disk(output_img):
            #print "11109" #return errno 29, connect or send or recieve message to node error
            EXIT(11109)
        output_img.seek(0)
        return output_img

    def node_list_disk_all (self):
        output_img = StringIO.StringIO()
        nodes = self.node_list
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(nodes))
            node_thread_pool.initPool(data=nodes, target_info=('update_disk', ['y'], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        for result in thread_result:
            anode = result[0]
            r = result[1]
        #for anode in self.node_list:
            output_img.write("%s\n"%(anode.get_name()))
            if not anode.list_disk(output_img):
                output_img.write("connection to this node is not ready now\n")
        output_img.seek(0)
        return output_img

    def node_reset_disk(self, node_name, disk_list):
        anode = self.get_node_by_name(node_name)
        disk_id_list = []
        if not anode:
            #print "11107" #return errno 27, the node to query not exist
            EXIT(11107)
        for disk_dev in disk_list:
            adisk = anode.get_disk_by_dev(disk_dev)
            if adisk:
                disk_id_list.append(adisk.get_dev_id()) 
            else:
                #print "Disk not found ..."
                digi_debug("Node reset disk, disk not found",3)
                #print "12007"
                EXIT(12007)
        if not anode.reset_disk(disk_id_list):
            #print "Reset disk failed ..." #return errno 29, connect or send or recieve message to node error
            digi_debug("Node reset disk, reset disk failed",3)
            #print "12013"
            EXIT(12013)
        anode.update_disk('Y')
        return 0 

    def node_format_disk(self, node_name, disk_list):
        anode = self.get_node_by_name(node_name)
        disk_id_list = []
        if not anode:
            #print "11107" #return errno 27, the node to query not exist
            EXIT(11107)
        for disk_dev in disk_list:
            adisk = anode.get_disk_by_dev(disk_dev)
            if adisk:
                disk_id_list.append(adisk.get_dev_id()) 
            else:
                #print "Disk not found ..."
                digi_debug("Node format disk, disk not found",3)
                #print "12007"
                EXIT(12007)
        failed_info = anode.format_disk(disk_id_list)
	format_disk_flag = 0
	format_disk_flag1 = 0
	for index in range(len(disk_list)):
            if failed_info[disk_list[index]] == "2":
                format_disk_flag = 1
                disk_info_list = []
                disk_info_list.append(node_name)
                disk_info_list.append(disk_list[index])
                disk_info_list.append(disk_id_list[index])
            #print "Reset disk failed ..." #return errno 29, connect or send or recieve message to node error
                digi_debug("Node format disk, format disk: %s failed" % ' '.join(disk_info_list),3)
	    elif failed_info[disk_list[index]] == "1":
                format_disk_flag1 = 1
                disk_info_list = []
                disk_info_list.append(node_name)
                disk_info_list.append(disk_list[index])
                disk_info_list.append(disk_id_list[index])
                digi_debug("Node format disk, format disk: %s succeed" % ' '.join(disk_info_list),7)
        if format_disk_flag and not format_disk_flag1:
            EXIT(12014)
        elif format_disk_flag and format_disk_flag1:
            EXIT(12015)
        #anode.update_disk('Y')
        return 0 

    def node_smart_enable(self, node_name, disk_dev):
        anode = self.get_node_by_name(node_name)
        if not anode:
            EXIT(11301)
        adisk = anode.get_disk_by_dev(disk_dev)
        if not adisk and not anode.check_disk_in_raid(disk_dev):
            digi_debug("Node smart status, disk not found",3)
            EXIT(12007)
        failed_info = anode.smart_enable(disk_dev)
        if failed_info != 1:
            digi_debug("Node smart enable, %s failed" % ' '.join(failed_info),3)
            EXIT(11302)
        return 0 

    def node_smart_disable(self, node_name, disk_dev):
        anode = self.get_node_by_name(node_name)
        if not anode:
            EXIT(11303)
        adisk = anode.get_disk_by_dev(disk_dev)
        if not adisk and not anode.check_disk_in_raid(disk_dev):
            digi_debug("Node smart status, disk not found",3)
            EXIT(12007)
        failed_info = anode.smart_disable(disk_dev)
        if failed_info != 1:
            digi_debug("Node smart disable, %s failed" % ' '.join(failed_info),3)
            EXIT(11304)
        return 0 

    def node_smart_status(self, node_name, disk_dev):
        output_img = StringIO.StringIO()
        anode = self.get_node_by_name(node_name)
        if not anode:
            EXIT(11305)
        adisk = anode.get_disk_by_dev(disk_dev)
        if not adisk and not anode.check_disk_in_raid(disk_dev):
            digi_debug("Node smart status, disk not found",3)
            EXIT(12007)
        ret = anode.smart_status(disk_dev)
        if ret == 0:
            output_img.write('Not Support\n')
        elif ret == 1:
            output_img.write('Enabled\n')
        elif ret == 2:
            output_img.write('Disabled\n')
        else:
            EXIT(11306)
        output_img.seek(0)
        return output_img

    def node_smart_start(self, node_name, smart_type, disk_dev):
        anode = self.get_node_by_name(node_name)
        if not anode:
            EXIT(11307)
        adisk = anode.get_disk_by_dev(disk_dev)
        if not adisk and not anode.check_disk_in_raid(disk_dev):
            digi_debug("Node smart status, disk not found",3)
            EXIT(12007)
        failed_info = anode.smart_start(disk_dev,smart_type)
        if failed_info != 1:
            if failed_info == 2:
                digi_debug("Node smart start, %s S.M.A.R.T already in progress" % disk_dev,3)
                EXIT(11308)
            elif failed_info == 3:
                digi_debug("Node smart start, %s S.M.A.R.T disabled" % disk_dev,3)
                EXIT(11309)
            else:
                digi_debug("Node smart start, %s failed" % disk_dev,3)
                EXIT(11310)
        return 0 

    def node_smart_stop(self, node_name, disk_dev):
        anode = self.get_node_by_name(node_name)
        if not anode:
            EXIT(11311)
        adisk = anode.get_disk_by_dev(disk_dev)
        if not adisk and not anode.check_disk_in_raid(disk_dev):
            digi_debug("Node smart status, disk not found",3)
            EXIT(12007)
        failed_info = anode.smart_stop(disk_dev)
        if failed_info != 1:
            if failed_info == 2:
                digi_debug("Node smart stop, %s S.M.A.R.T not in progress" % disk_dev,3)
                EXIT(11312)                
            else:
                digi_debug("Node smart stop, %s failed" % ' '.join(failed_info),3)
                EXIT(11313)
        return 0 

    def node_smart_info(self, node_name, disk_dev):
        output_img = StringIO.StringIO()
        anode = self.get_node_by_name(node_name)
        if not anode:
            EXIT(11314)
        for disk in disk_dev:
            adisk = anode.get_disk_by_dev(disk)
            if not adisk and not anode.check_disk_in_raid(disk):
                digi_debug("Node smart status, disk not found",3)
                EXIT(12007)
        ret = anode.smart_info(disk_dev)
        if ret:
            if ret == -1:
                EXIT(11315)
            output_img.write(ret)
        output_img.seek(0)
        return output_img

# Edit by ly 2011-05-16
    def node_list_static_info(self, node_name):
        output_img = StringIO.StringIO()
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11107" #return errno 27, the node to query not exist
            EXIT(11107)
        if not anode.list_static_info(output_img):
            #print "11109" #return errno 29, connect or send or recieve message to node error
            EXIT(11109)
        output_img.seek(0)
        return output_img

    def node_list_dynamic_info(self, node_name):
        output_img = StringIO.StringIO()
        node_list = node_name.split(',')
        node_obj_list = []
        for node in node_list:
            anode = self.get_node_by_name(node)
            if not anode:
                #print "11107" #return errno 27, the node to query not exist
                EXIT(11107)
            node_obj_list.append(anode)
        
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(node_obj_list))
            node_thread_pool.initPool(data=node_obj_list, target_info=('update_dynamic_sys_info', [], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            print traceback.print_exc(e)
        else:
            pass
        finally:
            pass
        
        #for result in thread_result:
        #    anode = result[0]
        #    r = result[1]
        
        #    if not anode.list_dynamic_info(output_img):
        #        #print "11109" #return errno 29, connect or send or recieve message to node error
        #        EXIT(11109)
        #        output_img.seek(0)
        f = open('/etc/digioceanfs_manager/nodes/%s_dynamicsysinfo' % node_name)
        output_img.write(f.read())
        output_img.seek(0)

        return output_img

    def node_list_raid (self, node_name):
        output_img = StringIO.StringIO()
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11107" #return errno 27, the node to query not exist
            EXIT(11107)
        anode.list_disk(output_img, "raid")
        output_img.seek(0)
        return output_img

    def node_list_inactive_raid (self, node_name):
        output_img = StringIO.StringIO()
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11107" #return errno 27, the node to query not exist
            EXIT(11107)
        if not anode.list_inactive_raid(output_img):
            #print "11109"
            EXIT(11109)
        output_img.seek(0)
        return output_img

    def node_update_disk (self, node_name):
        if node_name == 'all':
            nodes = self.node_list
            thread_result = []
            try:
                node_thread_pool = ClusterThreadPool(len(nodes))
                node_thread_pool.initPool(data=nodes, target_info=('update_disk', ['y'], dict()))
                node_thread_pool.start_threads()
                node_thread_pool.clear_threads()
                thread_result = node_thread_pool.get_results()
            except Exception, e:
                print traceback.print_exc(e)
            else:
                pass
            finally:
                pass
        else:
            anode = self.get_node_by_name(node_name)
            if not anode:
                #print "11110" #return errno 30, the node to query not exist
                EXIT(11110)
            if not anode.update_disk(update_disk_change = "y"):
                #print "11111"
                EXIT(11111)

    def node_raid_create (self, node_name, level, chunk, disks):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "14001" #return errno 121, the node to create raid not exist
            EXIT(14001)
        if len(disks) < 2:
            #print "14006"
            EXIT(14006)
            if level == '6':
                #print "14009"
                EXIT(14009)
            elif level == '10':
                #print "14010"
                EXIT(14010)
        anode.raid_create(level, chunk, disks)

    def node_raid_del (self, node_name, raid_name):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "14107" #return errno 127, the node to del raid not exist
            EXIT(14107)
        anode.raid_del(raid_name)

    def node_raid_info (self, node_name, raid_name):
        output_img = StringIO.StringIO()
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "14214" #return errno 134, the node to list raid info not exist
            EXIT(14214)
        anode.raid_info(raid_name, output_img)
        output_img.seek(0)
        return output_img

    def node_raid_hs_set (self, node_name, raid_name, disks):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "14214" #return errno 134, the node to list raid info not exist
            EXIT(14214)
        anode.raid_hs_set(raid_name, disks)

    def node_raid_hs_del (self, node_name, raid_name, disks):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "14427" #return errno 147, the node to del hs disk not exist
            EXIT(14427)
        anode.raid_hs_del(raid_name, disks)

    def node_raid_active (self, node_name, raid_name):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "14536" #return errno 156, the node to del hs disk not exist
            EXIT(14536)

        ret = anode.raid_active(raid_name)

        if ret == 2:
            #print "14537"
            EXIT(14537)
        elif ret == 3:
            #print "14538"
            EXIT(14538)
        elif ret == 4:
            #print "14539"
            EXIT(14539)
        elif ret == 5:
            #print "14540"
            EXIT(14540)

    def node_raid_disactive_disk (self, node_name, disk_name_list):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "14641"
            EXIT(14641)

        ret = anode.raid_disactive_disk(disk_name_list)

        if ret == 2:
            #print "14642"
            EXIT(14642)
        if ret == 3:
            #print "14643"
            EXIT(14643)

    def node_ip_set_by_nic(self, node_name, nic_name, new_ip, new_mask, new_gate, new_bcast):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11115"
            EXIT(11115)

        anic = anode.get_nic_by_name(nic_name)
        old_ip = anic.ip

        if new_ip != old_ip:
            if PING(new_ip):
                #print "11117"
                EXIT(11117)

        data = [new_ip, new_mask, new_gate, new_bcast]

        for v in data[:-1]:
            if not checkIP(v):
                #print "11100" #return errno 20, ipaddr is not legal
                EXIT(11100)
        if new_ip == "255.255.255.255":
            #print "11095"
            EXIT(11095)

        #change local ipaddr
        local_host_name = os.uname()[1]
        if anode.get_name() == local_host_name:
            ret = anode.ip_set_by_nic(nic_name, new_ip, new_mask, new_gate, new_bcast, True)
        else:
            ret = anode.ip_set_by_nic(nic_name, new_ip, new_mask, new_gate, new_bcast)

        if ret == 1: #ip set success, no change to host
            anode.disconnect()
            time.sleep(1)
            anode.update_nic()
            self.issue_service_client_hosts()
        elif ret == 2: #ip set success, host changed
            node_name = anode.get_name()
            ip_addr = anode.get_ip_addr()
            del_host(anode.get_name())
            add_host(anode.get_name(), anode.get_ip_addr())
            for lanode in self.node_list:
                lanode.disconnect()
                lanode.remote_connect_by_ip()
            self.issue_hosts()
            self.reset_config_file()
            anode.update_nic()
            for aservice in self.service_list:
                if aservice.node_has_disk(anode) == 1:
                    ret = aservice.stop()
                    digi_debug("node_ip_set_by_nic, stop service:%s, success:%d, failed:%d, not found:%d, no connect: %d"%(aservice.get_name(), ret[0], ret[1], ret[2], ret[3]),5)
                    ret = aservice.start()
                    digi_debug("node_ip_set_by_nic, start service:%s, success:%d, failed:%d, not found:%d, already started:%d, no connect:%d, version do not match:%d"%(aservice.get_name(), ret[0], ret[1], ret[2], ret[3], ret[4], ret[5]),5)
            args = node_name + ' ' + ip_addr 
            for tmp_node in self.node_list:
                node_manager.remote_set_manager_ip(tmp_node.node_name, tmp_node.ip_addr, args)
            self.issue_service_client_hosts()
        elif ret == 3:
            #print "11116"
            EXIT(11116)
        elif ret == 4:
            #print "11117"
            EXIT(11117)
        elif ret == 5:
            #print "11118"
            EXIT(11118)
        elif ret == 6:
            #print "11119"
            EXIT(11119)

    def node_bond_set(self, node_name, bond_mode, nic_list):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11328"
            EXIT(11328)
        if len(nic_list) < 2:
            #print "11329"
            EXIT(11329)
        if bond_mode.isdigit():
            bond_mode_int = int(bond_mode)
        else:
            #print "11330"
            EXIT(11330)
        if bond_mode_int < 0 or bond_mode_int > 6:
            #print "11330"
            EXIT(11330)
        ret = anode.bond_set(bond_mode_int, nic_list)
        if ret == 2:
            #print "11331"
            EXIT(11331)
        elif ret == 3:
            #print "11332"
            EXIT(11332)
        elif ret == 4:
            #print "11333"
            EXIT(11333)
        elif ret == 5:
            #print "11334"
            EXIT(11334)

    def node_bond_del(self, node_name, bond_name):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "11435"
            EXIT(11435)
        ret = anode.bond_del(bond_name)
        if ret == 2:
            #print "11436"
            EXIT(11436)
        elif ret == 3:
            #print "11437"
            EXIT(11437)

    def node_sms_set(self, option):
        if not self.node_list:
            EXIT(11521)
        result = ''
        sms_options = {}
        try:
            if len(option) >= 1:
                sms_options['option'] = option[0]
                sms_options['sms_number'] = ''
                sms_options['notify_type'] = []
            if len(option) >= 2:
                if option[0] == 'notify_type':
                    sms_options['notify_type'] = option[1:]
                else:
                    sms_options['sms_number'] = option[1]
        except Exception, e:
            digi_debug("Node sms setup, parse sms option arise error %s" % e,3)
            EXIT(-1, "Node sms setup, parse sms option arise error %s" % e)

        if os.path.exists(settings.SMSCONF):
            f = open(settings.SMSCONF,'r')
            smsinfos = pickle.load(f)
            f.close()
        else:
            smsinfos = {}
            
        if sms_options['option'] == 'list':
            result = self.sms_info_list(smsinfos)
        elif sms_options['option'] == 'enable':
            smsinfos['inuse'] = True
        elif sms_options['option'] == 'disable':
            smsinfos['inuse'] = False
        elif sms_options['option'] == 'sms_center_num':
            if sms_options['sms_number']:
                smsinfos['smsp'] = sms_options['sms_number'] 
            else:
                digi_debug("Node sms setup %s, parse sms option arise error" % (sms_options['option']),5)
                EXIT(-1, "Node sms setup %s, parse sms option arise error" % (sms_options['option']))
        elif sms_options['option'] == 'add_mobp_num':
            if sms_options['sms_number']:
                if 'mobp' in smsinfos:
                    if sms_options['sms_number'] not in smsinfos['mobp']:
                        smsinfos['mobp'].append(sms_options['sms_number'])
                    else:
                        digi_debug("Node sms setup , mob numbers exists",5)
                        EXIT(11522)
                else:
                    smsinfos['mobp'] = []
                    smsinfos['mobp'].append(sms_options['sms_number'])
            else:
                digi_debug("Node sms setup %s, parse sms option arise error" % (sms_options['option']),5)
                EXIT(-1, "Node sms setup %s, parse sms option arise error" % (sms_options['option']))
        elif sms_options['option'] == 'del_mobp_num':
            if sms_options['sms_number']:
                smsinfos['mobp'].remove(sms_options['sms_number'])
            else:
                digi_debug("Node sms setup %s, parse sms option arise error" % (sms_options['option']),5)
                EXIT(-1, "Node sms setup %s, parse sms option arise error" % (sms_options['option']))
        elif sms_options['option'] == 'notify_type':
            smsinfos['ntype'] = [ntype for ntype in sms_options['notify_type']]
        else:
            digi_debug("Node sms setup, option %s not found" % sms_options['option'], 3)
            EXIT(-1, "Node sms setup, option %s not found" % sms_options['option'])

        try:
            if smsinfos:
                for anode in self.node_list:
                    anode.sync_sms_conf(smsinfos)
        except:
            digi_debug("Node sms setup, sync sms conf failed", 3)
            EXIT(11523)

        output_img = StringIO.StringIO()
        output_img.write(result)
        output_img.seek(0)
        return output_img

    def sms_info_list(self,smsinfos):
        GSM_center_num = ''
        smsinfo_img = StringIO.StringIO()
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(self.node_list))
            node_thread_pool.initPool(data=self.node_list, target_info=('get_GSM_message_center_number', [], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            print e
            digi_debug("Node sms setup, Node manager multi threading tought exception: %s" % e,3)
        else:
            pass
        finally:
            pass
        for result in thread_result:
            node = result[0]
            ret = result[1]
            GSM_center_num = ret[1]
            break

        if 'inuse' in smsinfos and smsinfos['inuse']:
            smsinfo_img.write("Status: Enable\n")
        else:
            smsinfo_img.write("Status: Disable\n")
        if GSM_center_num:
            smsinfo_img.write("Message Center Number: %s(GSM)\n" % GSM_center_num)
        else:
            if 'smsp' in smsinfos:
                smsinfo_img.write("Message Center Number: %s\n" % smsinfos['smsp'])
        if 'mobp' in smsinfos and smsinfos['mobp']:
            smsinfo_img.write("Receive Number: %s\n" % ','.join(smsinfos['mobp']))
        if 'ntype' in smsinfos and smsinfos['ntype']:
            smsinfo_img.write("Notify Type: %s\n" % ','.join(smsinfos['ntype']))
        smsinfo_img.seek(0)
        return smsinfo_img.read()
        
            
    def node_init(self, node_name, init_level):
        anode = self.get_node_by_name(node_name)
        if not anode:
            EXIT(11435)
        ret = anode.init(init_level)

    def node_ipmi_power_control(self, node_name, option):
        anode = self.get_node_by_name(node_name)
        if not anode:
            EXIT(11206)
        if os.path.exists(settings.IPMICONF):
            f = open(settings.IPMICONF,'r')
            ipmilist = pickle.load(f)
            f.close()
        else:
            ipmilist = []
        ipmi_ip = ''
        for ipmi_info in ipmilist:
            if ipmi_info['node'] == node_name:
                ipmi_ip = ipmi_info['ipmi_ip']
        if not ipmi_ip:
            EXIT(11207)

        output_img = StringIO.StringIO()
        #ipmitool -I lan -H 10.10.101.51 -U ADMIN -P ADMIN chassis power on/off/status
        cmd = []
        cmd.append(settings.COMMANDS['ipmitool'])
        cmd.append('-I')
        cmd.append('lan')
        cmd.append('-H')
        cmd.append(ipmi_ip)
        cmd.append('-U')
        cmd.append('ADMIN')
        cmd.append('-P')
        cmd.append('ADMIN')
        cmd.append('chassis')
        cmd.append('power')
        cmd.append(option)
        try:
            tmp_img = tempfile.TemporaryFile()
            ret = execute(cmd, tmp_img)
            digi_debug("Node ipmi power control , %s return %d" % (' '.join(cmd),ret),5)
            tmp_img.seek(0)
            result = tmp_img.read()
            if ret:
                digi_debug("Node ipmi power control, %s" % result,3)
                EXIT(11208, result)        
            if option == 'status':
                if result.find('on') >= 0:
                    output_img.write('on')
                else:
                    output_img.write('off')
        except Exception,e:
            digi_debug("Node ipmi power control, caught exception: %s" % e,3)
        output_img.seek(0)
        return output_img

    def node_ipmi_info(self, node_name):
        try:
            output_img = StringIO.StringIO()
            if os.path.exists(settings.IPMICONF):
                f = open(settings.IPMICONF,'r')
                ipmilist = pickle.load(f)
                f.close()
            else:
                ipmilist = []    
            for ipmi_info in ipmilist:
                if ipmi_info['node'] == node_name:
                    output_img.write("%s|%s|%s|%s" % (ipmi_info['ipmi_ipsrc'] or '-',ipmi_info['ipmi_ip'] or '-',ipmi_info['ipmi_netmask'] or '-',ipmi_info['ipmi_gateway'] or '-'))
                    break
            # 10.10.100.175|255.255.0.0|10.10.10.1  or -|-|-
        except Exception,e:
            digi_debug("Node ipmi info, caught exception: %s" % e,3)
        output_img.seek(0)
        return output_img

    def node_ipmi_ip_set(self, node_name, ipaddress, netmask, gateway):
        anode = self.get_node_by_name(node_name)
        if not anode:
            EXIT(11201)
        if not PING(anode.get_ip_addr()):
            EXIT(11203)
        if os.path.exists(settings.IPMICONF):
            f = open(settings.IPMICONF,'r')
            ipmilist = pickle.load(f)
            f.close()
        else:
            ipmilist = []
        ipmi_ip = ''
        for ipmi_info in ipmilist:
            if ipmi_info['node'] == node_name:
                ipmi_ip = ipmi_info['ipmi_ip']
        if not ipmi_ip:
            EXIT(11202)
        ret = anode.remote_set_ipmi_ip(ipaddress,netmask,gateway)
        if ret == '1':
            add_ipmi_to_conf(node_name,'Static',ipaddress,netmask,gateway)
            self.issue_ipmi_conf()
        else:
            #ret = '2'/'3' and remote_call failed
            EXIT(11204)
        return 0

#    def node_replace(self, old_node_name, replace_node_name, new_node_name):
    def node_replace(self, node_name, replace_node_ip):
        old_node        = None
        replace_node    = None
        replace_disks   = None
        checked_disks   = None
        rip_arr         = []
        # ip check
        if not checkIP(replace_node_ip):
            #print "11124"
            EXIT(11124)

        old_node = self.get_node_by_name(node_name)
        if not old_node:
            #print "11120"
            EXIT(11120)
        if self.node_ip_duplicate(replace_node_ip):
            #print "11121"
            EXIT(11121)
        replace_node = node(self.options, TMP_NODE_NAME, ip_addr=replace_node_ip, connect_ahead=True)

        if not replace_node.remote_connect_by_ip():
            #print "11123"
            EXIT(11123)

        output_img = StringIO.StringIO()
        if not replace_node.list_nic(output_img):
            #print "11109" #return errno 29, connect or send or recieve message to node error
            EXIT(11109)
        
        ret = str(output_img.getvalue())
        ret = ret.strip().split('\n')
        output_img.close()
        
        for tmp in ret:
            rip_arr.append(tmp.split('\t')[4])

        for tnode in self.node_list:
            hosts_content = tnode.get_hosts()
            if tnode == old_node:
                continue
            if not hosts_content:
                #print "11109" #return errno 29, connect or send or recieve message to node error
                EXIT(11109)
            hosts_content = str(hosts_content)
            content_list = hosts_content.split('\n')
            for a_line in content_list:
                if len(a_line) < 2:
                    continue
                if a_line[0] == '#':
                    continue
                host_ip = a_line.split()[0]
                '''
                if node_ip_addr == host_ip:
                    #print "11102" #return errno 22, node to add already exist
                    EXIT(11102)
                '''
                for ip in rip_arr:
                    if ip == host_ip:
                        #print "11102" #return errno 22, node to add already exist
                        EXIT(11102)

        server_img = get_config_file(settings.HOSTFILE)
        
        replace_node.destroy()
        if not old_node.remote_connect():
            replace_disks = old_node.replace_fetch_disk_offline()
        else:
            old_node.update_disk()
            replace_disks = old_node.replace_fetch_disk()
        replace_node.update_disk()

        #do some check before replace
        if type(replace_disks) == types.NoneType:
            #print "11125"
            EXIT(11125)
        if len(replace_disks) == 0:
            #print "11128"
            EXIT(11128)           
        
        (ret, checked_disks) = replace_node.replace_check_disk(replace_disks)
        if not ret:
            #print "11126"
            EXIT(11126)
        
        #destroy disks on old_node
        ret = old_node.destroy_on_node()
        if not ret:
            #print "11127"
            EXIT(11127)

        #according to disk check result, initialize some list we use below
        # volumes                 = [] #list of old_disk volume name
        # replace_disk_names      = [] #list of new_disk_dev
        replace_disk_ports_user = [] #list of combine of disk_dev, disk_port and disk_user
        
        for adisk in checked_disks:
            # volumes.append("%s-%s"%(adisk[1], adisk[2]))
            # replace_disk_names.append(adisk[4])
            replace_disk_ports_user.append([adisk[4], adisk[2], adisk[3], adisk[1]])

        # maintain the relationship of group and node, write them to disk
        replace_node.set_name(old_node.get_name())
        agroup = old_node.get_group()
        agroup.rm_node(old_node)
        agroup.add_node(replace_node)
        # self.node_list.remove(old_node) # drop old node until sync hosts file on each host
        self.node_list.append(replace_node)
        self.reset_config_file()

        #change hosts and syn to all node
        try:
            old_node.rsyslog_request(rsyslog_utils.CMD_DESTROY,[old_node.ip_addr])
        except Exception, e:
            traceback.print_exc(e)
            digi_debug("Node replace, rsyslog_request % caught exception: %s"%(rsyslog_utils.CMD_DESTROY,e),3)

        del_host(old_node.get_name(), '', server_img)
        #del_host(old_node.get_name())
        add_host(replace_node.get_name(), replace_node.get_ip_addr())
        
        ret = self.issue_hosts()
        if ret:
            replace_node.set_hostname(node_name)
        
        self.node_list.remove(old_node) 

        #initial disks on new_node
        replace_node.replace_initial_disk(replace_disk_ports_user)

        #put replace on each service involved
        #        digi_debug("volumes                :%s"%(volumes))
        #        digi_debug("replace_disk_names     :%s"%(replace_disk_names))
        #        digi_debug("replace_disk_ports_user:%s"%(replace_disk_ports_user))
        
        for aservice in self.service_list:
            aservice.replace(old_node, replace_node, replace_disk_ports_user)

        replace_node.update_disk(update_disk_change = True)

        try:
            #fd = open('/etc/hosts', 'r')
            fd = open(settings.HOSTFILE, 'r')
            lines = fd.readlines()
            for sline in lines:
                for addr in self.get_ip_addr():
                    if not cmp('127',addr[:3]):
                        continue
                    if addr in sline: 
                        replace_node.rsyslog_request(rsyslog_utils.CMD_ADD,[addr])
                        break
                    
            fd.close()
            
            ip_list = get_local_ip_list()
            if replace_node_ip in ip_list:
                args = node_name + ' ' + replace_node_ip
                for tmp_node in self.node_list:
                    node_manager.remote_set_manager_ip(tmp_node.node_name, tmp_node.ip_addr, args)
            else:
                manager_tuple = node_manager.get_management_node()
                if manager_tuple != ():
                    args = manager_tuple[0] + ' ' + manager_tuple[1]
                    node_manager.remote_set_manager_ip(replace_node.node_name, replace_node.ip_addr, args)        
            
        except Exception, e:
            traceback.print_exc()
            digi_debug("Node replace, rsyslog_request % caught exception: %s"%(rsyslog_utils.CMD_ADD,e),3)
            
    def node_replace_nodisk(self, node_name, service_name, disks):
        for disk in disks:
            anode = self.get_node_by_name(node_name)
            disks_id_list = []
            if not anode:
                #print "node not found"
                digi_debug("Node replace nodisk, node not found",3)
                #print "11501"
                EXIT(11501)
    
            anode.update_disk()

            aservice = self.get_service_by_name(service_name)
            if not aservice:
                #print "service not found"
                digi_debug("Node replace nodisk, service not found",3)
                #print "11502"
                EXIT(11502)

            adisk = anode.get_disk_by_dev(disk)
            if not adisk:
                #print "one disk not found"
                digi_debug("Node replace nodisk, one disk not found",3)
                #print "11503"
                EXIT(11503)
            else:
                if adisk.disk_status == 3:
                    #print "disk is in use"
                    digi_debug("Node replace nodisk, disk is in use",3)
                    #print "11504"
                    EXIT(11504)

            disk_id = adisk.get_dev_id()

            (ret, replace_disk_id_dict) = anode.replace_nodisk(service_name, disk_id)
    
            if ret == "1":
                for k, v in replace_disk_id_dict.iteritems():
                    kdisk = anode.get_disk_by_name(k)
                    vdisk = anode.get_disk_by_name(v)
                    aservice.nodisk_del_disk([kdisk])
                    aservice.nodisk_add_disk([vdisk])
                #print "replace_nodisk success!"
                digi_debug("Node replace nodisk, success",5)
                EXIT()
            elif ret == "2":
                #print "no disk to replace"
                digi_debug("Node replace nodisk, no disk to replace",3)
                #print "11504"
                EXIT(11504)
            elif ret == "3":
                #print "replace disk not found"
                digi_debug("Node replace nodisk, replace disk not found",3)
                #print "11505"
                EXIT(11505)
            elif ret == "4":
                #print "12012"
                EXIT(12012)
            anode.update_disk()
            time.sleep(5)            
            afr_num = aservice.get_afr_num()
            for i in range(afr_num):
                os.system("ls -laR %s &>/dev/null"% mount_dir_prefix + "/" + service_name)
    
    def node_check_license(self, node_name, license):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "node not found"
            digi_debug("Node check license, node not found",3)            
            #print "16006"
            EXIT(16006)

        ret = anode.check_license(license)
        if ret != "1":
            #print "10000"
            EXIT()

    def node_get_device_id(self, node_name):
        anode = self.get_node_by_name(node_name)
        if not anode:
            #print "node not found"
            digi_debug("Node get device id, node not found",3)
            #print "11130"
            EXIT(11130)
        ret = anode.get_device_id()
        return ret
            
        
#########################################################
#methods for service
#########################################################
    def service_create(self, service_name, raid_type, disk_list):
        #at first, we do some check
        disks = list()
        #service_name require only include 0-9 a-z A-Z and four special characters @|_|-|.
        service_p = '[^0-9a-zA-Z@_.-]'
        if re.findall(service_p, service_name):
            #print "13100"
            digi_debug("Service create, illegal service name format, only 0-9 a-z A-Z @ - . _ allowed",3)
            EXIT(13100)
        aservice = self.get_service_by_name(service_name)
        if aservice:
            #print "13102"
            digi_debug("Service create, service already exists",3)
            EXIT(13102)
        #for disk_line in disk_list:
        #    if len(disk_line.split(':')) < 2:
        #        #print "13103"
        #        EXIT(13103)
        #    node_name = disk_line.split(':')[0]
        #    disk_name = disk_line.split(':')[1]
        #    anode = self.get_node_by_name(node_name)
        #    if not anode:
        #        #print "13104"
        #        EXIT(13104)
        #    adisk = anode.get_disk_by_dev(disk_name)
        #    if not adisk:
        #        #print "13105"
        #        EXIT(13105)
        #    if adisk.get_user():
        #        #print "13106"
        #        EXIT(13106)
        #    if not add_in_list(disks, adisk):
        #        #print "13106"
        #        EXIT(13106)

        ###################################
        # create volume for gluster-3.4
        ###################################
        node_list = []
        node_disk_dict = [] # {'node-1':['sdb','sdc']}
        node_disk_list = []
            
        aservice = service(self, service_name) 
        
        self.node_update_disk('all')

        # Check disk status
        for disk_line in disk_list:
            if len(disk_line.split(':')) < 2:
                digi_debug("Service create, illegal disks format",3)
                #print "13103"
                EXIT(13103)
            node_name = disk_line.split(':')[0]
            disk_name = disk_line.split(':')[1]
            anode = self.get_node_by_name(node_name)
            if not anode:
                digi_debug("Service create, node %s not exists" % node_name,3)
                #print "13104"
                EXIT(13104)
            if anode not in node_list:
                node_list.append(anode)
            #anode.update_disk('Y')
            adisk = anode.get_disk_by_dev(disk_name)
            if not adisk:
                digi_debug("Service create, disks %s not exist" % disk_name,3)
                #print "13105"
                EXIT(13105)
            node_disk_list.append(anode.get_name()+':'+adisk.dev_id)
            if not node_disk_dict:
                node_disk_dict = {anode.get_name():[adisk.dev_id]}
            else:
                if anode.get_name() in node_disk_dict:
                    node_disk_dict[anode.get_name()].append(adisk.dev_id)
                else:
                    node_disk_dict[anode.get_name()] = [adisk.dev_id]
            if adisk.get_user():
                digi_debug("Service create, disks %s already in use" % disk_name,3)
                #print "13106"
                EXIT(13106)
            if not add_in_list(disks, adisk):
                digi_debug("Service create, disks %s already in use" % disk_name,3)
                #print "13106"
                EXIT(13106)
        ####################################
        # manual or auto pair
        #################################### 
        if not self.options.manual_afr and int(self.options.afr_num) > 0:
            disks = afr_disk_auto_pair(disks,self.options.afr_num)
        
        if int(self.options.disp_num) > 0:
            disks = afr_disk_auto_pair(disks, int(self.options.disp_num))

        ####################################
        # Check params 
        #################################### 
        if not find_in_list(service_raid_type, raid_type):
            digi_debug("Service create, illegal raid level",3)
            #print "13218"
            EXIT(13218)

        if raid_type == "0":
            if self.options.stripe_num != 0:
                if len(disks)%self.options.stripe_num != 0:
                    digi_debug("Service create, number of disk does not match raid level require",3)
                    #print "13219"
                    EXIT(13219)
            else:
                digi_debug("Service create, number of disk does not match raid level require",3)
                #print "13219"
                EXIT(13219)

        if raid_type == "1":
            if self.options.afr_num != 0:
                if len(disks)%self.options.afr_num != 0:
                    digi_debug("Service create, number of disk does not match raid level require",3)
                    #print "13219"
                    EXIT(13219)
            else:
                self.options.afr_num = len(disks)
                if self.options.afr_num < 2:
                    digi_debug("Service create, number of disk does not match raid level require",3)
                    #print "13219"
                    EXIT(13219)

        if raid_type == "01":
            if self.options.afr_num*self.options.stripe_num != 0:
                if len(disks)%(self.options.afr_num*self.options.stripe_num) != 0:
                    digi_debug("Service create, number of disk does not match raid level require",3)
                    #print "13219"
                    EXIT(13219)
            else:
                digi_debug("Service create, number of disk does not match raid level require",3)
                #print "13219"
                EXIT(13219)

        # if raid_type is afr or default,disable the option '-m' 
        if raid_type == "2" or raid_type == "0":
            if self.options.manual_afr:
                digi_debug("Service create, number of disk does not match raid level require",3)
                #print "13219"
                EXIT(13219)

        # if raid_type is '2',disable the option '-a','-s','-m' 
        if raid_type == "2" and self.options.afr_num + self.options.stripe_num != 0:
            digi_debug("Service create, number of disk does not match raid level require",3)
            #print "13219"
            EXIT(13219)

        # if raid_type is '1',disable the option '-s'      
        if raid_type == "1" and self.options.stripe_num != 0:
            digi_debug("Service create, number of disk does not match raid level require",3)
            #print "13219"
            EXIT(13219)

        # if raid_type is '0',disable the option '-a','-m'     
        if raid_type == "0" and self.options.afr_num != 0 and self.options.manual_afr != None:
            digi_debug("Service create, number of disk does not match raid level require",3)
            #print "13219"
            EXIT(13219)
        ####################################
        # Check disk is already part of volumes 
        #################################### 
       
        ####################################
        # Check disk path is exist
        #################################### 
        #for adisk in disks:
        #    if not os.path.exists(os.path.join("/digioceanfs", adisk.dev_id)):
        #        os.mkdir(os.path.join("/digioceanfs", adisk.dev_id))    

        ####################################
        # Check disk is mounted
        ####################################
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(node_list))
            node_thread_pool.initPool(data=node_list, target_info=('service_create_pre', [node_disk_dict], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            print e
            digi_debug("Service create, Node manager multi threading tought exception: %s" % e,3)
        else:
            pass
        finally:
            pass
        for result in thread_result:
            node = result[0]
            ret = result[1]
            if ret == 4:
                digi_debug("Service create, some disks is already a part of volumes",3)
                #print "13453"
                EXIT(13453)
            elif ret == 3:
                digi_debug("Service create, some disks mount failed, please check disks mount point",3)
                #print "13454"
                EXIT(13454)
            elif ret == 2:
                digi_debug("Service create, some disks mount point occur to be problems",3)
                #print "13455"
                EXIT(13455)
            elif ret != 1:
                digi_debug("Service create, unknow error occur",3)
                #print "13456"
                EXIT(13456)

        
        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append('volume')
        cmd.append('create')
        cmd.append(service_name)
        try:
            if self.options.stripe_num:
                cmd.append('stripe')
                cmd.append(str(self.options.stripe_num))
            if self.options.afr_num:
                cmd.append('replica')
                cmd.append(str(self.options.afr_num))
            if self.options.redu_num and self.options.disp_num:
                cmd.append('disperse')
                cmd.append(str(self.options.disp_num))
                cmd.append('redundancy')
                cmd.append(str(self.options.redu_num))
            for adisk in disks:
                cmd.append('%s:%s'%(adisk.node, os.path.join("/digioceanfs", adisk.dev_id)))
            cmd.append('force')
            cmd.append('--mode=script')
            tmp_img = tempfile.TemporaryFile()
            stdinput = subprocess.PIPE
            ret = execute(cmd, std=tmp_img, stdi=stdinput, communicate='y\n')
            digi_debug("Service create, %s return %d" % (' '.join(cmd),ret),5)
            tmp_img.seek(0)
            result = tmp_img.read()
            if ret:
                digi_debug("Service create, %s" % result,3)
                #print "13456"
                EXIT(13456, result)
        except Exception,e:
            print e
            digi_debug("Service create, caught exception: %s" % e,3)
        default_options = {'network.ping-timeout':'20', 
                           #'performance.client-io-threads':'enable', 
                           'nfs.rpc-auth-reject':'*.*.*.*',
                           'server.allow-insecure': 'on',
                           'features.lock-heal': 'on',
                           'cluster.readdir-optimize': 'on',
                           'cluster.heal-timeout': '60'}
        afr_sync_option = {'cluster.replicate-post-op-fsync': 'on'}
        self.service_set_options(service_name, default_options)
        default_performance_options = {'performance.io-thread-count': '64',
                                       'performance.high-prio-threads': '64',
                                       'performance.normal-prio-threads': '64',
                                       'performance.low-prio-threads': '64',
                                       'performance.least-prio-threads': '64'}
        self.service_set_options(service_name, default_performance_options)
        options_list = []
        if self.options.feature_str:
            options_list = self.options.feature_str
        if 'native_store' in options_list:
            native_store = True
        else:
            native_store = False
        if 'custom_store' in options_list:
            custom_store = True
        else:
            custom_store = False
        if self.options.afr_num:
            self.service_set_options(service_name, afr_sync_option)
        if native_store:
            dht_local_options = {'cluster.nufa':'on'}
            self.service_set_options(service_name, dht_local_options)
        if self.options.afr_num and native_store:
            afr_local_options = {'cluster.choose-local':'on'}
            self.service_set_options(service_name, afr_local_options)
        if self.options.afr_num and custom_store:
            afr_custom_store = {'cluster.self-heal-choose-biggest': 'on'}
            self.service_set_options(service_name, afr_custom_store)
        #######################################
        # update status of disks on each node 
        ####################################### 
        thread_result = []
        try:
            #self.node_list : connect to all node and create service samba conf file
            node_thread_pool = ClusterThreadPool(len(self.node_list))
            node_thread_pool.initPool(data=self.node_list, target_info=('service_create_post', [service_name, node_disk_dict], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            print e
            digi_debug("Service create, Node manager multi threading tought exception: %s" % e,3)
        else:
            pass
        finally:
            pass

        for result in thread_result:
            anode = result[0]
            ret = result[1]
            if anode in node_list and ret != 1:  
                digi_debug("Service create service post failed, return %s" % ret,3)
                EXIT(13456)
            #anode.update_disk()
            
        os.system('sync')

        return 0

        #######################################
        # old service create, Obsoleted
        #######################################
        """
        #actual service create procedure
        aservice = service(self.options, self)
        ret = aservice.create(service_name, raid_type, local_prioritize, disks, self.max_mserver_port)
        if ret == 2:
            #print "13216" #return errno 96, a node can not be connected while create the service
            EXIT(13216)
        if ret == 3:
            #print "13218"
            EXIT(13218)
        if ret == 4:
            #print "13219"
            EXIT(13219)
        self.max_mserver_port = self.max_mserver_port + 1
        """

    def service_set_options(self, service_name, options):
        for o_key,o_value in options.iteritems():
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('set')
            cmd.append(service_name)
            cmd.append(o_key)
            cmd.append(o_value)
            tmp_img = tempfile.TemporaryFile()
            ret = execute(cmd, tmp_img)
            if ret:
                digi_debug("%s return %s, failed" % (' '.join(cmd), ret))
                return False
        return True
    
    def service_set_spare(self, service_name, disk_list, format=False):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            EXIT(13101)
        disk_dict = {}
        node_list = []
        for d in disk_list:
            node_name = d.split(':')[0]
            disk_name = d.split(':')[1]
            anode = self.get_node_by_name(node_name)
            if anode:
                node_list.append(anode)
                adisk = anode.get_disk_by_dev(disk_name)
            if anode.get_name() not in disk_dict:
                disk_dict[anode.get_name()] = []
                disk_dict[anode.get_name()].append(adisk.dev_id) 
            else:
                if adisk.dev_id not in disk_dict[anode.get_name()]:
                    disk_dict[anode.get_name()].append(adisk.dev_id) 
        print disk_dict
        node_list = [self.get_node_by_name(node_name) for node_name in disk_dict.keys()]
        print node_list
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(node_list))
            node_thread_pool.initPool(data=node_list, target_info=('service_set_spare', [disk_dict, service_name, format], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
            for r in thread_result:
                anode = r[0]
                if not anode.status():
                    continue
                ret = str(r[1])
                if ret == "5":
                    EXIT(13155)
                elif ret == "4":
                    EXIT(13156)
                elif ret == "3":
                    EXIT(13157)
                elif ret == "2":
                    EXIT(13158)
                elif ret != "1":
                    EXIT(-1)
        except Exception, e:
            digi_debug("Service set spare, Node manager multi threading tought exception: %s" % e,3)
            print e
            EXIT(-1, e)
        else:
            pass
        finally:
            pass
            
        
        

    def service_replace_disk(self, service_name, disk_pair_list, option, force=True, format=False):
        """
        Function for replacing disk using gluster-3.4
        """
        if option != 'commit':
            return None
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13101"
            EXIT(13101)
        disk_dict = {}
        cmd_list = []
        for disk_pair in disk_pair_list:
            try:
                # old disk parse
                old_disk_str = disk_pair.strip().split(',')[0]
                old_disk_node = old_disk_str.split(':')[0]
                old_disk_anode = self.get_node_by_name(old_disk_node)
                if not old_disk_anode:
                    EXIT(13150)
                # check old_disk node is online
                if not old_disk_anode.status():
                    old_node_offline = True 
                else:
                    old_node_offline = False 
                old_disk_dev = old_disk_str.split(':')[1]
                if old_node_offline:
                    old_adisk = old_disk_anode.get_disk_by_dev(old_disk_dev, offline=True)
                else:
                    old_adisk = old_disk_anode.get_disk_by_dev(old_disk_dev)
                if not old_adisk:
                    EXIT(13151)

                if old_disk_anode.get_name() not in disk_dict:
                    disk_dict[old_disk_anode.get_name()] = {'old_disk':[], 'new_disk':[]}
                    disk_dict[old_disk_anode.get_name()]['old_disk'].append(old_adisk.dev_id)
                else:
                    if old_adisk.dev_id not in disk_dict[old_disk_anode.get_name()]['old_disk']:
                        disk_dict[old_disk_anode.get_name()]['old_disk'].append(old_adisk.dev_id)

                old_disk_cmd_name = old_disk_anode.get_name() + ':/digioceanfs/' + old_adisk.get_dev_id()  

                # new disk parse
                new_disk_str = disk_pair.strip().split(',')[1]
                new_disk_node = new_disk_str.split(':')[0]
                new_disk_anode = self.get_node_by_name(new_disk_node)
                if not new_disk_anode:
                    EXIT(13152)
                new_disk_dev = new_disk_str.split(':')[1]
                new_adisk = new_disk_anode.get_disk_by_dev(new_disk_dev)
                if not new_adisk:
                    EXIT(13153)
                if new_disk_anode.get_name() not in disk_dict:
                    disk_dict[new_disk_anode.get_name()] = {'old_disk':[], 'new_disk':[]}
                    disk_dict[new_disk_anode.get_name()]['new_disk'].append(new_adisk.dev_id)
                else:
                    if new_adisk.dev_id not in disk_dict[new_disk_anode.get_name()]['new_disk']:
                        disk_dict[new_disk_anode.get_name()]['new_disk'].append(new_adisk.dev_id)

                new_disk_cmd_name = new_disk_anode.get_name() + ':/digioceanfs/' + new_adisk.get_dev_id()  
                cmd_list.append(old_disk_cmd_name + ' ' + new_disk_cmd_name)
            except Exception, e:
                traceback.print_exc(e)
                EXIT(13154)
        # check new service disk is ready
        node_list = [self.get_node_by_name(node_name) for node_name in disk_dict.keys()]
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(node_list))
            node_thread_pool.initPool(data=node_list, target_info=('service_replace_pre', [disk_dict, format], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
            for r in thread_result:
                anode = r[0]
                if not anode.status():
                    continue
                ret = str(r[1])
                if ret == "5":
                    EXIT(13155)
                elif ret == "4":
                    EXIT(13156)
                elif ret == "3":
                    EXIT(13157)
                elif ret == "2":
                    EXIT(13158)
                elif ret != "1":
                    EXIT(-1)
        except Exception, e:
            digi_debug("Service replace pre, Node manager multi threading tought exception: %s" % e,3)
            print e
            EXIT(-1, e)
        else:
            pass
        finally:
            pass
        
        try:
            for disk_pair in cmd_list: 
                tmp_img = tempfile.TemporaryFile()
                cmd = []
                cmd.append(settings.COMMANDS['digiocean'])
                cmd.append('volume')
                cmd.append('replace-brick')
                cmd.append(service_name)
                cmd.append(disk_pair.split()[0])
                cmd.append(disk_pair.split()[1])
                cmd.append(option)
                if force:
                    cmd.append("force")
                ret = execute(cmd, tmp_img)
                re_str = tmp_img.read().strip()
                if ret:
                    EXIT(-1, re_str)
        except Exception, e:
            traceback.print_exc(e)
            EXIT(-1, e)
    # update disk status after replace disk
        try:
            node_thread_pool = ClusterThreadPool(len(node_list))
            node_thread_pool.initPool(data=node_list, target_info=('service_replace_post', [service_name, disk_dict], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            digi_debug("Service replace pre, Node manager multi threading tought exception: %s" % e,3)
            print e
        else:
            pass
        finally:
            pass
        for r in thread_result:
            if r[1] != "1":
                digi_debug("Node manager service replace disk change %s failed on %s"% (r[1], r[0]), 3)
        #ret = new_service_anode.service_replace_post(service_name, {new_service_anode.get_name():(service_node_adisk.dev_id,new_service_node_adisk.dev_id)})
        digi_debug("Service replace disk post return: %s" % str(ret), 7)
        # sync disk 
        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append("volume")
        cmd.append("info")
        cmd.append(service_name)
        ret = execute(cmd, tmp_img)
        digi_debug("Service list single, %s return %d" % (' '.join(cmd),ret),5)
        result_str = tmp_img.read()
        service_type = get_service_type_info(service_name,result_str)
        if service_type['replica']:
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('heal')
            cmd.append(service_name)
            if format:
                cmd.append('full')
            ret = execute(cmd, tmp_img)
        elif service_type['disperse']:
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('heal')
            cmd.append(service_name)
            cmd.append('full')
            ret = execute(cmd, tmp_img)
            #cmd = 'find /cluster2/%s/ -d -exec getfattr -h -n trusted.ec.heal {} \;' % service_name
            #digi_debug(cmd, 3)
            #ret = execute(cmd, std=tmp_img, shell=True, nowait=True)
            #print ret
            #os.system('find /cluster2/%s/ -d -exec getfattr -h -n trusted.ec.heal {} \; >/dev/null 2>&1 &' % service_name)
            #execute(cmd)
        return True
    
    def service_heal_disperse(self, service_name, partten):
        anode = self.service_get_healing_node(self.node_list, service_name, partten)
        if anode:
            ret = anode.service_heal_disperse([service_name], partten)
            digi_debug("Node Manager, Service get heal node return: %s" % anode.get_name(), 3)
        else:
            anode = self.node_list[0]
            ret = anode.service_heal_disperse([service_name], partten)
            digi_debug("Node Manager, Service get heal node return first node: %s" % anode.get_name(), 3)
        return True
    
    def service_get_healing_node(self, node_list, service_name, partten):
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(node_list))
            node_thread_pool.initPool(data=node_list, target_info=('service_get_healing_status', [service_name, partten], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
            for r in thread_result:
                anode = r[0]
                #if not anode.status():
                if not PING(anode):
                    continue
                ret = str(r[1])
                if ret == '1':
                    return anode
        except Exception, e:
            digi_debug("Service get healing node, Node manager multi threading tought exception: %s" % e,3)
            print e
            return None
        else:
            pass
        finally:
            pass
    '''
    def service_list_disk_cache(self, service_name):
        disk_list_cache = []
        tmp_img = tempfile.TemporaryFile()
        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append("volume")
        cmd.append("info")
        cmd.append(service_name)
        ret = execute(cmd, tmp_img)
        result_str = tmp_img.read()
        if result_str:
            disk_list_cache = [disk.split(": ")[1] for disk in re.findall("Brick\d+: \S+", result_str)]
        return disk_list_cache
    '''

    def service_list_disk(self, service_name):
        output_img = StringIO.StringIO()
        aservice = self.get_service_by_name(service_name)
        #if not aservice:
        #    #print "13101" #return errno 81, the service to query not exist
        #    EXIT(13101)
        #aservice.list_disk(output_img)
        # new service list disk
        # using cli gluster-3.4 cmd: gluster volume status +volume_name detail
        node_offline_disk_str="""\
Brick                : Brick %s 
Port                 : NaN               
Online               : N                 
Pid                  : NaN 
File System          : Unkown 
Device               : /dev/%s
Mount Options        : Unkown                  
Inode Size           : Unkown                                   
Disk Space Free      : NaN             
Total Disk Space     : NaN 
Inode Count          : NaN 
Free Inodes          : NaN 
"""
        split_line = '------------------------------------------------------------------------------'
        disk_list_cache = service_list_disk_cache(service_name) 
        try:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append("volume")
            cmd.append("status")
            cmd.append(service_name)
            cmd.append("detail")
            ret = execute(cmd, tmp_img)
            digi_debug("Service list disk, %s return %d" % (' '.join(cmd),ret),5)
            new_lines = []
            ret_lines = tmp_img.read().strip()
            tmp_lines_head = ret_lines.split(split_line+'\n')[0]
            if tmp_lines_head.find('\n') < 0:
                tmp_lines_head += '\n'
            tmp_lines = ret_lines.split(split_line+'\n')[1:]
            for i in range(len(disk_list_cache)):
                node_dev_id = disk_list_cache[i]
                try:
                    anode = self.get_node_by_name(node_dev_id.split(':')[0])
                    adisk_cache = anode.get_disk_by_name(node_dev_id.split('/')[-1], True)
                    node_disk_dev = adisk_cache.dev
                except Exception, e:
                    digi_debug("Service replace disk, get cache disk dev failed")
                    print e
                    node_disk_dev = 'no_disk'
                if len(tmp_lines) <= i:
                    tmp_lines.append(node_offline_disk_str % (node_dev_id,node_disk_dev) + split_line + '\n')
                else:
                    if tmp_lines[i].find(node_dev_id) >= 0:
                        if i == len(tmp_lines) - 1:
                            tmp_lines[i]=tmp_lines[i]+'\n' + split_line+'\n'
                        else:
                            tmp_lines[i]=tmp_lines[i]+split_line+'\n'
                        continue
                    else:
                        tmp_lines.insert(i, node_offline_disk_str % (node_dev_id, node_disk_dev))
                        tmp_lines[i]=tmp_lines[i]+split_line+'\n'
            tmp_str = tmp_lines_head + split_line + '\n' + ''.join(tmp_lines)
                         
            tmp_lines = tmp_str.split('\n')
            for line in tmp_lines:
                if line.find("mapper") >= 0:
                    line = "Device\t\t     : /dev/no_disk"
                new_lines.append(line)
            output_img.write('\n'.join(new_lines))
            output_img.seek(0)
        except Exception, e:
            digi_debug("Service list disk, caught exception: %s" % e,3)
            print e
        return output_img

    def service_list_all_disk(self):
        output_img = StringIO.StringIO()
        try:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append("volume")
            cmd.append("status")
            cmd.append("all")
            cmd.append("detail")
            ret = execute(cmd, tmp_img)
            digi_debug("Service list all disk, %s return %d" % (' '.join(cmd),ret),5)
            ret_lines = tmp_img.readlines()
            new_lines = []
            for line in ret_lines:
                if line.find("mapper") >= 0:
                    line = "Device\t\t     : /dev/no_disk\n"
                new_lines.append(line)
            output_img.write(''.join(new_lines))
            output_img.seek(0)
        except Exception, e:
            digi_debug("Service list all disk, caught exception: %s" % e,3)
            print e
        return output_img

    def service_list_all(self):
        output_img = StringIO.StringIO()
        try:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append("volume")
            cmd.append("list")
            ret = execute(cmd, tmp_img)
            digi_debug("Service list, %s return %d" % (' '.join(cmd),ret),5)
            result_str = ''
            if not ret:
                result_str = tmp_img.read()
            service_list = result_str.split("\n")
            if 'ctdb' in service_list:
                service_list.remove('ctdb')
            for aservice in service_list:
                if aservice:
                    output_img.write(self.service_list_single(aservice).read())
            output_img.seek(0)
        except Exception, e:
            digi_debug("Service list, caught exception: %s" % e,3)
            print e
        return output_img

    def service_list_single(self, service_name):
        output_img = StringIO.StringIO()
        try:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append("volume")
            cmd.append("info")
            cmd.append(service_name)
            ret = execute(cmd, tmp_img)
            digi_debug("Service list single, %s return %d" % (' '.join(cmd),ret),5)
            result_str = tmp_img.read()
            
            service_type = get_service_type_info(service_name,result_str)
            type_num_str = ""
            if service_type['replica']:
                type_num_str = type_num_str + "Replica Number: %s\n" % str(service_type['replica'])
            if service_type['stripe']:
                type_num_str = type_num_str + "Stripe Number: %s\n" % str(service_type['stripe'])
            try:
                type_str = re.search("\s+Type: (\S+)\s+", result_str).groups()[0]
            except Exception, e:
                type_str = ''
            if type_str:
                result_str = result_str.replace("%s\n" % type_str,"%s\n%s" %(type_str,type_num_str))

            if self.service_list_size(service_name, service_type):
                free_size = self.service_list_size(service_name, service_type)['free_size']
                total_size = self.service_list_size(service_name, service_type)['total_size']
            else:
                free_size = 'N/A'
                total_size = 'N/A'
            if result_str.find("Bricks:\n") >= 0:
                result_str = result_str.replace("Bricks:\n","Free Size: %s\nTotal Size: %s\nBricks:\n" % (str(free_size),str(total_size)))
            if result_str.find("Status: Started") >= 0:
                ret = self.get_service_brick_status(service_name,result_str)
                if ret:
                    brickstatus = "OK"
                else:
                    brickstatus = "Brick Lost"
            else:
                brickstatus = "NaN"
            if result_str.find("Bricks:\n") >= 0:
                result_str = result_str.replace("Bricks:\n","Brick Status: %s\nBricks:\n" % brickstatus)
              

            output_img.write(result_str)
            output_img.seek(0)
        except Exception, e:
            print traceback.print_exc(e)
            digi_debug("Service list single, caught exception: %s" % e,3)
        return output_img

    def get_service_brick_status(self,service_name,result_str):
      	all_bricks = []
        online_bricks = []

        #brick_pattern = "Brick\s+:\s+Brick\s+(.*)\nPort\s+:\s+\d+\s+\nOnline\s+:\s+Y"
        #rdma_pattern = "Brick\s+:\s+Brick\s+(.*)\nTCP\s+Port\s+:\s+\d+\s+\nRDMA\s+Port\s+:\s+\d+\s+\nOnline\s+:\s+Y"
	
        all_bricks = re.findall("Brick\d+:\s+(.*)\n",result_str)
        
        tmp_img = self.service_list_disk(service_name)
        if tmp_img:
            #brick_result = tmp_img.read()
            #online_bricks = re.findall(brick_pattern,brick_result)
            brick_lines = tmp_img.readlines()
            bricks = get_service_all_bricks_info(brick_lines)
            online_bricks = [brick['Brick'] for brick in bricks if brick['Online'] == 'Y']

        if len(online_bricks) != len(all_bricks):
            return False 

        return True

    def service_list_size(self, service_name, service_type):
        """
        Return service size in format of: { 'service_name': 'test', 'free_size': '300000', 'total_size':'500000'}
        """
        try:
            if not os.path.ismount('/cluster2/%s' % service_name):
                return {'service_name':service_name, 'free_size': 'N/A', 'total_size': 'N/A'}
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append('df')
            cmd.append('/cluster2/%s' % service_name)
            ret = execute(cmd, tmp_img)
            result_str = tmp_img.readlines()
            if not ret:
                content = result_str[1].split()
                total_size = content[1]
                free_size = content[3]

                return {'service_name':service_name, 'free_size': free_size, 'total_size': total_size}
            else:
                return {'service_name':service_name, 'free_size': 'N/A', 'total_size': 'N/A'}
        except Exception, e:
            digi_debug("Service list size, caught exception: %s" % e,3)
            traceback.print_exc(e)
            return None 
        
    def service_fix_layout(self, service_name):
        tmp_img = tempfile.TemporaryFile()
        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append('volume')
        cmd.append('rebalance')
        cmd.append(service_name)
        cmd.append('fix-layout')
        cmd.append('start')
        ret = execute(cmd, tmp_img)
        if not ret:
            return '0'
        else:
            digi_debug("Service fix-layout failed", 3)
            #EXIT(-1, tmp_img.read())
            
    def service_quota_setup(self, service_name, option):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Service quota setup, service not exists",3)
            EXIT(13107)
        quota_options = {}
        try:
            if len(option) >= 1:
                quota_options['option'] = option[0]
                quota_options['path'] = ''
                quota_options['value'] = ''
            if len(option) >= 2:    
                quota_options['path'] = option[1]
                quota_options['value'] = ''
            if len(option) >= 3:
                quota_options['value'] = option[2]
        except Exception, e:
            digi_debug("Service quota setup, parse quota option arise error %s" % e)
            EXIT(-1, 'Service quota setup, parse quota option arise error')
            
        if quota_options['option'] == 'enable':
            result = self.service_quota_enable(service_name)
        elif quota_options['option'] == 'disable':
            result = self.service_quota_disable(service_name)
        elif quota_options['option'] == 'remove':
            if quota_options['path']:
                result = self.service_quota_remove(service_name,quota_options['path'])
            else:
                EXIT(-1, "Service quota %s, %s not found" % (quota_options['option']), quota_options['path'])
        elif quota_options['option'] == 'limit-usage':
            if 'path' in quota_options and 'value' in quota_options:
                if quota_options['path'] and quota_options['value']:
                    result = self.service_quota_limit(service_name, quota_options['path'],quota_options['value'])
                else:
                    EXIT(-1, "Service quota %s, %s or %s not found" % (quota_options['option'], quota_options['path'], quota_options['value']))
            else:
                EXIT(-1, "Service quota %s, not enough argument" % quota_options['option'])
        elif quota_options['option'] == 'list':
            result = self.service_quota_list(service_name, quota_options['path'])
        else:
            digi_debug("Service quota setup, option %s not found" % quota_options['option'], 3)
            EXIT(-1, "Service quota setup, option %s not found" % quota_options['option'])
        output_img = StringIO.StringIO()
        output_img.write(result)
        output_img.seek(0)
        return output_img
            
    def service_quota_enable(self, service_name):
        cmd = [settings.COMMANDS['digiocean'],'vol','quota', service_name, 'enable']
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, tmp_img)
        result = tmp_img.read()
        if ret:
            EXIT(ret, result)
        else:
            return result

    def service_quota_disable(self, service_name):
        cmd = [settings.COMMANDS['digiocean'],'vol','quota', service_name, 'disable']
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, std=tmp_img,stdi=subprocess.PIPE, communicate='y\n')
        result = tmp_img.read()
        if ret:
            EXIT(ret, result)
        else:
            return result
        
    def service_quota_remove(self, service_name, path):
        cmd = [settings.COMMANDS['digiocean'],'vol','quota', service_name, 'remove', path]
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, tmp_img)
        result = tmp_img.read()
        if ret:
            EXIT(ret, result)
        else:
            return result
        
    def service_quota_limit(self, service_name, path, value):
        cmd = [settings.COMMANDS['digiocean'],'vol','quota', service_name, 'limit-usage', path, value]
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, tmp_img)
        result = tmp_img.read()
        if ret:
            EXIT(ret, result)
        else:
            return result

    def service_quota_list(self, service_name, path):
        if path:
            cmd = [settings.COMMANDS['digiocean'],'vol','quota', service_name, 'list', path]
        else:
            cmd = [settings.COMMANDS['digiocean'],'vol','quota', service_name, 'list']
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd, tmp_img)
        result = tmp_img.read()
        if ret:
            EXIT(ret, result)
        else:
            return result

    def service_auth_setup(self, service_name, option):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            digi_debug("Service auth setup, service not exists",3)
            EXIT(13550)
        auth_options = {'option':'','path':'','value':''}
        try:
            if len(option) >= 1:
                auth_options['option'] = option[0]
            if len(option) >= 2:
                auth_options['path'] = option[1]
            if len(option) >= 3:
                auth_options['value'] = option[2:]
        except Exception, e:
            digi_debug("Service auth setup, parse auth option arise error %s" % e)
            EXIT(13551)

        if auth_options['option'] == 'list':
            if auth_options['path']:
                output_img = self.service_auth_list(service_name, auth_options['path'])
            else:
                output_img = self.service_auth_list(service_name)
        elif auth_options['option'] == 'edit':
            if auth_options['path']:
                output_img = self.service_auth_edit(service_name, auth_options['path'],auth_options['value'])
            else:
                EXIT(-1, "Service auth %s, path not found" % (auth_options['option']))
        else:
            digi_debug("Service auth setup, option %s not found" % auth_options['option'], 3)
            EXIT(-1, "Service auth setup, option %s not found" % auth_options['option'])
        return output_img

    def service_auth_list(self, service_name, path=''):
        output_img = StringIO.StringIO()
        smb_user_list = get_smb_user_info(service_name)        # Get all samba user

        if path:
            realpath = '/cluster2/' + service_name + '/' + path
        else:
            realpath = '/cluster2/' + service_name
        if os.path.exists(realpath):
            pathlist = os.listdir(realpath)
        else:
            EXIT(-1, "Service auth list, path : %s not exists" % (realpath))
        for path in pathlist:
            if path.startswith('.'):
                continue
            else:
                abspath = realpath + '/' + path
                if not os.path.exists(abspath):
                    EXIT(-1, "Service auth list, path : %s not exists" % (abspath))
                output_img.write(abspath + '\t')
                writeuser = []
                readuser = []
                nouser = []
                tmp_img = tempfile.TemporaryFile()
                cmd = [settings.COMMANDS['getfacl'], '-p', abspath]
                ret = execute(cmd,tmp_img)
                result = tmp_img.readlines()
                for data in result:
                    datalist = data.strip().split(':')
                    if datalist[0].find('owner') >= 0:
                        owner = datalist[1].strip()
                    if datalist[0] == 'user' and datalist[1] != '':
                        if datalist[2] == 'rwx':
                            writeuser.append(datalist[1])                  #set write user
                        elif datalist[2] == 'r-x':
                            readuser.append(datalist[1])                   #set read user
                for user in smb_user_list:
                    if user not in writeuser and user not in readuser and user != owner:
                        nouser.append(user)                                #set nouser
                writeuser = ','.join(writeuser)
                readuser = ','.join(readuser)
                nouser = ','.join(nouser)
                output_img.write('owner:%s\twriteuser:%s\treaduser:%s\tnouser:%s\n' % (owner,writeuser or '-',readuser or '-',nouser or '-'))
        output_img.seek(0)
        return output_img

    def service_auth_edit(self, service_name, path, value):
        readuser = []
        writeuser = []
        output_img = StringIO.StringIO()

        abspath = '/cluster2/' + service_name + '/' + path
        if not os.path.exists(abspath):
            EXIT(-1, "Service auth set, path : %s not exists" % (abspath))

        #value = ['rwx:aaa,bbb,ccc', 'r-x:ddd']
        for val in value:
            if val.find('rwx') >= 0:
                writeuser = val.split(':')[1].split(',')
            elif val.find('r-x') >= 0:
                readuser = val.split(':')[1].split(',')

        wu = ru = ''
        for wuser in writeuser:
            u = 'u:' + wuser.encode('utf-8') + ':rwx'
            wu = wu + u + ','
        for ruser in readuser:
            u = 'u:' + ruser.encode('utf-8') + ':r-x'
            ru = ru + u + ','
        data = wu + ru

        if data:
            cmd = [settings.COMMANDS['setfacl'], '-b', abspath]
            ret = execute(cmd)
            cmd = [settings.COMMANDS['setfacl'], '-m', data, abspath]
            ret = execute(cmd)
            cmd = [settings.COMMANDS['setfacl'], '-dm', data, abspath]
            ret = execute(cmd)
        else:
            cmd = [settings.COMMANDS['setfacl'], '-b', abspath]
            ret = execute(cmd)

        output_img.seek(0)
        return output_img

    def service_start(self, service_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13107" #return errno 87, the service to start not exist
            digi_debug("Service start, service not exists",3)
            EXIT(13107)

        status = list_service_status(service_name)
        if status == 'Started':
            digi_debug("Service start, service already started",3)
            #print "13441"
            EXIT(13441)

        node_list = self.get_service_nodes(service_name)
        node_disk_dict = self.get_service_disks(service_name)

	thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(node_list))
            node_thread_pool.initPool(data=node_list, target_info=('service_start_pre', [service_name, node_disk_dict], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            digi_debug("Service start, Node manager multi threading tought exception: %s" % e,3)
            print e
        else:
            pass
        finally:
            pass
    
        for result in thread_result:
            node = result[0]
            ret = result[1]
            if ret == 2:
                digi_debug("Service start, some disks of service not found",3)
                EXIT(13457)
            elif ret == 3:
                digi_debug("Service start, some disks of service not mount",3)
                EXIT(13458)
            elif ret == 4:
                digi_debug("Service start, some disks of service mount point not exist",3)
                EXIT(13459)
            elif ret != 1:
                digi_debug("Service start, unknow error occur",3)
                EXIT(13446)

        try:
            tmp_img = tempfile.TemporaryFile()
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('start')
            cmd.append(service_name)
            ret = execute(cmd, tmp_img)
            digi_debug("Service start, %s return %d" % (' '.join(cmd),ret),5)    
            result = tmp_img.read()

            if result.find('failed') >= 0 and result.find('already started') >= 0:
                digi_debug("Service start, service already started",3)
                #print "13441"
                EXIT(13441)
            elif result.find('failed') >= 0 and result.find('digioceanfs.volume-id') >= 0 and result.find('No data available') >= 0:
                digi_debug("Service start, digioceanfs.volume-id not found",3)
                #print "13442"
                EXIT(13442)
            elif result.find('failed') >= 0 and result.find('Volume id mismatch for brick') >= 0:
                digi_debug("Service start, volume id mismatch for brick",3)
                #print "13443"
                EXIT(13443)
            elif result.find('failed') >= 0 and result.find('Another transaction could be in progress') >= 0:
                digi_debug("Service start, another transaction could be in progress",3)
                #print "13444"
                EXIT(13444)
            elif result.find('failed') >= 0 and result.find('Failed to find brick directory') >= 0:
                digi_debug("Service start, failed to find brick directory",3)
                #print "13445"
                EXIT(13445)
            elif result.find('failed') >= 0:
                digi_debug("Service start, %s" % result,3)
                #print "13446"
                EXIT(13446)
        except Exception,e:
            digi_debug("Service start, caught exception: %s" % e,3)
            print e

	thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(self.node_list))
            node_thread_pool.initPool(data=self.node_list, target_info=('service_start_post', [service_name, node_disk_dict], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            digi_debug("Service start, Node manager multi threading tought exception: %s" % e,3)
            print e
        else:
            pass
        finally:
            pass

        for result in thread_result:
            anode = result[0]
            ret = result[1]
            if anode in node_list and ret != 1:
                digi_debug("Service start, unknow error occur",3)
                EXIT(13446)
            anode.update_disk()

        tmp_img = tempfile.TemporaryFile()
        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append('volume')
        cmd.append('info')
        cmd.append(service_name)
        ret = execute(cmd, tmp_img)
        result = tmp_img.read()
        type_str = re.search("\s+Type: (\S+)\s+", result).groups()[0]
        isSingleDisk = len(node_disk_dict.values()) == 1 and len(node_disk_dict.values()[0]) == 1
        if type_str.strip().find("Distribute") >= 0 and not isSingleDisk:
            self.service_fix_layout(service_name)
        if type_str.strip().find("Disperse") >= 0:
            self.service_heal_disperse(service_name, 'trusted.ec.heal')  
        
        return 0

    def service_stop(self, service_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13108" #return errno 88, the service to stop not exist
            digi_debug("Service stop, service not exists",3)
            EXIT(13108)
       
        status = list_service_status(service_name)
        if status != 'Started':
            digi_debug("Service stop, volume is not in the started state",3)
            #print "13447"
            EXIT(13447)

        node_list = self.get_service_nodes(service_name)
        node_disk_dict = self.get_service_disks(service_name)

	thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(self.node_list))
            node_thread_pool.initPool(data=self.node_list, target_info=('service_stop_pre', [service_name, node_disk_dict], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            digi_debug("Service stop, Node manager multi threading tought exception: %s" % e,3)
            print e
        else:
            pass
        finally:
            pass

        try:
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('stop')
            cmd.append(service_name)
            cmd.append('force')
            tmp_img = tempfile.TemporaryFile()
            ret = execute(cmd, std=tmp_img, stdi=subprocess.PIPE, communicate='y\n')
            digi_debug("Service stop, %s return %d" % (' '.join(cmd),ret),5)	    
            tmp_img.seek(0)
            result = tmp_img.read()
            if result.find('failed') >= 0 and result.find('is not in the started state') >= 0:
                digi_debug("Service stop, service already stoped",3)
                #print "13447"
                EXIT(13447)
            elif result.find('failed') >= 0:
                digi_debug("Service stop, %s" % result,3)
                #print "13448"
                EXIT(13448)
        except Exception,e:
            digi_debug("Service stop, caught exception: %s" % e,3)
            print e

	thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(node_list))
            node_thread_pool.initPool(data=node_list, target_info=('service_stop_post', [service_name, node_disk_dict], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            digi_debug("Service stop, Node manager multi threading tought exception: %s" % e,3)
            print e
        else:
            pass
        finally:
            pass

        for result in thread_result:
            anode = result[0]
            ret = result[1]
            if ret != 1:
                digi_debug("Service stop, unknow error occur",3)
                EXIT(13448)
            anode.update_disk()

        return 0

    def service_destroy(self, service_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13109" #return errno 89, the service to destroy not exist
            digi_debug("Service destroy, service not exists",3)
            EXIT(13109)

        node_list = self.get_service_nodes(service_name)
        node_disk_dict = self.get_service_disks(service_name)

        status = list_service_status(service_name)
        if status == 'Started':
            thread_result = []
            try:
                node_thread_pool = ClusterThreadPool(len(self.node_list))
                node_thread_pool.initPool(data=self.node_list, target_info=('service_stop_pre', [service_name, node_disk_dict], dict()))
                node_thread_pool.start_threads()
                node_thread_pool.clear_threads()
                thread_result = node_thread_pool.get_results()
            except Exception, e:
                digi_debug("Service stop, Node manager multi threading tought exception: %s" % e,3)
                print e
            else:
                pass
            finally:
                pass

            try:
                cmd = []
                cmd.append(settings.COMMANDS['digiocean'])
                cmd.append('volume')
                cmd.append('stop')
                cmd.append(service_name)
                tmp_img = tempfile.TemporaryFile()
                ret = execute(cmd, std=tmp_img, stdi=subprocess.PIPE, communicate='y\n')
                digi_debug("Service destroy, %s return %d" % (' '.join(cmd),ret),5)

                if ret == 1:
                    digi_debug("Service destroy, volume stop failed",3)
                    EXIT(13448)
                tmp_img.seek(0)
                result = tmp_img.read()
            except Exception,e:
                digi_debug("Service destroy, caught exception: %s" % e,3)
                print e

        try:
            cmd = []
            cmd.append(settings.COMMANDS['digiocean'])
            cmd.append('volume')
            cmd.append('delete')
            cmd.append(service_name)
            tmp_img = tempfile.TemporaryFile()
            ret = execute(cmd, std=tmp_img, stdi=subprocess.PIPE, communicate='y\n')
            digi_debug("Service destroy, %s return %d" % (' '.join(cmd),ret),5)
            tmp_img.seek(0)
            result = tmp_img.read()
            if result.find('failed') >= 0 and result.find('Another transaction could be in progress') >= 0:
                digi_debug("Service destroy, another transaction could be in progress",3)
                #print "13449"
                EXIT(13449)
            elif result.find('failed') >= 0:
                digi_debug("Service destroy, %s" % result,3)
                #print "13450"
                EXIT(13450)
        except Exception,e:
            digi_debug("Service destroy, caught exception: %s" % e,3)
            print e

        thread_result = []
        try:    
            #self.node_list : connect to all node and delete service samba conf file
            service_thread_pool = ClusterThreadPool(len(self.node_list))
            service_thread_pool.initPool(data=self.node_list, target_info=('service_destroy_post', [service_name, node_disk_dict], dict()))
            service_thread_pool.start_threads()
            service_thread_pool.clear_threads()
            thread_result = service_thread_pool.get_results()
        except Exception, e:
            digi_debug("Service destroy, Node manager multi threading tought exception: %s" % e,3)
        else:
            pass
        finally:
            pass

        for result in thread_result:
            anode = result[0]
            #ret = result[1]
            #if ret != 1:
            #    digi_debug("Service destroy, unknow error occur",3)
            #    EXIT(13450)
            anode.update_disk()

        return 0 

    def service_restart(self, service_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13217"
            EXIT(13217)
        ret = aservice.restart()
        if ret > 2:
            #print "13221"
            EXIT(13221)
        return True

    def service_status(self, service_name):
        output_img = StringIO.StringIO()
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13110" #return errno 90, the service to destroy not exist
            EXIT(13110)
        aservice.status(output_img)
        output_img.seek(0)
        return output_img

    def service_add_disk(self, service_name, disk_lines):
        disks = list()
        #aservice = self.get_service_by_name(service_name)
        #if not aservice:
        #    #print "13111" #return errno 91, the service to add disk not exist
        #    EXIT(13111)

        #for disk_line in disk_lines:
        #    if len(disk_line.split(':')) < 2:
        #        #print "13212"
        #        EXIT(13212)
        #    node_name = disk_line.split(':')[0]
        #    disk_name = disk_line.split(':')[1]
        #    anode = self.get_node_by_name(node_name)
        #    if not anode:
        #        #print "13213"
        #        EXIT(13213)
        #    adisk = anode.get_disk_by_dev(disk_name)
        #    if not adisk:
        #        #print "13214"
        #        EXIT(13214)
        #    if adisk.get_user():
        #        #print "13215"
        #        EXIT(13215)
        #    if not add_in_list(disks, adisk):
        #        #print "13215"
        #        EXIT(13215)

        #ret = aservice.add_disk(disks)
        #if not ret:
        #    #print "13220"
        #    EXIT(13220)
        #elif ret[6]:
        #    #print "13225"
        #    EXIT(13225)
        #return ret
        
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13111" #return errno 91, the service to add disk not exist
            digi_debug("Service add disk, service not exists",3)
            EXIT(13111)

        node_list = []
        node_disk_dict = {} # {'node-1':['sdb','sdc']}

        for disk_line in disk_lines:
            if len(disk_line.split(':')) < 2:
                digi_debug("Service add disk, illegal disks format",3)
                #print "13212"
                EXIT(13212)
            node_name = disk_line.split(':')[0]
            disk_name = disk_line.split(':')[1]
            anode = self.get_node_by_name(node_name)
            if anode not in node_list:
                node_list.append(anode)
            anode.update_disk('Y')
            if not anode:
                digi_debug("Service add disk, node %s not exists" % node_name,3)
                #print "13213"
                EXIT(13213)
            adisk = anode.get_disk_by_dev(disk_name)
            if not adisk:
                digi_debug("Service add disk, disks %s not exist" % disk_name,3)
                #print "13214"
                EXIT(13214)
            if not node_disk_dict:
                node_disk_dict = {anode.get_name():[adisk.dev_id]}
            else:
                if anode.get_name() in node_disk_dict:
                    node_disk_dict[anode.get_name()].append(adisk.dev_id)
                else:
                    node_disk_dict[anode.get_name()] = [adisk.dev_id]
            if adisk.get_user():
                digi_debug("Service add disk, disks %s already in use" % disk_name,3)
                #print "13215"
                EXIT(13215)
            if not add_in_list(disks, adisk):
                digi_debug("Service add disk, disks %s already in use" % disk_name,3)
                #print "13215"
                EXIT(13215)
       
        ####################################
        # manual or auto pair
        #################################### 
        afr_num = list_service_afr_num(service_name)
        if not self.options.manual_afr and afr_num > 0:
            disks = afr_disk_auto_pair(disks,afr_num)

        redu_num =  list_service_redu_num(service_name)
        if redu_num > 0:
            disks = afr_disk_auto_pair(disks,redu_num)

        ####################################
        # Check params
        #################################### 
        if self.options.stripe_num != 0:
            if len(disks)%self.options.stripe_num != 0:
                digi_debug("Service add disk, number of disk does not match raid level require",3)
                #print "13220"
                EXIT(13220)

        if self.options.afr_num != 0:
            if len(disks)%self.options.afr_num != 0:
                digi_debug("Service add disk, number of disk does not match raid level require",3)
                #print "13220"
                EXIT(13220)

        ####################################
        # Check disk path is exist
        #################################### 
        #for adisk in disks:
        #    if not os.path.exists(os.path.join("/digioceanfs", adisk.dev_id)):
        #        os.mkdir(os.path.join("/digioceanfs", adisk.dev_id))    

        ####################################
        # Check disk is mounted
        ####################################
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(node_list))
            node_thread_pool.initPool(data=node_list, target_info=('service_create_pre', [node_disk_dict], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            digi_debug("Service add disk, Node manager multi threading tought exception: %s" % e,3)
            print e
        else:
            pass
        finally:
            pass
        for result in thread_result:
            anode = result[0]
            ret = result[1]
            if ret == 3:
                digi_debug("Service add disk, some disks mount failed, please check disks mount point",3)
                #print "13451"
                EXIT(13451)
            elif ret == 2:
                digi_debug("Service add disk, some disks mount point occur to be problems",3)
                #print "13452"
                EXIT(13452)
            elif ret != 1:
                digi_debug("Service add disk, unknow error occur",3)
                #print "13225"
                EXIT(13225)
            anode.update_disk()

        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append('volume')
        cmd.append('add-brick')
        cmd.append(service_name)
        try:
            if self.options.stripe_num:
                cmd.append('stripe')
                cmd.append(str(self.options.stripe_num))
            if self.options.afr_num:
                cmd.append('replica')
                cmd.append(str(self.options.afr_num))
            for adisk in disks:
                cmd.append('%s:%s'%(adisk.node, os.path.join("/digioceanfs", adisk.dev_id)))
            cmd.append('force')
            tmp_img = tempfile.TemporaryFile()
            stdinput = subprocess.PIPE
            ret = execute(cmd, std=tmp_img, stdi=stdinput, communicate='y\n')
            digi_debug("Service add disk, %s return %d" % (' '.join(cmd),ret),5)	    
            tmp_img.seek(0)
            result = tmp_img.read()
            if ret:
                digi_debug("Service add disk, %s" % result,3)
                #print "13225"
                EXIT(13225,result)
        except Exception,e:
            digi_debug("Service add disk, caught exception: %s" % e,3)
            print e
        #######################################
        # update status of disks on each node 
        ####################################### 
        thread_result = []
        try:
            node_thread_pool = ClusterThreadPool(len(node_list))
            node_thread_pool.initPool(data=node_list, target_info=('service_add_disk_post', [service_name, node_disk_dict], dict()))
            node_thread_pool.start_threads()
            node_thread_pool.clear_threads()
            thread_result = node_thread_pool.get_results()
        except Exception, e:
            digi_debug("Service add disk, Node manager multi threading tought exception: %s" % e,3)
            print e
        else:
            pass
        finally:
            pass

        for result in thread_result:
            anode = result[0]
            ret = result[1]
            if ret != 1:
                digi_debug("Service add disk, unknow error occur",3)
                EXIT(13225)
            anode.update_disk()

        service_status = list_service_status(service_name)
        if service_status == 'Started':
            self.service_fix_layout(service_name)

        return 0

    def service_export_cifs_all(self, service_name, cmd):
        aservice = self.get_service_by_name(service_name)
        #aservice = service(self, aservice_str)
        node_names = self.node_list
        if not aservice:
            #print "13222"
            EXIT(13222)

        output_img = StringIO.StringIO()
        if cmd == "start":
            ret = aservice.export_cifs_start(node_names)
            output_img.write("success:%d not_found:%d failed:%d"%(ret[0], ret[1], ret[2]))
        elif cmd == "stop":
            ret = aservice.export_cifs_stop(node_names)
            if ret[2]:
                #print "13237"
                EXIT(13237)
            output_img.write("success:%d failed:%d in_use:%d not_found:%d not_connect:%d"%
                       (ret[0], ret[1], ret[2], (ret[3]+ret[4]), ret[5]))
        elif cmd == "status":
            try:
                ret = aservice.export_cifs_status(output_img, node_names)
            except Exception,e:
                traceback.print_exc()
        else:
            service_export_cifs_usage()
            EXIT(0)
        output_img.seek(0)
        return output_img
    def service_export_cifs_restart_node(self,service_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13222"
            EXIT(13222)
        ret = aservice.export_cifs_restart_node()
        return ret
    
    def service_export_cifs_restart_service(self,service_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13222"
            EXIT(13222)
        ret = aservice.export_cifs_restart_service()
        return ret
    
    def service_export_cifs(self, service_name, cmd, node_names):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13222"
            EXIT(13222)

        output_img = StringIO.StringIO()
        if cmd == "start":
            ret = aservice.export_cifs_start(node_names)
            output_img.write("success:%d not_found:%d failed:%d"%(ret[0], ret[1], ret[2]))
        elif cmd == "stop":
            ret = aservice.export_cifs_stop(node_names)
            output_img.write("success:%d failed:%d in_use:%d not_found:%d not_connect:%d"%
                       (ret[0], ret[1], ret[2], (ret[3]+ret[4]), ret[5]))
        elif cmd == "status":
            try:
                ret = aservice.export_cifs_status(output_img, node_names)
            except Exception,e:
                traceback.print_exc()
        else:
            service_export_cifs_usage()
            EXIT()
        output_img.seek(0)
        return output_img
    
    def service_export_cifs_list_user(self, service_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13222"
            EXIT(13222)
        output_img = StringIO.StringIO()
        ret = aservice.export_cifs_list_user(output_img)
        return ret

    def service_export_cifs_list_links(self, service_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13222"
            EXIT(13222)
        output_img = StringIO.StringIO()
        ret = aservice.export_cifs_list_links(output_img)
        return ret

    def service_export_cifs_del_links(self, service_name, node_name, pid):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13222"
            EXIT(13222)
        output_img = StringIO.StringIO()
        ret = aservice.export_cifs_del_links(node_name, pid)
        return ret
    
    def service_export_cifs_add_user(self, service_name, user_name, passwd):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13222"
            EXIT(13222)
        
        output_img = StringIO.StringIO()
        if not user_name:
            #print "13230"
            EXIT(13230)
        
        if not passwd:
            #print "13231"
            EXIT(13231)

        # check samba status
        cifs_status = ''
        ret = aservice.export_cifs_status()
        if ret [2] + ret[3] + ret[4] + ret[5] == 0:
            cifs_status = "start"
        if cifs_status != 'start':
            EXIT(13241)

        ret = aservice.export_cifs_add_user(user_name, passwd)
        if not ret:
            #print "13232"
            EXIT(13232)
        return ret
        
    def service_export_cifs_del_user(self, service_name, user_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13222"
            EXIT(13222)
        
        output_img = StringIO.StringIO()
        if not user_name:
            #print "13230"
            EXIT(13230)

        # check samba status
        cifs_status = ''
        ret = aservice.export_cifs_status()
        if ret [2] + ret[3] + ret[4] + ret[5] == 0:
            cifs_status = "start"
        if cifs_status != 'start':
            EXIT(13241)
        
        ret = aservice.export_cifs_del_user(user_name)
        if not ret:
            #print "13233"
            EXIT(13233)
        return ret
        
    def service_export_nfs_all(self, service_name, cmd):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13226"
            EXIT(13226)

        output_img = StringIO.StringIO()
        if cmd == "start":
            ret = aservice.export_nfs_start()
            output_img.write(str(ret))
        elif cmd == "stop":
            ret = aservice.export_nfs_stop()
            output_img.write(str(ret))
        elif cmd == "status":
            ret = aservice.export_nfs_status(output_img)
        else:
            service_export_nfs_usage()
            EXIT()
        output_img.seek(0)
        return output_img

    def service_export_nfs(self, service_name, cmd, node_names):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13226"
            EXIT(13226)

        output_img = StringIO.StringIO()
        if cmd == "start":
            ret = aservice.export_nfs_start(node_names)
            output_img.write("success:%d not_found:%d failed:%d"%(ret[0], ret[1], ret[2]))
        elif cmd == "stop":
            ret = aservice.export_nfs_stop(node_names)
            output_img.write("success:%d failed:%d in_use:%d not_found:%d not_connect:%d"%
                       (ret[0], ret[1], ret[2], (ret[3]+ret[4]), ret[5]))
        elif cmd == "status":
            ret = aservice.export_nfs_status(output_img, node_names)
        else:
            service_export_nfs_usage()
            EXIT()
        output_img.seek(0)
        return output_img
    
    def service_export_nfs_list_user(self, service_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13226"
            EXIT(13222)
        output_img = StringIO.StringIO()
        ret = aservice.export_nfs_list_user(output_img)
        return ret
    
    def service_export_nfs_list_links(self, service_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13222"
            EXIT(13222)
        output_img = StringIO.StringIO()
        ret = aservice.export_nfs_list_links(output_img)
        return ret    
    
    def service_export_nfs_del_links(self, service_name, node_name, tar_ip=''):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13222"
            EXIT(13222)
        output_img = StringIO.StringIO()
        ret = aservice.export_nfs_del_links(node_name, tar_ip)
        return ret
    
    def service_export_nfs_add_user(self, service_name, user_ip):
        #if not checkIP(user_ip):
        #    #print "13234"
        #    EXIT(13234)
            
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13226"
            EXIT(13226)
        
        output_img = StringIO.StringIO()
        if not user_ip:
            #print "13234"
            EXIT(13234)
            
        ret = aservice.export_nfs_add_user(user_ip)
        if not ret:
            #print "13235"
            EXIT(13235)
        return ret
        
    def service_export_nfs_del_user(self, service_name, user_ip):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13226"
            EXIT(13226)
        
        output_img = StringIO.StringIO()
        if not user_ip:
            #print "13234"
            EXIT(13234)
        
        ret = aservice.export_nfs_del_user(user_ip)
        if not ret:
            #print "13236"
            EXIT(13236)
        return ret

    def service_afr_info(self, service_name, opendir=''):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13227"
            EXIT(13227)
        output_img = StringIO.StringIO()
        tmp_img = tempfile.TemporaryFile()
        cmd = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append("volume")
        cmd.append("info")
        cmd.append(service_name)
        ret = execute(cmd, tmp_img)
        digi_debug("Service list single, %s return %d" % (' '.join(cmd),ret),5)
        result_str = tmp_img.read()

        service_type = get_service_type_info(service_name,result_str)
        if list_service_status(service_name) != "Started" or service_type['replica'] == 0:
            output_img.write("0")
            output_img.seek(0)
            return output_img
        ret = aservice.afr_info(output_img, opendir)
        if ret == 2:
            #print "13228"
            EXIT(13228)
        output_img.seek(0)
        return output_img

    def service_afr_info_topage(self, service_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13227"
            EXIT(13227)
        output_img = StringIO.StringIO()
        ret = aservice.afr_info_topage(output_img)
        if ret == 2:
            #print "13228"
            EXIT(13228)
        output_img.seek(0)
        return output_img

    def service_afr_info_topage_search(self, service_name, opendir):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13227"
            EXIT(13227)
        output_img = StringIO.StringIO()
        ret = aservice.afr_info_topage_search(output_img, opendir)
        if ret == 2:
            #print "13228"
            EXIT(13228)
        output_img.seek(0)
        return output_img

    def service_afr_expand(self, service_name, disk_lines):
        dup_checker = []
        disk_pod = {}
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13330"
            EXIT(13330)
        for disk_line in disk_lines:
            disk_info = disk_line.split(':')
            if len(disk_info) != 3:
                #print "13331"
                EXIT(13331)
            mirror_name = disk_info[0]
            node_name = disk_info[1]
            disk_name = disk_info[2]
            anode = self.get_node_by_name(node_name)
            if not anode:
                #print "13332"
                EXIT(13332)
            adisk = anode.get_disk_by_dev(disk_name)
            if not adisk:
                #print "13333"
                EXIT(13333)
            if adisk.get_user():
                #print "13334"
                EXIT(13334)
            if not add_in_list(dup_checker, adisk):
                #print "13334"
                EXIT(13334)
            if not disk_pod.__contains__(mirror_name):
                disk_pod[mirror_name] = []
            add_in_list(disk_pod[mirror_name], adisk)

        ret = aservice.afr_expand(disk_pod)
        if ret != 1:
            #print "13335"
            EXIT(13335)

    def service_afr_shrink(self, service_name, disk_lines):
        disk_pod = {}
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13436"
            EXIT(13436)
        for disk_line in disk_lines:
            disk_info = disk_line.split(':')
            if len(disk_info) != 3:
                #print "13437"
                EXIT(13437)
            mirror_name = disk_info[0]
            node_name = disk_info[1]
            disk_name = disk_info[2]
            anode = self.get_node_by_name(node_name)
            if not anode:
                #print "13438"
                EXIT(13438)
            adisk = anode.get_disk_by_dev(disk_name)
            if not adisk:
                #print "13439"
                EXIT(13439)
            if adisk.get_user() != service_name:
                #print "13440"
                EXIT(13440)
            if not disk_pod.__contains__(mirror_name):
                disk_pod[mirror_name] = []
            add_in_list(disk_pod[mirror_name], adisk)

        ret = aservice.afr_shrink(disk_pod)
        if ret != 1:
            #print "181"
            EXIT(181)

    def service_afr_syn(self, service_name):
        aservice = self.get_service_by_name(service_name)
        if not aservice:
            #print "13227"
            EXIT(13227)

        aservice.afr_syn()


#########################################################
#other methods
#########################################################
    def disconnect_all_node(self):
        for anode in self.node_list:
            anode.disconnect()
#        for th in threads_pool:
#            th.join()

    def get_all_node(self):
        return self.node_list

    def get_group_by_name (self, group_name):
        return find_in_list(self.group_list, group_name)

    def get_node_by_name (self, node_name):
        return find_in_list(self.node_list, node_name)

    def node_ip_duplicate(self, node_ip):
        for anode in self.node_list:
            if anode.get_ip_addr() == node_ip:
                return True
        return False

    def issue_hosts(self):
        ret = True
        hosts_img = get_hosts_img()
        for anode in self.node_list:
            if not anode.set_hosts(hosts_img):
                ret = False
        if not ret:
            self.reset_config_file()
        return ret     

    def issue_service_client_hosts(self):
        clients = []
        peer = self.peer_list()
        allclients = self.get_allclient_addr()
        for client_ip in allclients:
            if client_ip not in peer:
                clients.append(client_ip)
        for ipaddr in clients:
            aclient = client(options={}, ipaddr=ipaddr)
            hosts_img = get_hosts_img()
            data = simplejson.dumps(hosts_img, encoding='ascii', ensure_ascii=True)
            ret = aclient.node_event({},ipaddr,"client_add",data)
            if ret != 1:
                return False
        return True

    def issue_ipmi_conf(self):
        if os.path.exists(settings.IPMICONF):
            f = open(settings.IPMICONF,'r')
            ipmilist = pickle.load(f)
            f.close()
        else:
            ipmilist = []
        for tnode in self.node_list:
            tnode.remote_issue_ipmi_conf(ipmilist)

    def get_allclient_addr (self):
        cmd = []
        clients = []
        cmd.append(settings.COMMANDS['digiocean'])
        cmd.append('peer')
        cmd.append('status')
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd,tmp_img)
        results = tmp_img.readlines()
        if results:
            for ret in results:
                if ret.find("Hostname: ") >= 0:
                    client_ip = ret.replace('Hostname: ','').strip()
                    if client_ip not in clients:
                        clients.append(client_ip)
        return clients

    def peer_list (self):
        rtn = []
        cmd = []
        cmd.append('cat')
        cmd.append('/etc/hosts')
        tmp_img = tempfile.TemporaryFile()
        ret = execute(cmd,tmp_img)
        result = tmp_img.readlines()
        for data in result:
            if data.find('####DigioceanfsNode####') != -1:
                rtn.append(data.split(' ')[0])
                rtn.append(data.split(' ')[1])
        return rtn

    def get_service_by_name (self, service_name):
        ret = check_service_exist(service_name)
        if ret:
            return service(self, service_name)
        else:
            return None

    def check_none_group (self):
        agroup = self.get_group_by_name(orphanage_group_name)
        if not agroup:
            agroup = group(self.options, orphanage_group_name)
            self.group_list.append(agroup)
            self.reset_config_file()

    def print_all_group (self):
        self.check_none_group()
        group_content = StringIO.StringIO()
        for group in self.group_list:
            group.print_all(group_content, "", "\n")
        group_content.seek(0)
        return group_content

    def print_one_group (self, group_name):
        output_img = StringIO.StringIO()
        agroup = find_in_list(self.group_list, group_name)
        if not agroup:
            #print "10006"
            EXIT(10006)
        agroup.print_all(output_img, "", "\n")
        output_img.seek(0)
        return output_img

    def print_all_node (self):
        node_content = StringIO.StringIO()
        for node in self.node_list:
            node.print_all(node_content, "", "\n")
        node_content.seek(0)
        return node_content

    def reset_config_file(self):
        conf_img = StringIO.StringIO()
        for group in self.group_list :
            group.generate_config(conf_img)
        conf_img.seek(0)
        set_config_file(self.config_file_path, conf_img)

    def get_service_nodes(self,service_name):
        nodes = []
        node_list = list_service_node(service_name)
        for node_name in node_list:
            anode = self.get_node_by_name(node_name)
            nodes.append(anode)
        return nodes

    def get_service_disks(self,service_name):
        node_disk_dict = {} # {'node-1':['sdb','sdc']}
        service_disk = list_service_disk(service_name) 
        for adisk in service_disk:
            node_name = adisk.split(':')[0]
            dev_id = adisk.split(':')[1]
            anode = self.get_node_by_name(node_name)
            if anode:
                if not node_disk_dict:
                    node_disk_dict = {anode.get_name():[dev_id]}
                else:
                    if anode.get_name() in node_disk_dict:
                        node_disk_dict[anode.get_name()].append(dev_id)
                    else:
                        node_disk_dict[anode.get_name()] = [dev_id]
        return node_disk_dict


########################################################
#these functions deals with commands of separate objects
########################################################
#login commands
login_usage = \
'''
  %prog login <username>
'''
def login_setup_parser ():
    parser = OptionParser(usage=login_usage)
    parser.add_option("-w", "--web", action="store_true", dest="web", help="is web login", default=False)
    return parser

def login_commands_usage ():
    print login_usage

def login_commands(argv):
    parser = login_setup_parser()
    (options, args) = parser.parse_args(argv)
    if len(args) < 1:
        print "invalid input, check out login usage."
        login_commands_usage()
        EXIT()
    else:
        if not options.web:
            login_commands = args[0]
            if login_commands.__eq__("admin"):
                i = 0
                while i < 3:
                    password = getpass.getpass("DigioceanfsManager Password: ")
                    if password != 'perabytes':
                        #print "15002"
                        i += 1
                    else:
                        break
                else:
                    EXIT()
                amanager = manager(options, hosts_syn=False, connect_ahead=False)
                amanager.login_num_check()
                login_num = amanager.login_num
                digi_debug("login_commands, there is already %s users logined" % (login_num),3)
                if login_num < 1:
                    login()
                    print "0"
                else:
                    #print "15003"
                    EXIT(15003)
            else:
                #print "15001"
                EXIT(15001)
        else:
            if len(args) == 2:
                username = args[0]
                passwd = args[1]
                amanager = manager(options, hosts_syn=False, connect_ahead=False)
                amanager.login_num_check()
                login_num = amanager.login_num
                if login_num == 0:
                    if username == 'admin' and passwd == '3be314d2f6fec7fa64af9ac5d2e1e279':
                        login()
                        print "0"
                        EXIT()
                    elif username != 'admin':
                        print '15001'
                        EXIT()
                    elif passwd != '3be314d2f6fec7fa64af9ac5d2e1e279':
                        print '15002'
                        EXIT(15002)
                elif login_num >= 1:
                    #print "15003"
                    EXIT(15003)

#group commands
group_usage = \
'''
  %prog [options] [group_args]
'''
def group_setup_parser ():
    parser = OptionParser(usage=group_usage)
    parser.add_option("-f", "--file", dest="filename", help="filename to write")
    return parser

def group_commands_usage ():
    print """\
-1 
Available commands for object group:
   add
   del
   rename
   status
   list
   help

please select a command to operate
"""

def group_add_usage ():
    print """\
-1 
group add usage: group_name [[belong_node], [belong_node], ...]

add a group with name of 'group_name' to digioceanfs.
if there is one or more 'belong_node', the node's group will be set to this group.
"""

def group_del_usage ():
    print """\
-1 
group del usage: group_name

del a group with name of 'group_name' from digioceanfs.
"""

def group_rename_usage ():
    print """\
-1 
group rename usage: group_name_old group_name_new

rename group of name 'group_name_old' to 'group_name_new'.
"""

def group_status_usage ():
    print """\
-1 
group status usage: group_name

status all node in the group of name 'group_name'.
"""

def group_list_usage():
    print """\
-1 
group list usage:

this command list all groups in digioceanfs.
this command takes no argument
"""

def group_commands(argv):
    parser = group_setup_parser()
    (options, args) = parser.parse_args(argv)

    if len(args) < 1:
        group_commands_usage()
        EXIT(0)

    group_command = args[0]

    if group_command.__eq__("add"):
        if len(args) < 2:
            group_add_usage()
            EXIT(0)
        elif len(args) > 2:
            amanager = manager(options, hosts_syn=False, connect_ahead=False)
            amanager.group_add(args[1], args[2:])
            amanager.disconnect_all_node()
        else :
            amanager = manager(options, hosts_syn=False, connect_ahead=False)
            amanager.group_add(args[1])
            amanager.disconnect_all_node()
        print "0"
    elif group_command.__eq__("del"):
        if len(args) < 2:
            group_del_usage()
            EXIT(0)
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        amanager.group_del(args[1])
        amanager.disconnect_all_node()
        print "0"
    elif group_command.__eq__("rename"):
        if len(args) < 3:
            group_rename_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        amanager.group_rename(args[1], args[2])
        amanager.disconnect_all_node()
        print "0"
    elif group_command.__eq__("status"):
        if len(args) < 2:
            group_status_usage()
            EXIT()
        amanager = manager(options)
        status = amanager.group_status(args[1])
        amanager.disconnect_all_node()
        print "0"
        print status.read()
    elif group_command.__eq__("list"):
        if len(args) < 2:
            amanager = manager(options, hosts_syn=False, connect_ahead=False)
            group_content = amanager.print_all_group()
            amanager.disconnect_all_node()
        else:
            amanager = manager(options)
            group_content = amanager.print_one_group(args[1])
            amanager.disconnect_all_node()
        print "0"
        print group_content.read()

    elif group_command.__eq__("help"):
        group_commands_usage()
        EXIT()
    else:
        print "Unkown command: \'%s\'"%(group_command)
        group_commands_usage()
        EXIT()


#node commands
node_usage = \
'''
  %prog [options] [node_args]
'''
def node_setup_parser ():
    parser = OptionParser(usage=node_usage)
    parser.add_option("-f", "--file", dest="filename", help="filename to write")
    parser.add_option("--raid-level", dest="raid_level", help="to select raid level")
    return parser

def node_commands_usage():
    print """\
-1 
Available commands for object node:
   add
   add_by_hostname
   del
   setgroup
   status
   cifs_status
   nfs_status
   cifs_restart
   nfs_restart
   list_cpu
   list_nic
   list_disk
   list_raid
   update_disk
   format_disk
   reset_disk
   replace_nodisk
   list
   raid_create
   raid_del
   raid_info
   raid_hs_set
   raid_hs_del
   raid_active
   raid_disactive
   ip_set
   bond_set
   bond_del
   replace
   init
   ipmi_info
   ipmi_ip_set
   ipmi_power_control
   help

please select a command to operate
"""

def node_add_usage():
    print """\
-1 
node add usage:
    xxx.xxx.xxx.xxx [group_name]
args:
    arg1:node_ip.
opts:
    arg2:[group_name].

func:
    add a node to digioceanfs with 'node_ip'.
    if 'group_name' is set, the node's group will be set to that group.
    the node will be allocted a node name to it, use 'node list' for more.
"""
def node_send_msg_usage():
    print """\
-1 
node send_msg usage:
    node_name msg
args:
    arg1:node_name.
    arg2:msg.

func:
    ...
"""
def node_add_by_hostname_usage():
    print """\
-1 
node add_by_hostname usage:
    xxx.xxx.xxx.xxx node_name [group_name]
args:
    arg1:node ip.
    arg2:node_name.
opts:
    arg3:[group_name].

func:
    add a node to digioceafs, its ip will be set to 'node_ip',
    its node name will be set to 'node_name'.
    if 'group_name' is set, the node's group will be set to that group.
"""

def node_del_usage():
    print """\
-1 
node del usage:
    node_name
args:
    arg1:node_name.
opts:

func:
    del a node from digioceanfs
"""

def node_setgroup_usage():
    print """\
-1 
node setgroup usage
    node_name [group_name]
args:
    arg1:node_name.
opts:
    arg2:[group_name].

func:
    set a node's group. if no group is given, the node will be set to no group.
"""

def node_list_usage():
    print """\
-1 
node list usage
    [node_name]
args:
    arg1:node_name.  (when not given, list all nodes)
"""

def node_status_usage():
    print """\
-1 
node status usage
    [node_name]
args:
    arg1:node_name.  (when not given, list all nodes'status)
"""
def node_cifs_status_usage():
    print """\
-1 
node status usage
    [node_name]
args:
    arg1:node_name.  (when not given, list all nodes'status)
"""
def node_nfs_status_usage():
    print """\
-1 
node status usage
    [node_name]
args:
    arg1:node_name.  (when not given, list all nodes'status)
"""
def node_cifs_restart_usage():
    print """\
-1 
node status usage
    [node_name]
args:
    arg1:node_name.  (when not given, list all nodes'status)
"""
def node_nfs_rstart_usage():
    print """\
-1 
node status usage
    [node_name]
args:
    arg1:node_name.  (when not given, list all nodes'status)
"""
def node_list_disk_usage():
    print """\
-1 
node list_disk usage
    [node_name]
args:
    arg1:node_name.  (when not given, list all nodes'disks)
"""
def node_list_nic_usage():
    print """\
-1 
node list_nic usage
    [node_name]
args:
    arg1:node_name.  (when not given, list all nodes'nic-devices)
"""
def node_list_cpu_usage():
    print """\
-1 
node list_cpu usage
    [node_name]
args:
    arg1:node_name.  (when not given, list all nodes'cpu)
"""
def node_reset_disk_usage():
    print """\
-1 
node reset_disk usage
    node_name disk_list
args:
    arg1:node_name.
    arg2:disk_list.(like sdx.)
"""
def node_format_disk_usage():
    print """\
-1 
node format_disk usage
    node_name disk_list
args:
    arg1:node_name.
    arg2:disk_list.(like sdx.)
"""
def node_smart_enable_usage():
    print """\
-1 
node smart_enable usage:
    node_name disk_name
args:
    arg1:node_name.
    arg2:disk_name.
opts:

func:
    S.M.A.R.T enable
"""
def node_smart_disable_usage():
    print """\
-1 
node smart_disable usage:
    node_name disk_name
args:
    arg1:node_name.
    arg2:disk_name.
opts:

func:
    S.M.A.R.T disable
"""
def node_smart_status_usage():
    print """\
-1 
node smart_status usage:
    node_name disk_name
args:
    arg1:node_name.
    arg2:disk_name.
opts:

func:
    S.M.A.R.T status
"""
def node_smart_start_usage():
    print """\
-1 
node smart_start usage:
    node_name smarttype disk_name
args:
    arg1:node_name.
    arg2:smarttype
    arg3:disk_name.
opts:

func:
    S.M.A.R.T start
"""
def node_smart_stop_usage():
    print """\
-1 
node smart_stop usage:
    node_name disk_name
args:
    arg1:node_name.
    arg2:disk_name.
opts:

func:
    S.M.A.R.T stop
"""
def node_smart_info_usage():
    print """\
-1 
node smart_info usage:
    node_name disk_list
args:
    arg1:node_name.
    arg2:disk_list. ((This value must be name of disk,like sdX,can be multi))
opts:

func:
    S.M.A.R.T info
"""
# Edit by ly 2011-05-16
def node_list_static_info_usage():
    print """\
-1 
node list_static_info usage
    node_name
args:
    arg1:node_name.
"""
def node_list_dynamic_info_usage():
    print """\
-1 
node list_dynamic_info usage
    node_name
args:
    arg1:node_name.
"""
def node_list_raid_usage():
    print """\
-1 
node list_raid usage:
    node_name
args:
    arg1:node_name.
opts:

func:
    list all raid disk on the node.
"""
def node_list_inactive_usage():
    print """\
-1 
node list_inactive usage:
    node_name
args:
    arg1:node_name.
opts:

func:
    List all inactive disks on the node.
    Inactive disk is disk that in raid array but not start.
"""
def node_update_disk_usage():
    print """\
-1 
node update_disk usage:
    node_name
args:
    arg1:node_name.
opts:

func:
    Update disk on a node.
    Include:1.find disks that plug in.
            2.find disks that pop out.
            3.start disks that should start.
"""
def node_raid_create_usage():
    print """\
-1 
node raid_create usage:
    node_name raid_lv raid_chunk devices
args:
    arg1:node_name.
    arg2:raid_level. (0|1|01|10|5|6)
    arg3:raid_chunk. (This value must be 2^n times)
    arg4:devices.    (This value must be Letter,like sdX,could be multi)
opts:

func:
    Create a raid array on a node.
"""
def node_raid_info_usage():
    print """\
-1 
node raid_info usage:
    node_name raid_name
args:
    arg1:node_name.
    arg2:raid_name. (This value must be raidname,like mdXX,not /dev/mdXX)
opts:

func:
    List infomation about a raid.
"""
def node_raid_del_usage():
    print """\
-1 
node raid_del usage:
    node_name raid_name
args:
    arg1:node_name.
    arg2:raid_name. (This value must be raidname,like mdXX,not /dev/mdXX)
opts:

func:
    Del a raid array on a node.
"""
def node_raid_hs_set_usage():
    print """\
-1 
node raid_hs_set usage:
    node_name raid_name devices
args:
    arg1:node_name.
    arg2:raid_dev.
    arg3:devices.    (This value must be Letter,like sdX,could be multi)
opts:

func:
    Set hot spare disks to a raid array.
"""
def node_raid_hs_del_usage():
    print """\
-1 
node raid_hs_del usage:
    node_name raid_dev devices
args:
    arg1:node_name.
    arg2:raid_dev.
    arg3:devices.    (This value must be Letter,like sdX,could be multi)
opts:

func:
    Del hot spare disks from a raid array
"""
def node_raid_active_usage():
    print """\
-1 
node raid_active usage:
    node_name raid_name
args:
    arg1:node_name.
    arg2:raid_name. (This value must be raidname,like mdXX,not /dev/mdXX)
opts:

func:
    Active a raid array on a node.
    The disk belong to it MUST have an inactive status before this operation.
"""
def node_raid_disactive_usage():
    print """\
-1 
node raid_disactive usage:
    node_name devices
args:
    arg1:node_name.
    arg2:devices.    (This value must be Letter,like sdX,could be multi)
opts:

func:
    Disactive disks on a node.
    Disks to disactive MUST have an inactive status before this operation.
    This command is used to clean raid array infomation on it.
"""
def node_ip_set_usage():
    print """\
-1 
node ip_set usage:
    node_name nic_name new_ip_address new_netmask new_gateway_address new_broadcast_address
args:
    arg1:node_name.
    arg2:nic_name.
    arg3:new_ip_address.
    arg4:new_netmask.
    arg5:new_gateway_address.
    arg6:new_broadcast_address.
opts:

func:
    Set ip adress on a nic.
"""
def node_replace_usage():
    print """\
-1 
node replace usage:
    node_name replace_node_ip
args:
    arg1:node_name
    arg2:replace_node_ip
opts:

func:
"""
def node_check_license_usage():
    print """\
-1 
node replace usage:
    node_name license_num 
args:
    arg1:node_name
    arg2:license_num
opts:

func:
"""
def node_get_device_id_usage():
    print """\
-1 
node replace usage:
    node_name 
args:
    arg1:node_name
opts:

func:
"""
def node_replace_nodisk_usage():
    print """\
-1
node replace_nodisk usage:
    node_name service_name replace_disk
args:
    arg1:node_name
    arg2:service_name
    arg3:replace_disk
opts:

func:
    replace disks that missed in a service
"""
def node_bond_set_usage():
    print """\
-1 
node bond_set usage:
    node_name bond_mode devices
args:
    arg1:node_name.
    arg2:bond_mode.  (0|1|2|3|4|5|6)
    arg3:devices.    (This value must be name of net interface,like ethX,must be multi)
opts:

func:
    Create a bond on a node.The bond's address will be set to
    the node's connect address.
    NOTE:Create bond of mode 6 should be careful,
         because it depend on the device driver's support.
"""
def node_bond_del_usage():
    print """\
-1 
node bond_del usage:
    node_name bond_name
args:
    arg1:node_name.
    arg2:bond_name.
opts:

func:
    Del a bond on a node.
"""

def node_ctdb_set_usage():
    print """\
-1 
node node_ctdb_set usage:
    nodes_names public_addresses
args:
    arg1:nodes_names.       (This value is one or more node names)
                            (ex : node-1.estor,node-2.estor)
    arg2:public_addresses.  (This value format [xxx.xxx.xxx.xxx/netmask ethx])
                            (ex : 10.10.0.2/8 eth0,10.10.0.3/8 eth1)
func:
    ctdb set
"""

def node_sms_set_usage():
    print """\
-1 
node sms setup usage:
    option [sms_number] [notify_type]
args:
    arg1:option            <enable|disable|list|sms_center_num|add_mobp_num|del_mobp_num>
    arg2:sms_number        (This value format [+86xxxxxxxxxxx])
    arg3:notify_type       (This value like RaidEvent,FailSpare,RebuildStarted,RebuildFinished,SpareActive,NewArray,DeviceDisappeared,degraded,FAILED,NetLink,SpeedDown,SpeedResume,FileSystemEvent,Systemdisk,ok,notice,warnning,error,DiskTemp,SysMsg,usedcpu,cputemp,usedmem,cpufan)
opts:

func:
    enable|disable|list|sms_center_num|add_mobp_num|del_mobp_num|notify_type_set on a node.
"""

def node_init_usage():
    print """\
-1
node init usage:
    node_name init_level
args:
    arg1:node_name.
    arg2:init_level
func:
    node init
"""

def node_ipmi_power_control_usage():
    print """\
-1
node ipmi power contorl usage:
    node_name option
args:
    arg1:node_name.
    arg2:option            (on/off/status)
func:
    node ipmi power control
"""

def node_ipmi_ip_set_usage():
    print """\
-1
node ipmi ip set usage:
    node_name ipaddress netmask gateway
args:
    arg1:node_name.
    arg2:ipaddress.
    arg3:netmask.
    arg4:gateway.
func:
    node ipmi ip set
"""

def node_ipmi_info_usage():
    print """\
-1
node ipmi info usage:
    node_name
args:
    arg1:node_name.
func:
    node ipmi info list
"""

def node_commands(argv):
    parser = node_setup_parser()
    (options, args) = parser.parse_args(argv)

    if len(args) < 1:
        node_commands_usage()
        EXIT()

    node_command = args[0]

    if node_command.__eq__("add"):
        if len(args) < 2:
            node_add_usage()
            EXIT()

        elif len(args) > 2:
            amanager = manager(options, hosts_syn=False)
            if len(amanager.node_list) == 0:
                ip_list = amanager.get_ip_addr()
                if '127.0.0.1' in ip_list:
                    ip_list.remove('127.0.0.1')
                if args[1] in ip_list:       #add manager node ip first
                    amanager.node_add_by_host_name(args[1])
                    amanager.disconnect_all_node()
                    print ("0")
                    return
                else:                        #add other node ip first
                    flag = False             #no match ip
                    for ip_addr in ip_list:
                        if ipType(args[1]) == '':
                            node_add_usage()
                            return
                        else:
                            if ipType(args[1]) == ipType(ip_addr):
                                flag = True
                                break
                    else:
                        if not flag:
                            EXIT(11135)

                amanager.node_add_by_host_name(ip_addr, group_name=args[2])
                amanager.disconnect_all_node()
                amanager2 = manager(options, hosts_syn=False)
                amanager2.node_add_by_host_name(args[1], group_name=args[2])
                amanager2.disconnect_all_node()

            else:
                amanager.node_add_by_host_name(args[1], group_name=args[2])
                amanager.disconnect_all_node()

        else:
#            import pdb

#            pdb.set_trace()
            amanager = manager(options, hosts_syn=False)
            if len(amanager.node_list) == 0:
                ip_list = amanager.get_ip_addr()
                if '127.0.0.1' in ip_list:
                    ip_list.remove('127.0.0.1')
                if args[1] in ip_list:       #add manager node ip first
                    amanager.node_add_by_host_name(args[1])
                    amanager.disconnect_all_node()
                    print ("0")

                    return
                else:                        #add other node ip first
                    flag = False             #no match ip
                    for ip_addr in ip_list:
                        if ipType(args[1]) == '':
                            node_add_usage()
                            return
                        else:
                            if ipType(args[1]) == ipType(ip_addr):
                                flag = True
                                break
                    else:
                        if not flag:
                            EXIT(11135)

                amanager.node_add_by_host_name(ip_addr)
                amanager.disconnect_all_node()
                amanager2 = manager(options, hosts_syn=False)
                amanager2.node_add_by_host_name(args[1])
                amanager2.disconnect_all_node()

            else:
                amanager.node_add_by_host_name(args[1])
                amanager.disconnect_all_node()

        print "0"
    elif node_command.__eq__("send_msg"):
        if len(args) < 3:
            node_send_msg_usage()
            EXIT()
        amanager = manager(options)
        try:
            amanager.node_send_msg(args[1], args[2])
        except Exception,e:
            print traceback.print_exc(e)
        amanager.disconnect_all_node()
        print "0"    
        
    elif node_command.__eq__("add_by_hostname"):
        if len(args) < 3:
            node_add_by_hostname_usage()
            EXIT()
        elif len(args) > 3:
            amanager = manager(options)
            amanager.node_add_by_host_name(args[1], node_name=args[2], group_name=args[3])
            amanager.disconnect_all_node()
        else:
            amanager = manager(options)
            amanager.node_add_by_host_name(args[1], node_name=args[2])
            amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("del"):
        if len(args) < 2:
            node_del_usage()
            EXIT()
        amanager = manager(options)
        amanager.node_del(args[1])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("setgroup"):
        if len(args) < 2:
            node_setgroup_usage()
            EXIT()
        elif len(args) > 2:
            amanager = manager(options, hosts_syn=False, connect_ahead=False)
            amanager.node_set_group_by_name(args[1], args[2])
            amanager.disconnect_all_node()
        else:
            amanager = manager(options, hosts_syn=False, connect_ahead=False)
            amanager.node_set_group_by_name(args[1])
            amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("status"):
        if len(args) < 2:
            amanager = manager(options)
            status = amanager.node_status_all()
            amanager.disconnect_all_node()
        else:
            amanager = manager(options)
            status = amanager.node_status(args[1])
            amanager.disconnect_all_node()
        print "0"
        print status.read()
    elif node_command.__eq__("cifs_status"):
        if len(args) == 1:
            amanager = manager(options)
            status = amanager.node_cifs_status()
            amanager.disconnect_all_node()
        else:
            node_cifs_status_usage()
            EXIT()
        print "0"
        print status.read()
    elif node_command.__eq__("nfs_status"):
        if len(args) == 1:
            amanager = manager(options)
            status = amanager.node_nfs_status()
            amanager.disconnect_all_node()
        else:
            node_nfs_status_usage()
            EXIT()
        print "0"
        print status.read()
    elif node_command.__eq__("cifs_restart"):
        if len(args) == 2:
            amanager = manager(options)
            status = amanager.node_cifs_restart(args[1])
            amanager.disconnect_all_node()
        else:
            node_cifs_restart_usage()
            EXIT()
        print "0"
    elif node_command.__eq__("ctdb_set"):
        if len(args) > 3:
            amanager = manager(options)
            status = amanager.node_ctdb_set(args[1],' '.join(args[2:]))
            amanager.disconnect_all_node()
        else:
            node_ctdb_set_usage()
            EXIT()

        print "0"
    elif node_command.__eq__("ctdb_list"):
        if len(args) >= 1:
            amanager = manager(options)
            out = amanager.node_ctdb_list()
            amanager.disconnect_all_node()
            print "0"
            print out.read()
    elif node_command.__eq__("nfs_restart"):
        if len(args) == 2:
            amanager = manager(options)
            status = amanager.node_nfs_restart(args[1])
            amanager.disconnect_all_node()
        else:
            node_nfs_restart_usage()
            EXIT()
        print "0"
    elif node_command.__eq__("list_cpu"):
        if len(args) < 2:
            node_list_cpu_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        out = amanager.node_list_cpu(args[1])
        amanager.disconnect_all_node()
        print "0"
        print out.read()
    elif node_command.__eq__("list_nic"):
        if len(args) < 2:
            amanager = manager(options)
            ret = amanager.node_list_nic_all()
            amanager.disconnect_all_node()
        else:
            amanager = manager(options, hosts_syn=False, connect_ahead=False)
            ret = amanager.node_list_nic(args[1])
            amanager.disconnect_all_node()
        print "0"
        print ret.read()
    elif node_command.__eq__("list_disk"):
        if len(args) < 2:
            amanager = manager(options)
            out = amanager.node_list_disk_all()
            amanager.disconnect_all_node()
        else:
            amanager = manager(options, hosts_syn=False, connect_ahead=False)
            out = amanager.node_list_disk(args[1])
            amanager.disconnect_all_node()
        print "0"
        print out.read()
    elif node_command.__eq__("reset_disk"):
        if len(args) < 2:
            node_reset_disk_usage()
            EXIT()
        else:
            amanager = manager(options)
            amanager.node_reset_disk(args[1], args[2:])
            amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("format_disk"):
        if len(args) < 2:
            node_format_disk_usage()
            EXIT()
        else:
            amanager = manager(options)
            amanager.node_format_disk(args[1], args[2:])
            amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("smart_enable"):
        if len(args) < 3:
            node_smart_enable_usage()
            EXIT()
        else:
            amanager = manager(options)
            amanager.node_smart_enable(args[1], args[2])
            amanager.disconnect_all_node()
        print "0"    
    elif node_command.__eq__("smart_disable"):
        if len(args) < 3:
            node_smart_disable_usage()
            EXIT()
        else:
            amanager = manager(options)
            amanager.node_smart_disable(args[1], args[2])
            amanager.disconnect_all_node()
        print "0"  
    elif node_command.__eq__("smart_status"):
        if len(args) < 3:
            node_smart_status_usage()
            EXIT()
        else:
            amanager = manager(options)
            out = amanager.node_smart_status(args[1], args[2])
            amanager.disconnect_all_node()
        print "0"  
        print out.read()
    elif node_command.__eq__("smart_start"):
        if len(args) < 4:
            node_smart_start_usage()
            EXIT()
        else:
            amanager = manager(options)
            amanager.node_smart_start(args[1], args[2], args[3])
            amanager.disconnect_all_node()
        print "0"    
    elif node_command.__eq__("smart_stop"):
        if len(args) < 3:
            node_smart_stop_usage()
            EXIT()
        else:
            amanager = manager(options)
            amanager.node_smart_stop(args[1], args[2])
            amanager.disconnect_all_node()
        print "0"    
    elif node_command.__eq__("smart_info"):
        if len(args) < 3:
            node_smart_info_usage()
            EXIT()
        else:
            amanager = manager(options)
	    out = amanager.node_smart_info(args[1], args[2:])
            amanager.disconnect_all_node()
        print "0"  
        print out.read()

# Edit by ly 2011-05-16
    elif node_command.__eq__("list_static_info"):
        if len(args) < 2:
            node_list_static_info_usage()
            EXIT()
        amanager = manager(options)
        out = amanager.node_list_static_info(args[1])
        amanager.disconnect_all_node()
        print "0"
        print out.read()
    elif node_command.__eq__("list_dynamic_info"):
        if len(args) < 2:
            node_list_dynamic_info_usage()
            EXIT()
        amanager = manager(options)
        out = amanager.node_list_dynamic_info(args[1])
        amanager.disconnect_all_node()
        print "0"
        print out.read()
    elif node_command.__eq__("list_raid"):
        if len(args) < 2:
            node_list_raid_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        out = amanager.node_list_raid(args[1])
        amanager.disconnect_all_node()
        print "0"
        print out.read()
    elif node_command.__eq__("list_inactive"):
        if len(args) < 2:
            node_list_inactive_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        out = amanager.node_list_inactive_raid(args[1])
        amanager.disconnect_all_node()
        print "0"
        print out.read()
    elif node_command.__eq__("update_disk"):
        if len(args) < 2:
            node_update_disk_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        amanager.node_update_disk(args[1])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("list"):
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        node_content = amanager.print_all_node()
        amanager.disconnect_all_node()
        print "0"
        print node_content.read()

    elif node_command.__eq__("raid_create"):
        if len(args) < 5:
            node_raid_create_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        amanager.node_raid_create(args[1], args[2], args[3], args[4:])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("raid_del"):
        if len(args) < 3:
            node_raid_del_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        amanager.node_raid_del(args[1], args[2])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("raid_info"):
        if len(args) < 3:
            node_raid_info_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        ret = amanager.node_raid_info(args[1], args[2])
        amanager.disconnect_all_node()
        print "0"
        print ret.read()
    elif node_command.__eq__("raid_hs_set"):
        if len(args) < 4:
            node_raid_hs_set_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        amanager.node_raid_hs_set(args[1], args[2], args[3:])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("raid_hs_del"):
        if len(args) < 4:
            node_raid_hs_del_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        amanager.node_raid_hs_del(args[1], args[2], args[3:])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("raid_active"):
        if len(args) < 3:
            node_raid_active_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        amanager.node_raid_active(args[1], args[2])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("raid_disactive"):
        if len(args) < 3:
            node_raid_disactive_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        amanager.node_raid_disactive_disk(args[1], args[2:])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("ip_set"):
        if len(args) < 7:
            node_ip_set_usage()
            EXIT()
#                                  node_name nic_name new_ip   new_mask new_gate new_bcast
        amanager = manager(options)
        amanager.node_ip_set_by_nic(args[1], args[2], args[3], args[4], args[5], args[6])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("bond_set"):
        if len(args) < 4:
            node_bond_set_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        amanager.node_bond_set(args[1], args[2], args[3:])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("bond_del"):
        if len(args) < 3:
            node_bond_del_usage()
            EXIT()
        amanager = manager(options, hosts_syn=False, connect_ahead=False)
        amanager.node_bond_del(args[1], args[2])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("replace"):
        if len(args) < 3:
            node_replace_usage()
            EXIT()
        amanager = manager(options)
        amanager.node_replace(args[1], args[2])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("replace_nodisk"):
        if len(args) < 4:
            node_replace_nodisk_usage()
            EXIT()
        amanager = manager(options)
        amanager.node_replace_nodisk(args[1], args[2], args[3:])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("check_license"):
        if len(args) < 3:
            node_check_license_usage()
            EXIT()
        amanager = manager(options)
        amanager.node_check_license(args[1], args[2])
        amanager.disconnect_all_node()
        print "0"
    elif node_command.__eq__("get_device_id"):
        if len(args) < 2:
            node_get_device_id_usage()
            EXIT()
        amanager = manager(options)
        ret = amanager.node_get_device_id(args[1])
        amanager.disconnect_all_node()
        print "0"
        print ret
    elif node_command.__eq__('sms_set'):
        if len(args) < 2:
            node_sms_set_usage()
            EXIT()
        amanager = manager(options)
        try:
            ret = amanager.node_sms_set(args[1:])
        except Exception, e:
            print e
        amanager.disconnect_all_node()
        print "0"
        print ret.read()
    elif node_command.__eq__("init"):
        if len(args) < 3:
            node_init_usage()
            EXIT()
        amanager = manager(options)
        try:
            ret = amanager.node_init(args[1],args[2])
        except Exception,e:
            print e
        amanager.disconnect_all_node()
        print "0"

    elif node_command.__eq__("ipmi_power_control"):
        if len(args) < 3:
            node_ipmi_power_control_usage()
            EXIT()
        amanager = manager(options)
        try:
            ret = amanager.node_ipmi_power_control(args[1],args[2])
        except Exception,e:
            print e
        amanager.disconnect_all_node()
        print "0"
        ipmi_status = ret.read()
        if ipmi_status:
            print ipmi_status

    elif node_command.__eq__("ipmi_ip_set"):
        if len(args) < 5:
            node_ipmi_ip_set_usage()
            EXIT()
        amanager = manager(options)
        try:
            ret = amanager.node_ipmi_ip_set(args[1],args[2],args[3],args[4])
        except Exception,e:
            print e
        amanager.disconnect_all_node()
        print "0"

    elif node_command.__eq__("ipmi_info"):
        if len(args) < 2:
            node_ipmi_info_usage()
            EXIT()
        amanager = manager(options)
        try:
            ret = amanager.node_ipmi_info(args[1])
        except Exception,e:
            print e
        amanager.disconnect_all_node()
        print "0"
        print ret.read()

    elif node_command.__eq__("help"):
        node_commands_usage()
        EXIT()
    else:
        node_commands_usage()
        EXIT()


#service commands
service_usage = \
'''
  %prog [options] [service_args]
'''
def service_setup_parser ():
    parser = OptionParser(usage=service_usage)
#    parser.add_option("-f", "--file",
#                      dest="filename", help="filename to write")
    parser.add_option("-a", "--afr-num", type="int", default=0,
                      dest="afr_num", help="number of subvolumes of a afr")
    parser.add_option("-m", "--manual-afr", action="store_true", default=False,
                      dest="manual_afr", help="create afr by hand")
    parser.add_option("-s", "--stripe-num", type="int", default=0,
                      dest="stripe_num", help="number of stripe a file")
    parser.add_option("-R", "--redundancy-num", type="int", default=0,
                      dest="redu_num", help="number of redundancy")
    parser.add_option("-d", "--disperse-num", type="int", default=0,
                  dest="disp_num", help="number of disperse")
    parser.add_option("-x", "--afr-expand-degree", type="int", default=1,
                      dest="afr_expand_degree", help="dgree to expand an afr mirror")
    parser.add_option("-r", "--afr-shrink-degree", type="int", default=1,
                      dest="afr_shrink_degree", help="dgree to shrink an afr mirror")
    parser.add_option("-f", "--format-disk", action="store_true", default=False,
                      dest="format", help="format disk")
    parser.add_option("-o", "--feature-options", type="string", default="", dest="feature_str", \
                      help="valid string: native_store, custom_store; use ',' to split")
    return parser

def service_commands_usage():
    print """\
-1 
Available commands for object service:
   create
   set_spare
   replace_disk
   list
   list_disk
   start
   stop
   destroy
   add_disk
   restart
   export_cifs
   cifs_add_user
   cifs_del_user
   export_nfs
   afr_info
   afr_expand
   afr_shrink
   client_add
   client_destroy
   client_list
   client_start
   client_stop
   help

please select a command to operate
"""

def service_create_usage():
    print """\
-1 
service create usage:
    service_name service_raid_lv service_disks [opts]
args:
    arg1:service_name.
    arg2:service_raid_level.     (0:strip|01:stripe&afr|1:afr|2:normal.)
    arg3:service_disks.          (This value should be formated,like node_name:sdX, could be multi.)
opts:
    arg4: [-a afr_num]           (Specify afr subvolume number,when afr service created.)
    arg5: [-m]                   (Manually create a service of afr,when afr service created.)
    arg6: [-s stripe_num]        (Specify stripe subvolume number,when strip service created.)
    arg7: [-f format_disk]       (Format disk when service created.)
    arg8: [-o feature_options]   (Specify feature options when service created.)
    arg9: [-R redu_num]          (Specify redundancy num when service created.)
    arg10: [-d disperse-num]      (Specify disperse num when service created.)

func:
    create a service.
"""
def service_set_options_usage():
    print """\
-1 
service set_options usage:
    service_name service_options
args:
    arg1:service_name.
    arg2:service_options.        (Format in json)

func:
    set options for a service.
"""


def service_set_spare_usage():
    print """\
-1 
service set_spare usage:
    service_name disk_list option 
args:
    arg1:service_name.
    arg2:disk_list. {ex: node-1:sdb node-2:sda node-2:sdb} 
    arg3:option. {-f format disk}
opts:

func:
    add spare disk in a service.
"""
def service_replace_disk_usage():
    print """\
-1 
service replace_disk usage:
    service_name disk_pair_list option 
args:
    arg1:service_name.
    arg2:disk_pair_list. {ex: node-1:sdb,node-1:sdd node-2:sda,node-2:sdb} 
    arg3:option. {-f format disk}
opts:

func:
    replace disk in a service.
"""

def service_heal_disperse_usage():
    print """\
-1 
service heal_disperse usage:
    service_name  
args:
    arg1:service_name.
opts:

func:
    trigger disperse self-heal.
"""

def service_list_usage():
    print """\
-1 
service list usage:
    [service_name]
args:

opts:
    arg1:[service_name]

func:
"""

def service_list_disk_usage():
    print """\
-1 
service list_disk usage:
    service_name
args:
    arg1:service_name
opts:

func:
    list disk of a service.
"""

def service_afr_info_usage():
    print """\
-1 
service afr_info usage:
    service_name
args:
    arg1:service_name.
opts:

func:
    if the service is of type afr, output afr synchronous info of it.
"""

def service_afr_expand_usage():
    print """\
-1 
service afr_expand usage:
    service_name disks [-r afr_expand_degree]
args:
    arg1:service_name.
    arg2:disks.             (This value should be formated,like mirror_name:node_name:sdX,could be multi.)
opts:
    arg3:[-x afr_degree]    (Afr expand degree, indicate how many disks to be expand per mirror.)

func:
    Expand the service's afr mirror degree.
"""

def service_afr_shrink_usage():
    print """\
-1 
service afr_shrink usage:
    service_name disks [-r afr_shrink_degree]
args:
    arg1:service_name.
    arg2:disks.             (This value should be formated,like mirror_name:node_name:sdX,could be multi.)
opts:
    arg3:[-r afr_degree]    (Afr shrink degree, indicate how many disks to be shrink per mirror.)

func:
    shrink the service's afr mirror degree
"""

def service_start_usage():
    print """\
-1 
service start usage:
    service_name
args:
    arg1:service_name
opts:

func:
    start a service.
"""

def service_quota_usage():
    print """\
-1 
service quota_setup usage:
    service_name option [path] [value]
args:
    arg1:service_name
    arg2:option            <enable|disable|limit-usage|list|remove>
    arg3:path              directory under path of service, 
                           example: /quota-1 who's real path is /cluster2/test/quota-1
    arg4:value             number and unit required,example: 5KB,5MB,5GB,5TB
opts:

func:
    enable|disable|limit-usage|list|remove quota on a service.
"""

def service_auth_setup_usage():
    print """\
-1
service auth_setup usage:
    service_name option [path] [value]
args:
    arg1:service_name
    arg2:option            <list|edit>
    arg3:path              directory under path of service,
                           example: /auth-1 who's real path is /cluster2/test/auth-1
    arg4:value             authority of path
opts:

func:
    list|edit the authority of path on a service.
"""

def service_stop_usage():
    print """\
-1 
service stop usage:
    service_name
args:
    arg1:service_name
opts:

func:
    stop a service.
"""

def service_destroy_usage():
    print """\
-1 
service destroy usage:
    service_name
args:
    arg1:service_name.
opts:

func:
    destroy a service, clean all data in it.
"""

def client_add_usage():
    print """\
-1 
client add usage:
    client_ipaddr client_mask
args:
    arg1:client_ipaddr
    arg2:client_mask
opts:

func:
    add client.
"""

def client_destroy_usage():
    print """\
-1 
client destroy usage:
    client_ipaddr
args:
    arg1:client_ipaddr.
opts:

func:
    destroy client.
"""

def client_list_usage():
    print """\
-1 
client list usage:
    service_name
args:
    arg1: service_name
opts:

func:
    list all client for service.
"""
def client_start_usage():
    print """\
-1 
client list usage:
    service_name client_ipaddr
args:
    arg1:service_name
    arg2:client_ipaddr
opts:

func:
    start service on client.
"""
def client_stop_usage():
    print """\
-1 
client stop usage:
    service_name client_ipaddr
args:
    arg1:service_name
    arg2:client_ipaddr
opts:

func:
    stop service on client.
"""


def service_status_usage():
    print """\
-1 
service status usage:
    service_name service_disks
args:
    arg1:service_name.
    arg2:service_disks. (This value should be formated,like node_name:sdX,could be multi)
opts:

func:
    add disks to a service.
"""
def service_restart_usage():
    print """\
-1 
service restart usage:
    service restart service_name
args:
    arg1:service_name
opts:

func:
"""
def service_export_cifs_usage():
    print """\
-1 
service export_cifs usage:
    service_name option
args:
    arg1:service_name.
    arg2:option (start|stop|status)
opts:

func:
    start/stop/status a service's cifs export.
"""
def service_export_cifs_restart_node_usage():
    print """\
-1 
service export_cifs_restart usage:
    service_name
args:
    arg1:service_name.
opts:

func:
    restart a node's cifs .
"""
def service_export_cifs_restart_service_usage():
    print """\
-1 
service export_cifs_restart usage:
    service_name
args:
    arg1:service_name.
opts:

func:
    restart a service's cifs export.
"""
def service_export_cifs_list_user_usage():
    print """\
-1 
service export_cifs_list_user usage:
    service_name 
args:
    arg1:service_name.
opts:

func:
    list user to cifs service.
"""
def service_export_cifs_list_links_usage():
    print """\
-1 
service export_cifs_list_links usage:
    service_name 
args:
    arg1:service_name.
opts:

func:
    list links to cifs service.
"""
def service_export_cifs_del_links_usage():
    print """\
-1 
service export_cifs_del_links usage:
    service_name node_name pid
args:
    arg1:service_name.
    arg2:node_name
    arg3:pid
opts:

func:
    del links of cifs service.
"""
def service_export_cifs_add_user_usage():
    print """\
-1 
service export_cifs_add_user usage:
    service_name user_name password
args:
    arg1:service_name.
    arg2:user_name.
    arg3:password.
opts:

func:
    add user to cifs service.
"""
def service_export_cifs_del_user_usage():
    print """\
-1 
service export_cifs_del_user usage:
    service_name user_name
args:
    arg1:service_name.
    arg2:user_name.
opts:

func:
    del user from cifs service in system.
"""
def service_export_nfs_usage():
    print """\
-1 
service export_nfs usage:
    service_name option
args:
    arg1:service_name.
    arg2:option (start|stop|status)
opts:

func:
    start/stop/status a service's nfs export.
"""
def service_export_nfs_list_links_usage():
    print """\
-1 
service export_nfs_list_links usage:
    service_name 
args:
    arg1:service_name.
opts:

func:
    list links of nfs service.
"""
def service_export_nfs_list_user_usage():
    print """\
-1     
service export_nfs_list_user usage:
    service_name 
args:
    arg1:service_name.
opts:

func:
    list user to nfs service.
"""
def service_export_nfs_del_links_usage():
    print """\
-1 
service export_nfs_del_links usage:
    service_name node_name tar_ip
args:
    arg1:service_name.
    arg2:node_name
    arg3:tar_ip
opts:

func:
    del links of nfs service.
"""
def service_export_nfs_add_user_usage():
    print """\
-1    
service export_nfs_add_user usage:
    service_name user_ip
args:
    arg1:service_name.
    arg2:user_ip.
opts:

func:
    add user to nfs service.
"""
def service_export_nfs_del_user_usage():
    print """\
-1 
service export_nfs_del_user usage:
    service_name user_ip
args:
    arg1:service_name.
    arg2:user_ip.
opts:

func:
    del user from nfs service in system.
"""

def service_commands(argv):
    parser = service_setup_parser()
    (options, args) = parser.parse_args(argv)
    if len(args) < 1:
        service_commands_usage()
        EXIT()

    service_command = args[0]

    if service_command.__eq__("create"):
        if len(args) < 4:
            service_create_usage()
            EXIT()
        amanager = manager(options)
        amanager.service_create(args[1], args[2], args[3:])
        amanager.disconnect_all_node()
        print "0"
    elif service_command.__eq__("set_options"):
        if len(args) < 3:
            service_set_options_usage()
            EXIT()
        amanager = manager(options)
        try:
            #print args[2]
            options = simplejson.loads(args[2])
        except Exception,e:
            EXIT(-1, "Service options format error")
        amanager.service_set_options(args[1], options)
        amanager.disconnect_all_node()
        print "0"    
    
    elif service_command.__eq__("set_spare"):
        if len(args) < 3:
            service_set_spare_usage()
            EXIT()
        amanager = manager(options)
        try:
            if amanager.options.format:
                ret = amanager.service_set_spare(args[1], args[2:], format=True)
            else:
                ret = amanager.service_set_spare(args[1], args[2:], format=False)
        except Exception, e:
            print traceback.print_exc(e)
        if not ret:
            service_set_spare_usage()
            EXIT()
        amanager.disconnect_all_node()
        print "0"
    elif service_command.__eq__("replace_disk"):
        if len(args) < 3:
            service_replace_disk_usage()
            EXIT()
        amanager = manager(options)
        if amanager.options.format:
            ret = amanager.service_replace_disk(args[1], args[2:], 'commit', force=True, format=True)
        else:
            ret = amanager.service_replace_disk(args[1], args[2:], 'commit', force=True, format=False)
        if not ret:
            service_replace_disk_usage()
            EXIT()
        amanager.disconnect_all_node()
        print "0"
    elif service_command.__eq__("heal_disperse"):
        if len(args) < 2:
            amanager = manager(options)
            service_heal_disperse_usage()
            EXIT()
        else:
            amanager = manager(options)
            try:
                ret = amanager.service_heal_disperse(args[1])
            except Exception,e:
                traceback.print_exc(e)
            amanager.disconnect_all_node()
        print "0"
    elif service_command.__eq__("list"):
        if len(args) < 2:
            amanager = manager(options)
            ret = amanager.service_list_all()
            amanager.disconnect_all_node()
        else:
            amanager = manager(options)
            ret = amanager.service_list_single(args[1])
            amanager.disconnect_all_node()
        print "0"
        print ret.read()
    elif service_command.__eq__("list_disk"):
        if len(args) < 2:
            amanager = manager(options)
            service_disks = amanager.service_list_all_disk()
            amanager.disconnect_all_node()
        else:
            amanager = manager(options)
            service_disks = amanager.service_list_disk(args[1])
            amanager.disconnect_all_node()
        print "0"
        print service_disks.read()
    elif service_command.__eq__("afr_info"):
        if len(args) < 2:
            service_afr_info_usage()
            EXIT()
        amanager = manager(options)
        ret = amanager.service_afr_info(args[1])
        amanager.disconnect_all_node()
        print "0"
        print ret.read()
    elif service_command.__eq__("afr_info_topage"):
        if len(args) < 2:
            service_afr_info_usage()
            EXIT()
        amanager = manager(options)
        ret = amanager.service_afr_info_topage(args[1], args[2:])
        amanager.disconnect_all_node()
        print "0"
        print ret.read()
    elif service_command.__eq__("afr_info_topage_search"):
        if len(args) < 2:
            service_afr_info_usage()
            EXIT()
        amanager = manager(options)
        ret = amanager.service_afr_info_topage_search(args[1], args[2:])
        amanager.disconnect_all_node()
        print "0"
        print ret.read()
    elif service_command.__eq__("afr_syn"):
        if len(args) < 2:
            service_afr_syn_usage()
            EXIT()
        amanager = manager(options)
        ret = amanager.service_afr_syn(args[1])
        amanager.disconnect_all_node()
        print "0"
    elif service_command.__eq__("afr_expand"):
        if len(args) < 3:
            service_afr_expand_usage()
            EXIT()
        amanager = manager(options)
        ret = amanager.service_afr_expand(args[1], args[2:])
        amanager.disconnect_all_node()
        print "0"
    elif service_command.__eq__("afr_shrink"):
        if len(args) < 2:
            service_afr_shrink_usage()
            EXIT()
        amanager = manager(options)
        ret = amanager.service_afr_shrink(args[1], args[2:])
        amanager.disconnect_all_node()
        print "0"
    elif service_command.__eq__("start"):
        if len(args) < 2:
            service_start_usage()
            EXIT()
        amanager = manager(options)
        ret = amanager.service_start(args[1])
        amanager.disconnect_all_node()
        print "0"
    elif service_command.__eq__("quota_setup"):
        if len(args) < 3:
            service_quota_usage()
            EXIT()
        amanager = manager(options)
        try:
            ret = amanager.service_quota_setup(args[1],args[2:])
        except Exception, e:
            print e
        amanager.disconnect_all_node()
        print "0"
        print ret.read()
        #print "success:%d, failed:%d, not found:%d, already started:%d, no connect:%d, version do not match:%d"%(ret[0], ret[1], ret[2], ret[3], ret[4], ret[5])
    elif service_command.__eq__("auth_setup"):
        if len(args) < 3:
            service_auth_setup_usage()
            EXIT()
        amanager = manager(options)
        try:
            ret = amanager.service_auth_setup(args[1],args[2:])
        except Exception, e:
            print e
        amanager.disconnect_all_node()
        print "0"
        print ret.read()
    elif service_command.__eq__("client_add"):
        if len(args) < 3:
            client_add_usage()
            EXIT()
        try:
            aclient = client(options=options,ipaddr=args[1],mask=args[2])
            ret = aclient.client_add()
        except Exception,e:
            print traceback.print_exc(e)
        print ret
    elif service_command.__eq__("client_destroy"):
        if len(args) < 2:
            client_destroy_usage()
            EXIT()
        try:
            aclient = client(options=options, ipaddr=args[1])
            ret = aclient.client_destroy()
        except Exception,e:
            print traceback.print_exc(e)
        print ret
    elif service_command.__eq__("client_list"):
        if len(args) < 2:
            client_list_usage()
            EXIT()
        aclient = client(options=options, service_name=args[1])
        ret = aclient.client_list(options)
        print '0'
        print ret.read()
    elif service_command.__eq__("client_start"):
        if len(args) < 2:
            client_start_usage()
            EXIT()
        aclient = client(options=options, service_name=args[1], ipaddr=args[2])
        ret = aclient.client_start()
        print ret
    elif service_command.__eq__("client_stop"):
        if len(args) < 2:
            client_stop_usage()
            EXIT()
        aclient = client(options=options, service_name=args[1], ipaddr=args[2])
        ret = aclient.client_stop()
        print ret
    elif service_command.__eq__("client_status"):
        pass
    elif service_command.__eq__("stop"):
        if len(args) < 2:
            service_stop_usage()
            EXIT()
        amanager = manager(options)
        ret = amanager.service_stop(args[1])
        amanager.disconnect_all_node()
        print "0"
        #print "success:%d, failed:%d, not found:%d, already stop:%d, no connect: %d"%(ret[0], ret[1], ret[2],ret[5],ret[3])
    elif service_command.__eq__("destroy"):
        if len(args) < 2:
            service_destroy_usage()
            EXIT()
        amanager = manager(options)
        ret = amanager.service_destroy(args[1])
        amanager.disconnect_all_node()
        print "0"
        #print "success:%d, failed:%d, not found:%d"%(ret[0], ret[1], ret[2])
#    elif service_command.__eq__("status"):
#        if len(args) < 2:
#            service_status_usage()
#            EXIT()
#        amanager = manager(options)
#        ret = amanager.service_status(args[1])
#        amanager.disconnect_all_node()
#        print "0"
#        print ret.read()
    elif service_command.__eq__("add_disk"):
        if len(args) < 3:
            service_status_usage()
            EXIT()
        amanager = manager(options)
        ret = amanager.service_add_disk(args[1], args[2:])
        amanager.disconnect_all_node()
        print "0"
        #print "success:%d, not found:%d, failed:%d, disk pop out:%d, disk not exist:%d, no connect:%d"%(ret[0], ret[1], ret[2], ret[3], ret[4], ret[5])
    elif service_command.__eq__("restart"):
        if len(args) < 2:
            service_restart_usage()
            EXIT()
        amanager = manager(options)
        amanager.service_restart(args[1])
        amanager.disconnect_all_node()
        print "0"
    elif service_command.__eq__("export_cifs"):
        if len(args) < 3:
            service_export_cifs_usage()
            EXIT()
        if len(args) == 3:
            amanager = manager(options)
            ret = amanager.service_export_cifs_all(args[1], args[2])
            amanager.disconnect_all_node()
        else:
            amanager = manager(options)
            ret = amanager.service_export_cifs(args[1], args[2], args[3:])
            amanager.disconnect_all_node()
        print "0"
        ret.seek(0)
        print ret.read()
    elif service_command.__eq__("cifs_restart_node"):
        if len(args) < 2:
            service_export_cifs_restart_node_usage()
            EXIT()
        if len(args) == 2:
            amanager = manager(options)
            ret = amanager.service_export_cifs_restart_node(args[1])
            amanager.disconnect_all_node()
        else:
            service_export_cifs_usage()
            EXIT()
        print "0"
    elif service_command.__eq__("cifs_restart_service"):
        if len(args) < 2:
            service_export_cifs_restart_service_usage()
            EXIT()
        if len(args) == 2:
            amanager = manager(options)
            ret = amanager.service_export_cifs_restart_service(args[1])
            amanager.disconnect_all_node()
        else:
            service_export_cifs_usage()
            EXIT()
        print "0"
    elif service_command.__eq__("cifs_list_user"):
        if len(args) < 2:
            service_export_cifs_list_user_usage()
            EXIT()
        if len(args) == 2:
            amanager = manager(options)
            ret = amanager.service_export_cifs_list_user(args[1])
            amanager.disconnect_all_node()
        else:
            service_export_cifs_list_user_usage()
            EXIT()
        print "0"
        ret.seek(0)
        print ret.read()
    elif service_command.__eq__("cifs_list_links"):
        if len(args) < 2:
            service_export_cifs_list_links_usage()
            EXIT()
        if len(args) == 2:
            amanager = manager(options)
            ret = amanager.service_export_cifs_list_links(args[1])
            amanager.disconnect_all_node()
        else:
            service_export_cifs_list_links_usage()
            EXIT()
        print "0"
        ret.seek(0)
        print ret.read()
    elif service_command.__eq__("cifs_del_links"):
        if len(args) < 2:
            service_export_cifs_del_links_usage()
            EXIT()
        if len(args) == 4:
            amanager = manager(options)
            ret = amanager.service_export_cifs_del_links(args[1],args[2],args[3])
            amanager.disconnect_all_node()
        else:
            service_export_cifs_del_links_usage()
            EXIT()
        print "0"
    elif service_command.__eq__("cifs_add_user"):
        if len(args) < 4:
            service_export_cifs_add_user_usage()
            EXIT()
        if len(args) == 4:
            amanager = manager(options)
            ret = amanager.service_export_cifs_add_user(args[1], args[2], args[3])
            amanager.disconnect_all_node()
        else:
            service_export_cifs_add_user_usage()
            EXIT()
        print "0"
    elif service_command.__eq__("cifs_del_user"):
        if len(args) < 3:
            service_export_cifs_del_user_usage()
            EXIT()
        if len(args) == 3:
            amanager = manager(options)
            ret = amanager.service_export_cifs_del_user(args[1], args[2])
            amanager.disconnect_all_node()
        else:
            service_export_cifs_del_user_usage()
            EXIT()
        print "0"
    elif service_command.__eq__("export_nfs"):
        if len(args) < 3:
            service_export_nfs_usage()
            EXIT()
        if len(args) == 3:
            amanager = manager(options)
            ret = amanager.service_export_nfs_all(args[1], args[2])
            amanager.disconnect_all_node()
            if args[2] != 'status':
                ret.seek(0)
                retval = ret.read()
                if retval != "0":
                    print "-1"
                    EXIT()
                else:
                    print "0"
                    EXIT()
            else:
                print "0"
                ret.seek(0)
                print ret.read()
        else:
            amanager = manager(options)
            ret = amanager.service_export_nfs(args[1], args[2], args[3:])
            amanager.disconnect_all_node()
            if args[2] != 'status':
                ret.seek(0)
                list1 = ret.read().split()
                list2 = list1[1].split(":")
                if list2[1] != "0":
                    print "-1"
                    EXIT()
                else:
                    print "0"
                    EXIT()
            else:
                print "0"
                ret.seek(0)
                print ret.read()
    elif service_command.__eq__("nfs_list_user"):
        if len(args) < 2:
            service_export_nfs_list_user_usage()
            EXIT()
        if len(args) == 2:
            amanager = manager(options)
            ret = amanager.service_export_nfs_list_user(args[1])
            amanager.disconnect_all_node()
        else:
            service_export_nfs_list_user_usage()
            EXIT()
        print "0"
        ret.seek(0)
        print ret.read()
    elif service_command.__eq__("nfs_list_links"):
        if len(args) < 2:
            service_export_nfs_list_links_usage()
            EXIT()
        if len(args) == 2:
            amanager = manager(options)
            ret = amanager.service_export_nfs_list_links(args[1])
            amanager.disconnect_all_node()
        else:
            service_export_nfs_list_links_usage()
            EXIT()
        print "0"
        ret.seek(0)
        print ret.read()
    elif service_command.__eq__("nfs_del_links"):
        if len(args) < 2:
            service_export_nfs_del_links_usage()
            EXIT()
        if len(args) == 3:
            amanager = manager(options)
            ret = amanager.service_export_nfs_del_links(args[1],args[2])
            amanager.disconnect_all_node()
        elif len(args) == 4:
            amanager = manager(options)
            ret = amanager.service_export_nfs_del_links(args[1],args[2],args[3])
            amanager.disconnect_all_node()
        else:
            service_export_nfs_del_links_usage()
            EXIT()
        print "0"
    elif service_command.__eq__("nfs_add_user"):
        if len(args) < 3:
            service_export_nfs_add_user_usage()
            EXIT()
        if len(args) == 3:
            amanager = manager(options)
            ret = amanager.service_export_nfs_add_user(args[1], args[2])
            amanager.disconnect_all_node()
        else:
            service_export_nfs_add_user_usage()
            EXIT()
        print "0"
    elif service_command.__eq__("nfs_del_user"):
        if len(args) < 3:
            service_export_nfs_del_user_usage()
            EXIT()
        if len(args) == 3:
            amanager = manager(options)
            ret = amanager.service_export_nfs_del_user(args[1], args[2])
            amanager.disconnect_all_node()
        else:
            service_export_nfs_del_user_usage()
            EXIT()
        print "0"
    elif service_command.__eq__("help"):
        service_commands_usage()
        EXIT()
    else:
        print "unkown command: \'%s\'"%(service_command)
        service_commands_usage()
        EXIT()




def main_usage ():
    print """\
-1 
available objects:
    manager_check
    manager_set
    domain_set
    domain_get
    group
    node
    service

please select an object to operate
"""

def manager_check_usage():
    print """\
-1
manager_check usage:
    manager_check ipaddr 
args:
    arg1:ipaddr.
opts:

func:
    check if manager is set.
"""

def manager_set_usage():
    print """\
-1
manager_set usage:
    manager_set ipaddr 
args:
    arg1:ipaddr.
opts:

func:
    set ipaddr as manager node.
"""

def domain_set_usage():
    print """\
-1
domain_set usage:
    domain_set domainname 
args:
    arg1:domainname.
opts:

func:
    set cluster domainname.
"""

def domain_get_usage():
    print """\
-1
domain_get usage:
    domain_get 
args:
    none.
opts:

func:
    get cluster domainname.
"""

def command_log():
    obj       = ""
    cmd       = ""
    args_list = []
    args_line = ""
    argi      = int()

    digi_debug("**************************************************************")
    if len(sys.argv) < 3:
        digi_debug("command_log, * mis object or command",3)
    else:
        obj = sys.argv[1]
        cmd = sys.argv[2]
        args_list = sys.argv[3:]
        for argi in range(len(args_list)):
            args_line = "%s argv[%d]=\"%s\""%(args_line, argi+1, args_list[argi])
        digi_debug("command_log, * execute obj:%s cmd:%s args:%s"%(obj, cmd, args_line),5)
    digi_debug("**************************************************************")

def command_lock():
    global command_lock_fd

    if not os.path.isfile(command_lock_file):
        init_config_file(command_lock_file)

    command_lock_fd = open(command_lock_file, "w")
    if fcntl.flock(command_lock_fd, fcntl.LOCK_EX) == -1:
        digi_debug("command_lock, can not get command lock",3)
        EXIT(0)

def command_unlock():
    global command_lock_fd

    if not os.path.isfile(command_lock_file):
        init_config_file(command_lock_file)
        return
    if fcntl.flock(command_lock_fd, fcntl.LOCK_UN) == -1:
        digi_debug("command_unlock, can not unlock file:%s"%(),3)
    command_lock_fd.close()

def login_check():

    if not os.path.isfile(login_lock_file):
        return False
    else:
        return True

def login():
    global login_lock_fd

    if not os.path.isfile(login_lock_file):
        init_config_file(login_lock_file)
        return

    login_lock_fd = open(login_lock_file, "w")
    #login_lock_fd.write(str(time.time()))
    if fcntl.flock(login_lock_fd, fcntl.LOCK_EX) == -1:
        digi_debug("login, can not get login lock",3)
        EXIT(0)

def logout():

    if not os.path.isfile(login_lock_file):
        init_config_file(login_lock_file)
        return
    os.remove(login_lock_file)

# check manager
def manager_check(access_ipaddr):
    manager_info = list(node_manager.get_management_node())
    if not manager_info:
        digi_debug("manager_check, manager is not set",3)
        #print "16001"
        EXIT(16001)
    else:
        # check if manager_info is the same as manager 
        manager_info = list(node_manager.get_management_node())
        try:
            remote_manager_info = node_manager.remote_get_management_info(*manager_info).split()
        except Exception,e:
            digi_debug("manager_check, caught exception: %s" % e,3)
            #print "16003"
            EXIT(16003)
        #if manager_info != remote_manager_info: 
        if access_ipaddr not in manager_info: 
            digi_debug("manager_check, there is another manager in this cluster!",3)
            #print "16002"
            EXIT(16002)
            #return "there is another manager in this cluster!"
        else:
            #return "this is the cluster manager"
            digi_debug("manager_check, this is the cluster manager",3)
            print "0"
            EXIT()

def manager_set(ipaddr):
    manager_info = list(node_manager.get_management_node())
    if manager_info:
        digi_debug("manager_set, manager is not set",3)
        #print "16002"
        EXIT(16002)
    try:
        node_name = socket.gethostname()
        #ipaddr = socket.gethostbyaddr(node_name)[2][0]
        node_manager.set_management_node(node_name, ipaddr)
        print "0"
        EXIT(0)
    except Exception,e:
        digi_debug("manager_set, caught exception: %s" % e,3)
        #print "16004"
        EXIT(16004)

def domain_set(domainname):
    try:
        if os.path.exists(settings.PRIDOMAINPATH):
            EXIT(16008)
        if not node_name_check(domainname):
            EXIT(16009)
        f = open(settings.PRIDOMAINPATH,'w+')
        f.write(domainname)
        f.close()
        print "0"
        EXIT(0)
    except Exception,e:
        digi_debug("domain_set, caught exception: %s" % e,3)
        EXIT(16007)

def domain_get():
    try:
        if not os.path.exists(settings.PRIDOMAINPATH):
            EXIT(16010)
        f = open(settings.PRIDOMAINPATH,'r')
        domainname = f.read().strip()
        f.close()
        print "0"
        print domainname
        EXIT(0)
    except Exception,e:
        digi_debug("domain_get, caught exception: %s" % e,3)
        EXIT(16011)

def get_local_ip_list():
    fd = os.popen("ifconfig | grep addr: |grep -v '127.0.0.1'")
    content = fd.readlines()
    fd.close()
    ip_list = []
    for aline in content:
        if len(aline.strip()) == 0:
            continue
        tmp_list = aline.split()
        ip_addr = tmp_list[1].split(":")[1]
        ip_list.append(ip_addr)
        
    return ip_list

def manager_get():
    manager_info = list(node_manager.get_management_node())
    if not manager_info:
        digi_debug("manger_get, manager is not set",3)
        #print "16002"
        EXIT(16002)
    else:
        try:
            manager_ipaddr = manager_info[1]
        except:
            digi_debug("error arise when get manager ipaddr",3)
            #print "16005" 
            EXIT(16005)
        print "0"
        print manager_ipaddr 
        EXIT()

if __name__ == "__main__":
    digi_debug("################# cmd start ################")
    try:
        command_lock()
        command_log()

        if len(sys.argv) < 2:
            main_usage()
            EXIT()

        obj = sys.argv[1]

        # check if manager is set or this server is manager        
        if obj.__eq__("manager_check"):
            if len(sys.argv) != 3 or not sys.argv[2] :
                manager_check_usage()
                EXIT()
            if not checkIP(sys.argv[2]):
                manager_check_usage()
                EXIT()
            manager_check(sys.argv[2])
        elif obj.__eq__("manager_set"):
            if len(sys.argv) != 3 or not sys.argv[2]: 
                manager_set_usage()
                EXIT()
            if not checkIP(sys.argv[2]):
                manager_set_usage()
                EXIT()
            manager_set(sys.argv[2])
        elif obj.__eq__("domain_set"):
            if len(sys.argv) < 3 or not sys.argv[2]: 
                domain_set_usage()
                EXIT()
            domain_set(sys.argv[2])
        elif obj.__eq__("domain_get"):
            if len(sys.argv) != 2: 
                domain_get_usage()
                EXIT()
            domain_get()
        elif obj.__eq__("manager_get"):
            manager_get()
    
        if obj.__eq__("group"):
            group_commands(sys.argv[2:])
        elif obj.__eq__("node"):
            node_commands(sys.argv[2:])
        elif obj.__eq__("service"):
            service_commands(sys.argv[2:])
        else:
            print "unkown object: \'%s\'"%(sys.argv[1])
            main_usage()
            EXIT(0)
    except DigioceanfsError, e:
        print e
        if e.err_num == -1:
            digi_debug("**ERROR:%s" % traceback.format_exc(), 3)
    finally:
        digi_debug("################# cmd over ################")
        destroy_manager_log()
        backup_utils.mark_conf_file_updated()
        
        try:
            EXIT()
        except ValueError,e:
            pass
