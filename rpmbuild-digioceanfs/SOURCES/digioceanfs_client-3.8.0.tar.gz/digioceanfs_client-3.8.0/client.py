#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
#import subprocess
import tempfile
#import dircache
#import pickle
#import re
#import thread
#import threading
import time
#import signal
#import dircache
import traceback
import Queue
#import Digioceanfs_error
#import random as ran
#from optparse import OptionParser
#from optparse import Values

sys.path.append('/usr/local/digioceanfs_client')

import settings

import traceback
import syslog

#from digi_manager import node

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)

transportpath = os.path.join(currpath[:currpath.rfind('manager')],'transport')
if not transportpath in sys.path:
    sys.path.append(transportpath)

utilspath = os.path.join(currpath[:currpath.rfind('manager')],'utils')
if not utilspath in sys.path:
    sys.path.append(utilspath)
    
import manager_utils

from manager_utils import *
import ipsan.utils as utils

from digiserver import DigiServer

#from manager_protocol import *

#from localthread import *
SUDO='/usr/bin/sudo'
MOUNT = '/bin/mount'
UMOUNT = '/bin/umount'
DIGIOCEANFS = 'digioceanfs'
DIGIOCEAN = '/usr/sbin/digiocean'

PROC_QUEUE = Queue.Queue() 
syslog.openlog('Digioceanfs Client')

def collect_result(result):
    PROC_QUEUE.put(result)
    
def auto_mount():
    retcode,proc = utils.cust_popen2([DIGIOCEAN, 'volume', 'list'])
    mount_service = '127.0.0.1:/%s' 
    mount_point = '/cluster2/%s'
    syslog.syslog('digiocean vol list %s return %s' % (mount_service, retcode))
    if not retcode:
        out = proc.stdout.readlines()
        for service in out:
            service = service.strip()
            if service == 'ctdb':
                continue
            if not os.path.exists(mount_point % service):
                try:
                    os.mkdir(mount_point % service)
                except Exception, e:
                    pass
                os.system('chmod 777 %s  >/dev/null 2>&1' % (mount_point % service))
            retcode,proc = utils.cust_popen2([SUDO,MOUNT,'-t',DIGIOCEANFS, mount_service % service, mount_point % service])
            syslog.syslog('client mount service %s return %s' % (mount_service, retcode))
            if retcode:
                syslog.syslog(proc.stdout.read())
    else:
        syslog.syslog(proc.stdout.read())

def get_mount_point ():
    mounts = []
    mount = {}
    retcode,proc = utils.cust_popen(MOUNT)
    results = proc.stdout.readlines()
    for result in results:
        if result.find('fuse.digioceanfs') != -1:
            a = result.split(' ')
            i = a[0].find(':')
            mount['ip'] = a[0][:i].strip()
            mount['service'] = a[0][i+2:].strip()
            mount['point'] = a[2]
            mounts.append(mount)
            mount = {}
    return mounts

def set_hosts(data):
    self_hosts_img = get_hosts_img()
    hosts_img = data
    new_hosts_list = hosts_img.split('\n')
    tmp_hosts_list = []
    try:
        ret = clear_hosts()
        if ret != '0':
            return '-1'
    except Exception, e:
        return '-1'
    for host in self_hosts_img.split('\n'):
        if host and host.find('####DigioceanfsClient####') < 0:
            tmp_hosts_list.append(host)
    for host in new_hosts_list:
        if host.find('####DigioceanfsNode####') >= 0:
            tmp_hosts_list.append((host.replace('####DigioceanfsNode####','####DigioceanfsClient####')))
    
    if tmp_hosts_list:
        set_hosts_img('\n'.join(tmp_hosts_list) +'\n')

    return '1'
'''
    ret = set_hosts_img(hosts_img)
    if not ret:
        print "**ERROR: Node manager, set hosts failed"
        return "-1"
        #raise DigioceanfsError
    else:
        return "1"
'''
        
def clear_hosts():
    rfd = open("/etc/hosts", "r")
    lines = rfd.readlines()
    new_lines = []
    for aline in lines:
        if aline.find('####DigioceanfsClient####') < 0:
            new_lines.append(aline)
    rfd.close()
    rst_str = ''.join(new_lines).strip()
    wfd = open("/etc/hosts", "w")
    wfd.write(rst_str)
    wfd.close()
    return '0'

def protocol_parse (type, payload):
    syslog.syslog('Client receive message type : %s' % type)
    data = simplejson.loads(payload)
    if type == 90:
        service_name = data[0]
        mount_service = '127.0.0.1:/%s' % service_name
        mount_point = '/cluster2/%s' % service_name
        if not os.path.exists(mount_point):
            try:
                os.system('mkdir -p %s ' % (mount_point))
            except Exception, e:
                pass
            os.system('chmod 777 %s  >/dev/null 2>&1' % (mount_point))
        retcode,proc = utils.cust_popen2([SUDO,MOUNT,'-t',DIGIOCEANFS,mount_service,mount_point])
        out = proc.stdout.read() + ' ' + proc.stderr.read()
        syslog.syslog('client start service %s return %s' % (service_name, retcode))
        syslog.syslog(out)
        if out.strip() == '':
            collect_result('0')
        elif out.find('DigioceanFS is already mounted') != -1:
            collect_result('-1')
        elif out.find('Mount point does not exist.') != -1:
            collect_result('-2')
        else:
            collect_result('-3')
    elif type == 91:
        service_name = data[0]
        mount_service = '127.0.0.1:/%s' % data[0]
        mount_point = '/cluster2/%s' % data[0]
        retcode,proc = utils.cust_popen2([SUDO,UMOUNT,mount_point])
        syslog.syslog('client stop service %s return %s' % (service_name, retcode))
        out = proc.stdout.read() + ' ' + proc.stderr.read()
        syslog.syslog(out)
        if out.strip() == '':
            collect_result('0')
        elif out.find('DigioceanFS is already mounted') != -1:
            collect_result('-1')
        elif out.find('Mount point does not exist.') != -1:
            collect_result('-2')
        elif out.find('device is busy') != -1:
            collect_result('-3')
        else:
            collect_result('-4')
    elif type == 92:
        service_name = data[0]
        mounted = os.path.ismount('/cluster2/%s' % service_name)
        if mounted:
            syslog.syslog('client mount service status %s return %s' % (service_name, mounted))
            collect_result('1')
        else:
            collect_result('-1')
    elif type == 87:
        try:
            collect_result(set_hosts(data))
        except Exception,e:
            traceback.print_exc(e)
    elif type == 88:
        os.system("killall digioceanfs")
        collect_result(clear_hosts())
        
def protocol_post ():
	pass

def msg_lock_acquire ():
	pass

def msg_lock_release ():
	pass

def proc_queue_handler():
    try:
        return (PROC_QUEUE.empty(), PROC_QUEUE.get())
    except Exception, e:
        #digi_debug("Node manager caught expection: %s when collect result to queue" % e, 3)
        return (False, "error raise in queue") 

if __name__ == "__main__":
    auto_mount()
    s = DigiServer(('0.0.0.0', 9996),
                       protocol_parse,
                       protocol_post,
                       msg_lock_acquire,
                       msg_lock_release,
                       proc_queue_handler)

    s.start_loop()
