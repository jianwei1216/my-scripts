import os
#system#
path_list = []
HOSTFILE = '/etc/hosts'
HOSTNAMEFILE = '/etc/sysconfig/network'
RCLOCALPATH = '/etc/rc.local'
NFSCONF = '/etc/exports'
NFSRMTAB = '/var/lib/nfs/rmtab'
SMBCONF = '/etc/samba/smb.conf'
SHADOW = '/etc/shadow'
PASSWD = '/etc/passwd'
SMBPASSWD = '/usr/bin/smbpasswd'
SMBSTATUS = '/usr/bin/smbstatus'
USERADD = '/usr/sbin/useradd'
USERDEL = '/usr/sbin/userdel'
USERMOD = '/usr/sbin/usermod'
NETSTAT = '/bin/netstat'
MDSTAT = '/proc/mdstat'
CPUINFO = '/proc/cpuinfo'
RSYSLOG = '/etc/init.d/rsyslog'

#network#
# For debian6
ETHFILE = '/etc/network/interfaces'
IFCONFIG = '/sbin/ifconfig'
MIITOOL = '/sbin/mii-tool'
ALLNETINFO = '/sys/class/net'

# For CentOS 6+

#disk#
SCSIDEVICE = '/sys/class/scsi_device'
SASDEVICE = '/sys/class/sas_device'
DISKDEVICE = '/sys/block/%s/device'
DISKDEV = '/sys/class/scsi_device/%s/device/block'
JOBD = '/usr/local/admin/softraid/jobd'
PARTITIONS = '/proc/partitions'
DISKSERIAL = '/dev/disk/by-id'
SYSBLOCK = '/sys/block'
DMIDECODE = '/usr/sbin/dmidecode'

#others#
USERNAMEPREFIX = 'digioceanfs_smb_'
SMBCONFPREFIX = '/etc/digioceanfs/services'
SMBSERVICENAME = 'smbd'
SAMBA=os.path.exists("/etc/init.d/samba") and '/etc/init.d/samba' or '/etc/init.d/smb' 
SYNC_SCRIPT='/usr/local/digioceanfs_manager/utils/disk_sync.pyc'

#gluster-3.4
DIGIOCEAN='/usr/sbin/digiocean'
MOUNT='/bin/mount'
BLKID="/sbin/blkid"
MKFS='/sbin/mkfs.xfs'
ATTR='/usr/bin/attr'
CLEAR_ATTR='/usr/bin/clear_xattr'
DIGIOCEAND = '/etc/init.d/digioceand'

import utils.manager_utils
item_list =  globals() 
def _path_check(item_list=globals()):
    # core cmd check
    import os
    for k,v in item_list.items():
        if type(k) == str:
            if k == "DISKDEVICE" or k == "DISKDEV" or k == "JOBD" or k == "ETHFILE" or k == "SMBCONFPREFIX" or k == 'SASDEVICE' or k == 'SCSIDEVICE':
                continue
        if v and type(v) == str and v[0] == '/':
            utils.manager_utils.DEBUG_LVL = 7
            if not (os.path.isdir(v) or os.path.isfile(v)):
                utils.manager_utils.digi_debug("**ERROR: Path or Command: %s not found, exiting now ..." % v, 3)
                exit()
            else:
                try:
                    utils.manager_utils.digi_debug("**DEBUG: Path or Command: %s found, continue ..." % v, 7)
                except Exception, e:
                    print e
        else:
            continue

def _os_check():
    pass

if __name__ == "__main__":
    _path_check(item_list)
