#!/usr/bin/python
#-*- coding: UTF-8 -*-

import os
import sys
import re
import stat
import subprocess
import traceback
import platform

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if currpath not in sys.path:
    sys.path.append(currpath)

VGLOCK = '/var/lock/digitools/vglock'
DISKLOCK = '/var/lock/digitools/disklock'
RAIDLOCK = '/var/lock/digitools/raidlock'
COPYLOCK = '/var/lock/digitools/copylock'
NETLOCK = '/var/lock/digitools/netlock'
#-------------------------
# globals
#-------------------------
#-----------------------
#	Exceptions
#-----------------------
class ExecCommandError(Exception):
    pass
#-----------------------
#	functions
#-----------------------
def cust_popen(cmd,close_fds=True):
    try:
        proc = subprocess.Popen('sudo %s' % cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=close_fds)
        retcode = proc.wait()
        return retcode,proc
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        raise ExecCommandError,e

def cust_popen2(cmdlist,close_fds=True):
    lastcmdlist = ['sudo']
    lastcmdlist.extend(cmdlist)
    try:
        proc = subprocess.Popen(lastcmdlist,shell=False,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=close_fds)
        retcode = proc.wait()
        return retcode,proc
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        raise ExecCommandError,e
        
def cust_popen3(cmd,close_fds=True):
    try:
        proc = subprocess.Popen('sudo %s' % cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=close_fds)
        return proc
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        raise ExecCommandError,e

def change_fstat(filepath):
    fstat = int(oct(stat.S_IMODE(os.stat(filepath).st_mode)))
    retcode,proc = cust_popen('chmod 777 %s' % filepath)
    return fstat

def recover_fstat(filepath,fstat):
    retcode,proc = cust_popen('chmod %d %s' % (int(fstat),filepath))
        
def cust_fopen(filepath,mode='r'):
    if os.path.exists(filepath):
        fstat = change_fstat(filepath)
        f = open(filepath,mode)
        return f,fstat
    else:
        if mode.startswith('a') or mode.startswith('w') or mode.startswith('r+'):
            parentdir = os.path.split(filepath)[0]
            if not os.path.exists(parentdir):
                retcode,proc = cust_popen2(['mkdir','-p',parentdir])
            retcode,proc = cust_popen('touch %s' % filepath)
            fstat = change_fstat(filepath)
            f = open(filepath,mode)
            return f,fstat
        else:
            raise IOError,'%s not exists' % filepath

def cust_fclose(f,fstat):
    recover_fstat(f.name,fstat)
    f.close()
#------------------------
# sort disk id
#------------------------
def embedded_numbers(s):  
    re_digits = re.compile(r'(\d+)') 
    pieces = re_digits.split(s)
    pieces[1::2] = map(int, pieces[1::2])
    return pieces
    
def sort_strings(alist):  
    return sorted(alist, key=embedded_numbers)
#-------------------------
# 
#-------------------------
class Storage(dict):
    """
    A Storage object is like a dictionary except `obj.foo` can be used
    in addition to `obj['foo']`.
    
        >>> o = storage(a=1)
        >>> o.a
        1
        >>> o['a']
        1
        >>> o.a = 2
        >>> o['a']
        2
        >>> del o.a
        >>> o.a
        Traceback (most recent call last):
            ...
        AttributeError: 'a'
    
    """
    def __getattr__(self, key): 
        try:
            return self[key]
        except KeyError, k:
            raise AttributeError, k
    
    def __setattr__(self, key, value): 
        self[key] = value
    
    def __delattr__(self, key):
        try:
            del self[key]
        except KeyError, k:
            raise AttributeError, k
    
    def __repr__(self):     
        return '<Storage ' + dict.__repr__(self) + '>'

def check_if_debian6():
    DEBIAN6 = False
    pf = platform.platform()
    if pf.find('debian-6') >= 0:
        DEBIAN6 = True
    return DEBIAN6

#-----------------------------------
# check lock exists
#-----------------------------------
def is_lock(locktype):
    islock = False
    lockfile = eval('%sLOCK' % locktype.upper())
    if os.path.isfile(lockfile):
        islock = True
    return islock
#-----------------------------------
# set lock
#-----------------------------------
def set_lock(locktype):
    lockstat = False
    lockstr = '%slock' % locktype
    lockfile = eval('%sLOCK' % locktype.upper())
    try:
        if not os.path.isfile(lockfile):
            retcode,proc = cust_popen2(['mkdir','-p',lockfile.replace(lockstr,'')])
            f,fstat = cust_fopen(lockfile,'w')
            cust_fclose(f,fstat)
            lockstat = True
    except:
        print >> sys.stderr,traceback.print_exc()
    return lockstat
#-----------------------------------
# release lock
#-----------------------------------
def release_lock(locktype):
    releasestat = False
    trytime = 0
    maxtrytime = 3
    lockfile = eval('%sLOCK' % locktype.upper())
    try:
        if os.path.isfile(lockfile):
            while trytime < maxtrytime and not releasestat:
                retcode,proc = cust_popen2(['rm','-rf',lockfile])
                if retcode == 0:
                    releasestat = True
                else:
                    trytime += 1
    except:
        print >> sys.stderr,traceback.print_exc()
    return releasestat
