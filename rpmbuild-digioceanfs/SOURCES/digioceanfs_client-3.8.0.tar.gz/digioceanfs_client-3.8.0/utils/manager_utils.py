# -*- coding: utf-8 -*-
import os
import sys
import StringIO
import time
import logging
import subprocess
import tempfile
import types
import dircache
import fcntl
import re
import signal
import simplejson
import syslog
import inspect
import traceback
#import pexpect

import settings

from log import Log
from os.path import *
from ipsan.baseboard import get_diskmap

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)

manager_path = os.path.join(currpath[:currpath.rfind('utils')],'manager')
if not manager_path in sys.path:
    sys.path.append(manager_path)
from Digioceanfs_error import DigioceanfsError

#HOSTS_FILE="/etc/hosts"

#HOSTNAME_FILE="/etc/hostname"
HOSTNAME_FILE=settings.HOSTNAMEFILE

LOG_FILE_PATH="/var/log/digioceanfs_manager/server.log"

PROC_PIPE_PATH="/usr/local/digioceanfs_manager/manager/processing_pipe"

DEV_ID_DIR="/dev/disk/by-id"

POSITION_CONF = "/usr/local/admin/softraid/raidconfig/lib/"

#RCLOCALPATH = "/etc/rc.local"
RCLOCALPATH = settings.RCLOCALPATH

#MDSTAT = '/proc/mdstat'
#SCSIDEVICE = '/sys/class/scsi_device/'
#SASDEVICE = '/sys/class/sas_device/'
#DISKDEVICE = '/sys/block/%s/device'
#DISKDEV = '/sys/class/scsi_device/%s/device/block'
#JOBD = '/usr/local/admin/softraid/jobd'
#PARTITIONS = '/proc/partitions'
#DISKSERIAL = '/dev/disk/by-id/'
#SYSBLOCK = '/sys/block/'
#DMIDECODE = '/usr/sbin/dmidecode'

MDSTAT = settings.MDSTAT 
SCSIDEVICE = settings.SCSIDEVICE 
SASDEVICE = settings.SASDEVICE 
DISKDEVICE = settings.DISKDEVICE 
DISKDEV = settings.DISKDEV 
JOBD = settings.JOBD 
PARTITIONS = settings.PARTITIONS 
DISKSERIAL = settings.DISKSERIAL 
SYSBLOCK = settings.SYSBLOCK 
DMIDECODE = settings.DMIDECODE 

NODEMARK = "####DigioceanfsNode####"
DEBUG_LVL = None
currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
#utilspath = os.path.join(currpath, 'utils')

if not os.path.exists('/sys/class/sas_device/') or len(os.listdir('/sys/class/sas_device/')) == 0:
        diskCate = 'sata'
else:
        diskCate = 'sas'


if 'log_fd' not in globals():
    log_fd = None
else:
    log_fd = globals()['log_fd']

#######################################################
#   
#    System Log Suite
#
#######################################################

LOG_LEVEL = ['M', 'A', 'C', 'E', 'W', 'N', 'I', 'D']

LOG_LEVEL_EMERG   = 0
LOG_LEVEL_ALERT   = 1
LOG_LEVEL_CRIT    = 2
LOG_LEVEL_ERR     = 3
LOG_LEVEL_WARNING = 4
LOG_LEVEL_NOTICE  = 5
LOG_LEVEL_INFO    = 6
LOG_LEVEL_DEBUG   = 7

# Serious message will be record in syslog
LOG_LEVEL_NOTIFY  = LOG_LEVEL_ERR 

MANAGER_IDENT = "DigiManager"

def init_manager_log():
    #syslog.openlog( MANAGER_IDENT,syslog.LOG_PID,syslog.LOG_DAEMON)
    #return
    from log import Log
    logger = Log()

def destroy_manager_log():
    syslog.closelog()
    return

def valid_log_level(lv):
    if lv >= LOG_LEVEL_EMERG and lv <= LOG_LEVEL_DEBUG:
        return True
    return False

def set_notify_level(lv):
    if valid_log_level(lv):
        LOG_LEVEL_NOTIFY = lv
    return

def get_notify_level():
    return LOG_LEVEL_NOTIFY

def log_level(lv):
    level = None
    if lv == LOG_LEVEL_EMERG:
        level = syslog.LOG_EMERG 
    elif lv == LOG_LEVEL_ALERT:
        level = syslog.LOG_ALERT
    elif lv == LOG_LEVEL_CRIT:
        level = syslog.LOG_CRIT
    elif lv == LOG_LEVEL_ERR:
        level = syslog.LOG_ERR
    elif lv == LOG_LEVEL_WARNING:
        level = syslog.LOG_WARNING
    elif lv == LOG_LEVEL_NOTICE:
        level = syslog.LOG_NOTICE
    elif lv == LOG_LEVEL_INFO:
        level = syslog.LOG_INFO
    elif lv == LOG_LEVEL_DEBUG:
        level = syslog.LOG_DEBUG
    else:
        level = syslog.LOG_DEBUG
        lv    = LOG_LEVEL_DEBUG

    return (level, LOG_LEVEL[lv], lv)

#############################################################
#                                                           #
#    Config file operations                                 #
#                                                           #
#############################################################

def init_dir (dir_path,chattr=False,mode=511):
    
    if not os.path.isdir(dir_path) :
#        digi_debug("manager_utils:config directory not exist")
        try :
            os.makedirs(dir_path, mode)
            if chattr != False:
                cmd = []
                cmd.append(settings.CHATTR)
                cmd.append("+i")
                cmd.append(dir_path)
                ret = execute(cmd)
                if ret:
                    digi_debug("Node manager, Chattr file %s failed." % dir_path,5)
                else:
                    digi_debug("Node manager, Chattr file %s success." % dir_path,7)
        except OSError,e:
            digi_debug("**ERROR: Init dir failed: %s" % e, 3)
            #raise DigioceanfsError
#            digi_debug("manager_utils:can not init config file.%s"%(e))

def init_config_file (file_path):
    config_file_dir = os.path.dirname(file_path)
    if not os.path.isdir(config_file_dir) :
#        digi_debug("manager_utils:config directory not exist")
        try :
            os.makedirs(config_file_dir)
        except OSError,e:
            digi_debug("**ERROR: Init config file failed: %s" % e, 3)
#            digi_debug("manager_utils:can not init config file.%s"%(e))
            return False
    file = open(file_path, "w")
    file.close()

    return True

def get_config_file(file_path, lock=False):
    try:
        config_file = open(file_path, "r")
    except IOError,e:
        digi_debug("**ERROR: Get config file failed: %s" % e, 3)
        if e.errno == 2:
#            digi_debug("manager_utils:config file not exist.%s"%(e))
            config_file = init_config_file(file_path)
            config_file = open(file_path, "r")
        else:
            digi_debug("**ERROR: Get config file failed: %s" % e, 3)
#            digi_debug("manager_utils:can not open config filei.%s"%(e))
            return None
    if lock:
        if fcntl.flock(config_file, fcntl.LOCK_SH) == -1:
            digi_debug("**ERROR: Get config file can not lock file:%s!!!"%(file_path), 2)
    config_img = StringIO.StringIO(config_file.read())
    if lock:
        if fcntl.flock(config_file, fcntl.LOCK_UN) == -1:
            digi_debug("**ERROR: Get config file can not unlock file:%s!!!"%(file_path), 2)
    config_file.close()
    return config_img

def set_config_file(file_path, conf_img):
    try:
        config_file = open(file_path, "w")
    except IOError,e:
        digi_debug("**ERROR: Set config file failed: %s" % e, 3)
        if e.errno == 2:
#            digi_debug("manager_utils:config file not exist.%s"%(e))
            config_file = init_config_file(file_path)
            config_file = open(file_path, "w")
        else:
            digi_debug("**ERROR: Set config file failed: %s" % e, 3)
            return False
    conf_img.seek(0)
    config_file.truncate()
    try:
        config_file.write(conf_img.read())
    except:
        config_file.close()
        digi_debug("**ERROR: Set config file failed: %s" % e, 3)
        return False
    config_file.close()
    return True

def inotify_wait(file_path, event, time_out):
    """
        return code specify:
        0:    event occured
        1:    file not exist
        2:    event not occured
        3:    other error
    """
    cmd = []
    cmd.append("/usr/bin/inotifywait")
    cmd.append("-e")
    cmd.append(event)
    cmd.append("-t")
    cmd.append(time_out)
    cmd.append(file_path)
    ret = execute(cmd)
    if ret >= 0 and ret <= 2:
        return ret
    return 3

def property_init(file_path):
    property_dict = None
    if not os.path.isfile(file_path):
        property_dict = {}
        property_package = simplejson.dumps(property_dict)
        property_img = StringIO.StringIO(property_package)
        set_config_file(file_path, property_img)
    else:
        property_img = get_config_file(file_path)
        property_package = property_img.read()
        property_dict = simplejson.loads(property_package)

    return [file_path, property_dict]

def property_get(file_property, name):
    file_path = file_property[0]
    property_dict = file_property[1]
    if not property_dict.__contains__(name):
        return None
    return property_dict[name]

def property_set(file_property, name, value):
    file_path = file_property[0]
    property_dict = file_property[1]
    property_dict[name] = value

    property_package = simplejson.dumps(property_dict)
    property_img = StringIO.StringIO(property_package)
    set_config_file(file_path, property_img)

    return True

#############################################################
#                                                           #
#    Log utils.                                             #
#                                                           #
#############################################################

def set_log_file(log_file_path):
    global LOG_FILE_PATH
    LOG_FILE_PATH = log_file_path

def digi_debug(msgStr, lvl=7):
    Log()
    logger = logging.getLogger("nodeManager")
    if lvl == 2:
        logger.critical(msgStr)
    elif lvl == 3:
        logger.error(msgStr)
    elif lvl == 4:
        logger.warn(msgStr)
    elif lvl == 5:
        logger.info(msgStr)
    elif lvl == 7:
        logger.debug(msgStr)
    else:
        logger.error(msgStr)

def _digi_debug(s, l=7):
    
    import exception_utils
    global log_fd
    global DEBUG_LVL
    can_open = True
    
    level, mark, l = log_level(l)

    while not log_fd:
        try:
            log_fd = open(LOG_FILE_PATH, "a")
        except:
            if not can_open:
                print "can not open log file:%s"%(LOG_FILE_PATH)
                return False
            os.makedirs(dirname(LOG_FILE_PATH))
            can_open = False
            continue
    try:
        exception_utils.uni_exception_handler(s, log_fd, None)
        
    except Exception, e:
        print >> log_fd, "***Exception Handler Failed:"
        print >> log_fd, str(e) 
  
    st = inspect.stack()[1]

    time_now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
#    print "%s: %s"%(time_now, s)

    if l == LOG_LEVEL_INFO:
        msg = "%s [%s]: %s"%(time_now, mark, s)
    elif l == LOG_LEVEL_DEBUG:
        msg = "%s [%s]: %s"%(time_now, mark, s)
    else:    
        msg = "%s [%s]: %s"%(time_now, mark, s)
    
    if l <= DEBUG_LVL:
        print >> log_fd, msg
        log_fd.flush()
    
    syslog_msg = str(s)
    if l <= DEBUG_LVL and syslog_msg:#sget_notify_level(): 
        syslog.syslog(level, syslog_msg)
    
    return True

#############################################################
#                                                           #
#    Process operations.                                    #
#                                                           #
#############################################################

def execute(cmd, std=None, stdi=None, shell=False, nowait=False, communicate='', err_ignore=False):
    try:
        use_black_hole = False
        if not std:
            use_black_hole = True
            std = tempfile.TemporaryFile()
        proc = subprocess.Popen(cmd, stdout=std, stderr=std, stdin=stdi, close_fds=True, shell=shell)
        if nowait:
            return proc.pid
        if communicate:
            proc.communicate(input=communicate)
            ret = proc.wait()
            std.seek(0)
            return ret
        ret = proc.wait()
        if use_black_hole:
            std.close()
        else:
            std.seek(0)
        if type(cmd) == list:
            cmd_string = ' '.join(cmd)
        if err_ignore:
            digi_debug("**DEBUG: Execute command: %s return %s" % (cmd_string, ret), 5)
        else:
            if not ret:
                digi_debug("**DEBUG: Execute command: %s return %s" % (cmd_string, ret), 7)
            else:
                digi_debug("**ERROR: Execute command: %s return %s" % (cmd_string, ret), 3)
        return ret
    except Exception,e:
        digi_debug("**ERROR: [Exception]: In execute command, caught exception: %s" % (e), 1)
        print e
        raise DigioceanfsError(11072)

#def pexpect_execute(cmd, communicate):
#    try:
#        child = pexpect.spawn(' '.join(cmd))
#        while True:
#            i = child.expect(['(y/n)'])
#            if i is 0:
#                child.sendline(communicate)
#                break
#        child.expect([pexpect.EOF, pexpect.TIMEOUT, '#'])
#    except Exception,e:
#        print e
#    return 0


def child_return(pid):
    try:
        ret = os.waitpid(pid, os.WNOHANG)
    except Exception,e:
        digi_debug("**ERROR: Child process execute raise error: %s" % e, 3)
        if e.args[0] == 10:
            return True
    #if child process does not return, waitpid return a pid of 0
    return ret[0] != 0

def child_kill(pid):
    os.kill(pid, signal.SIGTERM)

def return_or_kill(pid, timeout):
    for i in range(timeout):
        if child_return(pid):
            digi_debug("**DEBUG: Child:%d exit success" % (pid), 7)
            return True
        digi_debug("**DEBUG: Wait %d second for child:%d to exit" % (i, pid), 7)
        time.sleep(0.1)
        if child_return(pid):
            digi_debug("**DEBUG: Child:%d exit success"%(pid), 7)
            return True
    digi_debug("**DEBUG: Child:%d not return, kill it!"%(pid), 7)
    child_kill(pid)
    return False

#############################################################
#                                                           #
#    Operations for file "/etc/hosts".                      #
#                                                           #
#############################################################

def add_host(new_host_name, new_host_ip):
    """
        return code specify:
        1:    add host success
        2:    host ip exist
        3:    host name exist
        4:    hosts file parse error 
    """
    #hosts_img = get_config_file(HOSTS_FILE)
    hosts_img = get_config_file(settings.HOSTFILE)
    hosts_lines = hosts_img.readlines()
    if not hosts_lines:
        digi_debug("**ERROR: Get host file content from %s return: %s" % (hosts_lines, new_host_ip), 3)
        return 4
    for a_line in hosts_lines:
        if len(a_line) < 2:
            continue
        if a_line[0] == '#':
            continue
        if a_line.find(NODEMARK) < 0:
            continue
        host_ip = a_line.split()[0]
        if new_host_ip == host_ip:
            digi_debug("**ERROR: Found host ip exist in %s hosts file" % new_host_ip, 3)
            return 2
        host_names = a_line.split('\n')[0].split()[1:]
        for host_name in host_names:
            if new_host_name == host_name:
                digi_debug("**ERROR: Found host name exist in %s hosts file" % new_host_ip, 3)
                return 3
    if len(hosts_lines[-1].split('\n')) > 1:
        hosts_lines.append("%s %s %s\n"%(new_host_ip, new_host_name, NODEMARK))
    else:
        hosts_lines.append("\n%s %s %s\n"%(new_host_ip, new_host_name, NODEMARK))
#    digi_debug(hosts_lines)
    hosts_img_new = StringIO.StringIO()
    for a_line in hosts_lines:
        hosts_img_new.write(a_line)
    #set_config_file(HOSTS_FILE, hosts_img_new)
    set_config_file(settings.HOSTFILE, hosts_img_new)
    digi_debug("**DEBUG: Add host success in %s hosts file" % new_host_ip, 7)
    return 1

def append_host(old_host_name, append_hostnames):
    """
        return code specify:
        1:    append host success
        2:    host not exist
    """
    digi_debug("**DEBUG: Append hostname:%s to host:%s"%(append_hostnames, old_host_name), 7)
    #hosts_img = get_config_file(HOSTS_FILE)
    hosts_img = get_config_file(settings.HOSTFILE)
    hosts_lines = hosts_img.readlines()
    for a_line in hosts_lines:
        if len(a_line) < 2:
            continue
        if a_line[0] == '#':
            continue
        host_ip = a_line.split()[0]
        host_name = a_line.split('\n')[0].split()[1]
        if host_name == old_host_name:
            break
    else:
        digi_debug("**ERROR: Host not exist on %s" % old_host_name, 3)
        return 2

    hosts_lines.remove(a_line)
    for ahostname in append_hostnames:
        a_line = "%s %s\n"%(a_line.split('\n')[0], ahostname)
    hosts_lines.append(a_line)

    digi_debug("**DEBUG: After host append, hosts:%s"%(hosts_lines), 7)
    hosts_img_new = StringIO.StringIO()
    for a_line in hosts_lines:
        hosts_img_new.write(a_line)
    #set_config_file(HOSTS_FILE, hosts_img_new)
    set_config_file(settings.HOSTFILE, hosts_img_new)
    digi_debug("**DEBUG: Append host success on node %s" % old_host_name, 7)
    return 1

def del_host(old_host_name, old_host_ip="", server_img=None):
    """
        return code specify:
        hostnames:    del host success
        None:         host not exist
    """
    digi_debug("**DEBUG: delete hostname:%s"%(old_host_name),5)
    #hosts_img = get_config_file(HOSTS_FILE)
    #hosts_lines = hosts_img.readlines()
    if not server_img:
        #hosts_img = get_config_file(HOSTS_FILE)
        hosts_img = get_config_file(settings.HOSTFILE)
        hosts_lines = hosts_img.readlines()
        digi_debug("**DEBUG: %s" % hosts_lines,5)
    else:
        hosts_img = server_img
        hosts_lines = hosts_img.readlines()
        digi_debug("**DEBUG: %s" % hosts_lines,5)

    for a_line in hosts_lines:
        if len(a_line) < 2:
            continue
        if a_line[0] == '#':
            continue
        if a_line.find(NODEMARK) < 0:
            continue
        host_ip = a_line.split()[0]
        host_name = a_line.split('\n')[0].split()[1]
        if old_host_name == host_name:
            break
    else:
        digi_debug("**ERROR: Host name not exist on %s" % old_host_name, 3)
        return None
    hosts_lines.remove(a_line)

    deleted_hostnames = a_line.split('\n')[0].split()[1:]

    hosts_img_new = StringIO.StringIO()
    for a_line in hosts_lines:
        hosts_img_new.write(a_line)
    #set_config_file(HOSTS_FILE, hosts_img_new)
    set_config_file(settings.HOSTFILE, hosts_img_new)

    digi_debug("**DEBUG: Delete hostname from %s:%s" % ( old_host_name, deleted_hostnames), 7)

    return deleted_hostnames

def get_hosts_img():
    #return get_config_file(HOSTS_FILE).read()
    return get_config_file(settings.HOSTFILE).read()

def set_hosts_img(hosts_img):
    hosts = StringIO.StringIO(hosts_img)
    #return set_config_file(HOSTS_FILE, hosts)
    return set_config_file(settings.HOSTFILE, hosts)

#############################################################
#                                                           #
#    Dev & uuid related operations.                         #
#                                                           #
#############################################################

def get_dev_id_map():
    dev_container = dict()
    disk_ids = dircache.listdir(DEV_ID_DIR)
    for disk_id in disk_ids:
        dev_path = realpath("%s/%s"%(DEV_ID_DIR, disk_id))
        dev = basename(dev_path)
        digi_debug("**DEBUG: Dev %s dev id is %s" % (dev_path, disk_id), 7)
        dev_container[dev] = disk_id.replace(':','-')

#    digi_debug("get dev-id map:%s"%(dev_container))
    digi_debug("**DEBUG: Get dev ip map return: %s" % dev_container, 7)
    return dev_container

def get_dev_by_id(disk_id):
    if not os.path.islink("%s/%s"%(DEV_ID_DIR, disk_id)):
        digi_debug("**ERROR: Get dev by id: %s return None" % disk_id, 3)
        return None
    dev_path = realpath("%s/%s"%(DEV_ID_DIR, disk_id))
    dev = basename(dev_path)
    return dev
#if not os.path.exists(os.path.join(currpath, "sas_sn.py")):
    #digi_debug(utilspath)
#    digi_debug(POSITION_CONF)
#    os.link(POSITION_CONF + "sas_sn.py", os.path.join(currpath, "sas_sn.py"))
#    digi_debug("position conf sas_sn.py not exist")
#import sas_sn

#if not os.path.exists(os.path.join(currpath, "sata_sn.py")):
#    os.link(POSITION_CONF + "sata_sn.py", os.path.join(currpath, "sata_sn.py"))
#    digi_debug("position conf sata_sn.py not exist")
#import sata_sn

def get_position_by_dev(dev='all'):
    try:
        jobd = get_diskmap()[4][0]['diskcounttype']
        diskmap = simplejson.loads(get_diskmap(True))
        if dev == "all":
            return (diskmap,jobd)
        else:
            position = diskmap[dev]
    except Exception, e:
        traceback.print_exc()
        jobd = 16
        position = "-1"
    return str(position)+'/'+str(jobd)

def analysis_disk_id(disk_id):
    lines = disk_id.split('-', 1)
    head = lines[0]
    body = lines[1]

    if head == "ata":
        pass
    elif head == "wwn":
        pass
    elif head == "scsi":
        lines = re.split(r'_|-', body, 1)
        if len(lines) > 1:
            head = lines[0]
            body = lines[1]
        else:
            pass
    else:
        digi_debug("**ERROR: Analysis disk id: %s failed" % disk_id, 3)
        return ("", "", "")

    disk_type = head

    lines = body.rsplit('_', 1)
    if len(lines) > 1:
        disk_model = lines[0]
        disk_serial = lines[1]
    else:
        disk_model = 'unkwon' 
        disk_serial = body
    
    return (disk_type, disk_model, disk_serial)

def get_type_from_id(disk_id):
    (disk_type, disk_model, disk_serial) = analysis_disk_id(disk_id)
    return disk_type

def get_model_from_id(disk_id):
    (disk_type, disk_model, disk_serial) = analysis_disk_id(disk_id)
    return disk_model

def get_serial_from_id(disk_id):
    (disk_type, disk_model, disk_serial) = analysis_disk_id(disk_id)
    return disk_serial

#############################################################
#                                                           #
#    MISC                                                   #
#                                                           #
#############################################################

def string_compare(str1, str2):
    """
        return code specify:
        str1 > str2    : 1
        str1 = str2    : 0
        str1 < str2    :-1
        either str1 or str2 is an None type : None
    """
#    digi_debug("compare:%s with %s"%(str1, str2))
    if type(str1) == types.NoneType:
        return None
    if type(str2) == types.NoneType:
        return None
    i1 = long(str1)
    i2 = long(str2)
    if i1 > i2:
        return 1
    elif i1 < i2:
        return -1
    else:
        return 0

def find_in_list_index (list, name):
    try:
        index = list.index(name)
    except ValueError:
        digi_debug("**ERROR: Find in list index raise ValueError" , 2)
        return -1
    return index

def add_in_list (list, item):
    if find_in_list(list, item):
        digi_debug("**ERROR: Add item: %s in list: %s failed" % (item, list), 2)
        return False
    list.append(item)
    return True

def del_in_list (list, item):
    try:
        list.remove(item)
    except ValueError:
        digi_debug("**ERROR: Remove item: %s from list: %s failed" % (item, list), 2)
        return False
    return True

def find_in_list (list, name):
    try:
        index = list.index(name)
    except ValueError:
        digi_debug("**ERROR: Find item: %s in list: %s failed" % (name, list), 2)
        return None
    return list[index]
def name_check(name):
    p = '[^0-9a-zA-Z@_.-]'
    if not name:
        return True
    if re.findall(p, name):
        return False
    if len(name) > 20 or len(name) < 3:
        return False
    return True

def node_name_check(name):
    p = '[^0-9a-zA-Z.-]'
    if not name:
        return True
    if len(name) > 20 or len(name) < 3:
        return False
    if re.match('^\d|\w(.*)',name):  
        if re.findall(p, name):
            return False
        if name.isdigit(): 
            return False
        if re.sub('\.','0',name).isdigit(): 
            return False
        if re.search('\.-',name) or re.search('-\.',name):
            return False
    else:
        return False
    return True

def convert_disk_slot_to_port_addr(diskslot):
    portaddr = None
    pciaddr = ''
    find = False
    portfile = None

    portfilestr = 'phy_identifier'
    cmd = []
    tmpfile = tempfile.TemporaryFile()
    cmd.append("%s -t2 | sed -n '/Product Name/,1p' | awk -F\: '{print $2}'" % (DMIDECODE))
    execute(cmd, tmpfile, shell=True)
    result = tmpfile.readlines()
    #retcode,proc = utils.cust_popen("%s -t2 | sed -n '/Product Name/,1p' | awk -F\: '{print $2}'" % DMIDECODE)
    #result = proc.stdout.read().strip()
    if result in ["X8SIE","X8DTL"]:
        portfilestr = "sas_address"
    devicelist = os.listdir(SASDEVICE)
    for eachdev in devicelist:
        devsubdir = "%s%s/device" %(SASDEVICE,eachdev)
        targetlist = os.listdir(devsubdir)
        for eachtarget in targetlist:
            if re.match("target\d+\:\d+\:\d+",eachtarget):
                targetsubdir = '%s/%s' % (devsubdir,eachtarget)
                slotlist = os.listdir(targetsubdir)
                for eachslot in slotlist:
                    if eachslot == diskslot:
                        pciaddr = eachdev[:eachdev.rindex(':')]
                        portfile = '%s%s/%s' % (SASDEVICE,eachdev,portfilestr)
                        find = True
    if find:
        f = open(portfile,'r')
        result = f.read().strip()
        f.close()
        if result:
            if portfilestr == 'phy_identifier':
                portaddr = '%s:%s' %(pciaddr,result)
            else:
                portaddr = result
    return portaddr

def get_disk_slot_from_dev(diskdev):
    diskslot = None
    diskname = diskdev.replace('/dev/','')
    diskslotmatch = ".*\/(\d+:\d+:\d+:\d+)"
    if os.path.exists(DISKDEVICE % diskname):
        if os.path.islink(DISKDEVICE % diskname):
            result = os.readlink(DISKDEVICE % diskname)
            m = re.match(diskslotmatch,result)
            if m:
                diskslot = m.group(1)
    return diskslot

def lic_check(license):
    licensestate = False
    cmd = []
    cmd.append('dmesg')
    cmd.append('-c')
    execute(cmd)
    cmd = []
    cmd.append('/sbin/check_lic')
    cmd.append(license)
    execute(cmd)
    cmd = []
    cmd.append('dmesg')
    cmd.append('-c')
    tmpfile = tempfile.TemporaryFile()
    ret = execute(cmd, tmpfile, shell=True)
    result = tmpfile.readlines()
    rechecklic = '.*check lic(.*)\n'
    for line in result:
        clm = re.match(rechecklic,line)
        if clm:
            checkresult = clm.group(1).strip()
            if checkresult == 'ok':
                savelicense(license)
                licensestate = True
            elif checkresult == 'failed':
                licensestate = False
    return licensestate    

def savelicense(license):
    try:
        f = open(RCLOCALPATH, "r+")
        result = f.readlines()
    finally:
        f.close()
    for lic_line in result:
        if lic_line.find("check_lic") >= 0:
            line_num = result.index(lic_line)
            break
    license_line = result[line_num]
    license_line = license_line.split()[0] + ' ' + license + '\n'
    result[line_num] = license_line
    try: 
        f = open(RCLOCALPATH, "w+")
        f.writelines(result)
    finally:
        f.close()

def getDeviceId():
    cmd = []
    tmpfile = tempfile.TemporaryFile()
    cmd.append("/usr/bin/hexdump -C /dev/checklic | grep 0000000")
    execute(cmd, tmpfile, shell=True)
    dumpid = None
    line = tmpfile.read()
    m = re.match('.*(.. .. .. .. .. .. .. ..  .. .. .. .. .. .. .. ..)',line)
    if m:
        tmp = m.group(1)
        temp = tmp.split(" ")
        dumpid = ''.join(temp)
    return dumpid

def recordProcOperation(operation):
    pass

def printProcOperation():
    pass

def check_digioceand():
    cmd = []
    cmd.append(settings.DIGIOCEAND)
    cmd.append('status')
    tmpfile = tempfile.TemporaryFile()
    ret = execute(cmd, tmpfile)
    result = tmpfile.read()
    if re.search('is running...',result):
        return True
    return False

def start_digioceand():
    cmd = []
    cmd.append(settings.DIGIOCEAND)
    cmd.append('start')
    ret = execute(cmd, err_ignore=True)

def check_service_exist(servicename):
    exist = False
    cmd = []
    cmd.append(settings.DIGIOCEAN)
    cmd.append("volume")
    cmd.append("info")
    tmpfile = tempfile.TemporaryFile()
    execute(cmd, tmpfile)
    result = tmpfile.readlines()
    for line in result:
        n = re.match('Volume Name:(.*)',line)
    if n:
            name = n.group(1).strip()
            if servicename == name:
                exist = True
    return exist

def list_service_node(servicename):
    node_list = []
    try:
        cmd = []
        cmd.append(settings.DIGIOCEAN)
        cmd.append("volume")
        cmd.append("info")
        cmd.append(servicename)
        tmpfile = tempfile.TemporaryFile()
        execute(cmd, tmpfile)
        lines = tmpfile.readlines()
        for line in lines:
            m = re.search('Brick\d+:(.*)',line)
            if m:
                nodename = m.group(1).split(':')[0].strip()
                if nodename not in node_list:
                    node_list.append(nodename)         
        return node_list
            
    except Exception, e:
        print e
        return []

def list_service_disk(servicename):
    disk_list = []
    try:
        cmd = []
        cmd.append(settings.DIGIOCEAN)
        cmd.append("volume")
        cmd.append("info")
        cmd.append(servicename)
        tmpfile = tempfile.TemporaryFile()
        execute(cmd, tmpfile)
        lines = tmpfile.readlines()
        for line in lines:
            m = re.search('Brick\d+:(.*)',line)
            if m:
                nodename = m.group(1).split(':')[0].strip ()
                disk_dev_id = m.group(1).split(':')[1].replace('/digioceanfs/','').strip()
                disk_list.append(nodename + ':' + disk_dev_id)         
        return disk_list
            
    except Exception, e:
        print e
        return []

def list_service_status(servicename):
    status = ''
    try:
        cmd = []
        cmd.append(settings.DIGIOCEAN)
        cmd.append("volume")
        cmd.append("info")
        cmd.append(servicename)
        tmpfile = tempfile.TemporaryFile()
        execute(cmd, tmpfile)
        lines = tmpfile.readlines()
        for line in lines:
            n = re.match('Status:(.*)',line)
            if n:
                status = n.group(1).strip()
                return status
    except Exception, e:
        print e
        return status

def list_service_name_all():
    service_list = []
    try:
        tmp_img = tempfile.TemporaryFile()
        cmd = []
        cmd.append(settings.DIGIOCEAN)
        cmd.append("volume")
        cmd.append("list")
        ret = execute(cmd, tmp_img)
        digi_debug("**DEBUG: list_service_name_all, %s return %d" % (' '.join(cmd),ret),5)
        result_str = ''
        if not ret:
            result_str = tmp_img.read()
        if result_str and not result_str.find('No volumes present') >= 0:
            service_list = result_str.split("\n")[:-1]
        return service_list
    except Exception, e:
        print e
        return []

def get_service_type_info(service_name,result_str):
    try:
        service_type = {}
        try:
            type_str = re.search("\s+Type: (\S+)\s+", result_str).groups()[0]
        except Exception, e:
            type_str = ''
        distributed = 0
        stripe = 0
        replica = 0
        if type_str.find("Distributed") >= 0:
            distributed += 1
        if type_str.find("Stripe") >= 0:
            stripe += 1
        if type_str.find("Replicate") >= 0:
            replica += 1
        # Bricks
        try:
            brick_list = re.search("\s+Number of Bricks: (.*) =\s+", result_str).groups()[0].split(' x ')
        except Exception, e:
            brick_list = []
        # service_type: {'distributed': int, 'stripe': int, 'replica': int}
        if brick_list:
            if distributed:
                distributed = int(brick_list[0])
                if stripe:
                    stripe = int(brick_list[1])
                    if replica:
                        replica = int(brick_list[2])
                else:
                    replica = int(brick_list[1])
            else:
                if stripe:
                    stripe = int(brick_list[1])
                    if replica:
                        replica = int(brick_list[1])
                else:
                    replica = int(brick_list[1])
        service_type = {'distributed': distributed, 'stripe': stripe, 'replica': replica}
    except Exception, e:
        print e
        digi_debug("**ERROR: Service list single, caught exception: %s" % e,3)
    return service_type
    

if "__name__" == "__main__":
    print lic_check("asdfasdfaklsdjflak;sdjf")
    #diskdev = "sdc"
    #diskslot = get_disk_slot_from_dev(diskdev)
    #convert_disk_slot_to_port_addr(diskslot)
