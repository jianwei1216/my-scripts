#!/usr/bin/env python
#-*- coding: utf-8 -*-

import os
import sys
import re
import subprocess
import simplejson

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if currpath not in sys.path:
    sys.path.append(currpath)
from base import Page,stow,session,web,_
import settings
from libcommon import clusnodelib
from libcommon import clusservicelib
from libcommon import findir
from findir import myFile

class Service(Page):
    def _checkservice(self):
        if not session.runtime.service:
            raise web.seeother('/clusterservice')

class clusterservice(Page):
    def _logic(self):
        self.content = stow({

        })
        self.setup = stow({
            'template':'clusterservice',
            'breadcrumbs':['clusterservice']
        })

    def GET(self):
        return self.render()

class clusterserviceview(Page):
    def _logic(self):
        params = web.input()
        service = 'service' in params and params['service'] or None
        if service:
            session.runtime.service = service
        self.content = stow({
            'servicename': service
        })
        self.setup = stow({
            'template':'clusterserviceview',
            'breadcrumbs':['clusterservice','clusterserviceview']
        })

    def GET(self):
        return self.render()

class clusterserviceviewtabspage(Page):
    def _logic(self):
        params = web.input()
        service = 'service' in params and params['service'] or None
        if service:
            session.runtime.service = service
        self.content = stow({
            'servicename': service
        })
        self.setup = stow({
            'template':'clusterserviceviewload'
        })
    def GET(self):
        return self.render(ajax=True)

class clusterserviceload(Page):
    def _logic(self):
        #unit = session.runtime.unit
        params = web.input()
        session.runtime.node = ''
        unit = session.runtime.unit	
        clusterservices = clusservicelib.func_service_list_all(unit)
        self.content = stow({
            'clusterservices':clusterservices,
            'unit':unit
        })
        self.setup = stow({
            'template':'clusterserviceload',
            'jstemplate':['datatable_ZH']
        })
    def _action(self):
        params = web.input()
        unit = 'unit' in params and params['unit'] or None
        if unit:
            session.runtime.unit = unit
        clusterservices = clusservicelib.func_service_list_all(unit)
        return simplejson.dumps(clusterservices)

    def GET(self):
        return self.render(ajax=True)

    def POST(self):
        return self.action(ajax=True)

class clusterserviceviewloadrefresh(Page):
    def _action(self):
        params = web.input()
        service = session.runtime.service
        #print >>sys.stderr, params
        #print >>sys.stderr, params['expandarray'].decode('UTF-8')
        my_dict= clusservicelib.func_service_afr_info_search(service, '', params['expandarray'])
        return simplejson.dumps([my_dict], encoding="UTF-8")
    def POST(self):
        return self.action(ajax=True)

class clusterserviceviewload(Page):
    def _logic(self):
        params = web.input()
        service= session.runtime.service
        unit = session.runtime.unit
        mydict = {}
        #clusterservices = clusservicelib.func_service_list_disk(service)
        mydict = clusservicelib.func_service_afr_info_search(service,)
        self.content = stow({
        #    'clusterservices':clusterservices,
            'mydict':mydict
        })
        self.setup = stow({
            'template':'clusterserviceviewload',
        })

    def _action(self):
        params = web.input()
        unit = 'unit' in params and params['unit'] or None
        if unit:
            session.runtime.unit = unit
        service = session.runtime.service
        if 'PATH' in params:
            dirname = params['PATH']
            #print >>sys.stderr, params
            #print >>sys.stderr, dirname.decode('UTF-8')
            my_dict= clusservicelib.func_service_afr_info_search(service,dirname,'')
        else:
            my_dict= clusservicelib.func_service_afr_info_search(service)
        return simplejson.dumps({})

    def GET(self):
        return self.render(ajax=True)
    def POST(self):
        return self.action(ajax=True)

class clusterservicecreateguide_a(Page):
    def _logic(self):
        self.content = stow({

        })
        self.setup = stow({
            'template':'clusterservicecreateguide_a'
        })
    def GET(self):
        return self.render(ajax=True)

class clusterservicecreateguide_b(Page):
    def _logic(self):
        clusternodes = clusnodelib.func_node_list_all('True')
        nodenum = len(clusternodes)
        self.content = stow({
            'nodenum':nodenum
        })
        self.setup = stow({
            'template':'clusterservicecreateguide_b'
        })
    def GET(self):
        return self.render(ajax=True)

class clusterservicecreateguide_c(Page):
    def _logic(self):
        self.setup = stow({
            'template':'clusterservicecreateguide_c'
        })
    def GET(self):
        return self.render(ajax=True)
    
class clusterservicecreatedisk(Page):
    def _action(self):
        clusterservicediskinfo = []
        clusterservicedisk = clusnodelib.func_node_disk_info()
        for disk in clusterservicedisk:
            if disk['status'] == 'unused':
                clusterservicediskinfo.append(disk)
        return simplejson.dumps(clusterservicediskinfo)
    def POST(self):
        return self.action(ajax=True)

class clusterservicecreateguide_c_afr_strip(Page):
    def _logic(self):
        self.setup = stow({
            'template':'clusterservicecreateguide_c_afr_strip'
        })
    def GET(self):
        return self.render(ajax=True)

class clusterservicecreateguide_c_strip_afr(Page):
    def _logic(self):
        clusterservicediskinfo = []
        clusterservicedisk = clusnodelib.func_node_disk_info()
        for disk in clusterservicedisk:
            if disk['status'] == 'unused':
                clusterservicediskinfo.append(disk)
        self.content = stow({
            'clusterservicediskinfo':clusterservicediskinfo
        })
        self.setup = stow({
            'template':'clusterservicecreateguide_c_strip_afr'
        })
    def GET(self):
        return self.render(ajax=True)

class clusterservice_afr_syn(Page):
    def _action(self):
        params = web.input()
        service = params['servicename']
        retcode = clusservicelib.func_service_afr_syn(service)
        return retcode
    def POST(self):
        return self.action(ajax=True)

class clusterservicecreate(Page):
    def _action(self):
        params = web.input(afrdisknewdev=[],stripdisknewdev=[],defaultdisknewdev=[],dispersedisknewdev=[])
        if 'disks_num' in params:
            disks_num = params['disks_num']
        if 'sub_volume_num' in params:
            sub_volume_num = params['sub_volume_num']
        if 'disperse_num' in params:
            disperse_num = params['disperse_num']
        clusterservicetype = params['clusterservicetype']
        clusterservicelocalpor = params['clusterservicelocalpor']
        clusterservicecustom_store = params['clusterservicecustom_store']

        if clusterservicetype == 'clusterservicetype_afr':
            clusterservicenewdev = params['afrdisknewdev'][0].split(',')
        elif clusterservicetype == 'clusterservicetype_strip':
            clusterservicenewdev = params['stripdisknewdev'][0].split(',')
        elif clusterservicetype == 'clusterservicetype_disperse':
            clusterservicenewdev = params['dispersedisknewdev'][0].split(',')
        else:
            clusterservicenewdev = params['defaultdisknewdev'][0].split(',')
        option = {}
        if clusterservicetype == 'clusterservicetype_default':
            clusterserviceraidlv = '2'
            option = {} #'-a ' + disks_num  + ' -s ' + sub_volume_num
        elif clusterservicetype == 'clusterservicetype_strip' and sub_volume_num == '1':
            clusterserviceraidlv = '0'
            option['-s'] = disks_num
        elif clusterservicetype == 'clusterservicetype_afr' and disks_num == '1':
            clusterserviceraidlv = '1'
            option['-a'] = sub_volume_num
        elif clusterservicetype == 'clusterservicetype_strip' and sub_volume_num != '1':
            clusterserviceraidlv = '01'
            option['-s'] = disks_num
            option['-a'] = sub_volume_num
        elif clusterservicetype == 'clusterservicetype_afr' and disks_num != '1':
            clusterserviceraidlv = '01'
            option['-a'] = sub_volume_num
            option['-s'] = disks_num
        elif clusterservicetype == 'clusterservicetype_disperse' and disks_num != '1':
            clusterserviceraidlv = '3'
            option['-R'] = disperse_num
            option['-d'] = disks_num
        
        if clusterservicecustom_store == 'video_pic':
            if '-o' in option:
                option['-o'].append('custom_store')
            else:
                option['-o'] = ['custom_store']
        else:
            option['-o'] = ['']
                
        if clusterservicelocalpor == 'clusterservicelocalpor_no':
            clusterservicelocalpor = '0'
            del option['-o']
        else:
            clusterservicelocalpor = '1'    
            option['-o'].append('native_store')
            #del option['-o']
        clusterservicedata = ' '.join(clusterservicenewdev)
        clusterservicename = params['clusterservicename']
        formated_options = ''
        for k,v in option.iteritems():
            if k == '-o':
                formated_options += ' '  + k+ ' ' + ','.join(v)
            else:
                formated_options += ' '  + k+ ' ' + v
        retcode = clusservicelib.func_service_create(clusterservicename, clusterserviceraidlv, clusterservicedata, formated_options)
        return retcode
    def GET(self):
        return self.render(ajax=True)
    def POST(self):
        return self.action(ajax=True)

class clusterservicextend(Page):
    def _logic(self):
        #clusterservice = clusservicelib.func_service_list_all()
        #clusterservicename = []
        #for name in clusterservice:
        #    clusterservicename.append(name['servicename'])
        #clusternodeip = []
        #clusterdiskunused = []
        #for node in clusnodelib.func_node_list_all('False'):
        #    clusternodeip.append(node['nodename'])
        #self.content = stow({
        #    'clusterservice':clusterservicename,
        #    'clusternodeip':clusternodeip,
        #})
        self.setup = stow({
            'template':'clusterservicextend'
        })

    def _action(self):
        params = web.input(clusterexservicedev=[])
        clusterserviceraidlv = '2'
        clusterservicename = params['clusterservicename']
        if 'clusterservicetype_none' in params and params['clusterservicetype_none'] == 'on':
            clusterserviceraidlv = '2'
        elif 'clusterservicetype_afr' in params and params['clusterservicetype_afr'] == 'on':
            clusterserviceraidlv = '1'
        elif 'clusterservicetype_strip' in params and params['clusterservicetype_strip'] == 'on':
            clusterserviceraidlv = '0'
        clusterservicedata = ' '.join(params['clusterexservicedev'])
        retcode = clusservicelib.func_service_extend(clusterservicename, clusterservicedata)
        return retcode

    def GET(self):
        return self.render(ajax=True)

    def POST(self):
        return self.action(ajax=True)

#�ͻ��˽ڵ��б�	
class clusterclientnodeload(Page):
    def _logic(self):
        params = web.input()
        clusterclientnodes = clusservicelib.func_client_node_list_all(params['service_name'])
        #print >> sys.stderr, clusterclientnodes
        self.content = stow({
            'clusterclientnodes':clusterclientnodes
        })
        self.setup = stow({
            'template':'clusterclientnodeload',
            #'jstemplate':['datatable_ZH']
        })
    def _action(self):
        #ɾ��ʱ�ж��Ƿ��������еĿͻ��˽ڵ�
        service_arr=[]
        params = web.input()
        clusterservice=clusservicelib.func_service_list_all()
        for service in clusterservice:            	
            clusterclientnodes = clusservicelib.func_client_node_list_all(service['servicename'])
            for node in clusterclientnodes:
                if params['node_name']==node['node_name']:
                    if node['status']=='1':
                        service_arr.append(service['servicename'])
        if service_arr:
            retcode=','.join(service_arr)
        else:
            retcode='0'
        return retcode

    def GET(self):
        return self.render(ajax=True)

    def POST(self):
        return self.action(ajax=True)		

class clusterserviceclientmanage(Page):
    def _logic(self):
        self.content = stow({
        })
        self.setup = stow({
            'template':'clusterserviceclientmanage',
        })
    def GET(self):
        return self.render(ajax=True)

#�ͻ��˽ڵ����
class clusterclientnodecreate(Page):
    def _logic(self):      
        self.setup = stow({
            'template':'clusterclientnodecreate'
        })

    def _action(self):
        params = web.input()			
        retcode = clusservicelib.func_client_node_create(params['service_name'],params['node_name'])
        return retcode

    def GET(self):
        return self.render(ajax=True)

    def POST(self):
        return self.action(ajax=True)		

#�ͻ��˽ڵ�ɾ��
class clusterclientnodedelete(Page):
    def _action(self):
        params = web.input()			
        retcode = clusservicelib.func_client_node_delete(params['service_name'],params['node_name'])
        return retcode

    def GET(self):
        return self.render(ajax=True)

    def POST(self):
        return self.action(ajax=True)
		
#�ͻ��˽ڵ�cifs
'''
class clusterclientnodecifs(Page):
    def _action(self):
        params = web.input()			
        retcode = clusservicelib.func_client_node_cifs(params['op'],params['service_name'],params['node_name'])
        return retcode

    def GET(self):
        return self.render(ajax=True)

    def POST(self):
        return self.action(ajax=True)

#�ͻ��˽ڵ�nfs
class clusterclientnodenfs(Page):
    def _action(self):
        params = web.input()			
        retcode = clusservicelib.func_client_node_nfs(params['op'],params['service_name'],params['node_name'])
        return retcode

    def GET(self):
        return self.render(ajax=True)

    def POST(self):
        return self.action(ajax=True)
'''
		
#�ͻ��˽ڵ�״̬
class clusterclientnodestatus(Page):
    def _action(self):
        params = web.input()			
        retcode = clusservicelib.func_client_node_status(params['op'],params['service_name'],params['node_name'])
        return retcode

    #def GET(self):
    #    return self.render(ajax=True)

    def POST(self):
        return self.action(ajax=True)

		
#������̿�
class clusterserviceraidlvdetail(Page):
    def _logic(self):       
        params = web.input()
        clusternodediskinfo = clusnodelib.func_node_disk_info('')
        servicedetail = clusservicelib.func_service_list_options(params['service_name'])
        bricks = clusservicelib.func_raidlv_detail(params['service_name'])
        afr = int(params['afr']) + int(params['strip'])
        for brick in bricks:
            brick['dposition'] = ''
            for diskinfo in clusternodediskinfo:
                if diskinfo['nodename'] in brick['mount_point'] and diskinfo['devname'] == brick['interface'].split('/')[-1]:
                    brick['dposition'] = diskinfo['position'].replace('-1','NaN').split('/')[0]
        #print >> sys.stderr,  bricks
        self.content = stow({
            'servicedetail': servicedetail,
            'bricks': bricks,
            'service_name':params['service_name'],
            'afr':afr,
			'key':0
        })
        self.setup = stow({
            'template':'clusterserviceraidlvdetail',
            #'jstemplate':['datatable_ZH']
        })
    def _action(self):
        params = web.input()
    def GET(self):
        return self.render(ajax=True)
    def POST(self):
        return self.action(ajax=True)
		
#��������滻
class clusterservicediskreplace(Page):
    def _logic(self):       
        params = web.input()
        unit = session.runtime.unit
        disk_arr = clusnodelib.func_node_disk_info('',unit)
        unuse_disk=[]
        for disk in disk_arr:
            if disk['status']=='unused':
                unuse_disk.append(disk['nodename']+':'+disk['devname'])
        unuse_disk_str=','.join(unuse_disk)			
        self.content = stow({
            'service_name':params['service_name'],
            'disk':params['disk'],
            'unuse_disk_str':unuse_disk_str,
        })
        self.setup = stow({
            'template':'clusterservicediskreplace',
        })
    def _action(self):
        params = web.input()
    def GET(self):
        return self.render(ajax=True)
    def POST(self):
        return self.action(ajax=True)
		
class clusterservicedisk(Page):
    def _logic(self):
        #node = session.runtime.node
        node = ''
        unit = session.runtime.unit
        #clusternodediskinfo = clusnodelib.func_node_disk_info(node,unit)
        #clusternoderaidinfo = clusnodelib.func_node_raid_info(node,unit)
        self.content = stow({
            #'clusternodediskinfo':clusternodediskinfo,
            #'clusternoderaidinfo':clusternoderaidinfo,
			'is_service':'1'
        })
        self.setup = stow({
            'template':'clusternodedisk',
            #'breadcrumbs':['clusternode','clusternodeview','clusternodedisk'],
            #'menus':gmenus,
            #'currmenu':'clusternodedisk',
        })
    def GET(self):
        return self.render(ajax=True)
		
class clusterserviceraidload(Page):
    def _logic(self):
        #node = session.runtime.node
        node = ''
        unit = session.runtime.unit
        clusternodediskinfo = clusnodelib.func_node_disk_info(node,unit)
        clusternoderaidinfo = clusnodelib.func_node_raid_info(node,unit)
        try:
            for raidinfo in clusternoderaidinfo:
                if raidinfo['type_in_raid'].find(',') >= 0:
                    raidinfo['type_in_raid'] = ','.join([_(k).decode('utf-8').encode('utf-8') for k in raidinfo["type_in_raid"].split(',')])
                else:
                    raidinfo['type_in_raid'] = _(raidinfo['type_in_raid'])
        except Exception,e:
            print >> sys.stderr, e
        try:
            for diskinfo in clusternodediskinfo:
                diskinfo['dposition'] = ''
                diskinfo['dposition'] = diskinfo['position'].replace('-1','NaN').split('/')[0]
        except Exception,e:
            print >> sys.stderr, e
        try:
            for raidinfo in clusternoderaidinfo:
                raidinfo['dposition'] = ''
                raidinfo['dposition'] = raidinfo['position'].replace('-1','NaN').split('/')[0]
        except Exception,e:
            print >> sys.stderr, e
        self.content = stow({
            'clusternodediskinfo':clusternodediskinfo,
            'clusternoderaidinfo':clusternoderaidinfo,
            'unit':unit,
			'is_unused':'0',
            'is_service':'1'
        })
        self.setup = stow({
            'jstemplate':['datatable_ZH'],
            'template':'clusternoderaidload',
        })
    def _action(self):
        params = web.input()
        node = session.runtime.node
        unit = 'unit' in params and params['unit'] or None
        if unit:
            session.runtime.unit = unit
        clusternodediskinfo = clusnodelib.func_node_disk_info(node,unit)
        return simplejson.dumps(clusternodediskinfo)

    def GET(self):
        return self.render(ajax=True)
    def POST(self):
        return self.action(ajax=True)

class clusterserviceraidload_select(Page):
    def _logic(self):
        node = ''
        unit = session.runtime.unit
        clusternodediskinfo = clusnodelib.func_node_disk_info(node,unit)
        clusternoderaidinfo = clusnodelib.func_node_raid_info(node,unit)
        try:
            for raidinfo in clusternoderaidinfo:
                if raidinfo['type_in_raid'].find(',') >= 0:
                    raidinfo['type_in_raid'] = ','.join([_(k).decode('utf-8').encode('utf-8') for k in raidinfo["type_in_raid"].split(',')])
                else:
                    raidinfo['type_in_raid'] = _(raidinfo['type_in_raid'])
        except Exception,e:
            print >> sys.stderr, e
        try:
            for diskinfo in clusternodediskinfo:
                diskinfo['dposition'] = ''
                diskinfo['dposition'] = diskinfo['position'].replace('-1','NaN').split('/')[0]
        except Exception,e:
            print >> sys.stderr, e
        try:
            for raidinfo in clusternoderaidinfo:
                raidinfo['dposition'] = ''
                raidinfo['dposition'] = raidinfo['position'].replace('-1','NaN').split('/')[0]
        except Exception,e:
            print >> sys.stderr, e
        self.content = stow({
            'clusternodediskinfo':clusternodediskinfo,
            'clusternoderaidinfo':clusternoderaidinfo,
            'unit':unit,
			'is_unused':'1'
        })
        self.setup = stow({
            'jstemplate':['datatable_ZH'],
            'template':'clusternoderaidload',
        })
    def _action(self):
        params = web.input()
        node = session.runtime.node
        unit = 'unit' in params and params['unit'] or None
        if unit:
            session.runtime.unit = unit
        clusternodediskinfo = clusnodelib.func_node_disk_info(node,unit)
        return simplejson.dumps(clusternodediskinfo)

    def GET(self):
        return self.render(ajax=True)
    def POST(self):
        return self.action(ajax=True)			
		
class clusterservicextendservice(Page):
    def _action(self):
        clusterservice = clusservicelib.func_service_list_all()
        clusterservicename = []
        for name in clusterservice:
            clusterservicename.append(name['servicename']+'::'+name['afr']+'::'+name['strip'])
        return simplejson.dumps(clusterservicename)
    def POST(self):
        return self.action(ajax=True)

class clusterservicextendnode(Page):
    def _action(self):
        clusternode = clusnodelib.func_node_list_all('False')
        clusternodeip = []
        for node in clusternode:
            clusternodeip.append(node['nodename'])
        return simplejson.dumps(clusternodeip)
    def POST(self):
        return self.action(ajax=True)

class clusterservicecifs_status(Page):
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        clusterserviceoption = params['clusterservicecifsoption']
        retcode = clusservicelib.func_service_export(clusterserviceoption, 'cifs', clusterservicename)
        return retcode
    def POST(self):
        return self.action(ajax=True)
    
class clusterservicecifsrestart(Page):
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        retcode = clusservicelib.func_service_cifs_restart(clusterservicename)
        return retcode
    def POST(self):
        return self.action(ajax=True)

class clusterservicenfs_status(Page):
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        clusterserviceoption = params['clusterservicenfsoption']
        retcode = clusservicelib.func_service_export(clusterserviceoption, 'nfs', clusterservicename)
        return retcode
    def POST(self):
        return self.action(ajax=True)

class clusterservicexportstatus(Page):
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        type = params['type']
        clusterserviceoption = 'status'
        retcode = clusservicelib.func_service_export(clusterserviceoption, type, clusterservicename)
        return simplejson.dumps(retcode)
    def POST(self):
        return self.action(ajax=True)

class clusterservicecreatedialog(Page):
    def _logic(self):
        clusterdiskunused = []
        clusternodediskinfo = []
        clusternodedisksize = []
        clusternewservicedev = {}
        params = web.input()
        disk = clusnodelib.func_node_disk_info(params['clusternodeipaddr'])
        for d in disk:
            if d['status'] == 'unused':
                dev = params['clusternodeipaddr'] + ':' + d['devname']
                diskinfo = 'model:' + d['vandor'] + '<br />' + 'serial_number:' +d['sn_number'] + '<br />' + 'size:' + d['size']
                clusternodediskinfo.append(diskinfo)
                clusterdiskunused.append(dev)
                clusternewservicedev['clusterdiskunused'] = clusterdiskunused
                clusternewservicedev['clusternodediskinfo'] = clusternodediskinfo
        return simplejson.dumps(clusternewservicedev)
    def GET(self):
        return self.render(ajax=True, notemplate=True)

class clusterservicecifsmanage(Page):
    def _logic(self):
        params = web.input()
        service_name = params['service_name']
        self.setup = stow({
            'template':'clusterservicecifsmanage'
        })
        self.content = stow({
            'service_name':service_name
        })
    def GET(self):
        return self.render(ajax=True)
    
class clusterservicecifsusermanage(Page):
    def _logic(self):
        #params = web.input()
        #service_name = params['service_name']
        self.setup = stow({
            'template':'clusterservicecifsusermanage'
        })
        '''self.content = stow({
            'service_name':service_name
        })'''
    def GET(self):
        return self.render(ajax=True)
class clusterservicecifslistuser(Page):
    def _action(self):
        params = web.input()
        service_name = params['service_name']
        clusterservicename = params['service_name']
        userlist = clusservicelib.func_service_cifs_list_user(clusterservicename)
        return simplejson.dumps(userlist)
    def POST(self):
        return self.action(ajax=True)
    
class clusterservicecifsadduser(Page):
    def _action(self):
        params = web.input()
        optype = params['optype']
        service_name = params['service_name']
        clusterservicename = params['service_name']
        username = params['username']
        password = params['password']
        if optype == 'create':
            cifsuserinfo = clusservicelib.func_service_cifs_list_user(clusterservicename)
            cifsusernames = [user['user'] for user in cifsuserinfo]
            if username in cifsusernames:
                return _("cifsuseralreadyexist")
        retcode = clusservicelib.func_service_cifs_add_user(clusterservicename, username, password)
        return retcode
    def POST(self):
        return self.action(ajax=True)
    
class clusterservicecifsdeluser(Page):
    def _action(self):
        params = web.input()
        service_name = params['service_name']
        clusterservicename = params['service_name']
        username = params['username']
        retcode = clusservicelib.func_service_cifs_del_user(clusterservicename, username)
        return retcode
    def POST(self):
        return self.action(ajax=True)

class clusterservicecifschecklinks(Page):
    def _logic(self):
        params = web.input()
        service_name = params['service_name']
        self.setup = stow({
            'template':'clusterservicecifschecklinks'
        })
        self.content = stow({
            'service_name':service_name
        })
    def GET(self):
        return self.render(ajax=True)
    
class clusterservicecifschecklinksdata(Page):
    def _action(self):
        params = web.input()
        servicename = params['service_name']
        cifschecklinksdata = clusservicelib.func_service_list_cifs_links(servicename)
        return simplejson.dumps(cifschecklinksdata)
    def POST(self):
        return self.action(ajax=True)
    
class clusterservicecifsdellink(Page):
    def _action(self):
        params = web.input()
        servicename = params['service_name']
        nodename = params['node_name']
        pid = params['pid']
        ret = clusservicelib.func_service_del_cifs_links(servicename, nodename, pid)
        return ret
    def POST(self):
        return self.action(ajax=True)
    
class clusterservicenfsmanage(Page):
    def _logic(self):
        params = web.input()
        service_name = params['service_name']
        self.setup = stow({
            'template':'clusterservicenfsmanage'
        })
        self.content = stow({
            'service_name':service_name
        })
    def GET(self):
        return self.render(ajax=True)
    
class clusterservicenfsusermanage(Page):
    def _logic(self):
        #params = web.input()
        #service_name = params['service_name']
        self.setup = stow({
            'template':'clusterservicenfsusermanage'
        })
        '''self.content = stow({
            'service_name':service_name
        })'''
    def GET(self):
        return self.render(ajax=True)
class clusterservicenfslistuser(Page):
    def _action(self):
        params = web.input()
        service_name = params['service_name']
        clusterservicename = params['service_name']
        userlist = clusservicelib.func_service_nfs_list_user(clusterservicename)
        return simplejson.dumps(userlist)
    def POST(self):
        return self.action(ajax=True)
    
class clusterservicenfschecklinks(Page):
    def _logic(self):
        params = web.input()
        service_name = params['service_name']
        self.setup = stow({
            'template':'clusterservicenfschecklinks'
        })
        self.content = stow({
            'service_name':service_name
        })
    def GET(self):
        return self.render(ajax=True)

class clusterservicenfschecklinksdata(Page):
    def _action(self):
        params = web.input()
        servicename = params['service_name']
        nfschecklinksdata = clusservicelib.func_service_list_nfs_links(servicename)
        return simplejson.dumps(nfschecklinksdata)
    def POST(self):
        return self.action(ajax=True)
    
class clusterservicenfsdellink(Page):
    def _action(self):
        params = web.input()
        servicename = params['service_name']
        nodename = params['node_name']
        tar_ip = params['targetip']
        ret = clusservicelib.func_service_del_nfs_links(servicename, nodename, tar_ip)
        return ret
    def POST(self):
        return self.action(ajax=True)
    
    
class clusterservicenfsadduser(Page):
    def _action(self):
        params = web.input()
        service_name = params['service_name']
        clusterservicename = params['service_name']
        userip = params['userip']
        userlist = clusservicelib.func_service_nfs_list_user(clusterservicename)
        if userip in userlist:
            return _("clusterservicenfsuserexists")
        retcode = clusservicelib.func_service_nfs_add_user(clusterservicename, userip)
        return retcode
    def POST(self):
        return self.action(ajax=True)
    
class clusterservicenfsdeluser(Page):
    def _action(self):
        params = web.input()
        service_name = params['service_name']
        clusterservicename = params['service_name']
        userip = params['userip']
        retcode = clusservicelib.func_service_nfs_del_user(clusterservicename, userip)
        return retcode
    def POST(self):
        return self.action(ajax=True)
		
		
class clusterservicesharemanage(Page):
    def _logic(self):
        clusterservice=clusservicelib.func_service_list_all()
        '''clusterservice=[]
        serviceinfos = clusservicelib.func_service_list_all()
        for serviceinfo in serviceinfos:
            clusterservice.append(serviceinfo['servicename'])'''
        self.setup = stow({
            'template':'clusterservicesharemanage'
        })
        self.content = stow({
            'clusterservice':clusterservice
        })
    def _action(self):
        params = web.input()
    def POST(self):
        return self.action(ajax=True)
    def GET(self):
        return self.render(ajax=True)
		
class clusterservicestart(Page):
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        retcode = clusservicelib.func_service_start(clusterservicename)
        ret = clusservicelib.func_service_enable_quota(clusterservicename)
        return retcode
    def POST(self):
        return self.action(ajax=True)

class clusterservicestop(Page):
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        clusterclientnodes = clusservicelib.func_client_node_list_all(clusterservicename)
        for clusterclientnode in clusterclientnodes:
            if clusterclientnode['status'] == '1':
                return _("13505")
        retcode = clusservicelib.func_service_stop(clusterservicename)
        return retcode
    def POST(self):
        return self.action(ajax=True)

class clusterservicedestroy(Page):
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        retcode = clusservicelib.func_service_destroy(clusterservicename)
        return retcode
    def POST(self):
        return self.action(ajax=True)

class clusterservicerestart(Page):
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        retcode = clusservicelib.func_service_restart(clusterservicename)
        clusservicelib.func_service_list_all()[0]['status']
        return retcode
    def POST(self):
        return self.action(ajax=True)
    
class clusterservicegetsize(Page):
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        retcode = clusservicelib.func_service_get_size(clusterservicename)
        return simplejson.dumps(retcode)
    def POST(self):
        return self.action(ajax=True)
    
class clusterservicelistdir(Page):
    def _logic(self):
        self.setup = stow({
            'template':'clusterservicelistdir'
        })
        clusterservice = clusservicelib.func_service_list_all() 
        self.content = stow({
            'clusterservice':clusterservice
        })
        
    def _action(self):
        params = web.input()
        targetpath = params['path']
        retcode = clusservicelib.func_service_list_quota(targetpath)
        return retcode

    def POST(self):
        return self.action(ajax=True)
    def GET(self):
        return self.render(ajax=True)
    
class clusterservicequotaset(Page):
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        targetpath = params['targetpath']
        value = params['value']
        retcode = clusservicelib.func_service_quota_set(clusterservicename, targetpath,value)
        return retcode
    
    def POST(self):
        return self.action(ajax=True)
    
class clusterservicequotaremove(Page):
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        targetpath = params['targetpath']
        retcode = clusservicelib.func_service_quota_remove(clusterservicename, targetpath)
        return retcode
    
    def POST(self):
        return self.action(ajax=True)
    
class clusterserviceoptionlist(Page):
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        clusterserviceoptiongroup = params['clusterserviceoptiongroup']
        clusterserviceoptions = clusservicelib.func_service_list_options(clusterservicename, True)
        rtnoptions = {}
        for option_name, option_value in clusterserviceoptions.iteritems():
            if option_name.find(clusterserviceoptiongroup) >= 0:
                rtnoptions[option_name] = option_value
            
        else:
            if 'cluster.quorum-type' not in rtnoptions.keys():
                rtnoptions['cluster.quorum-type'] = 'none'
            
            if 'cluster.quorum-count' not in rtnoptions.keys():
                rtnoptions['cluster.quorum-count'] = '0'
                
            if 'cluster.quorum-reads' not in rtnoptions.keys():
                rtnoptions['cluster.quorum-reads'] = 'no'
            return simplejson.dumps(rtnoptions)
    
    def POST(self):
        return self.action(ajax=True)
    
class clusterserviceoptionset(Page):
    def _logic(self):
        params = web.input()
        service_name = params['clusterservicename']
        #clusterserviceoptions = clusservicelib.func_service_list_options(service_name, True)
        clusterserviceoptiongroups = ['quorum']
        self.setup = stow({
            'template':'clusterserviceoptionset'
        })
        self.content = stow({
            'clusterserviceoptiongroups': clusterserviceoptiongroups,
            'clusterservicename':service_name
        })
        
    def GET(self):
        return self.render(ajax=True)
        
    def _action(self):
        params = web.input()
        clusterservicename = params['clusterservicename']
        clusterserviceoptions = params['clusterserviceoptions']
        retcode = clusservicelib.func_service_option_set(clusterservicename, simplejson.dumps(clusterserviceoptions))
        return retcode
    
    def POST(self):
        return self.action(ajax=True)

class clusterserviceauthmanage(Page):
    def _logic(self):
        self.setup = stow({
            'template':'clusterserviceauthmanage'
        })
        clusterservice = clusservicelib.func_service_list_all()
        self.content = stow({
            'clusterservice':clusterservice
        })

    def _action(self):
        params = web.input()
        targetpath = params['path']
        retcode = clusservicelib.func_service_list_auth(targetpath)
        return retcode

    def POST(self):
        return self.action(ajax=True)
    def GET(self):
        return self.render(ajax=True)

class clusterserviceauthedit(Page):
    def _logic(self):
        params = web.input()
        path = params['path']
        owner = params['owner']
        wuser = params['wuser']
        ruser = params['ruser']
        nouser = params['nouser']
        service_name = path.split('/')[2]
        smb_user_list = []
        if wuser == '-':
            wuser = []
        else:
            wuser = wuser.split(',')
        if ruser == '-':
            ruser = []
        else:
            ruser = ruser.split(',')
        if nouser == '-':
            nouser = []
        else:
            nouser = nouser.split(',')
        self.setup = stow({
            'template':'clusterserviceauthedit'
        })
        self.content = stow({
            'path': path,
            'wuser': wuser,
            'ruser': ruser,
            'nouser': nouser
        })

    def _action(self):
        retcode = '0'
        params = web.input()
        clusterauthruser = params['clusterauthruser']
        clusterauthwuser = params['clusterauthwuser']
        path = params['path']
        value = ''
        if clusterauthwuser:
            value = value + 'rwx:%s ' % clusterauthwuser
        if clusterauthruser:
            value = value + 'r-x:%s ' % clusterauthruser
        clusterservicename = path.split('/')[2]
        targetpath = path.replace("/cluster2/%s/" % clusterservicename,"")
        retcode = clusservicelib.func_service_edit_auth(clusterservicename,targetpath,value)
        return retcode

    def POST(self):
        return self.action(ajax=True)
    def GET(self):
        return self.render(ajax=True)