$def with (content)

{
    "sZeroRecords": "$_('No Records Found!')",
    "sLengthMenu": "$_('show _MENU_ entries')",
    "sUnitMenu": "$_('Unit _UNIT_')",
    "sInfo": "$_('From _START_ to _END_ item the total is _TOTAL_ ')",
    "sInfoEmpty": "$_('Records is 0')",
    "sInfoFiltered": "",
    "sInfoPostFix": "",
    "sSearch": "$_('Search')",
    "sUrl": "",
    "oPaginate": {
        "sFirst": "$_('First Page')",
        "sPrevious": "$_('Previous Page')",
        "sNext": "$_('Next Page')",
        "sLast": "$_('Last Page')"
    }
}
