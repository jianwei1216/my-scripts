#!/usr/bin/env python
#-*- coding: utf-8 -*-

import os
import sys
import subprocess
import re
import copy
import utils
from logger import logger
from logger import Ologger
from xml.dom import minidom
from read_from_pipe import *
import xml.etree.ElementTree as etree

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)
homepath = currpath[:currpath.find('libcommon')]
if not homepath in sys.path:
    sys.path.append(homepath)
import settings
from base import _

def func_login(username, passwd):
    try:
        cmd = "sudo python %s login %s %s -w" % (settings.digimanager, username, passwd)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        Ologger.info(cmd)
        retcode = proc.stdout.read().strip()
        print >> sys.stderr, retcode
        proc.wait()
        return retcode == '0' and retcode or _(retcode)
    except Exception,e:
        logger.debug(e)
        return retcode == '0' and retcode or _(retcode)
    
def func_logout():
    try:
        cmd = "sudo python %s logout"% (settings.digimanager)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        print >> sys.stderr, cmd
        Ologger.info(cmd)
        retcode = proc.stdout.read().strip()
        print >> sys.stderr, retcode
        proc.wait()
        return retcode == '0' and retcode or _(retcode)
    except Exception,e:
        logger.debug(e)
        return retcode == '0' and retcode or _(retcode)

def func_manager_check(ipaddr):
    try:
        cmd = "sudo python %s manager_check %s" % (settings.digimanager, ipaddr)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        Ologger.info(cmd)
        retcode = proc.stdout.read().strip()
        proc.wait()
        print >> sys.stderr, retcode
        if retcode!='0':
            retcode=retcode.split(':')
            retcode=retcode[0]			
        return retcode == '0' and retcode or _(retcode)
    except Exception,e:
        logger.debug(e)
        return retcode == '0' and retcode or _(retcode)

def func_manager_set(ipaddr):
    try:
        cmd = "sudo python %s manager_set %s" % (settings.digimanager, ipaddr)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        Ologger.info(cmd)
        retcode = proc.stdout.read().strip()
        print >> sys.stderr, retcode
        if retcode!='0':
            retcode=retcode.split(':')
            retcode=retcode[0]			
        proc.wait()
        return retcode == '0' and retcode or _(retcode)
    except Exception,e:
        logger.debug(e)
        return retcode == '0' and retcode or _(retcode)

def func_manager_get():
    try:
        cmd = "sudo python %s manager_get" % (settings.digimanager)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        Ologger.info(cmd)
        result = proc.stdout.readlines()
        print >> sys.stderr, result
        retcode = result[0].strip()
        proc.wait()
        if retcode == "0":
            data = result[1].strip()
            print >> sys.stderr, data
            return data 
        else:
            return retcode == '0' and retcode or _(retcode)
    except Exception,e:
        logger.debug(e)
        return retcode == '0' and retcode or _(retcode)

def func_domain_set(domainname):
    try:
        cmd = "sudo python %s domain_set %s" % (settings.digimanager, domainname)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        Ologger.info(cmd)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        print >> sys.stderr, retcode
        if retcode!='0':
            retcode=retcode.split(':')
            retcode=retcode[0]			
        proc.wait()
        return retcode == '0' and retcode or _(retcode)
    except Exception,e:
        logger.debug(e)
        return retcode == '0' and retcode or _(retcode)

def func_domain_get():
    try:
        cmd = "sudo python %s domain_get" % (settings.digimanager)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        Ologger.info(cmd)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        print >> sys.stderr, retcode
        if retcode!='0':
            return 
        return result[1].strip()
    except Exception,e:
        logger.debug(e)
        return 
    
def func_dashboard_info(nodes, infotype):
    try:
        cmd = 'sudo python %s node list_%s_info %s' % (settings.digimanager, infotype, nodes)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        Ologger.info(cmd)
        proc.wait()
        result_proc = proc.stdout.readlines()
        retcode = result_proc[0].strip()
        xml_dict = {}
        for node in nodes.split(','):
            try:
                f = open('/etc/digioceanfs_manager/nodes/' + node + '_' + infotype + 'sysinfo','r')
                str = f.read()
                result_xml = str.split('\n')
                xml_str = ''.join(str.split('\n')[1:])
                xml_dom = minidom.parseString(xml_str)
                print >> sys.stderr, xml_dom.toxml()
                xml_dict[node.encode('utf-8')] = xml_dom.toxml().encode('utf-8')
            except Exception,e:
                import traceback
                print >> sys.stderr, traceback.print_exc(e)
        if retcode == '0':
            return xml_dict#.replace('\t','')
        else:
            return retcode == '0' and retcode or _(retcode)
    except Exception,e:
        logger.debug(e)
        return retcode == '0' and retcode or _(retcode)
