
{
    "sZeroRecords": "没有您要搜索的内容",
    "sLengthMenu": "每页显示 _MENU_ 条",
    "sUnitMenu": "存储单位 _UNIT_ ",
    "sInfo": "从 _START_ 到 _END_ 条记录--总共 _TOTAL_ 条",
    "sInfoEmpty": "没有记录！",
    "sInfoFiltered": "there is _MAX_ records",
    "sInfoPostFix": "",
    "sSearch": "搜索",
    "sUrl": "",
    "oPaginate": {
        "sFirst": "第一页",
        "sPrevious": "上一页",
        "sNext": "下一页",
        "sLast": "末页"
    }
}
