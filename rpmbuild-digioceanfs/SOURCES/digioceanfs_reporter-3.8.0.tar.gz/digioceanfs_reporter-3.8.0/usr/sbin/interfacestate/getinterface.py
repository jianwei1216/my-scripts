#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import snmp_passpersist as snmp
import interface
import syslog
pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.6.2.1")
def update():
    rtndata = interface.getInterfacesmsg()
    i = 1
    for m in range(len(rtndata)):
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),rtndata[m]['name'])
        pp.add_str('3.' + str(i),rtndata[m]['mode'])
        pp.add_str('4.' + str(i),rtndata[m]['link'])
        pp.add_str('5.' + str(i),rtndata[m]['up'])
        i = i + 1

pp.start(update,1)
