#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import re
import utils

ethfile = '/etc/network/interfaces'
ethtool = '/sbin/ethtool'
ifconfig = '/sbin/ifconfig'
modelist = ['Balance Round-Robin','Active Backup','Balance - XOR','Broadcast','802.3ad','Balance-tlb','Balance-alb']
def bootInterfaces():
    ethmsg = []
    msg = []
    eth = {}
    retcode,proc = utils.cust_popen2([ifconfig])
    result = proc.stdout.readlines()
    for data in result:
        if data != '\n':
            msg.append(data)
        else:
            a = msg[0].split(' ')
            if a[0].strip() != 'lo':
                eth['name'] = a[0].strip()
                if eth['name'].find('bond') != -1:
                    f,fstat = utils.cust_fopen(ethfile,'r')
                    lines = f.readlines()
                    for line in lines:
                        if line.find('bond_mode') != -1:
                            b = line.split(' ')
                            eth['mode'] = modelist[int(b[1].strip())]
                for m in msg:
                    if m.find('BROADCAST') != -1:
                        if m.find('UP') != -1:
                            eth['up'] = 'yes'
                        else:
                            eth['up'] = 'no'
                retcode,proc = utils.cust_popen("%s %s | awk -F\Speed: '/Speed:/{print $2}'" % (ethtool,eth['name']))
                speed = proc.stdout.read().strip()
                retcode,proc = utils.cust_popen("%s %s | awk -F\Duplex: '/Duplex:/{print $2}'" % (ethtool,eth['name']))
                duplex = proc.stdout.read().strip()
                retcode,proc = utils.cust_popen("%s %s | grep 'Link detected' | awk -F\: '{print $2}'" % (ethtool,eth['name']))
                eth['link'] = proc.stdout.read().strip()
                if speed and duplex:
                    eth['mode'] = '%s %s' % (speed,duplex)
                ethmsg.append(eth)
                eth = {}
            msg = []
    return ethmsg

def getInterfacesmsg():
    data = bootInterfaces()
    return data

bootInterfaces()
