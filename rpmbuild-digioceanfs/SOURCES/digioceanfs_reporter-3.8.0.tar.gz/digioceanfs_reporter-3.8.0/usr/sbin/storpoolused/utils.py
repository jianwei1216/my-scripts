#!/usr/bin/python
#-*- coding: UTF-8 -*-

import re
import os
import sys
import stat
import time
import string
import subprocess
import traceback
import fcntl
import platform

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if currpath not in sys.path:
    sys.path.append(currpath)

homepath = currpath[:currpath.find('libcommon')]
if not homepath in sys.path:
    sys.path.append(homepath)

#-------------------------
# globals
#-------------------------
def check_if_debian6():
    DEBIAN6 = False
    pf = platform.platform()
    if pf.find('debian-6') >= 0:
        DEBIAN6 = True
    return DEBIAN6
#-------------------------
miitool = '/sbin/mii-tool'
ethtool = '/usr/sbin/ethtool'
if check_if_debian6():
    ethtool = '/sbin/ethtool'
VGLOCK = '/var/lock/digitools/vglock'
DISKLOCK = '/var/lock/digitools/disklock'
RAIDLOCK = '/var/lock/digitools/raidlock'
COPYLOCK = '/var/lock/digitools/copylock'
NETLOCK = '/var/lock/digitools/netlock'
CRONLOCK = '/var/lock/digitools/cronlock'
EXPIRETIMEOUT = 180
#-----------------------
#	Exceptions
#-----------------------
class ExecCommandError(Exception):
    pass
#-----------------------
#	functions
#-----------------------
def cust_popen(cmd,close_fds=True):
    try:
        proc = subprocess.Popen('sudo %s' % cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=close_fds)
        retcode = proc.wait()
        return retcode,proc
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        raise ExecCommandError,e

def cust_popen2(cmdlist,close_fds=True):
    lastcmdlist = ['sudo']
    lastcmdlist.extend(cmdlist)
    try:
        proc = subprocess.Popen(lastcmdlist,shell=False,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=close_fds)
        retcode = proc.wait()
        return retcode,proc
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        raise ExecCommandError,e
        
def cust_popen3(cmd,close_fds=True):
    try:
        proc = subprocess.Popen('sudo %s' % cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=close_fds)
        return proc
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        raise ExecCommandError,e

def change_fstat(filepath):
    fstat = int(oct(stat.S_IMODE(os.stat(filepath).st_mode)))
    retcode,proc = cust_popen('chmod 777 %s' % filepath)
    return fstat

def recover_fstat(filepath,fstat):
    retcode,proc = cust_popen('chmod %d %s' % (int(fstat),filepath))
        
def cust_fopen(filepath,mode='r'):
    if os.path.exists(filepath):
        fstat = change_fstat(filepath)
        f = open(filepath,mode)
        return f,fstat
    else:
        if mode.startswith('a') or mode.startswith('w') or mode.startswith('r+'):
            parentdir = os.path.split(filepath)[0]
            if not os.path.exists(parentdir):
                retcode,proc = cust_popen2(['mkdir','-p',parentdir])
            retcode,proc = cust_popen('touch %s' % filepath)
            fstat = change_fstat(filepath)
            f = open(filepath,mode)
            return f,fstat
        else:
            raise IOError,'%s not exists' % filepath

def cust_fclose(f,fstat):
    recover_fstat(f.name,fstat)
    #retcode,proc = cust_popen('chmod %d %s' % (fstat,f.name))
    f.close()
    
def read_file(*arg):
    #Fill an associative array with name=value pairs from a file
    lst = list(arg)
    length = len(lst)
    retcode,proc = cust_popen("cat %s" % lst[0])
    result = proc.stdout.readlines()
    #o = open(lst[0],"r")
    #lines = o.readlines()
    #o.close()
    for line in result:
        line = line.rstrip()
        m = re.match("^([^=]+)=(.*)$",line)
        if not re.search("^#",line) and m:
            if length >= 4:
                str = m.group(1).lower()
            else:
                str = m.group(1)
            lst[1][str] = m.group(2)
            if length >= 3:
                lst[2].append(m.group(1))
    return lst
    
def check_ipaddress(ip):
    #check if ip address in right format
    m = re.match("^(\d+)\.(\d+)\.(\d+)\.(\d+)$",ip)
    if m:
        if 1 <= string.atoi(m.group(1)) <= 255 and 0 <= string.atoi(m.group(2)) <= 255 and 0 <= string.atoi(m.group(3)) <= 255 and 0 <= string.atoi(m.group(4)) <= 255:
            return ip
    return 0
    
def check_ip(ip):
    """
    check the ip address
    """
    p = re.compile(r"^(([1-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.)(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){2}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$")
    if p.match(ip):
        return True
    else:
        return False
    
def read_file_lines(file):
    lines = []
    retcode,proc = cust_popen("cat %s" % file)
    result = [line.strip() for line in proc.stdout.readlines()]
    #f = open(file,'r')
    #line = f.readline()
    #while line:
    #    lines.append(line.rstrip())
    #    line = f.readline()
    #f.close()
    return result
    
def flush_file_lines(file,lst):
    f,fstat = cust_fopen(file,'w')
    #f = open(file,'w')
    for line in lst:
        f.write(line)
    f.write('\n')
    cust_fclose(f,fstat)
    #f.close()

def read_env_file(*arg):
    modelist = ['Balance Round-Robin','Active Backup','Balance - XOR','Broadcast','802.3ad','Balance-tlb','Balance-alb']
    arglist = list(arg)
    ethlist = []
    conf = {}
    f,fstat = cust_fopen(arglist[0],'r')
    #f = open(arglist[0],'r')
    line = f.readline()
    find = False
    while line:
        mstr = re.match('auto\s+(\S+)',line)
        mstr1 = re.match('^#auto\s+(\S+)',line)
        if mstr and mstr.group(1) != 'lo':
            conf['ONBOOT'] = 'yes'
            find = True
        if mstr1 and mstr1.group(1) != 'lo':
            conf['ONBOOT'] = 'no'
            find = True
        if find:
            line = f.readline()
            m = re.match('iface\s+(eth\S+)\s+inet\s+(\S+)\n',line)
            bond = re.match('iface\s+(bond\S+)\s+inet\s+(\S+)\n',line)
            if m:
                conf['DEVICE'] = m.group(1)
                #retcode,proc = cust_popen("%s %s" % (ethtool,conf['DEVICE']))
                #echoresult = proc.stdout.read()
                #print >> sys.stderr,echoresult
                #retcode,proc = cust_popen("%s %s | awk -F\link '/link/{print $2}'" % (miitool,conf['DEVICE']))
                retcode,proc = cust_popen("%s %s | grep 'Link detected:' | awk -F\: '{print $2}'" % (ethtool,conf['DEVICE']))
                #proc = subprocess.Popen("%s %s | awk -F\link '/link/{print $2}'" % (miitool,conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE)
                #proc.wait()
                result = proc.stdout.read().strip()
                conf['LINK'] = result
                conf['MODE'] = None 
                speed = ''
                duplex = ''
                if re.match("(\S+):(\d+)",conf['DEVICE']):
                    #retcode,proc = cust_popen("%s %s" % (ethtool,conf['DEVICE']))
                    retcode,proc = cust_popen("%s %s | awk -F\Speed: '/Speed:/{print $2}'" % (ethtool,conf['DEVICE']))
                    speed = proc.stdout.read().strip()
                    retcode,proc = cust_popen("%s %s | awk -F\Duplex: '/Duplex:/{print $2}'" % (ethtool,conf['DEVICE']))
                    duplex = proc.stdout.read().strip()
                    if speed and duplex:
                        conf['MODE'] = '%s %s' % (speed,duplex)
                    #proc = subprocess.Popen("%s %s | awk -F\link '/link/{print $1}'| awk -F\: '{print $3}'" % (miitool,conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE)
                else:
                    #retcode,proc = cust_popen("%s %s | awk -F\link '/link/{print $1}'| awk -F\: '{print $2}'" % (miitool,conf['DEVICE']))
                    #proc = subprocess.Popen("%s %s | awk -F\link '/link/{print $1}'| awk -F\: '{print $2}'" % (miitool,conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE)
                    retcode,proc = cust_popen("%s %s | awk -F\Speed: '/Speed:/{print $2}'" % (ethtool,conf['DEVICE']))
                    speed = proc.stdout.read().strip()
                    retcode,proc = cust_popen("%s %s | awk -F\Duplex: '/Duplex:/{print $2}'" % (ethtool,conf['DEVICE']))
                    duplex = proc.stdout.read().strip()
                    if speed and duplex:
                        conf['MODE'] = '%s %s' % (speed,duplex)
                #proc.wait()
                retcode,proc = cust_popen("ifconfig %s | awk '/%s/{print $5}'" % (conf['DEVICE'],conf['DEVICE']))
                #proc = subprocess.Popen("ifconfig %s | awk '/%s/{print $5}'" % (conf['DEVICE'],conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE)
                #conf['MAC'] = proc.stdout.read()
                #proc.wait()
                result = proc.stdout.read().strip()
                conf['MAC'] = result
                conf['DHCP'] = m.group(2)
                if conf['DHCP'] == 'dhcp':
                    retcode,proc = cust_popen('ifconfig %s | sed -n 1,2p' % conf['DEVICE'])
                    result = ''.join(proc.stdout.readlines() + proc.stderr.readlines())
                    #proc = subprocess.Popen('ifconfig %s | sed -n 1,2p' % conf['DEVICE'],shell=True,close_fds = True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                    #result = ''.join(proc.stdout.readlines() + proc.stderr.readlines())
                    #proc.wait()
                    mp = re.search('%s\s+Link encap:(\S+)\s+HWaddr\s+(\S+)\s+inet addr:(\S+)\s+Bcast:(\S+)\s+Mask:(\S+).*' % conf['DEVICE'],result)
                    if mp:
                        conf['IPADDR'] = mp.group(3)
                        conf['NETMASK'] = mp.group(5)
                        conf['BROADCAST'] = mp.group(4)
                        conf['GATEWAY'] = ''
                        conf['NETWORK'] = ''
                    else:
                        conf['IPADDR'] = ''
                        conf['NETMASK'] = ''
                        conf['BROADCAST'] = ''
                        conf['GATEWAY'] = ''
                        conf['NETWORK'] = ''
                    line = f.readline()
                    while line:
                        mt = re.match('mtu\s+(\d+)',line)
                        if mt:
                            conf['MTU'] = mt.group(1)
                        else:
                            curraddr = f.tell() - len(line)
                            f.seek(curraddr)
                            break
                        line = f.readline()
                    ethlist.append(conf)
                    conf = {}
                    find = False
                    line = f.readline()
                    continue
                conf['IPADDR'] = ''
                conf['NETMASK'] = ''
                conf['BROADCAST'] = ''
                conf['GATEWAY'] = ''
                conf['NETWORK'] = ''
                netheadmatch = ['auto\s+(\S+)','^#auto\s+(\S+)']
                netdetailmatch = [('address\s+(\S+)','IPADDR'),('netmask\s+(\S+)','NETMASK'),('broadcast\s+(\S+)','BROADCAST'),('gateway\s+(\S+)','GATEWAY'),('network\s+(\S+)','NETWORK'),('mtu\s+(\d+)','MTU')]
                line = f.readline()
                while line:
                    dflag = False
                    for netdetail in netdetailmatch:
                        nd = re.match(netdetail[0],line)
                        if nd:
                            dflag = True
                            conf[netdetail[1]] = nd.group(1)
                    if not dflag:
                        curraddr = f.tell() - len(line)
                        f.seek(curraddr)
                        break
                    line = f.readline()
                """         
                n = re.match('address\s+(\S+)',line)
                if n:
                    conf['IPADDR'] = n.group(1)
                line = f.readline()
                o = re.match('netmask\s+(\S+)',line)
                if o:
                    conf['NETMASK'] = o.group(1)
                line = f.readline()
                p = re.match('broadcast\s+(\S+)',line)
                if p:
                    conf['BROADCAST'] = p.group(1)
                if len(conf['DEVICE']) > 5:
                    ethlist.append(conf)
                    conf = {}
                    line = f.readline()
                    continue
                line = f.readline()
                q = re.match('gateway\s+(\S+)',line)
                if q:
                    conf['GATEWAY'] = q.group(1)
                """
                ethlist.append(conf)
                conf = {}
            if bond:
                bondsignal = 0
                for eth in ethlist:
                    if re.search('bond',eth['DEVICE']):
                        bondsignal = 1
                #if bondsignal == 0:
                #    ethlist = []
                conf['DEVICE'] = bond.group(1)
                conf['DHCP'] = bond.group(2)
                #retcode,proc = cust_popen("%s %s | awk -F\link '/link/{print $2}'" % (miitool,conf['DEVICE']))
                retcode,proc = cust_popen("%s %s | grep 'Link detected' | awk -F\: '{print $2}'" % (ethtool,conf['DEVICE']))
                #proc = subprocess.Popen("%s %s | awk -F\link '/link/{print $2}'" % (miitool,conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE)
                conf['LINK'] = proc.stdout.read().strip()
                #proc.stdout.close()
                #proc.wait()
                #proc = subprocess.Popen("%s %s | awk -F\link '/link/{print $1}'| awk -F\: '{print $2}'" % (miitool,conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE)
                conf['MODE'] = None
                #proc.stdout.close()
                #proc.wait()
                retcode,proc = cust_popen("ifconfig %s | awk '/%s/{print $5}'" % (conf['DEVICE'],conf['DEVICE']))
                #proc = subprocess.Popen("ifconfig %s | awk '/%s/{print $5}'" % (conf['DEVICE'],conf['DEVICE']),shell=True,close_fds = True,stdout=subprocess.PIPE)
                conf['MAC'] = proc.stdout.read()
                #proc.stdout.close()
                #proc.wait()
                if conf['DHCP'] == 'dhcp':
                    retcode,proc = cust_popen('ifconfig %s | sed -n 1,2p' % conf['DEVICE'])
                    #proc = subprocess.Popen('ifconfig %s | sed -n 1,2p' % conf['DEVICE'],shell=True,close_fds = True,stdout=subprocess.PIPE)
                    result = ''.join(proc.stdout.readlines())
                    #proc.wait()
                    mp = re.search('%s\s+Link encap:(\S+)\s+HWaddr\s+(\S+)\s+inet addr:(\S+)\s+Bcast:(\S+)\s+Mask:(\S+).*' % conf['DEVICE'],result)
                    if mp:
                        conf['IPADDR'] = mp.group(3)
                        conf['NETMASK'] = mp.group(5)
                        conf['BROADCAST'] = mp.group(4)
                    line = f.readline()
                    while line:
                        mt = re.match('mtu\s+(\d+)',line)
                        if mt:
                            conf['MTU'] = mt.group(1)
                        else:
                            curraddr = f.tell() - len(line)
                            f.seek(curraddr)
                            break
                        line = f.readline()
                    ethlist.append(conf)
                    conf = {}
                    find = False
                    line = f.readline()
                    continue
                conf['IPADDR'] = ''
                conf['NETMASK'] = ''
                conf['BROADCAST'] = ''
                conf['GATEWAY'] = ''
                conf['NETWORK'] = ''
                netheadmatch = ['auto\s+(\S+)','^#auto\s+(\S+)']
                netdetailmatch = [('address\s+(\S+)','IPADDR'),('netmask\s+(\S+)','NETMASK'),('broadcast\s+(\S+)','BROADCAST'),('gateway\s+(\S+)','GATEWAY'),('network\s+(\S+)','NETWORK'),('mtu\s+(\d+)','MTU'),('slaves\s+(.*)','SLAVES'),('bond_mode\s+(\d+)','MODE')]
                line = f.readline()
                while line:
                    dflag = False
                    for netdetail in netdetailmatch:
                        nd = re.match(netdetail[0],line)
                        if nd:
                            dflag = True
                            if netdetail[1] == 'MODE':
                                conf[netdetail[1]] = modelist[int(nd.group(1))]
                            else:
                                conf[netdetail[1]] = nd.group(1)
                    if not dflag:
                        if re.match('auto\s+(\S+)',line) or re.match('^#auto\s+(\S+)',line):
                            curraddr = f.tell() - len(line)
                            f.seek(curraddr)
                            break
                    #if not dflag:
                    #    if re.match('iface\s+(\S+)\s+inet\s+(\S+)',line):
                    #        curraddr = f.tell() - len(line)
                    #        f.seek(curraddr)
                    #        break
                    line = f.readline()
                conf['slaveinfos'] = []
                if 'SLAVES' in conf and conf['SLAVES']:
                    slaves = conf['SLAVES'].split()
                    for slave in slaves:
                        slaveinfo = {'iface':slave,'mode':None,'link':False}
                        retcode,proc = cust_popen("%s %s | awk -F\link '/link/{print $1}'| awk -F\: '{print $2}'" % (miitool,slave))
                        result = proc.stdout.read().strip()[:-1]
                        remode = re.match('[^\d]*(\d+\S+)(\s*\S*)',result)
                        if remode:
                            slaveinfo['mode'] = remode.group(1)
                        retcode,proc = cust_popen("%s %s | awk -F\link '/link/{print $2}'" % (miitool,slave))
                        result = proc.stdout.read().strip()
                        if retcode == 0 and result and result == 'ok':
                            slaveinfo['link'] = True
                        conf['slaveinfos'].append(slaveinfo)
                        for eth in ethlist:
                            if re.search(slave,eth['DEVICE']):
                                ethlist.remove(eth)
                                break
                ethlist.append(conf)
                conf = {}
        find = False
        line = f.readline()
    cust_fclose(f,fstat)
    #f.close()
    return ethlist
    
def write_env_file(*arg):
    lst = list(arg)
    fstr = lst[0]
    conf = lst[1]
    if len(lst) > 2:
        f,fstat = cust_fopen(fstr,'r+')
        #f = open(fstr,'r+')
        line = f.readline()
        while line:
            if re.search('^up',line):
                addr = f.tell() - len(line)
                line = f.readline()
                temp = f.read()
                f.seek(addr)
                f.truncate()
                f.write(temp)
                f.seek(0)
            line = f.readline()
        for i in conf:
            f.write(i)
        #f.close()
        cust_fclose(f,fstat)
    else:
        ethlist = read_env_file(fstr)
        curreth = None
        typestr = ''
        signal = 0
        bsignal = conf['ONBOOT']
        #f = open(fstr,'r+')
        f,fstat = cust_fopen(fstr,'r+')
        line = f.readline()
        matchstr1 = 'auto %s\n' % conf['DEVICE']
        matchstr2 = '#auto %s\n' % conf['DEVICE']
        staticitems = ['iface','address','netmask','broadcast','gateway','mtu']
        for eth in ethlist:
            if conf['DEVICE'] == eth['DEVICE']:
                typestr = eth['DHCP']
                curreth = eth
                break
        if conf['DHCP'] == 'static':
            ifacestr = 'iface %s inet %s\n' % (conf['DEVICE'],conf['DHCP'])
            addrstr = 'address %s\n' % conf['IPADDR']
            netmaskstr = 'netmask %s\n' % conf['NETMASK']
            #brostr = 'broadcast %s\n' % conf['BROADCAST']
            gatestr = 'gateway %s\n' % conf['GATEWAY']
            mtustr = None
            if 'MTU' in conf and conf['MTU']:
                mtustr = 'mtu %s\n' % conf['MTU']
            while line:
                if re.search(matchstr1,line):
                    signal = 1
                    addr = f.tell() - len(line)
                    if typestr == 'static':
                        while True:
                            itemin = False
                            line = f.readline()
                            for staticitem in staticitems:
                                if line.find(staticitem) >= 0:
                                    itemin = True
                                    break
                            if itemin:
                                continue
                            else:
                                f.seek(f.tell() - len(line))
                                break
                        #if 'GATEWAY' in curreth and curreth['GATEWAY'] != '':
                        #    line = f.readline()
                        #if 'MTU' in curreth and curreth['MTU'] != '':
                        #    line = f.readline()
                    else:
                        line = f.readline()
                    temp = f.read()
                    f.seek(addr)
                    f.truncate()
                    if bsignal == 'yes':
                        f.write(matchstr1)
                    else:
                        f.write(matchstr2)
                    f.write(ifacestr)
                    f.write(addrstr)
                    f.write(netmaskstr)
                    #f.write(brostr)
                    if conf['GATEWAY'] != '':
                        f.write(gatestr)
                    else:
                        f.write('#gateway\n')
                    if mtustr:
                        f.write(mtustr)
                    f.write(temp)
                    break
                line = f.readline()
            if signal == 0:
                if bsignal == 'yes':
                    f.write(matchstr1)
                else:
                    f.write(matchstr2)
                f.write(ifacestr)
                f.write(addrstr)
                f.write(netmaskstr)
                #f.write(brostr)
                if conf['GATEWAY'] != '':
                    f.write(gatestr)
                else:
                    f.write('#gateway\n')
                if mtustr:
                    f.write(mtustr)
        else:
            ifacestr = 'iface %s inet %s\n' % (conf['DEVICE'],conf['DHCP'])
            mtustr = None
            if 'MTU' in conf and conf['MTU']:
                mtustr = 'mtu %s\n' % conf['MTU']
            while line:
                if re.search(matchstr1,line):
                    signal = 1
                    addr = f.tell() - len(line)
                    if typestr == 'static':
                        while True:
                            itemin = False
                            line = f.readline()
                            for staticitem in staticitems:
                                if line.find(staticitem) >= 0:
                                    itemin = True
                                    break
                            if itemin:
                                continue
                            else:
                                f.seek(f.tell() - len(line))
                                break
                        #for i in range(4):
                        #    line = f.readline()
                        #if curreth['GATEWAY'] != '':
                        #    line = f.readline()
                        #if curreth['MTU'] != '':
                        #    line = f.readline()
                    else:
                        line = f.readline()
                    temp = f.read()
                    f.seek(addr)
                    f.truncate()
                    if bsignal == 'yes':
                        f.write(matchstr1)
                    else:
                        f.write(matchstr2)
                    f.write(ifacestr)
                    if mtustr:
                        f.write(mtustr)
                    f.write(temp)
                    break
                line = f.readline()
        #f.close()
        cust_fclose(f,fstat)

def has_command(cmd):
    if not cmd:
        return False
    if re.search('^\/',cmd):
        if os.access(cmd,os.X_OK):
            return True
        else:
            return False
    lst = os.environ['PATH'].split(':')
    for d in lst:
        if os.access('%s/%s' % (d,cmd),os.X_OK):
            return True
    return False
#------------------------
# sort disk id
#------------------------
def embedded_numbers(s):  
    re_digits = re.compile(r'(\d+)') 
    pieces = re_digits.split(s)
    pieces[1::2] = map(int, pieces[1::2])
    return pieces
    
def sort_strings(alist):  
    return sorted(alist, key=embedded_numbers)
#------------------------
# check software installed or not
#------------------------
def check_installed(softname):
    installed = False
    if softname:
        retcode,proc = cust_popen('dpkg -l | grep %s' % softname)
        result = proc.stdout.readlines()
        if result:
            installed = True
    return installed
#-----------------------------------
# check lock exists
#-----------------------------------
def is_lock(locktype):
    islock = False
    lockfile = eval('%sLOCK' % locktype.upper())
    if os.path.isfile(lockfile):
        islock = True
    return islock
#-----------------------------------
# set lock
#-----------------------------------
def set_lock(locktype):
    lockstat = False
    lockstr = '%slock' % locktype
    lockfile = eval('%sLOCK' % locktype.upper())
    try:
        if not os.path.isfile(lockfile):
            retcode,proc = cust_popen2(['mkdir','-p',lockfile.replace(lockstr,'')])
            f,fstat = cust_fopen(lockfile,'w')
            cust_fclose(f,fstat)
            lockstat = True
        else:
            if time.time() - os.stat(lockfile).st_mtime > EXPIRETIMEOUT:
                release_lock(locktype)
            if not is_lock(locktype):
                retcode,proc = cust_popen2(['mkdir','-p',lockfile.replace(lockstr,'')])
                f,fstat = cust_fopen(lockfile,'w')
                cust_fclose(f,fstat)
                lockstat = True
    except:
        print >> sys.stderr,traceback.print_exc()
    return lockstat
#-----------------------------------
# release lock
#-----------------------------------
def release_lock(locktype):
    releasestat = False
    trytime = 0
    maxtrytime = 3
    lockfile = eval('%sLOCK' % locktype.upper())
    try:
        if os.path.isfile(lockfile):
            while trytime < maxtrytime and not releasestat:
                retcode,proc = cust_popen2(['rm','-rf',lockfile])
                if retcode == 0:
                    releasestat = True
                else:
                    trytime += 1
    except:
        print >> sys.stderr,traceback.print_exc()
    return releasestat
#------------------------------------
# check module exists
#------------------------------------
def check_module(modulename):
    moduleinstalled = False
    retcode,proc = cust_popen('lsmod | grep %s' % modulename)
    result = proc.stdout.read().strip()
    if result:
        moduleinstalled = True
    return moduleinstalled
#------------------------------------
# load module
#------------------------------------    
def load_module(modulename):
    moduleloaded = False
    if check_module(modulename):
        moduleloaded = True
    else:
        retcode,proc = cust_popen('modprobe %s' % modulename)
        if check_module(modulename):
            moduleloaded = True
    return moduleloaded
#------------------------------------
# 
#------------------------------------
def peoplereadnum(number):
    unit = 'K'
    if number > pow(1024,4):
        number = round(number / pow(1024,4),3)
        unit = 'PB'
    elif number > pow(1024,3):
        number = round(number / pow(1024,3),3)
        unit = 'TB'
    elif number > pow(1024,2):
        number = round(number / pow(1024,2),3)
        unit = 'GB'
    elif number > pow(1024,1):
        number = round(number / pow(1024,1),3)
        unit = 'MB'
    return number,unit
#--------------------------------
# smart encode
#--------------------------------
def smart_encode(estr):
    if type(estr) == unicode:
        try:
            estr = estr.encode('utf-8')
        except:
            try:
                estr = estr.encode('gbk')
            except:
                pass
    return estr
