#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import re
import string
import utils
VGS = '/sbin/vgs'
def getstorpoolused ():
    vginfos = []
    retcode,proc = utils.cust_popen2([VGS])
    result = proc.stdout.readlines()
    if result:
        result.pop(0)
    for line in result:
        vgtemp = re.split("\x20*",line)
        if vgtemp:
            if vgtemp[1].strip().startswith('StorPool'):
                vginfo = {}
                vginfo['name'] = vgtemp[1].strip()
                a = vgtemp[6].strip()
                b = vgtemp[7].strip()
                if a[-1] == 't':
                    vgsize = string.atof(a[:-1]) * 1024 * 1024
                elif a[-1] == 'g':
                    vgsize = string.atof(a[:-1]) * 1024
                else:
                    vgsize = string.atof(a[:-1])
                if b != '0':
                    if b[-1] == 't':
                        lastsize = string.atof(b[:-1]) * 1024 * 1024
                    elif b[-1] == 'g':
                        lastsize = string.atof(b[:-1]) * 1024
                    else:
                        lastsize = string.atof(b[:-1])
                else:
                    lastsize = string.atof(b)
                vgused = round((vgsize - lastsize) / vgsize * 100,2)
                vginfo['vgused'] = str(vgused) + '%'
                vginfos.append(vginfo)
    return vginfos

getstorpoolused()
