#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import snmp_passpersist as snmp
import getused
pp=snmp.PassPersist(".1.3.6.1.4.1.38696.2.5.2.1")

def update():
    rtndata = getused.getstorpoolused ()
    i = 1
    for m in range(len(rtndata)):
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),rtndata[m]['name'])
        pp.add_str('3.' + str(i),rtndata[m]['vgused'])
        i = i + 1

pp.start(update,1)
