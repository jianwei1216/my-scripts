#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusnodelib
import setting
import snmp_passpersist as snmp

'''
Map of Interface MIB
+--NodeInactiveTable(8)
   |
   +--NodeInactiveEntry(1)
      |  Index: NodeInactiveIndex
      |
      +-- -R-- Integer32 NodeInactiveIndex(1)
      |        Range: 0..65535
      +-- -R-- String    NodeInactiveRaidname(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeInactiveRaidUuid(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- Gauge     NodeInactiveNormalCount(4)
      +-- -R-- Gauge     NodeInactiveDiskNum(5)
      +-- -R-- String    NodeInactiveChildName(6)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeInactiveChildType(7)
               Textual Convention: DisplayString
               Size: 0..255
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusnodelib.func_node_list_inactive(os.uname()[1])

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.20.8.1")
def update():
    #rtndata = [{'uuid': '9f01f703-af24575c-b4ab71af-7d64de8e', 'disk_num': 2, 'devname': 'md10', 'normal_count': 3, 'child': [{'sdb': 'clean'}, {'sdc': 'clean'}]}, {'uuid': '455a3a70-af5f6621-3ee44faf-4195e4f5', 'disk_num': 1, 'devname': 'md11', 'normal_count': 3, 'child': [{'sdd': 'clean'}]}]
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusnodelib.func_node_list_inactive(os.uname()[1])
        uptime = currtime

    i = 1
    for m in range(len(rtndata)):
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),rtndata[m]['devname'])
        pp.add_str('3.' + str(i),rtndata[m]['uuid'])
        pp.add_gau('4.' + str(i),int(rtndata[m]['normal_count']))
        pp.add_gau('5.' + str(i),int(rtndata[m]['disk_num']))
        j = 1
        child = rtndata[m]['child']
        for n in range(len(child)):
            pp.add_str('6.' + str(i) + '.' + str(j),child[n].keys()[0])
            pp.add_str('7.' + str(i) + '.' + str(j),child[n].values()[0])
            j = j + 1
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
