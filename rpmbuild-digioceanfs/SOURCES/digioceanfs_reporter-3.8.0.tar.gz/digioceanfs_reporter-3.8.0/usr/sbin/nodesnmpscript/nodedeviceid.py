#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusnodelib
import setting
import snmp_passpersist as snmp

'''
+--NodeDeviceIDTable(11)
   |
   +--NodeDeviceIDEntry(1)
      |
      +-- -R-- String    NodeDeviceIDNodeName(1)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeDeviceIDRegId(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeDeviceIDLicense(3)
               Textual Convention: DisplayString
               Size: 0..255
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusnodelib.func_node_get_device_id(os.uname()[1])

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.20.11.1")
def update():
    #rtndata = ['node-1.cluster-1', '7bb1cc05d0a8c2005d8cf80c5b4e8597', 'CDCAFF957DA8A701B6DAC4954BB86553']
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusnodelib.func_node_get_device_id(os.uname()[1])
        uptime = currtime

    pp.add_str('1',rtndata[0])
    pp.add_str('2',rtndata[1])
    pp.add_str('3',rtndata[2])

if __name__ == "__main__":
    pp.start(update,1)
