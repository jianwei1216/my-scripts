#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusnodelib
import setting
import snmp_passpersist as snmp

'''
Map of Interface MIB
+--NodeNFSStatusTable(9)
   |
   +--NodeNFSStatusEntry(1)
      |  Index: NodeNFSStatusIndex
      |
      +-- -R-- Integer32 NodeNFSStatusIndex(1)
      |        Range: 0..65535
      +-- -R-- String    NodeNFSStatusName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- EnumVal   NodeNFSStatusUp(3)
               Values: start(1), stop(0)
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata =clusnodelib.func_node_nfs_status()

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.20.9.1")
def update():
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata =clusnodelib.func_node_nfs_status()
        uptime = currtime

    i = 1
    for m in range(len(rtndata)):
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),rtndata.keys()[m])
        if rtndata.values()[m] == 'start':
            pp.add_int('3.' + str(i),1)
        else:
            pp.add_int('3.' + str(i),0)
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
