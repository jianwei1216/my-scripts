#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusservicelib
import setting
import snmp_passpersist as snmp

'''
+--ServiceCIFSLinkTable(8)
   |
   +--ServiceCIFSLinkEntry(1)
      |  Index: ServiceCIFSLinkIndex
      |
      +-- -R-- Integer32 ServiceCIFSLinkIndex(1)
      |        Range: 0..65535
      +-- -R-- String    ServiceCIFSLinkServiceName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceCIFSLinkNodeName(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceCIFSLinkStatus(4)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceCIFSLinkUserName(5)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- Integer32 ServiceCIFSLinkPid(6)
      |        Range: 0..32768
      +-- -R-- String    ServiceCIFSLinkTime(7)
               Textual Convention: DisplayString
               Size: 0..255
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusservicelib.func_service_cifs_list_links()

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.21.8.1")
def update():
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusservicelib.func_service_cifs_list_links()
        uptime = currtime

    i = 1
    for m in range(len(rtndata)):
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),rtndata[m]['servicename'])
        pp.add_str('3.' + str(i),rtndata[m]['nodename'])
        pp.add_str('4.' + str(i),rtndata[m]['link'])
        if rtndata[m]['username']:
            pp.add_str('5.' + str(i),rtndata[m]['username'])
        if 'pid' in rtndata[m] and rtndata[m]['pid']:
            pp.add_int('6.' + str(i),int(rtndata[m]['pid']))
        if rtndata[m]['time']:
            pp.add_str('7.' + str(i),rtndata[m]['time'])
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
