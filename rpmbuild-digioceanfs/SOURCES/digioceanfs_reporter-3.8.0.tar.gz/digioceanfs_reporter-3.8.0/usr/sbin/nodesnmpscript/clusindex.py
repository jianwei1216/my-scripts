#!/usr/bin/env python
#-*- coding: utf-8 -*-

import os
import sys
import subprocess
import re
import copy
from xml.dom import minidom
import xml.etree.ElementTree as etree

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)

DIGIMANAGER = "/usr/local/digioceanfs_manager/manager/digi_manager.pyc"

def func_domain_get():
    try:
        cmd = "sudo python %s domain_get" % (DIGIMANAGER)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        if retcode!='0':
            return ''
        return result[1].strip()
    except Exception,e:
        return ''
