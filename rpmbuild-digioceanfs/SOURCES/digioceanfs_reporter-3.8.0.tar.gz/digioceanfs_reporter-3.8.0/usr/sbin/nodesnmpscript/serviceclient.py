#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusservicelib
import setting
import snmp_passpersist as snmp

'''
+--ServiceClientTable(4)
   |
   +--ServiceClientEntry(1)
      |  Index: ServiceClientIndex
      |
      +-- -R-- Integer32 ServiceClientIndex(1)
      |        Range: 0..65535
      +-- -R-- String    ServiceClientServiceName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceClientNodeName(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- EnumVal   ServiceClientStatus(4)
               Values: start(1), stop(0)
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusservicelib.func_client_node_list_all()

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.21.4.1")
def update():
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusservicelib.func_client_node_list_all()
        uptime = currtime

    i = 1
    for m in range(len(rtndata)):
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),rtndata[m]['service_name'])
        pp.add_str('3.' + str(i),rtndata[m]['node_name'])
        if rtndata[m]['status'] == '1':
            pp.add_int('4.' + str(i),1)
        else:
            pp.add_int('4.' + str(i),0)

        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
