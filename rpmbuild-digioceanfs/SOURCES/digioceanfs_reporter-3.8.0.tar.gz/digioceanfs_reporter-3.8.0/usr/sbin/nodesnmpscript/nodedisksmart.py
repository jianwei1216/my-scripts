#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusnodelib
import setting
import snmp_passpersist as snmp

'''
Map of Interface MIB
+--NodeDiskSmartTable(7)
   |
   +--NodeDiskSmartEntry(1)
      |  Index: NodeDiskSmartIndex
      |
      +-- -R-- Integer32 NodeDiskSmartIndex(1)
      |        Range: 0..65535
      +-- -R-- String    NodeDiskSmartName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeDiskSmartSN(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- EnumVal   NodeDiskSmartStatus(4)
      |        Values: enabled(1), disabled(0)
      +-- -R-- EnumVal   NodeDiskSmartHealth(5)
      |        Values: true(1), false(0)
      +-- -R-- String    NodeDiskSmartExecutionStatus(6)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- Gauge     NodeDiskSmartAttrID(7)
      +-- -R-- String    NodeDiskSmartAttrName(8)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- Gauge     NodeDiskSmartAttrValue(9)
      +-- -R-- Gauge     NodeDiskSmartAttrWorst(10)
      +-- -R-- Gauge     NodeDiskSmartAttrThresh(11)
      +-- -R-- String    NodeDiskSmartAttrWhenFailed(12)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- Gauge     NodeDiskSmartAttrRawValue(13)
      +-- -R-- String    NodeDiskSmartAttrStatus(14)
               Textual Convention: DisplayString
               Size: 0..255
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusnodelib.func_node_smart_info(os.uname()[1])

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.20.7.1")
def update():
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusnodelib.func_node_smart_info(os.uname()[1])
        uptime = currtime

    i = 1
    for m in xrange(len(rtndata)):
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),rtndata[m]['Diskname'])
        pp.add_str('3.' + str(i),rtndata[m]['Serial_Number'])
        if rtndata[m]['Status'] == 'Enabled':
            pp.add_int('4.' + str(i),1)
        else:
            pp.add_int('4.' + str(i),0)
        if rtndata[m]['Health'] == 'PASSED':
            pp.add_int('5.' + str(i),1)
        else:
            pp.add_int('5.' + str(i),0)
        pp.add_str('6.' + str(i),rtndata[m]['Execution_Status'])
        Smartmsg = rtndata[m]['Smartmsg']
        j = 1
        for n in xrange(len(Smartmsg)):
            pp.add_gau('7.' + str(i) + '.' + str(j),int(Smartmsg[n][0]))
            pp.add_str('8.' + str(i) + '.' + str(j),Smartmsg[n][1])
            pp.add_gau('9.' + str(i) + '.' + str(j),int(Smartmsg[n][2]))
            pp.add_gau('10.' + str(i) + '.' + str(j),int(Smartmsg[n][3]))
            pp.add_gau('11.' + str(i) + '.' + str(j),int(Smartmsg[n][4]))
            pp.add_str('12.' + str(i) + '.' + str(j),Smartmsg[n][5])
            pp.add_gau('13.' + str(i) + '.' + str(j),int(Smartmsg[n][6]))
            pp.add_str('14.' + str(i) + '.' + str(j),Smartmsg[n][7])
            j = j + 1
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
