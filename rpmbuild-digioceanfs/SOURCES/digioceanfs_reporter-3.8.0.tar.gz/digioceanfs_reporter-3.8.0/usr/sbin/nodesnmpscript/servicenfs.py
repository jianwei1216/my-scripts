#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusservicelib
import setting
import snmp_passpersist as snmp

'''
+--ServiceNFSTable(9)
   |
   +--ServiceNFSEntry(1)
      |  Index: ServiceNFSIndex
      |
      +-- -R-- Integer32 ServiceNFSIndex(1)
      |        Range: 0..65535
      +-- -R-- String    ServiceNFSServiceName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- EnumVal   ServiceNFSStatus(3)
               Values: start(1), stop(0)
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusservicelib.func_service_nfs_export_status()

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.21.9.1")
def update():
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusservicelib.func_service_nfs_export_status()
        uptime = currtime

    i = 1
    for servicename in rtndata.keys():
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),servicename)
        if rtndata[servicename] == 'Started':
            pp.add_int('3.' + str(i),1)
        else:
            pp.add_int('3.' + str(i),0)
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
