#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusnodelib
import setting
import snmp_passpersist as snmp

'''
+--NodeSmsTable(13)
   |
   +--NodeSmsEntry(1)
      |
      +-- -R-- EnumVal   NodeSmsInuse(1)
      |        Values: true(1), false(0)
      +-- -R-- String    NodeSmsWarningType(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeSmsCenterNumber(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeSmsMobilePhone(4)
               Textual Convention: DisplayString
               Size: 0..255
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusnodelib.func_node_sms_info()

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.20.13.1")
def update():
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusnodelib.func_node_sms_info()
        uptime = currtime

    if rtndata['inuse'] == 'Disable':
        pp.add_int('1',0)
    else:
        pp.add_int('1',1)
    if 'ntype' in rtndata:
        for i in range(1,len(rtndata['ntype'])+1):
            pp.add_str('2.' + str(i), rtndata['ntype'][i-1])
    if 'smsp' in rtndata:
        pp.add_str('3',rtndata['smsp'])
    if 'mobp' in rtndata:
        for i in range(1,len(rtndata['mobp'])+1):
            pp.add_str('4.' + str(i),rtndata['mobp'][i-1])

if __name__ == "__main__":
    pp.start(update,1)
