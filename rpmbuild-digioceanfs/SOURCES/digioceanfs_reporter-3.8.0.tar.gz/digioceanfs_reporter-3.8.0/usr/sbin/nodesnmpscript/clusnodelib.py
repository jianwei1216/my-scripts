#!/usr/bin/env python
#-*- coding: utf-8 -*-

import os
import sys
import subprocess
import re
import copy
import traceback
import simplejson
from threading import Thread 
from xml.dom import minidom
import xml.etree.ElementTree as etree

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)

DIGIMANAGER = "/usr/local/digioceanfs_manager/manager/digi_manager.pyc"

def getUnit(unit, value, isB = 'false'):
    if isB == 'true':
        if unit == 'KB':
           value = round(float(value) / 1024, 2)
        elif unit == 'MB':
           value = round(float(value) / 1024/ 1024, 2)
        elif unit == 'GB':
           value = round(float(value) / 1024/ 1024/ 1024, 2)
        elif unit == 'TB':
           value = round(float(value) / 1024/ 1024/ 1024/ 1024, 2)
        return value
    else:
        if unit == 'KB':
           value = round(float(value) / 1, 2)
        elif unit == 'MB':
           value = round(float(value) / 1024, 2)
        elif unit == 'GB':
           value = round(float(value) / 1024/ 1024, 2)
        elif unit == 'TB':
           value = round(float(value) / 1024/ 1024/ 1024, 2)
        return value

#########################################################################################################
#
#   Function: func_node_list_all
#   Variable: list_status(this variable is to decide if data is sent to the servers side ),
#             clusternodes
#   Purpose: to list all nodes info
#   Data structure: type: list,
#                   ex: [{'nodename':node1, 'ipaddr':ipaddr, 'diskinfo':diskinfo, 'status':status}, {...}, ...]
#
#########################################################################################################
def func_node_list_all(list_status):
    clusternodes = []
    key = ['nodename','ipaddr','diskinfo','cifsstatus','nfsstatus','status']
    clusternodes_status = func_node_status()
    clusternodes_cifs_status = func_node_cifs_status()
    #clusternodes_nfs_status = func_node_nfs_status()clusternodes_nfs_status[value[0]],
    try:
        cmd = "sudo python %s node list" % DIGIMANAGER
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result.pop(0).strip()
        if retcode != '0':
            return clusternodes
        else:
            result.pop(-1)
            p = '^(\S+)\s(\S+)\s+$'
            for v in result:
                m = re.match(p, v)
                if m:
                    value = list(m.groups())
                    nodeinfo = [[],clusternodes_cifs_status[value[0]],'',clusternodes_status[value[0]]]
                    value.extend(nodeinfo)
                    d = dict(zip(key,value))
                    clusternodes.append(d)
            return clusternodes
    except Exception,e:
        return clusternodes

#########################################################################################################
#
#   Function: func_node_status
#   Variable: list_status(this variable is to decide if data is sent to the servers side ),
#             clusternodes
#   Purpose: to replace a old node(this maybe broken or has broken disks)
#   Data structure: type: list,
#                   ex: [{'nodename':node1, 'ipaddr':ipaddr, 'diskinfo':diskinfo, 'status':status}, {...}, ...]
#
#########################################################################################################
def func_node_status():
    '''{'node-1':'start', 'node-2':'stop'}'''
    nodes_status = dict()
    try:
        cmd = 'sudo python %s node status' % DIGIMANAGER
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        if retcode == '0':
            p = '^(\S+)\t(\S+)\s+'
            for line in result[1:-1]:
                status = re.findall(p, line)
                nodes_status[status[0][0]] = status[0][1]
            return nodes_status
        else:
            return nodes_status
    except Exception,e:
        return nodes_status
    
def func_node_cifs_status():
    '''{'node-1':'start', 'node-2':'stop'}'''
    nodes_status = dict()
    try:
        cmd = 'sudo python %s node cifs_status' % DIGIMANAGER
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        if retcode == '0':
            p = '^(\S+)\t(\S+)\s+'
            for line in result[1:-1]:
                status = re.findall(p, line)
                nodes_status[status[0][0]] = status[0][1]
            return nodes_status
        else:
            return nodes_status
    except Exception,e:
        return nodes_status
    
def func_node_nfs_status():
    '''{'node-1':'start', 'node-2':'stop'}'''
    nodes_status = dict()
    try:
        cmd = 'sudo python %s node nfs_status' % DIGIMANAGER
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        if retcode == '0':
            p = '^(\S+)\t(\S+)\s+'
            for line in result[1:-1]:
                status = re.findall(p, line)
                nodes_status[status[0][0]] = status[0][1]
            return nodes_status
        else:
            return nodes_status
    except Exception,e:
        return nodes_status

def func_node_dynamic_info(node):
    dynamic_info = {}
    try:
        v_keys = ['Distro','Hostname','IPAddr','Kernel','LoadAvg','Uptime','Users']
        n_keys = ['NetDrops','NetErrors','NetName','NetRxBytes','NetTxBytes']
        m_keys = ['MemFree','MemPercent','MemTotal','MemUsed','MemApp','MemAppPercent','MemBuffers','MemBuffersPercent','MemCached','MemCachedPercent']
        d_keys = ['MountFree','MountPoint','MountMountPercent','MountTotal','MountUsed']

        cmd = 'sudo python %s node list_dynamic_info %s' % (DIGIMANAGER, node)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        proc.wait()
        result_proc = proc.stdout.readlines()
        f = open('/etc/digioceanfs_manager/nodes/' + node + '_dynamicsysinfo','r')
        str = f.read()
        xml_str = ''.join(str.split('\n')[1:])
        xml_dom = minidom.parseString(xml_str)

        # analyze XML Vitals Tag
        v_list = []
        v_dom = xml_dom.getElementsByTagName('Vitals')[0]
        for key in v_keys:
            v_list.append(v_dom.getAttribute(key))
        v_d = dict(zip(v_keys,v_list))
        dynamic_info['Vitals'] = v_d

        # analyze XML NetDevice Tag
        n_list = []
        n_d_list = []
        n_dom = xml_dom.getElementsByTagName('NetDevice')
        for tmp_dom in n_dom:
            for key in n_keys:
                n_list.append(tmp_dom.getAttribute(key.replace('Net','',1)))
            n_d = dict(zip(n_keys,n_list))
            n_d_list.append(n_d)
            n_list = []
        dynamic_info['NetDevice'] = n_d_list

        # analyze XML Memory Tag
        m_list = []
        m_dom_1 = xml_dom.getElementsByTagName('Memory')[0]
        m_dom_2 = xml_dom.getElementsByTagName('Details')[0]
        for key in m_keys[:4]:
            m_list.append(m_dom_1.getAttribute(key.replace('Mem','',1)))
        for key in m_keys[4:]:
            m_list.append(m_dom_2.getAttribute(key.replace('Mem','',1)))
        m_d = dict(zip(m_keys,m_list))
        dynamic_info['Memory'] = m_d

        # analyze XML Disk Mount Tag
        d_list = []
        d_d_list = []
        d_dom = xml_dom.getElementsByTagName('Swap')[0]
        for key in d_keys:
            d_list.append(d_dom.getAttribute(key.replace('Mount','',1)))
        d_d = dict(zip(d_keys,d_list))
        d_d_list.append(d_d)
        d_m_dom = xml_dom.getElementsByTagName('Mount')
        for tmp_dom in d_m_dom:
            for key in d_keys:
                d_list.append(d_dom.getAttribute(key.replace('Mount','',1)))
            d_d = dict(zip(d_keys,d_list))
            d_d_list.append(d_d)
        dynamic_info['Mount'] = d_d_list

        return dynamic_info

    except Exception,e:
        return dynamic_info


#########################################################################################################
#
#   Function: func_node_raid_info
#   Variable: node,
#             unit(this variable is to decide unit of return value),
#             clusternoderaidinfo
#   Purpose: to list disks info in a raid
#   Data structure: type: list,
#                   ex: [{'status':status, 'devname':devname, 'type':type, 'vandor':vandor, 'sn_number':sn_number, 'size':size, 'type_in_raid':type_in_raid, 'raidname':raidname},
#                        {...},
#                        ...]
#
#########################################################################################################
def func_node_raid_info(node,unit=''):
    clusternoderaidinfo = []
    d = {}
    key = ['position','status','devname','type','vandor','active','size','port','servicename','istart','pid']
    #disk_key = ['position','status','devname','type','vandor','sn_number','size','type_in_raid','raidname','nodename']
    try:
        cmd = 'sudo python %s node list_disk %s' % (DIGIMANAGER, node)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        proc.wait()
        result = proc.stdout.readlines()
        if result[0].strip() != '0':
            return clusternoderaidinfo
        else:
            for line in result[1:-1]:
                devinfo = line.split('\t')
                devinfo = [info.strip() for info in devinfo]
                if 'raid' in devinfo:
                    if d:
                        clusternoderaidinfo.append(d)
                    d = dict(zip(key,devinfo))
                    d['size'] = getUnit(unit, d['size'])
                    d['devices'] = []
                    raidname = devinfo[2]

                if 'in_raid' in devinfo and raidname in devinfo:
                    d['devices'].append(devinfo[2])
            else:
                clusternoderaidinfo.append(d)
        return clusternoderaidinfo
    except Exception,e:
        return clusternoderaidinfo

def func_node_list_raid(node, unit=''):
    clusternoderaidinfo = {}
    try:
        cmd = 'sudo python %s node list_raid %s' % (DIGIMANAGER, node)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        p = 'spare'
        if retcode == '0':
            for line in result[1:-1]:
                if p in line.split():
                    dataline = line.split()
                    raidname = dataline[-1].strip()
                    if raidname not in clusternoderaidinfo:
                        clusternoderaidinfo[raidname] = []
                        clusternoderaidinfo[raidname].append(dataline[2].strip())
                    else:
                        clusternoderaidinfo[raidname].append(dataline[2].strip())
            else:
                return clusternoderaidinfo
        else:
            return clusternoderaidinfo
    except Exception,e:
        return clusternoderaidinfo

#########################################################################################################
#
#   Function: func_node_disk_info
#   Variable: node(if this is default, list all the disk in cluster),
#             unit(this variable is to decide unit of return value),
#             clusternoderaidinfo
#   Purpose: to list disks info in a node or a cluster
#   Data structure: type: list,
#                   ex: [{'status':status, 'devname':devname, 'type':type, 'vandor':vandor, 'sn_number':sn_number, 'size':size, 'port':port,'servicename':raidname, 'istart':istart, 'pid':pid},
#                        {...},
#                        ...]
#
#########################################################################################################
def func_node_disk_info(node='',unit=''):
    retcode = '0'
    clusternodediskinfo = []
    key_nodisk = ['position','nodisk', 'devname']
    key_raid = ['position','status','devname','type','vandor','sn_number','size','type_in_raid','raidname','istart','pid']
    key_service = ['position','status','devname','type','vandor','sn_number','size','port','servicename','istart','pid']
    try:
        if node != '':
            cmd = 'sudo python %s node list_disk %s' % (DIGIMANAGER, node)
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
            result = proc.stdout.readlines()
            proc.wait()
            for res in result[1:-1]:
                if len(res.split()) <= 3:
                    diskinfo = res.split()
                    disk = dict()
                    disk['position'] = '-'
                    disk['status'] = diskinfo[1].strip()
                    disk['devname'] = diskinfo[2].strip()
                    disk['type'] = '-'
                    disk['vandor'] = '-'
                    disk['sn_number'] = '-'
                    disk['size'] = '-'
                    disk['port'] = '-'
                    disk['nodename'] = '-'
                    disk['size'] = '-'
                    clusternodediskinfo.append(disk)
                    continue
                diskinfo = res.split('\t')
                for i in range(len(diskinfo)):
                    diskinfo[i] = diskinfo[i].strip()
                if diskinfo[1] == "in_raid":
                    d = dict(zip(key_raid,diskinfo))
                else:
                    d = dict(zip(key_service,diskinfo))
                d['nodename'] = node
                d['size'] = getUnit(unit, d['size'])
                clusternodediskinfo.append(d)
            return clusternodediskinfo
        else:
            cmd = 'sudo python %s node list_disk %s' % (DIGIMANAGER, node)
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
            result = proc.stdout.readlines()
            proc.wait()
            disklist = []
            flag = -1
            retcode = result[0]
            if retcode == '0\n':
                for res in result[1:-1]:
                    disk = dict()
                    diskinfo = res.split('\t')
                    if len(diskinfo) < 2:
                        disklist.append(diskinfo[0].strip())
                        flag += 1
                    elif len(diskinfo) == 3:
                        disk['position'] = diskinfo[0].strip()
                        disk['status'] = diskinfo[1].strip()
                        disk['devname'] = diskinfo[2].strip()
                        disk['type'] = '-'
                        disk['vandor'] = '-'
                        disk['sn_number'] = '-'
                        disk['size'] = '-'
                        disk['port'] = '-'
                        disk['nodename'] = '-'
                        disk['size'] = '-'
                        clusternodediskinfo.append(disk)
                    elif len(diskinfo) <= 8:
                        disk['position'] = diskinfo[0].strip()
                        disk['status'] = diskinfo[1].strip()
                        disk['devname'] = diskinfo[2].strip()
                        disk['type'] = diskinfo[3].strip()
                        disk['vandor'] = diskinfo[4].strip()
                        disk['sn_number'] = diskinfo[5].strip()
                        disk['size'] = diskinfo[6].strip()
                        disk['port'] = diskinfo[7].strip()
                        disk['nodename'] = disklist[flag]
                        disk['size'] = getUnit(unit, disk['size'])
                        clusternodediskinfo.append(disk)
                    else:
                        if diskinfo[1].strip()=='no_disk':
                            disk['position'] = '-'
                            disk['status'] = diskinfo[1].strip()
                            disk['devname'] = diskinfo[2].strip()
                            disk['type'] = '-'
                            disk['vandor'] = '-'
                            disk['sn_number'] = '-'
                            disk['size'] = '-'
                            disk['port'] = '-'
                            disk['nodename'] = '-'
                            disk['size'] = '-'
                        else:
                            disk['position'] = diskinfo[0].strip()
                            disk['status'] = diskinfo[1].strip()
                            disk['devname'] = diskinfo[2].strip()
                            disk['type'] = diskinfo[3].strip()
                            disk['vandor'] = diskinfo[4].strip()
                            disk['sn_number'] = diskinfo[5].strip()
                            disk['size'] = diskinfo[6].strip()
                            disk['port'] = diskinfo[7].strip()
                            if disk['status'] == 'in_raid':
                                disk['raidname'] = diskinfo[8].strip()
                            else:
                                disk['servicename'] = diskinfo[8].strip()
                            disk['istart'] = diskinfo[9].strip()
                            disk['nodename'] = disklist[flag]
                            disk['size'] = getUnit(unit, disk['size'])
                        clusternodediskinfo.append(disk)
                return clusternodediskinfo
            else:
                return clusternodediskinfo
    except Exception,e:
        return clusternodediskinfo

#########################################################################################################
#
#   Function: func_node_iface_info
#   Variable: node,
#             clusternodeifaceinfo
#   Purpose: to list disks info in a raid
#   Data structure: type: list,
#                   ex: [{'status':status, 'devtype':devtype, 'mac':mac, 'ipaddr':ipaddr, 'broadcast':broadcast, 'netmask':netmask, 'status':status},
#                        {...},
#                        ...]
#
#########################################################################################################
def func_node_iface_info(node):
    clusternodeifaceinfo = []
    key = ['devname','devtype','mac','ipaddr','broadcast','netmask','gateway','status']
    try:
        cmd = 'sudo python %s node list_nic %s' % (DIGIMANAGER, node)
        proc = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        for res in result[1:-1]:
            nicinfo = res.split('\t')
            nicinfo.pop(-1)
            if len(nicinfo) == 2:
                nicinfo = [nicinfo[1],'','','','','down']
                d = dict(zip(key,nicinfo))
            elif len(nicinfo) == 8:
                nicinfo.append('yes')
                d = dict(zip(key,nicinfo[1:]))
            elif len(nicinfo) > 8:
                sub_nic = nicinfo[8:]
                nicinfo = nicinfo[:8]
                nicinfo.append('yes')
                d = dict(zip(key,nicinfo[1:]))
                d['sub_nic'] = sub_nic
            else:
                continue
            clusternodeifaceinfo.append(d)
        return clusternodeifaceinfo
    except Exception,e:
        return clusternodeifaceinfo

#########################################################################################################
#
#   Function: func_node_list_inactive
#   Variable: node,
#             clusternodedisk_inactive,
#             clusternoderaids
#   Purpose: list all the disks which status is inactive
#   Data structure: type: list
#                   ex: [{'devname':devname, 'disknum':disknum, 'child': [disk1, disk2, disk3,...]},
#                        {},...]
#
#########################################################################################################

def func_node_list_inactive(node):
    clusternoderaid_inactive = []
    inactivedisklist = []
    clusternoderaids = []
    flag = -1
    try:
        cmd = 'sudo python %s node list_inactive %s' % (DIGIMANAGER, node)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        result_str = result[1:]
        if retcode == '0':
            for res in result_str[0:-1]:
                disk_inactive = {}
                disk_inactive['raidname'] = res.split()[0]
                disk_inactive['normal_count'] = res.split()[1]
                disk_inactive['diskname'] = res.split()[2]
                disk_inactive['disk_type'] = res.split()[3]
                disk_inactive['belong_raid_uuid'] = res.split()[-1]
                inactivedisklist.append(disk_inactive)
        else:
            return []
        if inactivedisklist:
            for disk in inactivedisklist:
                if not clusternoderaid_inactive:
                    raid_inactive = {}
                    raid_inactive['devname'] = disk['raidname']
                    raid_inactive['normal_count'] = int(disk['normal_count'])
                    raid_inactive['disk_num'] = 1 
                    raid_inactive['child'] = [{disk['diskname']: disk['disk_type']}]
                    raid_inactive['uuid'] = disk['belong_raid_uuid']
                    clusternoderaid_inactive.append(raid_inactive)
                else:
                    _clusternoderaid_inactive = clusternoderaid_inactive
                    flag = False
                    for raid in _clusternoderaid_inactive:
                        if raid['uuid'] == disk['belong_raid_uuid']:
                            raid['child'].append({disk['diskname']: disk['disk_type']})
                            raid['disk_num'] += 1
                            flag = True
                            break
                    if not flag:
                        raid_inactive = {}
                        raid_inactive['devname'] = disk['raidname']
                        raid_inactive['normal_count'] = int(disk['normal_count'])
                        raid_inactive['disk_num'] = 1 
                        raid_inactive['child'] = [{disk['diskname']: disk['disk_type']}]
                        raid_inactive['uuid'] = disk['belong_raid_uuid']
                        clusternoderaid_inactive.append(raid_inactive)

            return clusternoderaid_inactive
        else:
            return []
    except Exception,e:
        return []

def func_node_ipmi_info(node):
    ipmiinfo= []
    try:
        cmd = 'sudo python %s node ipmi_info %s'% (DIGIMANAGER, node)
        proc = subprocess.Popen(cmd, shell=True,stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        if retcode == '0':
            ipmiinfo = result[1].strip().split('|')

        cmd = 'sudo python %s node ipmi_power_control %s status'% (DIGIMANAGER, node)
        proc = subprocess.Popen(cmd, shell=True,stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        if retcode == '0':
            ipmiinfo.insert(0,result[1].strip())
        else:
            ipmiinfo.insert(0,'-')
        return ipmiinfo
    except Exception,e:
        return ipmiinfo

#########################################################################################################
#
#   Function: func_node_get_device_id
#   Variable: node,
#   Purpose: get node device id in cluster
#   Data structure: type: str or int
#
#########################################################################################################
def func_node_get_device_id(node):
    device_id_list = []
    try:
        cmd = 'sudo python %s node get_device_id %s' % (DIGIMANAGER, node)
        proc = subprocess.Popen(cmd, shell=True,stdout=subprocess.PIPE)
        proc.wait()
        result = proc.stdout.readlines()
        ret = result[0].strip()
        if ret == "0":
            device_id_list = result[1].strip().split('\t')
            device_id_list.insert(0,node)
        return device_id_list
    except Exception,e:
        return device_id_list

def func_node_smart_status(node,diskname):
    try:
        smart_status = ''
        cmd = 'sudo python %s node smart_status %s %s' % (DIGIMANAGER,node,diskname)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        retcode = result[0].strip()
        if retcode == '0':
            smart_status = result[1].strip()
            return smart_status
        else:
            return smart_status
    except Exception,e:
        return smart_status

def func_node_smart_info(node):
    clustersmartinfo = []
    disk_list = []
    split_line = '--------------------------------------------------------------------------------------------------------'
    try:
        clusternodediskinfo = func_node_disk_info(node)
        for disk in clusternodediskinfo:
            if disk['type'] != 'raid':
                disk_list.append(disk['devname'])
        cmd = 'sudo python %s node smart_info %s %s' % (DIGIMANAGER, node, ' '.join(disk_list))
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        proc.wait()
        smart_result = proc.stdout.read()
        retcode = smart_result[:smart_result.find('\n')]
        if retcode != '0':
            return clustersmartinfo
        else:
            smart_result_list = smart_result.split(split_line)
            for tmpinfo in smart_result_list:
                result = tmpinfo.split('\n')
                smartinfo = {}
                allmsg = []
                for i in range(len(result)):
                    if result[i].find('Diskname') >= 0:
                        smartinfo['Diskname'] = result[i].split(':')[1].strip()
                    elif result[i].find('Serial Number') >= 0:
                        smartinfo['Serial_Number'] = result[i].split(':')[1].strip()
                    elif result[i].find('SMART Status') >= 0:
                        smartinfo['Status'] = result[i].split(':')[1].strip()
                    elif result[i].find('SMART Overall-Health') >= 0:
                        smartinfo['Health'] = result[i].split(':')[1].strip()
                    elif result[i].find('Selftest Execution Status') >= 0:
                        smartinfo['Execution_Status'] = result[i].split(':')[1].strip()
                    elif result[i].find('ID#') >= 0:
                        msg = []
                        info = []
                        while True:
                            i = i+1
                            if result[i] == '':
                                break
                            for data in result[i].split(' '):
                                if data != '':
                                    msg.append(data)
                            for m in range(len(msg)):
                                if m in [0,1,3,4,5,8,9]:
                                    info.append(msg[m].strip())
                            if int(info[2]) == 0 and int(info[3]) == 0 and int(info[4]) == 0 and int(info[6]) == 0:
                                info.append('OK')
                            else:
                                if info[5] == 'FAILING_NOW':
                                    info.append('FAILED')
                                else:
                                    if int(info[4]) < int(info[2]):
                                        if info[0] in ['5','10','196','197','198','199']:
                                            if info[0] == '5' and int(info[6]) > 0:
                                                info.append('WARNING')
                                            else:
                                                if int(info[6]) > int(info[4]):
                                                    if info[0] == '199' and int(info[6]) < 200:
                                                        info.append('OK')
                                                    else:
                                                        info.append('WARNING')
                                                else:
                                                    info.append('OK')
                                        else:
                                            info.append('OK')
                                    else:
                                        info.append('WARNING')
                            allmsg.append(info)
                            msg = []
                            info = []
                        smartinfo['Smartmsg'] = allmsg
                        allmsg = []
                    else:
                        continue
                if smartinfo:
                    smartinfo['Nodename'] = node
                    clustersmartinfo.append(smartinfo)
        for smartinfo in clustersmartinfo:
            smartinfo['dposition'] = ''
            for diskinfo in clusternodediskinfo:
                if smartinfo['Diskname'] == diskinfo['devname']:
                    smartinfo['dposition'] = diskinfo['position'].replace('-1','NaN').split('/')[0]
                    break
        return clustersmartinfo
    except Exception,e:
        return clustersmartinfo

def func_node_sms_info():
    smsinfos = {}
    try:
        cmd = "sudo python %s node sms_set list" % DIGIMANAGER
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        proc.wait()
        result = proc.stdout.readlines()
        if result[0].strip() != '0':
            return smsinfos
        for line in result:
            if line.find('Status') >= 0:
                if line.split(':')[1].strip() == 'Enable':
                    smsinfos['inuse'] = 'Enable'
                else:
                    smsinfos['inuse'] = 'Disable'
            if line.find('Message Center Number') >= 0:
                if line.find('GSM') >= 0:
                    smsinfos['smsp'] = line.split(':')[1].strip().replace('(GSM)','')
                    smsinfos['fsmsp'] = True
                else:
                    smsinfos['smsp'] = line.split(':')[1].strip()
            if line.find('Receive Number') >= 0:
                smsinfos['mobp'] = line.split(':')[1].strip().split(',')
            if line.find('Notify Type') >= 0:
                smsinfos['ntype'] = line.split(':')[1].strip().split(',')
        return smsinfos

    except Exception,e:
        return smsinfos 

def func_node_list_cpu(node):
    cpu_info_dict = {}
    try:
        cmd = 'sudo python %s node list_cpu %s' % (DIGIMANAGER, node)
        proc = subprocess.Popen(cmd, shell=True,stdout=subprocess.PIPE)
        proc.wait()
        result = proc.stdout.readlines()
        ret = result[0].strip()
        if ret == "0":
            tmp_list = simplejson.loads(result[1].strip()).split(',')
            cpu_info_dict = dict(zip(['processor','cpuinfo'],tmp_list))
            cpu_info_dict['nodename'] = node
        return cpu_info_dict
    except Exception,e:
        return cpu_info_dict