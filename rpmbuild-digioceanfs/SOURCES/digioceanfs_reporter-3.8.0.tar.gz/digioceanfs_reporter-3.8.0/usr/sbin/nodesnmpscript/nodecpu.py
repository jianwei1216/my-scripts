#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusnodelib
import setting
import snmp_passpersist as snmp

'''
+--NodeCpuTable(12)
   |
   +--NodeCpuEntry(1)
      |
      +-- -R-- String    NodeCpuNodeName(1)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- Gauge     NodeCpuProcessorTotal(2)
      +-- -R-- String    NodeCpuInfo(3)
               Textual Convention: DisplayString
               Size: 0..255
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusnodelib.func_node_list_cpu(os.uname()[1])

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.20.12.1")
def update():
    #rtndata = {'cpuinfo': '3.30GHz', 'processor': '8', 'nodename': 'node-1.cluster-1'}
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusnodelib.func_node_list_cpu(os.uname()[1])
        uptime = currtime

    pp.add_str('1',rtndata['nodename'])
    pp.add_gau('2',int(rtndata['processor']))
    pp.add_str('3',rtndata['cpuinfo'])

if __name__ == "__main__":
    pp.start(update,1)
