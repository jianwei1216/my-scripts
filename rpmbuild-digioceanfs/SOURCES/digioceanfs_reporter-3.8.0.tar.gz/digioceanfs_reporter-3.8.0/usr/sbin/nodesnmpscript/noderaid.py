#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusnodelib
import setting
import snmp_passpersist as snmp

'''
Map of Interface MIB
+--NodeRaidTable(5)
   |
   +--NodeRaidEntry(1)
      |  Index: NodeRaidIndex
      |
      +-- -R-- Integer32 NodeRaidIndex(1)
      |        Range: 0..65535
      +-- -R-- String    NodeRaidName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeRaidStatus(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- Gauge     NodeRaidSize(4)
      +-- -R-- EnumVal   NodeRaidActive(5)
      |        Values: active(1), inactive(0)
      +-- -R-- String    NodeRaidVandor(6)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeRaidDevs(7)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- EnumVal   NodeRaidIstart(8)
      |        Values: start(1), stop(0), nostate(-1)
      +-- -R-- Integer32 NodeRaidPort(9)
      |        Range: 0..65535
      +-- -R-- String    NodeRaidService(10)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- Integer32 NodeRaidPid(11)
               Range: 0..32768
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusnodelib.func_node_raid_info(os.uname()[1])

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.20.5.1")
def update():
    #rtndata = {'status': 'unused', 'vandor': '1', 'devname': 'md10', 'devs': ['sdb', 'sdc'], 'active': 'active', 'position': '-1', 'type': 'raid', 'port': '10017', 'size': '488255360'}
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusnodelib.func_node_raid_info(os.uname()[1])
        uptime = currtime

    i = 1
    for m in xrange(len(rtndata)):
        pp.add_int('1.' + str(i),i)
        if rtndata[m]:
            pp.add_str('2.' + str(i),rtndata[m]['devname'])
            pp.add_str('3.' + str(i),rtndata[m]['status'])
            pp.add_gau('4.' + str(i),int(rtndata[m]['size']))
            if rtndata[m]['active'] == 'active':
                pp.add_int('5.' + str(i),1)
            else:
                pp.add_int('5.' + str(i),0)
            pp.add_str('6.' + str(i),rtndata[m]['vandor'])
            pp.add_str('7.' + str(i),' '.join(rtndata[m]['devices']))
            if rtndata[m]['istart'] == 'start':
                pp.add_int('8.' + str(i),1)
            elif rtndata[m]['istart'] == 'stop':
                pp.add_int('8.' + str(i),0)
            else:
                pp.add_int('8.' + str(i),-1)
            if 'port' in rtndata[m] and rtndata[m]['port']:
                pp.add_int('9.' + str(i),int(rtndata[m]['port']))
            pp.add_str('10.' + str(i),rtndata[m]['servicename'])
            if 'pid' in rtndata[m] and rtndata[m]['pid']:
                pp.add_int('11.' + str(i),int(rtndata[m]['pid']))
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
