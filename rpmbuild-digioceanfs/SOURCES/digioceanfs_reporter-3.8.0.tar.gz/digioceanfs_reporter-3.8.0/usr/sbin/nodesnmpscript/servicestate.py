#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusservicelib
import setting
import snmp_passpersist as snmp

'''
+--ServiceStateTable(2)
   |
   +--ServiceStateEntry(1)
      |  Index: ServiceStateIndex
      |
      +-- -R-- Integer32 ServiceStateIndex(1)
      |        Range: 0..65535
      +-- -R-- String    ServiceStateName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceStateRaidlv(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceStateVid(4)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- EnumVal   ServiceStateUp(5)
      |        Values: create(0), start(1), stop(-1)
      +-- -R-- Gauge     ServiceStateDiskNumber(6)
      +-- -R-- String    ServiceStateTransportType(7)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- Gauge     ServiceStateFreeSize(8)
      +-- -R-- Gauge     ServiceStateTotalSize(9)
      +-- -R-- Gauge     ServiceStateUsedSize(10)
      +-- -R-- Integer32 ServiceStateUsage(11)
      |        Range: 0..100
      +-- -R-- String    ServiceStateBrickStatus(12)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- Gauge     ServiceStateClientNumber(13)
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusservicelib.func_service_list_all()

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.21.2.1")
def update():
    #rtndata = [{'status': 'Started', 'vid': '0044453c-79e9-4be6-b49e-5ca234d6bfb5', 'totalsize': '976296192', 'usedsize': 66176.0, 'disknum': '1 x (2 + 1) = 3', 'client': 0, 'servicename': 'test', 'raidlv': 'Disperse', 'brickstatus': 'OK', 'strip': '2', 'usage': 0.0, 'afr_info': '0', 'type': 'tcp', 'freesize': '976230016', 'afr': '1'}]
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusservicelib.func_service_list_all()
        uptime = currtime

    i = 1
    for m in range(len(rtndata)):
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),rtndata[m]['servicename'])
        pp.add_str('3.' + str(i),rtndata[m]['raidlv'])
        pp.add_str('4.' + str(i),rtndata[m]['vid'])
        if rtndata[m]['status'] == 'Started':
            pp.add_int('5.' + str(i),1)
        elif rtndata[m]['status'] == 'Created':
            pp.add_int('5.' + str(i),0)
        else:
            pp.add_int('5.' + str(i),-1)
        pp.add_gau('6.' + str(i),int(rtndata[m]['disknum']))
        pp.add_str('7.' + str(i),rtndata[m]['type'])
        pp.add_gau('8.' + str(i),int(rtndata[m]['freesize']))
        pp.add_gau('9.' + str(i),int(rtndata[m]['totalsize']))
        pp.add_gau('10.' + str(i),int(rtndata[m]['usedsize']))
        pp.add_int('11.' + str(i),float(rtndata[m]['usage']))
        pp.add_str('12.' + str(i),rtndata[m]['brickstatus'])
        pp.add_gau('13.' + str(i),int(rtndata[m]['client']))
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
