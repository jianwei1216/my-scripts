#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusservicelib
import setting
import snmp_passpersist as snmp

'''
+--ServiceQuotaTable(5)
   |
   +--ServiceQuotaEntry(1)
      |  Index: ServiceQuotaIndex
      |
      +-- -R-- Integer32 ServiceQuotaIndex(1)
      |        Range: 0..65535
      +-- -R-- String    ServiceQuotaServiceName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceQuotaName(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceQuotaPath(4)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceQuotaTotalSize(5)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceQuotaUsedSize(6)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceQuotaFreeSize(7)
               Textual Convention: DisplayString
               Size: 0..255
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusservicelib.func_service_list_quota()

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.21.5.1")
def update():
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusservicelib.func_service_list_quota()
        uptime = currtime

    i = 1
    for m in range(len(rtndata)):
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),rtndata[m]['servicename'])
        pp.add_str('3.' + str(i),rtndata[m]['name'])
        pp.add_str('4.' + str(i),rtndata[m]['path'])
        pp.add_str('5.' + str(i),rtndata[m]['quota_tsize'])
        pp.add_str('6.' + str(i),rtndata[m]['quota_usize'])
        pp.add_str('7.' + str(i),rtndata[m]['quota_fsize'])
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
