#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusnodelib
import setting
import snmp_passpersist as snmp

'''
+--NodeIPMITable(14)
   |
   +--NodeIPMIEntry(1)
      |
      +-- -R-- EnumVal   NodeIPMIPowerStatus(1)
      |        Values: on(1), off(0)
      +-- -R-- String    NodeIPMIIPSource(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeIPMIIpAddress(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeIPMINetMask(4)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeIPMIGateway(5)
               Textual Convention: DisplayString
               Size: 0..255
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusnodelib.func_node_ipmi_info(os.uname()[1])

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.20.14.1")
def update():
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusnodelib.func_node_ipmi_info(os.uname()[1])
        uptime = currtime

    if rtndata[0] == 'on':
        pp.add_int('1',1)
    else:
        pp.add_int('1',0)
    pp.add_str('2',rtndata[1])
    pp.add_str('3',rtndata[2])
    pp.add_str('4',rtndata[3])
    pp.add_str('5',rtndata[4])

if __name__ == "__main__":
    pp.start(update,1)
