#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusnodelib
import setting
import snmp_passpersist as snmp

'''
Map of Interface MIB
+--NodeStateTable(2)
   |
   +--NodeStateEntry(1)
      |  Index: NodeStateIndex
      |
      +-- -R-- Integer32 NodeStateIndex(1)
      |        Range: 0..65535
      +-- -R-- String    NodeStateName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeStateIP(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- EnumVal   NodeStateUp(4)
               Values: start(1), stop(0)
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusnodelib.func_node_list_all('True')

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.20.2.1")
def update():
    #rtndata = [{'status': 'start', 'nodename': 'node-1.cluster-1', 'ipaddr': '10.10.12.116', 'diskinfo': [], 'nfsstatus': '', 'cifsstatus': 'start'}, {'status': 'start', 'nodename': 'node-2.cluster-1', 'ipaddr': '10.10.12.119', 'diskinfo': [], 'nfsstatus': '', 'cifsstatus': 'start'}]
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusnodelib.func_node_list_all('True')
        uptime = currtime

    i = 1
    for m in range(len(rtndata)):
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),rtndata[m]['nodename'])
        pp.add_str('3.' + str(i),rtndata[m]['ipaddr'])
        if rtndata[m]['status'] == 'start':
            pp.add_int('4.' + str(i),1)
        else:
            pp.add_int('4.' + str(i),0)
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)

