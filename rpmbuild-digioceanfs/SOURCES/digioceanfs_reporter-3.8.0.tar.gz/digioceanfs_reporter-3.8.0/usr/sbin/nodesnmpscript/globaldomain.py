#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusindex
import setting
import snmp_passpersist as snmp

'''
+--GlobalInfo(22)
   |
   +--GlobalInfoMIB(1)
   |
   +--GlobalDomainTable(2)
      |
      +--GlobalDomainEntry(1)
         |
         +-- -R-- String    GlobalDomainName(1)
                  Textual Convention: DisplayString
                  Size: 0..255
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusindex.func_domain_get()

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.22.2.1")
def update():
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusindex.func_domain_get()
        uptime = currtime

    pp.add_str('1',rtndata)

if __name__ == "__main__":
    pp.start(update,1)
