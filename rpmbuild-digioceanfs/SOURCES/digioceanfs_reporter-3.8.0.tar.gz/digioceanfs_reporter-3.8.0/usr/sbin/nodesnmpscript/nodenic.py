#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusnodelib
import setting
import snmp_passpersist as snmp

'''
Map of Interface MIB
+--NodeNicTable(3)
   |
   +--NodeNicEntry(1)
      |  Index: NodeNicIndex
      |
      +-- -R-- Integer32 NodeNicIndex(1)
      |        Range: 0..65535
      +-- -R-- String    NodeNicName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeNicIP(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeNicMac(4)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeNicGateway(5)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeNicMask(6)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeNicBroadcast(7)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeNicType(8)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- EnumVal   NodeNicStatus(9)
               Values: no(0), yes(1)
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusnodelib.func_node_iface_info(os.uname()[1])

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.20.3.1")
def update():
    #rtndata = [{'status': 'yes', 'devname': 'eth0', 'ipaddr': '10.10.12.116', 'mac': '0C:C4:7A:30:BF:60', 'broadcast': '10.10.12.116', 'devtype': 'Ethernet', 'netmask': '25.255.0.0', 'gateway': '10.10.10.1'}, {'status': 'yes', 'devname': 'eth1', 'ipaddr': 'NOCONFIG', 'mac': '0C:C4:7A:30:BF:61', 'broadcast': 'NOCONFIG', 'devtype': 'Ethernet', 'netmask': 'NOCONFIG', 'gateway': 'NOCONFIG'}]
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusnodelib.func_node_iface_info(os.uname()[1])
        uptime = currtime

    i = 1
    for m in range(len(rtndata)):
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),rtndata[m]['devname'])
        pp.add_str('3.' + str(i),rtndata[m]['ipaddr'])
        pp.add_str('4.' + str(i),rtndata[m]['mac'])
        pp.add_str('5.' + str(i),rtndata[m]['gateway'])
        pp.add_str('6.' + str(i),rtndata[m]['netmask'])
        pp.add_str('7.' + str(i),rtndata[m]['broadcast'])
        pp.add_str('8.' + str(i),rtndata[m]['devtype'])
        if rtndata[m]['status'] == 'yes':
            pp.add_int('9.' + str(i),1)
        else:
            pp.add_int('9.' + str(i),0)
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
