#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusservicelib
import setting
import snmp_passpersist as snmp

'''
+--ServiceDiskTable(3)
   |
   +--ServiceDiskEntry(1)
      |  Index: ServiceDiskIndex
      |
      +-- -R-- Integer32 ServiceDiskIndex(1)
      |        Range: 0..65535
      +-- -R-- String    ServiceDiskServiceName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceDiskInterface(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceDiskMark(4)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceDiskMountPoint(5)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceDiskFS(6)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceDiskStatus(7)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceDiskTotal(8)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceDiskFree(9)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceDiskUsage(10)
               Textual Convention: DisplayString
               Size: 0..255
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusservicelib.func_service_list_disk()

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.21.3.1")
def update():
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusservicelib.func_service_list_disk()
        uptime = currtime

    i = 1
    for servicename in rtndata.keys():
        bricks = rtndata[servicename]
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),servicename)
        j = 1
        for m in range(len(bricks)):
            pp.add_str('3.' + str(i) + '.' + str(j),bricks[m]['interface'])
            pp.add_str('4.' + str(i) + '.' + str(j),bricks[m]['mark'])
            pp.add_str('5.' + str(i) + '.' + str(j),bricks[m]['mount_point'])
            pp.add_str('6.' + str(i) + '.' + str(j),bricks[m]['fs'])
            if bricks[m]['status'] == 'Y':
                pp.add_int('7.' + str(i) + '.' + str(j),1)
            else:
                pp.add_int('7.' + str(i) + '.' + str(j),0)
            pp.add_str('8.' + str(i) + '.' + str(j),bricks[m]['total'])
            pp.add_str('9.' + str(i) + '.' + str(j),bricks[m]['free'])
            if bricks[m]['usage'] == 'NaN':
                pp.add_int('10.' + str(i) + '.' + str(j),0)
            else:
                pp.add_int('10.' + str(i) + '.' + str(j),float(bricks[m]['usage']))
            j = j + 1
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
