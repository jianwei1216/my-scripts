#!/usr/bin/env python
#-*- coding: utf-8 -*-

import os
import sys
import subprocess
import re
import copy
import pickle
import simplejson
from decimal import *

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)

DIGIMANAGER = "/usr/local/digioceanfs_manager/manager/digi_manager.pyc"

def getUnit_2(unit, value):
    if unit == 'KB':
        value = round(float(value) / 1, 2)
    elif unit == 'MB':
        value = round(float(value) / 1024, 2)
    elif unit == 'GB':
        value = round(float(value) / 1024 /1024, 2)
    elif unit == 'TB':
        value = round(float(value) / 1024 /1024 /1024, 2)
    return value

def func_service_name_list_all():
    services = []
    cmd = "digiocean vol list"
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    result = proc.stdout.readlines()
    services = [service.strip() for service in result]
    return services

#########################################################################################################
#
#   Function: func_service_list_all
#   Variable: unit(not-essential)
#   Purpose: to list all services info
#   Data structure: type: list
#                   ex: [{'servicename': servicename, 'totalsize': toatlsize, 'usesize': usesize, 'raidlv': raidlv, 'status': status, 'usage': usage, 'abmormal_status': abnormal_status}#                       ,{...},...]
#
#########################################################################################################

def func_service_list_all(unit=''):
    clusterservices = []
    try:
        p_status = 'name: (\S+)\s+service total size: (\S+)\s+service used size: (\S*)\s+service raid level: (\S+)\s+service status: (\S+)\s+'
        cmd = "sudo python %s service list" % (DIGIMANAGER)
        proc_status = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result_status = proc_status.stdout.readlines()
        proc_status.wait()
        if len(result_status)>1:
            for i in range(len(result_status)):
                arr=result_status[i].replace('\n','')
                index=arr.split(': ')
                if index[0]=='Volume Name':
                    x=0
                    end=''
                    while end!='Bricks':
                        end=result_status[i+x].replace('\n','')
                        end=end.split(':')
                        end=end[0]
                        x+=1
                    service=dict()						
                    service['servicename']=index[1]
                    for j in range(x-1):
                        r=result_status[i+j].replace('\n','')
                        s=r.split(': ')
                        if s[0]=='Type':		
                            service['raidlv']=s[1]
                            continue
                        elif s[0]=='Replica Number':	
                            service['afr']=s[1]
                            continue
                        elif s[0]=='Stripe Number':	
                            service['strip']=s[1]
                            continue
                        elif s[0]=='Volume ID':		
                            service['vid']=s[1]
                            continue
                        elif s[0]=='Status':		
                            service['status']=s[1]
                            continue
                        elif s[0]=='Number of Bricks':		
                            service['disknum']=s[1]
                            continue
                        elif s[0]=='Transport-type':		
                            service['type']=s[1]
                            continue
                        elif s[0]=='Free Size':		
                            service['freesize']=s[1]
                            continue
                        elif s[0]=='Total Size':		
                            service['totalsize']=s[1]
                            continue
                        elif s[0]=='Brick Status':		
                            service['brickstatus']=s[1]
                            continue
                        else:
                            pass
                    try:
                        service['afr']
                    except:    
                        service['afr']='NaN'
                    try:
                        service['strip']
                    except:    
                        service['strip']='NaN'
                    if 	service['freesize']=='N/A':
                        service['usage']=0
                        service['freesize']=0.0
                        service['totalsize']=0.0
                        service['usedsize']=0.0
                    else:
                        if float(service['totalsize'])==0:
                            service['usedsize']=0						
                            service['usage']=0
                        else:	
                            service['usedsize']=float(service['totalsize'])-float(service['freesize'])
                            service['usage']=round(Decimal(str(service['usedsize']))/Decimal(str(service['totalsize'])), 2)	
                        service['freesize']=getUnit_2(unit, service['freesize'])
                        service['totalsize']=getUnit_2(unit, service['totalsize'])
                        service['usedsize']=getUnit_2(unit, service['usedsize'])
                    service['client']=len(func_client_node_list_all(service['servicename']))
                    service['afr_info']='0'
                    if service['raidlv'].find('Disperse') >= 0:
                        re_result = re.match('(.*)\((.*)\)(.*)',service['disknum'])
                        if re_result:
                            disperse_detail = re_result.groups()[1]
                            service['afr'] = disperse_detail.split(" + ")[1]
                            service['strip'] = str(int(disperse_detail.split(" + ")[0]))
                    clusterservices.append(service)
        else:
            clusterservices=[]
        return clusterservices
    except Exception,e:
        return clusterservices

def func_client_node_list_all(service_name=''):
    clusterclientnodes=[]
    try:
        if service_name:
            cmd = 'sudo python %s service client_list %s' % (DIGIMANAGER, service_name)
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
            result = proc.stdout.readlines()
            proc.wait()
            #retcode = result[0]
            if len(result)>1:
                for i in result:
                    r=i.replace('\n','')
                    if r!='0' and r!='':
                        s=r.split('\t')
                        node=dict()
                        node['service_name']=service_name
                        node['node_name']=s[0]
                        if s[1]=='started':
                            node['status']='1'
                        else:
                            node['status']='0'
                        clusterclientnodes.append(node)
        else:
            services = func_service_name_list_all()
            for service_name in services:
                cmd = 'sudo python %s service client_list %s' % (DIGIMANAGER, service_name)
                proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
                result = proc.stdout.readlines()
                proc.wait()
                #retcode = result[0]
                if len(result)>1:
                    for i in result:
                        r=i.replace('\n','')
                        if r!='0' and r!='':
                            s=r.split('\t')
                            node=dict()
                            node['service_name']=service_name
                            node['node_name']=s[0]
                            if s[1]=='started':
                                node['status']='1'
                            else:
                                node['status']='0'
                            clusterclientnodes.append(node)
        return clusterclientnodes
    except Exception,e:
        return clusterclientnodes

def func_service_list_disk():
    service_bricks = {}
    services = func_service_name_list_all()
    for service_name in services:
        bricks = func_raidlv_detail(service_name)
        service_bricks[service_name] = bricks
    return service_bricks

def func_raidlv_detail(service_name):
    bricks=[]
    try:
        cmd = 'sudo python %s service list_disk %s' % (DIGIMANAGER, service_name)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        
        if len(result)>2:
            for i in range(len(result)):
                index=result[i].replace('\n','')
                if index=='------------------------------------------------------------------------------':
                    brick=dict()
                    for j in range(12):
                        r=result[i+j].replace('\n','')
                        s=r.split(":")
                        if s[0].strip()=='Brick':
                            brick_name=s[1].strip().split(' ')
                            brick['mount_point']=brick_name[1]+':'+s[2].strip()
                            mark=brick['mount_point'].split('/')
                            brick['mark']=mark[2]
                            continue
                        elif s[0].strip()=='Online':
                            brick['status']=s[1].strip()
                            continue
                        elif s[0].strip()=='File System':
                            brick['fs']=s[1].strip()
                            continue
                        elif s[0].strip()=='Device':
                            brick['interface']=s[1].strip()
                            continue
                        elif s[0].strip()=='Disk Space Free':
                            brick['free']=s[1].strip()
                            continue
                        elif s[0].strip()=='Total Disk Space':
                            brick['total']=s[1].strip()
                            continue
                        else:
                            pass
					
                    if brick['free']=='NaN' or brick['free']=='0Bytes':
                        brick['usage']='NaN'
                    else:
                        free=re.match('\d+.\d+',brick['free'])
                        free=free.group()
                        free_unit=brick['free'].replace(free,'')
                        free=float(free)
                        if free_unit=='KB':
                            free=free*1024
                        elif free_unit=='MB':
                            free=free*1024*1024
                        elif free_unit=='GB':
                            free=free*1024*1024*1024
                        elif free_unit=='TB':
                            free=free*1024*1024*1024*1024
                        else:
                            pass

                        total=re.match('\d+.\d+',brick['total'])
                        total=total.group()
                        total_unit=brick['total'].replace(total,'')
                        total=float(total)
                        if total_unit=='KB':
                            total=total*1024
                        elif total_unit=='MB':
                            total=total*1024*1024
                        elif total_unit=='GB':
                            total=total*1024*1024*1024
                        elif total_unit=='TB':
                            total=total*1024*1024*1024*1024
                        else:
                            pass
									
                        usedsize=total-free
                        brick['usage']=round(Decimal(str(usedsize))/Decimal(str(total)), 2)
                    bricks.append(brick)
        else:
            bricks=[]
        return bricks
    except Exception,e:
        return bricks

def func_service_cifs_list_user():
    service_cifs_user = {}
    try:
        services = func_service_name_list_all()
        for clusterservicename in services:
            user_list = []
            cmd= 'sudo python %s service cifs_list_user %s' % (DIGIMANAGER, clusterservicename)
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
            result = proc.stdout.readlines()
            proc.wait()
            user_list = [line.strip() for line in result[1:-1]]
            service_cifs_user[clusterservicename] = user_list
        return service_cifs_user
    except Exception,e:
        return service_cifs_user

def func_service_cifs_list_links():
    service_cifs_links = []
    try:
        services = func_service_name_list_all()
        for clusterservicename in services:
            cmd= 'sudo python %s service cifs_list_links %s' % (DIGIMANAGER, clusterservicename)
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
            result = proc.stdout.readlines()
            proc.wait()
            for line in result[1:-1]:
                cifs_link = {}
                line_list = line.split('\t')
                if len(line_list) >= 4:
                    cifs_link['servicename'] = clusterservicename
                    cifs_link['nodename'] = line_list[0]
                    cifs_link['username'] = line_list[1]
                    cifs_link['pid'] = line_list[2]
                    cifs_link['time'] = line_list[3].strip()
                    cifs_link['link'] = 'linked'
                elif len(line_list) == 2:
                    cifs_link['servicename'] = clusterservicename
                    cifs_link['nodename'] = line_list[0]
                    cifs_link['username'] = ''
                    cifs_link['pid'] = ''
                    cifs_link['time'] = ''
                    cifs_link['link'] = 'nolink'
                else:
                    continue
                service_cifs_links.append(cifs_link)
        return service_cifs_links
    except Exception,e:
        return service_cifs_links
        
def func_service_nfs_list_user():
    service_nfs_user = {}
    try:
        services = func_service_name_list_all()
        for clusterservicename in services:
            cmd= 'sudo python %s service nfs_list_user %s' % (DIGIMANAGER, clusterservicename)
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
            result = proc.stdout.readlines()
            proc.wait()
            retcode = result[0]
            user_list = []
            if retcode == '0\n':
                user_str=result[1].replace('\n','')
                if user_str != 'None':
                    user_list=user_str.replace('None','').split(',')
            service_nfs_user[clusterservicename] = user_list
        return service_nfs_user
    except Exception,e:
        return service_nfs_user
    
def func_service_list_nfs_links(clusterservicename):
    retcode = 'operation failed'
    try:
        cmd= 'sudo python %s service nfs_list_links %s' % (DIGIMANAGER, clusterservicename)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0]
        links_list = []
        if retcode == '0\n':
            for link in result[1:-1]:
                linkdata = link.split('\t')
                linkdatadict = {}
                if len(linkdata) == 2:
                    linkdatadict['nodename'] = linkdata[0].strip()
                    linkdatadict['tar_ip'] = linkdata[1].strip()
                else:
                    linkdatadict['fatalerror'] = 'fatalerror'
                links_list.append(linkdatadict)
            return links_list
        else:
            return links_list
    except Exception,e:
        return links_list

def func_service_list_cifs_links(clusterservicename):
    retcode = 'operation failed'
    try:
        cmd= 'sudo python %s service cifs_list_links %s' % (DIGIMANAGER, clusterservicename)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0]
        links_list = []
        if retcode == '0\n':
            for link in result[1:-1]:
                linkdata = link.split('\t')
                linkdatadict = {}
                if len(linkdata) > 2:
                    linkdatadict['nodename']  = linkdata[0]
                    linkdatadict['username']  = linkdata[1]
                    linkdatadict['pid']       = linkdata[2]
                    linkdatadict['linktime'] = linkdata[3]
                elif len(linkdata) == 2:
                    if linkdata[1] == 'nolink':
                        linkdatadict['nodename'] = linkdata[0]
                        linkdatadict['nolink'] = linkdata[1]
                    else:
                        linkdatadict['nodename'] = linkdata[0]
                        linkdatadict['error'] = linkdata[1]
                else:
                    linkdatadict['fatalerror'] = 'fatalerror'
                links_list.append(linkdatadict)
            return links_list
        else:
            return links_list
    except Exception,e:
        return links_list
            
#########################################################################################################
#
#   Function: func_service_export
#   Variable: clusterservicename, option
#   Purpose: export a serivce using cifs
#   Data structure: type: str or int
#
#########################################################################################################
#def func_service_export(option, type, clusterservicename=''):
#    if(type == 'cifs'):
#        return func_service_cifs_export(option, clusterservicename)
#    else:
#        return func_service_nfs_export(option, clusterservicename)

def func_service_cifs_export_status():
    service_cifs = {}
    services = func_service_name_list_all()
    for clusterservicename in services:
        nodes_status = []
        key = ['nodename','cifs_status']
        cmd = 'sudo python %s service export_cifs %s status' % (DIGIMANAGER, clusterservicename)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        retcode = result[0].strip()
        if retcode == '0' :
            p = '^(\S+)\t(\S+)\s+'
            for line in result[1:-1]:
                d = dict(zip(key,line.split()))
                nodes_status.append(d)
        service_cifs[clusterservicename] = nodes_status
    return service_cifs

def func_service_nfs_export_status():
    service_nfs = {}
    try:
        services = func_service_name_list_all()
        for clusterservicename in services:
            cmd = 'sudo python %s service export_nfs %s status' % (DIGIMANAGER, clusterservicename)
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
            result = proc.stdout.readlines()
            proc.wait()
            nfs_status = ''
            for line in result:
                if line.find('NFS status') >= 0:
                    nfs_status = line.split(':')[1].strip()
            service_nfs[clusterservicename] = nfs_status
        return service_nfs
    except Exception,e:
        return service_nfs

#########################################################################################################
#
#   Function: func_service_abnormal_status
#   Variable: none
#   Purpose: provide info of abnormal service status
#   Data structure: type: str
#
#########################################################################################################
def func_service_abnormal_status():
    abnormal_status = []
    try:
        cmd = 'sudo python %s service list' % DIGIMANAGER
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        result.pop(0)
        proc.wait()
        for res in result[5:-2]:
            value = res.split('\n')
            abnormal_status.append(value[0])
        return abnormal_status
    except Exception,e:
        return abnormal_status
    
def func_service_list_dir(targetpath):
    children = []
    #target_dir = os.path.join(dir_prefix, clusterservicename)
    try:
        for path in os.listdir(targetpath):
            subpath = os.path.join(targetpath, path.decode('utf-8'))
            if os.path.isdir(subpath.encode('utf-8')):
                children.append({"name": path, "path": subpath, "isParent":"true"})
        #children = [{"name": path, "path": os.path.join(targetpath, path)} for path in os.listdir(targetpath)]
    except Exception, e:
        pass
    return children

def func_service_list_quota():
    service_quota = []
    services = func_service_name_list_all()
    for clusterservicename in services:
        cmd = 'sudo python %s service quota_setup %s list' % (DIGIMANAGER, clusterservicename)#, quota_dir)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        if len(result[1:]) >= 2:
            for line in result[3:]:
                quota_dict = {}
                if len(line.split()) >= 5:
                    quota_dict['servicename'] = clusterservicename
                    quota_dict['path'] = '/cluster2/%s%s' % (clusterservicename, line.split()[0])
                    quota_dict['name'] = line.split()[0].replace('/','')
                    quota_dict['quota_tsize'] = line.split()[1]   #total size
                    quota_dict['quota_usize'] = line.split()[3]   #used size
                    quota_dict['quota_fsize'] = line.split()[4]   #free size
                if quota_dict:
                    service_quota.append(quota_dict)
    return service_quota
        
def func_service_list_options(clusterservicename, dynamic=False):
    try:
        clusterserviceoptions = {}
        clusterservicedynamicoptions = {}
        cmd = "sudo python %s service list %s" % (DIGIMANAGER,clusterservicename)
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        result = proc.stdout.readlines()
        proc.wait()
        dynamic_flag = False
        if ' '.join(result).find('does not exist') < 0:
            for i in range(len(result)):
                arr = result[i].replace('\n','')
                index = arr.split(':')
                if len(index) == 2:
                    if index[0] == 'Bricks' or index[0] == 'Options Reconfigured':
                        if index[0] == 'Options Reconfigured':
                            dynamic_flag = True
                    else:
                        if dynamic and dynamic_flag:
                            clusterserviceoptions[index[0]] = index[1].strip()
                            clusterservicedynamicoptions[index[0]] = index[1].strip()
                        else:
                            clusterserviceoptions[index[0]] = index[1].strip()
        if dynamic:
            return clusterservicedynamicoptions
        else:
            return clusterserviceoptions
    except Exception,e:
        return clusterserviceoptions
