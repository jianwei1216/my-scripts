#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusservicelib
import setting
import snmp_passpersist as snmp

'''
+--ServiceCIFSUserTable(7)
   |
   +--ServiceCIFSUserEntry(1)
      |  Index: ServiceCIFSUserIndex
      |
      +-- -R-- Integer32 ServiceCIFSUserIndex(1)
      |        Range: 0..65535
      +-- -R-- String    ServiceCIFSUserServiceName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    ServiceCIFSUserName(3)
               Textual Convention: DisplayString
               Size: 0..255
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusservicelib.func_service_cifs_list_user()

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.21.7.1")
def update():
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusservicelib.func_service_cifs_list_user()
        uptime = currtime

    i = 1
    for servicename in rtndata.keys():
        users = rtndata[servicename]
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),servicename)
        pp.add_str('3.' + str(i),','.join(users))
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
