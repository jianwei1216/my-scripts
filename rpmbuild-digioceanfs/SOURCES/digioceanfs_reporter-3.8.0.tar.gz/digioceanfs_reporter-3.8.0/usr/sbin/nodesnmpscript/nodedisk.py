#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusnodelib
import setting
import snmp_passpersist as snmp

'''
Map of Interface MIB
+--NodeDiskTable(4)
   |
   +--NodeDiskEntry(1)
      |  Index: NodeDiskIndex
      |
      +-- -R-- Integer32 NodeDiskIndex(1)
      |        Range: 0..65535
      +-- -R-- String    NodeDiskName(2)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeDiskStatus(3)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- Gauge     NodeDiskSize(4)
      +-- -R-- String    NodeDiskSN(5)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeDiskVandor(6)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeDiskType(7)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- String    NodeDiskPosition(8)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- EnumVal   NodeDiskIstart(9)
      |        Values: start(1), stop(0), nostate(-1)
      +-- -R-- Integer32 NodeDiskPort(10)
      |        Range: 0..65535
      +-- -R-- String    NodeDiskService(11)
      |        Textual Convention: DisplayString
      |        Size: 0..255
      +-- -R-- Integer32 NodeDiskPid(12)
               Range: 0..32768
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusnodelib.func_node_disk_info(os.uname()[1])

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.20.4.1")
def update():
    #rtndata = [{'status': 'used', 'vandor': 'WDC WD5003ABYX-0', 'istart': 'stop', 'nodename': 'node-1.cluster-1', 'devname': 'sdb', 'pid': '', 'sn_number': '0x50014ee0adac76c9', 'servicename': 'test', 'position': '14/16', 'type': 'HDD', 'port': '10013', 'size': '488386584'}, {'status': 'used', 'vandor': 'WDC WD5003ABYX-0', 'istart': 'stop', 'nodename': 'node-1.cluster-1', 'devname': 'sdc', 'pid': '', 'sn_number': '0x50014ee0adad717a', 'servicename': 'test', 'position': '10/16', 'type': 'HDD', 'port': '10016', 'size': '488386584'}]
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusnodelib.func_node_disk_info(os.uname()[1])
        uptime = currtime

    i = 1
    for m in xrange(len(rtndata)):
        if rtndata[m]['type'] == 'raid':
            continue
        pp.add_int('1.' + str(i),i)
        pp.add_str('2.' + str(i),rtndata[m]['devname'])
        pp.add_str('3.' + str(i),rtndata[m]['status'])
        pp.add_gau('4.' + str(i),int(rtndata[m]['size']))
        pp.add_str('5.' + str(i),rtndata[m]['sn_number'])
        pp.add_str('6.' + str(i),rtndata[m]['vandor'])
        pp.add_str('7.' + str(i),rtndata[m]['type'])
        pp.add_str('8.' + str(i),rtndata[m]['position'])
        if rtndata[m]['istart'] == 'start':
            pp.add_int('9.' + str(i),1)
        elif rtndata[m]['istart'] == 'stop':
            pp.add_int('9.' + str(i),0)
        else:
            pp.add_int('9.' + str(i),-1)
        if 'port' in rtndata[m] and rtndata[m]['port']:
            pp.add_int('10.' + str(i),int(rtndata[m]['port']))
        if 'servicename' in rtndata[m]:
            pp.add_str('11.' + str(i),rtndata[m]['servicename'])
        else:
            pp.add_str('11.' + str(i),'')
        if 'pid' in rtndata[m] and rtndata[m]['pid']:
            pp.add_int('12.' + str(i),int(rtndata[m]['pid']))
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
