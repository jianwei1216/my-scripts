#!/usr/bin/python -u
# -*- coding:Utf-8 -*-
import os
import time
import clusnodelib
import setting
import snmp_passpersist as snmp

'''
Map of Interface MIB
+--NodeSysTable(6)
   |
   +--NodeSysEntry(1)
      |
      +--NodeSysVitalsEntry(1)
      |  |  Index: NodeSysVitalsIndex
      |  |
      |  +-- -R-- Integer32 NodeSysVitalsIndex(1)
      |  |        Range: 0..65535
      |  +-- -R-- String    NodeSysVitalsDistro(2)
      |  |        Textual Convention: DisplayString
      |  |        Size: 0..255
      |  +-- -R-- String    NodeSysVitalsHostname(3)
      |  |        Textual Convention: DisplayString
      |  |        Size: 0..255
      |  +-- -R-- String    NodeSysVitalsIPAddr(4)
      |  |        Textual Convention: DisplayString
      |  |        Size: 0..255
      |  +-- -R-- String    NodeSysVitalsKernel(5)
      |  |        Textual Convention: DisplayString
      |  |        Size: 0..255
      |  +-- -R-- String    NodeSysVitalsLoadAvg(6)
      |  |        Textual Convention: DisplayString
      |  |        Size: 0..255
      |  +-- -R-- String    NodeSysVitalsUptime(7)
      |  |        Textual Convention: DisplayString
      |  |        Size: 0..255
      |  +-- -R-- Integer32 NodeSysVitalsUsers(8)
      |           Range: 0..65535
      |
      +--NodeSysNetEntry(2)
      |  |  Index: NodeSysNetIndex
      |  |
      |  +-- -R-- Integer32 NodeSysNetIndex(1)
      |  |        Range: 0..65535
      |  +-- -R-- String    NodeSysNetName(2)
      |  |        Textual Convention: DisplayString
      |  |        Size: 0..255
      |  +-- -R-- Gauge     NodeSysNetErrors(3)
      |  +-- -R-- Gauge     NodeSysNetDrops(4)
      |  +-- -R-- Gauge     NodeSysNetRxBytes(5)
      |  +-- -R-- Gauge     NodeSysNetTxBytes(6)
      |
      +--NodeSysMemEntry(3)
      |  |  Index: NodeSysMemIndex
      |  |
      |  +-- -R-- Integer32 NodeSysMemIndex(1)
      |  |        Range: 0..65535
      |  +-- -R-- Gauge     NodeSysMemFree(2)
      |  +-- -R-- Integer32 NodeSysMemPercent(3)
      |  |        Range: 0..100
      |  +-- -R-- Gauge     NodeSysMemTotal(4)
      |  +-- -R-- Gauge     NodeSysMemUsed(5)
      |  +-- -R-- Gauge     NodeSysMemApp(6)
      |  +-- -R-- Integer32 NodeSysMemAppPercent(7)
      |  |        Range: 0..100
      |  +-- -R-- Gauge     NodeSysMemBuffers(8)
      |  +-- -R-- Integer32 NodeSysMemBuffersPercent(9)
      |  |        Range: 0..100
      |  +-- -R-- Gauge     NodeSysMemCached(10)
      |  +-- -R-- Integer32 NodeSysMemCachedPercent(11)
      |           Range: 0..100
      |
      +--NodeSysMountEntry(4)
         |  Index: NodeSysMountIndex
         |
         +-- -R-- Integer32 NodeSysMountIndex(1)
         |        Range: 0..65535
         +-- -R-- Gauge     NodeSysMountFree(2)
         +-- -R-- String    NodeSysMountMountPoint(3)
         |        Textual Convention: DisplayString
         |        Size: 0..255
         +-- -R-- Integer32 NodeSysMountPercent(4)
         |        Range: 0..100
         +-- -R-- Gauge     NodeSysMountTotal(5)
         +-- -R-- Gauge     NodeSysMountUsed(6)
'''
TIMEOUT = setting.TIMEOUT
uptime = time.time()
rtndata = clusnodelib.func_node_dynamic_info(os.uname()[1])

pp = snmp.PassPersist(".1.3.6.1.4.1.38696.2.20.6.1")
def update():
    #rtndata = {'NetDevice': [{'NetDrops': u'527990', 'NetRxBytes': u'1724741399', 'NetName': u'eth0', 'NetTxBytes': u'207718761', 'NetErrors': u'00'}, {'NetDrops': u'527990', 'NetRxBytes': u'1724741399', 'NetName': u'eth0', 'NetTxBytes': u'207718761', 'NetErrors': u'00'}, {'NetDrops': u'527990', 'NetRxBytes': u'1724741399', 'NetName': u'eth0', 'NetTxBytes': u'207718761', 'NetErrors': u'00'}], 'Memory': {'MemTotal': u'8399302656', 'MemApp': u'267816960', 'MemAppPercent': u'4.0', 'MemCachedPercent': u'4.0', 'MemPercent': u'9.0', 'MemFree': u'7690805248', 'MemBuffersPercent': u'2.0', 'MemUsed': u'708497408', 'MemCached': u'275247104', 'MemBuffers': u'165433344'}, 'Mount': [{'MountFree': u'6312419328', 'MountPoint': '', 'MountTotal': u'6312419328', 'MountMountPercent': '', 'MountUsed': u'0'}, {'MountFree': u'6312419328', 'MountPoint': '', 'MountTotal': u'6312419328', 'MountMountPercent': '', 'MountUsed': u'0'}, {'MountFree': u'6312419328', 'MountPoint': '', 'MountTotal': u'6312419328', 'MountMountPercent': '', 'MountUsed': u'0'}], 'Vitals': {'Kernel': u'3.6.11 (SMP)x86_64', 'Uptime': u'1320569.35', 'Users': u'4', 'Hostname': u'node-1.cluster-1', 'IPAddr': u'10.10.12.116', 'LoadAvg': u'0.125', 'Distro': u'CentOS release 6.4 (Final)'}}
    global rtndata
    global uptime
    currtime = time.time()
    if currtime - uptime >= TIMEOUT:
        rtndata = clusnodelib.func_node_dynamic_info(os.uname()[1])
        uptime = currtime

    v_info = rtndata['Vitals']
    pp.add_int('1.1',1)
    pp.add_str('1.2',v_info['Distro'])
    pp.add_str('1.3',v_info['Hostname'])
    pp.add_str('1.4',v_info['IPAddr'])
    pp.add_str('1.5',v_info['Kernel'])
    pp.add_str('1.6',v_info['LoadAvg'])
    pp.add_str('1.7',v_info['Uptime'])
    pp.add_int('1.8',int(v_info['Users']))

    n_info = rtndata['NetDevice']
    i = 1
    for m in xrange(len(n_info)):
        pp.add_int('2.1.' + str(i),i)
        pp.add_str('2.2.' + str(i),n_info[m]['NetName'])
        pp.add_gau('2.3.' + str(i),int(n_info[m]['NetErrors']))
        pp.add_gau('2.4.' + str(i),int(n_info[m]['NetDrops']))
        pp.add_gau('2.5.' + str(i),int(n_info[m]['NetRxBytes']))
        pp.add_gau('2.6.' + str(i),int(n_info[m]['NetTxBytes']))
        i = i + 1

    m_info = rtndata['Memory']
    pp.add_int('3.1',1)
    pp.add_gau('3.2',int(m_info['MemFree']))
    pp.add_int('3.3',float(m_info['MemPercent']))
    pp.add_gau('3.4',int(m_info['MemTotal']))
    pp.add_gau('3.5',int(m_info['MemUsed']))
    pp.add_gau('3.6',int(m_info['MemApp']))
    pp.add_int('3.7',float(m_info['MemAppPercent']))
    pp.add_gau('3.8',int(m_info['MemBuffers']))
    pp.add_int('3.9',float(m_info['MemBuffersPercent']))
    pp.add_gau('3.10',int(m_info['MemCached']))
    pp.add_int('3.11',float(m_info['MemCachedPercent']))

    d_info = rtndata['Mount']
    i = 1
    for m in xrange(len(d_info)):
        pp.add_int('4.1.' + str(i),i)
        pp.add_gau('4.2.' + str(i),int(d_info[m]['MountFree']))
        pp.add_str('4.3.' + str(i),d_info[m]['MountPoint'])
        if 'MountMountPercent' in d_info[m] and d_info[m]['MountMountPercent']:
            pp.add_int('4.4.' + str(i),float(d_info[m]['MountMountPercent']))
        else:
            pp.add_int('4.4.' + str(i),0)
        pp.add_gau('4.5.' + str(i),int(d_info[m]['MountTotal']))
        pp.add_gau('4.6.' + str(i),int(d_info[m]['MountUsed']))
        i = i + 1

if __name__ == "__main__":
    pp.start(update,1)
