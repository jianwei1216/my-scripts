#!/usr/bin/python
#-*- coding: UTF-8 -*-

import os
import sys
import utils
import pexpect
import setting
import sysmonitor

sensors = '/usr/bin/sensors'
sensorsdetect = '/usr/sbin/sensors-detect'
loadmoudle = '/etc/init.d/module-init-tools start'

def sensors_detect ():
    try:
        rtn = pexpect.spawn(sensorsdetect,timeout = 1)
        rtn.expect(['Do you want to scan for them? This is totally safe. (YES/no):', pexpect.TIMEOUT])
        rtn.sendline ('yes')
        rtn.expect(['Do you want to scan for Super I/O sensors? (YES/no):', pexpect.TIMEOUT])
        rtn.sendline ('yes')
        rtn.expect(['interfaces? (YES/no):', pexpect.TIMEOUT])
        rtn.sendline ('yes')
        rtn.expect(['Do you want to scan the ISA I/O ports? (yes/NO):', pexpect.TIMEOUT])
        rtn.sendline ('yes')
        rtn.expect(['Do you want to probe the I2C/SMBus adapters now? (YES/no):', pexpect.TIMEOUT])
        rtn.sendline ('yes')
        rtn.expect(['Do you want to scan it? (YES/no/selectively):', pexpect.TIMEOUT])
        rtn.sendline ('yes')
        rtn.expect(['Just press ENTER to continue:', pexpect.TIMEOUT])
        rtn.sendline ()
        rtn.expect(['(yes/NO)', pexpect.TIMEOUT])
        rtn.sendline ('yes')
        rtn.expect(['to load them.', pexpect.TIMEOUT])
        retcode,proc = utils.cust_popen(loadmoudle)
        if retcode == 0:
            return 'OK'
        else:
            return 'FAIL'
    except Exception,e:
        setting.errlogdata(setting.LINE(),'readfan.py')
        return 'err'

def installmodule ():
    ipmi_module = ['ipmi_poweroff','ipmi_devintf','ipmi_si','ipmi_msghandler']
    retcode,proc = utils.cust_popen(setting.LSMOD)
    datas = proc.stdout.readlines()
    i = 0
    for data in datas:
        #if data.find('ipmi_watchdog') != -1:
        #    i = i + 1
        if data.find('ipmi_poweroff') != -1:
            i = i + 1
        if data.find('ipmi_devintf') != -1:
            i = i + 1
        if data.find('ipmi_si') != -1:
            i = i + 1
        if data.find('ipmi_msghandler') != -1:
            i = i + 1
    if i < 8:
        for module in ipmi_module:
            cmd = setting.MODPROBE + ' ' + module
            retcode,proc = utils.cust_popen(cmd)
            errmsg = proc.stderr.read()
            if errmsg.find('FATAL') != -1:
                failmsg = 'FATAL: Module %s not found.' %(module)
                setting.errlogdata(setting.LINE(),'sysmonitor.py',failmsg)

def readfan_ipmi ():
    fans = []
    try:
        ipmicmd = '/usr/bin/ipmitool sdr'
        #installmodule()
        retcode,proc = utils.cust_popen(setting.BASEBOARDCMD)
        baseboardmsg = proc.stdout.readlines()
        for msg in baseboardmsg:        
            if msg.find('Product Name:') != -1:
                i = msg.find(':')
                baseboardtype = msg[i+1:].strip()
        retcode,proc = utils.cust_popen(ipmicmd)
        datas = proc.stdout.readlines()
        if baseboardtype == 'X8SIE':
            for data in datas:
                fan = {}
                if data.find('FAN 1') != -1:
                    i = data.find('|')
                    j = data.find('RPM')
                    fan['fan'] = 'cpufan'
                    fan['rev'] = data[i+1:j].strip()
                    if int(fan['rev']) < 100:
                        fan['alarm'] = 'ALARM'
                    else:
                        fan['alarm'] = 'OK'
                    fans.append(fan)
                if data.find('FAN 2') != -1:
                    i = data.find('|')
                    j = data.find('RPM')
                    fan['fan'] = 'fan1'
                    fan['rev'] = data[i+1:j].strip()
                    if int(fan['rev']) < 100:
                        fan['alarm'] = 'ALARM'
                    else:
                        fan['alarm'] = 'OK'
                    fans.append(fan)
                if data.find('FAN 3') != -1:
                    i = data.find('|')
                    j = data.find('RPM')
                    fan['fan'] = 'fan2'
                    fan['rev'] = data[i+1:j].strip()
                    if int(fan['rev']) < 100:
                        fan['alarm'] = 'ALARM'
                    else:
                        fan['alarm'] = 'OK'
                    fans.append(fan)
        elif baseboardtype == 'X10SL7-F':
            for data in datas:
                fan = {}
                if data.find('FAN1') != -1:
                    i = data.find('|')
                    j = data.find('RPM')
                    fan['fan'] = 'cpufan'
                    fan['rev'] = data[i+1:j].strip()
                    if int(fan['rev']) < 100:
                        fan['alarm'] = 'ALARM'
                    else:
                        fan['alarm'] = 'OK'
                    fans.append(fan)
                if data.find('FAN2') != -1:
                    i = data.find('|')
                    j = data.find('RPM')
                    fan['fan'] = 'fan1'
                    fan['rev'] = data[i+1:j].strip()
                    if int(fan['rev']) < 100:
                        fan['alarm'] = 'ALARM'
                    else:
                        fan['alarm'] = 'OK'
                    fans.append(fan)
                if data.find('FAN3') != -1:
                    i = data.find('|')
                    j = data.find('RPM')
                    fan['fan'] = 'fan2'
                    fan['rev'] = data[i+1:j].strip()
                    if int(fan['rev']) < 100:
                        fan['alarm'] = 'ALARM'
                    else:
                        fan['alarm'] = 'OK'
                    fans.append(fan)
        else:
            return 'err'
    except:
        setting.errlogdata(setting.LINE(),'readfan.py','read fan data error')
        return 'err'
    return fans 

def readfan ():
    rtndata = []
    retcode,proc = utils.cust_popen(sensors)
    if retcode != 0:
        a = sensors_detect()
        if a == 'OK':
            retcode,proc = utils.cust_popen(sensors)
        else:
            return 'err'
    if retcode == 0:
        lines = proc.stdout.readlines()
        for line in lines:
            a = {}
            if line.find('fan1') >= 0:
                b = line.strip().split()
                a['fan'] = 'fan2'
                a['rev'] = b[1]
                if int(b[1]) < 100:
                    a['alarm'] = 'ALARM'
                else:
                    a['alarm'] = 'OK'
                rtndata.append(a)
            if line.find('fan2') >= 0:
                b = line.strip().split()
                a['fan'] = 'cpufan'
                a['rev'] = b[1]
                if int(b[1]) < 100:
                    a['alarm'] = 'ALARM'
                else:
                    a['alarm'] = 'OK'
                rtndata.append(a)
            if line.find('fan5') >= 0:
                b = line.strip().split()
                a['fan'] = 'fan1'
                a['rev'] = b[1]
                if int(b[1]) < 100:
                    a['alarm'] = 'ALARM'
                else:
                    a['alarm'] = 'OK'
                rtndata.append(a)
    else:
        return 'err'
    return rtndata

def fanalarm ():
    errdata = ''
    cherrdata = ''
    #fandata = readfan()
    fandata = readfan_ipmi()
    if fandata != 'err':
        for data in fandata:
            if data['alarm'] == 'ALARM':
                errdata = errdata + 'fan:' + data['fan'] + ',' + 'rev:' + data['rev'] + ',' + 'alarm:' +  data['alarm'] + ' '
                cherrdata = cherrdata + '����:' + data['fan'] + ',' + 'ת��:' + data['rev'] + ',' + '����״̬:' +  data['alarm'] + ' '
    else:
        errdata = 'read fan data error'
        cherrdata = '��ȡ�������ݴ���'
    if errdata != '':
        setting.iperrdata(errdata,'en')
        setting.iperrdata(cherrdata,'ch')
    return errdata
