#coding: utf-8

import os
import re
import sys
import utils
import setting
import traceback
import snmptrap

def readipaddr ():
    iplist = []
    retcode,proc = utils.cust_popen2(['ifconfig','-a'])
    rtnipdata = proc.stdout.readlines()
    for i in range(len(rtnipdata)):
        ipaddr = {}
        if rtnipdata[i].find('eth') != -1:
            eth = rtnipdata[i].split()
            ipaddr['eth'] = eth[0].strip()
            ipaddr['mac'] = eth[4]
            if rtnipdata[i+1].find('addr') != -1:
                addr = rtnipdata[i+1].split()
                ipaddr['addr'] = addr[1].strip()[addr[1].strip().find(':')+1:]
            else:
                ipaddr['addr'] = ''
            iplist.append(ipaddr)
        elif rtnipdata[i].find('bond') != -1:
            eth = rtnipdata[i].split()
            ipaddr['eth'] = eth[0].strip()
            ipaddr['mac'] = eth[4]
            if rtnipdata[i+1].find('addr') != -1:
                addr = rtnipdata[i+1].split()
                ipaddr['addr'] = addr[1].strip()[addr[1].strip().find(':')+1:]
            else:
                ipaddr['addr'] = ''
            iplist.append(ipaddr)
        elif rtnipdata[i].find('br') != -1:
            eth = rtnipdata[i].split()
            ipaddr['eth'] = eth[0].strip()
            ipaddr['mac'] = eth[4]
            if rtnipdata[i+1].find('addr') != -1:
                addr = rtnipdata[i+1].split()
                ipaddr['addr'] = addr[1].strip()[addr[1].strip().find(':')+1:]
            else:
                ipaddr['addr'] = ''
            iplist.append(ipaddr)
    return iplist

def CentOs7_readipaddr ():
    iplist = []
    retcode,proc = utils.cust_popen2(['ifconfig','-a'])
    rtnipdata = proc.stdout.readlines()
#    setting.errlogdata(setting.LINE(),'checkip.py','rtnipdata = ' + str(rtnipdata))
    for i in range(len(rtnipdata)):
        ipaddr = {}
        if rtnipdata[i].find('eth') != -1 and rtnipdata[i].find('ether') == -1:
            eth = rtnipdata[i].split()
            ipaddr['eth'] = eth[0].strip()
            ipaddr['mac'] = eth[4]
            if rtnipdata[i+1].find('addr') != -1:
                addr = rtnipdata[i+1].split()
                ipaddr['addr'] = addr[1].strip()[addr[1].strip().find(':')+1:]
            else:
                ipaddr['addr'] = ''
            iplist.append(ipaddr)
        elif rtnipdata[i].find('bond') != -1:
            if rtnipdata[i].find('flags') == -1:
                eth = rtnipdata[i].split()
                ipaddr['eth'] = eth[0].strip()
                ipaddr['mac'] = eth[4]
                if rtnipdata[i+1].find('addr') != -1:
                    addr = rtnipdata[i+1].split()
                    ipaddr['addr'] = addr[1].strip()[addr[1].strip().find(':')+1:]
                else:
                    ipaddr['addr'] = ''
            else:
                eth = rtnipdata[i].split()
                ipaddr['eth'] = eth[0].strip(':')
                if rtnipdata[i+1].find('inet') != -1:
                    addr = rtnipdata[i+1].split()
                    ipaddr['addr'] = addr[1]
                    if rtnipdata[i+3].find('ether') != -1:
                        mac = rtnipdata[i+3].split()
                        ipaddr['mac'] = mac[1]
                else:
                    ipaddr['addr'] = ''
                    ipaddr['mac'] = ''
            iplist.append(ipaddr)
        elif rtnipdata[i].find('br') != -1 and rtnipdata[i].find('broadcast') == -1:
            eth = rtnipdata[i].split()
            ipaddr['eth'] = eth[0].strip()
            ipaddr['mac'] = eth[4]
            if rtnipdata[i+1].find('addr') != -1:
                addr = rtnipdata[i+1].split()
                ipaddr['addr'] = addr[1].strip()[addr[1].strip().find(':')+1:]
            else:
                ipaddr['addr'] = ''
            iplist.append(ipaddr)
        elif rtnipdata[i].find('enp') != -1:
            eth = rtnipdata[i].split()
            ipaddr['eth'] = eth[0].strip(':')
            if rtnipdata[i+1].find('inet') != -1:
                addr = rtnipdata[i+1].split()
                ipaddr['addr'] = addr[1]
                if rtnipdata[i+3].find('ether') != -1:
                    mac = rtnipdata[i+3].split()
                    ipaddr['mac'] = mac[1]
            else:
                ipaddr['addr'] = ''
                ipaddr['mac'] = ''
            iplist.append(ipaddr)
    return iplist

def checkip ():
    ipconflictflag = False
    rtndata = []
    errdata = {}
    iplist = CentOs7_readipaddr()
    for ip in iplist:
        retcode,proc = utils.cust_popen2(['arping','-c','3','-I',ip['eth'],ip['addr']])
        rtnipdata = proc.stdout.readlines()
        datalen = len(rtnipdata)
        n = rtnipdata[datalen-1].split(',')
        i = n[1].find('packets received')
        j = n[0].find('packets transmitted')
        sendpacketnum = n[0][:j-1].strip()
        if i != -1:
            recvpacketnum = n[1][:i-1].strip()
            if int(recvpacketnum) >= 1:
                ips = rtnipdata[0].split(' ')
                conflictip = ips[1].strip()
                mac = rtnipdata[1].split(' ')
                conflictmac = mac[3].strip()
                if conflictip == ip['addr']:
                    errdata['data'] = 'The IP address conflict.Conflicting net export:%s,Conflicting IP address:%s,The other side mac address:%s.' %(ip['eth'],ip['addr'],conflictmac)
                    errdata['chdata'] = 'IP��ַ��ͻ.��ͻ����:%s,��ͻ��ַ:%s,�Է�MAC��ַ:%s.' %(ip['eth'],ip['addr'],conflictmac)
                    errdata['flag'] = 'error'
                    errdata['eth'] = ip['eth']
            else:
                errdata['data'] = 'Conflicting net export %s conflict termination.' %(ip['eth'])
                errdata['chdata'] = '���� %s ��ͻ���.' %(ip['eth'])
                errdata['flag'] = 'ok'
                errdata['eth'] = ip['eth']
            rtndata.append(errdata)
            errdata = {}
    return rtndata


def getpingmsg ():
    try:
        managenodeflag = False
        rtnping = []
        b = []
        iplist = []
        local_ipaddr = None
        ipaddr = CentOs7_readipaddr()
        '''
        managenode = snmptrap.readconf()
        if managenode != []:
            for ips in ipaddr:
                if ips['addr'] == managenode[0]['ip']:
                    managenodeflag = True
        '''
        retcode,proc = utils.cust_popen2([setting.CAT,setting.IPFILEADDR])
        datas = proc.stdout.readlines()
        for data in datas:
            if data.find('####DigioceanfsNode####') != -1:
                c = {}
                ipmsg = data.split(' ')
                c['addr'] = ipmsg[0]
                c['node'] = ipmsg[1]
                iplist.append(c)
        for i in range(len(iplist)):
            for m in ipaddr:
                if iplist[i]['addr'] == m['addr']:
                    b.append(i)
        for i in b:
            local_ipaddr = iplist.pop(i)
        if iplist != []:
            for ip in iplist:
                d = {}
                d['op'] = 'Ping'
                d['Ip'] = ip['addr']
                d['Node'] = ip['node']
                retcode,proc = utils.cust_popen2([setting.PING,'-c','5',ip['addr']])
                pingdata = proc.stdout.readlines()
                errdata = proc.stderr.read()
                if not pingdata and errdata.find('Network is unreachable') >= 0:
                    d['Event'] = 'Off-line'
                    d['op'] = 'Ping'
                    d['Ip'] = local_ipaddr and 'addr' in local_ipaddr and local_ipaddr['addr']
                    d['Node'] = local_ipaddr and 'node' in local_ipaddr and local_ipaddr['node']
                    rtnping.append(d)
                    break
                else:
                    aa = pingdata[-2].split(',')
                    for a in aa:
                        if a.find('% packet loss') != -1:
                            b = a.find('% packet loss')
                            loss = a[:b]
                            if int(loss) < 20:
                                d['Event'] = 'On-line'
                            else:
                                d['Event'] = 'Off-line'
                rtnping.append(d)
        return rtnping

    except Exception,e:
        print >> sys.stderr,traceback.print_exc()

