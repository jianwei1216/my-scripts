#!/usr/bin/env python
#-*- coding: UTF-8 -*-

import os
import sys
import pickle
import traceback
currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
homepath = currpath[:currpath.find('diskbitmap')]
if not currpath in sys.path:
    sys.path.append(currpath)
if not homepath in sys.path:
    sys.path.append(homepath)
import utils
from diskbitmap import baseboard
from diskbitmap import diskinfo
import setting
from checkdevice import digiraid4 as digiraid
#---------------------------------
#global
#---------------------------------
DISKMAPPATH = '/etc/storage/diskmap'
#if not os.path.exists(DISKMAPPATH):
#    retcode,proc = utils.cust_popen2(['mkdir','-p',DISKMAPPATH])
#---------------------------------
# system command 
#---------------------------------
#----------------------------------------
# get disk bitmap
#----------------------------------------
'''
def get_disk_bitmap(olddiskbitmap=None):
    diskbitmap = utils.Storage({})
    changediskbitmap = utils.Storage({})
    try:
        diskraids = diskinfo.get_disks_raid()
        cabinetcount,expanderidmap,expanderdisks = baseboard.get_cabinet_info()
        if cabinetcount == 0 or expanderidmap == {} or expanderdisks == {}:
            raise
        expander = baseboard.get_all_expanders()
        if expander == {}:
            raise 
        expanders = baseboard.reverse_map(expander)
        for expanderid,expanderinfo in expanderidmap.iteritems():
            expandersasaddress = expanderinfo['sasaddress']
            smpdevice = baseboard.get_smp_device(expanders[expandersasaddress],expandersasaddress)
            if smpdevice == None:
                raise
            diskbitmap[expandersasaddress] = utils.Storage({
                'id':expanderid,
                'smpdevice':smpdevice,
                'disks':utils.Storage({})
            })
            f = open(os.path.join(DISKMAPPATH,'%d-%d-%s' % (expanderid,expanderinfo['diskcounttype'],expandersasaddress)),'r')
            expanderdiskidmap = pickle.load(f)
            f.close()
            diskinfo.get_sorted_raid_disks()
            olddisks = None
            if olddiskbitmap and expandersasaddress in olddiskbitmap:
                olddisks = olddiskbitmap[expandersasaddress]['disks']
            for phyid,locateid in expanderdiskidmap.iteritems():
                diskname = expanderdisks[expandersasaddress][phyid]
                diskstate = diskinfo.get_disk_state(diskname)
                if olddisks:
                    if phyid in olddisks:
                        if not olddisks[phyid]['diskstate'] == diskstate:
                            if not expandersasaddress in changediskbitmap:
                                changediskbitmap[expandersasaddress] = utils.Storage({
                                    'id':expanderid,
                                    'smpdevice':smpdevice,
                                    'disks':utils.Storage({})
                                })
                            changediskbitmap[expandersasaddress]['disks'][phyid] = utils.Storage({
                                'diskdev':diskname,
                                'locateid':locateid,
                                'locate':olddisks[phyid]['locate'],
                                'olddiskstate':olddisks[phyid]['diskstate'],
                                'newdiskstate':diskstate,
                                'oldraidname':olddisks[phyid]['raidname'],
                                'raidname':diskname in diskraids and '/dev/md%s' % diskraids[diskname] or None
                            })
                    else:
                        if not expandersasaddress in changediskbitmap:
                            changediskbitmap[expandersasaddress] = utils.Storage({
                                'id':expanderid,
                                'smpdevice':smpdevice,
                                'disks':utils.Storage({})
                            })
                        changediskbitmap[expandersasaddress]['disks'][phyid] = utils.Storage({
                            'diskdev':diskname,
                            'locateid':locateid,
                            'locate':False,
                            'olddiskstate':'',
                            'newdiskstate':diskstate,
                            'oldraidname':'',
                            'raidname':diskname in diskraids and '/dev/md%s' % diskraids[diskname] or None
                        })
                elif olddiskbitmap:
                    if not expandersasaddress in changediskbitmap:
                        changediskbitmap[expandersasaddress] = utils.Storage({
                            'id':expanderid,
                            'smpdevice':smpdevice,
                            'disks':utils.Storage({})
                        })
                    changediskbitmap[expandersasaddress]['disks'][phyid] = utils.Storage({
                        'diskdev':diskname,
                        'locateid':locateid,
                        'locate':False,
                        'olddiskstate':'',
                        'newdiskstate':diskstate,
                        'oldraidname':'',
                        'raidname':diskname in diskraids and '/dev/md%s' % diskraids[diskname] or None
                    })
                diskbitmap[expandersasaddress]['disks'][phyid] = utils.Storage({
                    'diskdev':diskname,
                    'locateid':locateid,
                    'diskstate':diskstate,
                    'locate':(olddisks and phyid in olddisks) and olddisks[phyid]['locate'] or False,
                    'raidname':diskname in diskraids and '/dev/md%s' % diskraids[diskname] or None
                })
    except:
        setting.errlogdata(setting.LINE(),'baseboard.py')
        diskbitmap = utils.Storage({})
        changediskbitmap = utils.Storage({})
    return diskbitmap,changediskbitmap
'''    
def get_disk_pre(cabinetnum,cabinetcount):
    diskpre = ''
    if cabinetcount > 1:
        diskpre = '%s-' % cabinetnum
    return diskpre
    
def get_disk_bitmap(olddiskbitmap=None):
    diskbitmap = utils.Storage({})
    changediskbitmap = utils.Storage({})
    if baseboard.check_device():
        try:
            diskraids = diskinfo.get_disks_raid()
            cabinetcount,expanderidmap,expanderdisks = baseboard.get_cabinet_info()
            if cabinetcount == 0 or expanderidmap == {} or expanderdisks == {}:
                raise
            expander = baseboard.get_all_expanders()
            if expander == {}:
                raise 
            expanders = baseboard.reverse_map(expander)
            for expanderid,expanderinfo in expanderidmap.iteritems():
                expandersasaddress = expanderinfo['sasaddress']
                smpdevice = baseboard.get_smp_device(expanders[expandersasaddress],expandersasaddress)
                if smpdevice == None:
                    raise
                diskbitmap[expandersasaddress] = utils.Storage({
                    'id':expanderid,
                    'smpdevice':smpdevice,
                    'disks':utils.Storage({})
                })
                f = open(os.path.join(DISKMAPPATH,'%d-%d-%s' % (expanderid,expanderinfo['diskcounttype'],expandersasaddress)),'r')
                expanderdiskidmap = pickle.load(f)
                f.close()
                diskinfo.get_sorted_raid_disks()
                olddisks = None
                if olddiskbitmap and expandersasaddress in olddiskbitmap:
                    olddisks = olddiskbitmap[expandersasaddress]['disks']
                setting.errlogdata(setting.LINE(),'diskbit.py','olddisks = ' + str(olddisks))
                setting.errlogdata(setting.LINE(),'diskbit.py','expanderdisks = ' + str(expanderdisks))
                if olddisks:
                    for phyid in olddisks:
                        if phyid not in expanderdisks[expandersasaddress]:
                            if not expandersasaddress in changediskbitmap:
                                changediskbitmap[expandersasaddress] = utils.Storage({
                                    'id':expanderid,
                                    'smpdevice':smpdevice,
                                    'disks':utils.Storage({})
                                })
                            changediskbitmap[expandersasaddress]['disks'][phyid] = utils.Storage({
                                'diskdev':olddisks[phyid]['diskdev'],
                                'locateid':olddisks[phyid]['locateid'],
                                'locate':olddisks[phyid]['locate'],
                                'olddiskstate':olddisks[phyid]['diskstate'],
                                'newdiskstate':4,          #remove disk
                                'oldraidname':olddisks[phyid]['raidname'],
                                'raidname':''
                            }) 
                for phyid,locateid in expanderdiskidmap.iteritems():
                    if phyid in expanderdisks[expandersasaddress]:
                        diskname = expanderdisks[expandersasaddress][phyid]
                        diskstate = diskinfo.get_disk_state(diskname)
                        if olddisks:
                            if phyid in olddisks:
                                if not olddisks[phyid]['diskstate'] == diskstate:
                                    if not expandersasaddress in changediskbitmap:
                                        changediskbitmap[expandersasaddress] = utils.Storage({
                                            'id':expanderid,
                                            'smpdevice':smpdevice,
                                            'disks':utils.Storage({})
                                        })
                                    changediskbitmap[expandersasaddress]['disks'][phyid] = utils.Storage({
                                        'diskdev':diskname,
                                        'locateid':locateid,
                                        'locate':olddisks[phyid]['locate'],
                                        'olddiskstate':olddisks[phyid]['diskstate'],
                                        'newdiskstate':diskstate,
                                        'oldraidname':olddisks[phyid]['raidname'],
                                        'raidname':diskname in diskraids and '/dev/md%s' % diskraids[diskname] or None
                                    })
                            else:
                                if not expandersasaddress in changediskbitmap:
                                    changediskbitmap[expandersasaddress] = utils.Storage({
                                        'id':expanderid,
                                        'smpdevice':smpdevice,
                                        'disks':utils.Storage({})
                                    })
                                changediskbitmap[expandersasaddress]['disks'][phyid] = utils.Storage({
                                    'diskdev':diskname,
                                    'locateid':locateid,
                                    'locate':False,
                                    'olddiskstate':4,
                                    'newdiskstate':diskstate,
                                    'oldraidname':'',
                                    'raidname':diskname in diskraids and '/dev/md%s' % diskraids[diskname] or None
                                })
                        elif olddiskbitmap:
                            if not expandersasaddress in changediskbitmap:
                                changediskbitmap[expandersasaddress] = utils.Storage({
                                    'id':expanderid,
                                    'smpdevice':smpdevice,
                                    'disks':utils.Storage({})
                                })
                            changediskbitmap[expandersasaddress]['disks'][phyid] = utils.Storage({
                                'diskdev':diskname,
                                'locateid':locateid,
                                'locate':False,
                                'olddiskstate':4,
                                'newdiskstate':diskstate,
                                'oldraidname':'',
                                'raidname':diskname in diskraids and '/dev/md%s' % diskraids[diskname] or None
                            })
                        diskbitmap[expandersasaddress]['disks'][phyid] = utils.Storage({
                            'diskdev':diskname,
                            'locateid':locateid,
                            'diskstate':diskstate,
                            'locate':(olddisks and phyid in olddisks) and olddisks[phyid]['locate'] or False,
                            'raidname':diskname in diskraids and '/dev/md%s' % diskraids[diskname] or None
                        })
        except:
            setting.errlogdata(setting.LINE(),'baseboard.py')
            diskbitmap = utils.Storage({})
            changediskbitmap = utils.Storage({})
    else:
        try:
            diskraids = diskinfo.get_disks_raid()
            diskidmap = digiraid.get_diskmap().digidisk.diskidmap
            diskdevs = digiraid.get_disk_info()
            raiddevs = digiraid.get_raid_info()
            status,cabinetcount,diskcounttype = digiraid.get_jobd_status()
            for i in range(cabinetcount):
                diskidpre = get_disk_pre(i,cabinetcount)
                diskbitmap[i] = utils.Storage({
                    'id':i,
                    'smpdevice':'',
                    'disks':utils.Storage({})
                })
                olddisks = None
                if olddiskbitmap and i in olddiskbitmap:
                    olddisks = olddiskbitmap[i]['disks']
                if olddisks:
                    for diskid in olddisks:
                        if diskid not in diskidmap:
                            if not i in changediskbitmap:
                                changediskbitmap[i] = utils.Storage({
                                   'id':i,
                                    'smpdevice':'',
                                    'disks':utils.Storage({})
                                })
                                changediskbitmap[i]['disks'][diskid] = utils.Storage({
                                    'diskdev':olddisks[diskid]['diskdev'],
                                    'locateid':'',
                                    'locate':False,
                                    'olddiskstate':olddisks[diskid]['diskstate'],
                                    'newdiskstate':'',
                                    'oldraidname':olddisks[diskid]['raidname'],
                                    'raidname':''
                                }) 
                for diskid,diskname in diskidmap.iteritems():
                    if diskid.startswith(diskidpre):
                        diskstate = diskdevs[diskid]['state']
                        if olddisks:
                            if diskid in olddisks:
                                if not olddisks[diskid]['diskstate'] == diskstate:
                                    if not i in changediskbitmap:
                                        changediskbitmap[i] = utils.Storage({
                                            'id':i,
                                            'smpdevice':'',
                                            'disks':utils.Storage({})
                                        })
                                    changediskbitmap[i]['disks'][diskid] = utils.Storage({
                                        'diskdev':diskname,
                                        'locateid':'',
                                        'locate':False,
                                        'olddiskstate':olddisks[diskid]['diskstate'],
                                        'newdiskstate':diskstate,
                                        'oldraidname':olddisks[diskid]['raidname'],
                                        'raidname':diskname in diskraids and '/dev/md%s' % diskraids[diskname] or None
                                    })
                            else:
                                if not i in changediskbitmap:
                                    changediskbitmap[i] = utils.Storage({
                                        'id':i,
                                        'smpdevice':'',
                                        'disks':utils.Storage({})
                                    })
                                changediskbitmap[i]['disks'][diskid] = utils.Storage({
                                    'diskdev':diskname,
                                    'locateid':'',
                                    'locate':False,
                                    'olddiskstate':'',
                                    'newdiskstate':diskstate,
                                    'oldraidname':'',
                                    'raidname':diskname in diskraids and '/dev/md%s' % diskraids[diskname] or None
                                })
                        else:
                            if not i in changediskbitmap:
                                changediskbitmap[i] = utils.Storage({
                                    'id':i,
                                    'smpdevice':'',
                                    'disks':utils.Storage({})
                                })
                            changediskbitmap[i]['disks'][diskid] = utils.Storage({
                                'diskdev':diskname,
                                'locateid':'',
                                'locate':False,
                                'olddiskstate':'',
                                'newdiskstate':diskstate,
                                'oldraidname':'',
                                'raidname':diskname in diskraids and '/dev/md%s' % diskraids[diskname] or None
                            })
                        diskbitmap[i]['disks'][diskid] = utils.Storage({
                            'diskdev':diskname,
                            'locateid':'',
                            'diskstate':diskstate,
                            'locate':(olddisks and diskid in olddisks) and olddisks[diskid]['locate'] or False,
                            'raidname':diskname in diskraids and '/dev/md%s' % diskraids[diskname] or None
                        })
        except:
            print >> sys.stderr,traceback.print_exc()
            setting.errlogdata(setting.LINE(),'baseboard.py')
            diskbitmap = utils.Storage({})
            changediskbitmap = utils.Storage({})
    return diskbitmap,changediskbitmap
    
if __name__ == '__main__':
    #olddiskbitmap = utils.Storage({'0x500605b0000272bf': utils.Storage({'smpdevice': 'sg16', 'disks': utils.Storage({'11': utils.Storage({'raidname': None, 'diskdev': 'sdl', 'locateid': '2', 'diskstate': 1}), '10': utils.Storage({'raidname': None, 'diskdev': 'sdk', 'locateid': '3', 'diskstate': 1}), '13': utils.Storage({'raidname': None, 'diskdev': 'sdn', 'locateid': '5', 'diskstate': 1}), '12': utils.Storage({'raidname': None, 'diskdev': 'sdm', 'locateid': '1', 'diskstate': 1}), '15': utils.Storage({'raidname': None, 'diskdev': 'sdp', 'locateid': '13', 'diskstate': 1}), '14': utils.Storage({'raidname': None, 'diskdev': 'sdo', 'locateid': '9', 'diskstate': 1}), '1': utils.Storage({'raidname': None, 'diskdev': 'sdc', 'locateid': '10', 'diskstate': 1}), '0': utils.Storage({'raidname': None, 'diskdev': 'sdb', 'locateid': '14', 'diskstate': 1}), '3': utils.Storage({'raidname': None, 'diskdev': None, 'locateid': '16', 'diskstate': 5}), '2': utils.Storage({'raidname': None, 'diskdev': 'sde', 'locateid': '15', 'diskstate': 1}), '5': utils.Storage({'raidname': None, 'diskdev': 'sdf', 'locateid': '11', 'diskstate': 1}), '4': utils.Storage({'raidname': None, 'diskdev': 'sdq', 'locateid': '12', 'diskstate': 1}), '7': utils.Storage({'raidname': None, 'diskdev': 'sdh', 'locateid': '7', 'diskstate': 1}), '6': utils.Storage({'raidname': None, 'diskdev': 'sdg', 'locateid': '8', 'diskstate': 1}), '9': utils.Storage({'raidname': None, 'diskdev': 'sdj', 'locateid': '4', 'diskstate': 1}), '8': utils.Storage({'raidname': None, 'diskdev': 'sdi', 'locateid': '6', 'diskstate': 1})}), 'id': 0})})
    #diskbitmap,changediskbitmap = get_disk_bitmap(olddiskbitmap)
    #print diskbitmap
    #for expandersasaddress,expanderinfo in diskbitmap.iteritems():
    #    for phyid,diskinfo in expanderinfo.disks.iteritems():
    #        print phyid
    #        print diskinfo
    #        print '################################'
    #print changediskbitmap
    diskbitmap,changediskbitmap = get_disk_bitmap(None)
    print diskbitmap
