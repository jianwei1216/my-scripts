#-*- coding: utf-8 -*-

import os
import sys
import re
import traceback

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
homepath = currpath[:currpath.find('checkdevice')]
if not homepath in sys.path:
    sys.path.append(homepath)
import utils
#---------------------------------
#global
#---------------------------------
#---------------------------------
# system config
#---------------------------------
TARGETPATH = '/sys/kernel/scst_tgt/targets/iscsi/'
TARGETDEVICEPATH = '/sys/kernel/scst_tgt/devices/'
TARGETNAMEPRE = 'iqn.2011'
DEFAULTDIRITEMS = ['mgmt']
VGPRE = 'StorPool'
SANLVPRE = 'SANLun'
#TARGETLUNSPATH = '/sys/kernel/scst_tgt/targets/iscsi/%s/luns/'
#TARGETGROUPSPATH = '/sys/kernel/scst_tgt/targets/iscsi/%s/ini_groups/'
#target name
# iqn.2011-08.ocean.com.hostname:target0
#device name
#diskname
# dev_sdb -> /dev/sdb
# dev_storpool1_sanlun1 -> /dev/StorPool1/SANLun1
# dev_md10 -> /dev/md10

#---------------------------------
# system command
#---------------------------------
HOSTNAME = '/bin/hostname'
CAT = '/bin/cat'
ISCSISCST = '/etc/init.d/iscsi-scst'
SCSTADMIN = '/usr/local/sbin/scstadmin'
#----------------------------------
# get iscsi status
#----------------------------------
def get_iscsi_status():
    iscsistatus = False
    retcode,proc = utils.cust_popen2([ISCSISCST,'status'])
    result = proc.stdout.read()
    if result.find('iSCSI-SCST target is running') >= 0:
        iscsistatus = True
    return iscsistatus
#---------------------------------
# get new target name
#---------------------------------
def get_new_target_name():
    targetid = 0
    targetnames = list_all_target()
    targetids = []
    for targetname in targetnames:
        targetnamematch = re.match('\S+:\S+(\d+)',targetname)
        if targetnamematch:
            targetids.append(int(targetnamematch.group(1)))
    while True:
        if targetid in targetids:
            targetid += 1
            continue
        break
    newtargetname = '%s.%s:target%d' %(TARGETNAMEPRE,get_hostname(),targetid)
    return newtargetname
#---------------------------------
# get new lun num
#---------------------------------
def get_new_lun_num(targetname,groupname=None):
    newlunnum = 0
    lunnums = []
    targetlunspath = os.path.join(TARGETPATH,targetname,'luns')
    if groupname:
        targetlunspath = os.path.join(TARGETPATH,targetname,'ini_groups',groupname,'luns')
    if os.path.exists(targetlunspath):
        diritems = os.listdir(targetlunspath)
        for item in diritems:
            if item not in DEFAULTDIRITEMS:
                try:
                    lunnums.append(int(item))
                except:
                    pass
    while True:
        if newlunnum in lunnums:
            newlunnum += 1
            continue
        break
    return str(newlunnum)
#---------------------------------
# change devicepath to devicename 
#---------------------------------
def changedevicepathtodevicename(devicepath):
    devicename = 'disk'
    if devicepath.find(VGPRE) >= 0:
        devicename = devicepath[1:].replace('/','_').replace(VGPRE,'stor').replace(SANLVPRE,'san')
    else:
        devicename = devicepath[1:].replace('/','_')
    return devicename
#---------------------------------
# get all target devices
#---------------------------------
def get_all_target_devices():
    targetdevices = []
    if os.path.exists(TARGETDEVICEPATH):
        diritems = os.listdir(TARGETDEVICEPATH)
        for item in diritems:
            if re.match('^dev.*',item):
                devicepath = '/%s' % (item.replace('_','/').replace('stor',VGPRE).replace('san',SANLVPRE))
                targetdevices.append(devicepath)
    return targetdevices
#---------------------------------
# get target devices
#---------------------------------
def get_target_devices(targetname):
    targetdevices = []
    targetlunspath = os.path.join(TARGETPATH,targetname,'luns')
    if os.path.exists(targetlunspath):
        diritems = os.listdir(targetlunspath)
        for item in diritems:
            if item not in DEFAULTDIRITEMS:
                targetlunpath = os.path.join(targetlunspath,item)
                targetlundevicepath = os.path.join(targetlunpath,'device')
                if os.path.islink(targetlundevicepath):
                    retcode,proc = utils.cust_popen2([CAT,os.path.join(targetlundevicepath,'filename')])
                    devicepath = proc.stdout.readlines()[0].strip()
                    targetdevices.append(devicepath)
    #groups
    targetgroupspath = os.path.join(TARGETPATH,targetname,'ini_groups')
    if os.path.exists(targetgroupspath):
        diritems = os.listdir(targetgroupspath)
        for item in diritems:                
            if item not in DEFAULTDIRITEMS:
                targetgrouppath = os.path.join(targetgroupspath,item)
                #group device
                targetgrouplunspath = os.path.join(targetgrouppath,'luns')
                if os.path.exists(targetgrouplunspath):
                    diritems = os.listdir(targetgrouplunspath)
                    for item in diritems:
                        if item not in DEFAULTDIRITEMS:
                            targetgrouplunpath = os.path.join(targetgrouplunspath,item)
                            targetgrouplundevicepath = os.path.join(targetgrouplunpath,'device')
                            if os.path.islink(targetgrouplundevicepath):
                                retcode,proc = utils.cust_popen2([CAT,os.path.join(targetgrouplundevicepath,'filename')])
                                devicepath = proc.stdout.readlines()[0].strip()
                                targetdevices.append(devicepath)
    return targetdevices
#---------------------------------
# get target group devices
#---------------------------------
def get_target_group_devices(targetname,targetgroup):
    targetdevices = []
    #groups
    targetgroupspath = os.path.join(TARGETPATH,targetname,'ini_groups')
    if os.path.exists(targetgroupspath):
        diritems = os.listdir(targetgroupspath)
        for item in diritems:                
            if item not in DEFAULTDIRITEMS and item == targetgroup:
                targetgrouppath = os.path.join(targetgroupspath,item)
                #group device
                targetgrouplunspath = os.path.join(targetgrouppath,'luns')
                if os.path.exists(targetgrouplunspath):
                    diritems = os.listdir(targetgrouplunspath)
                    for item in diritems:
                        if item not in DEFAULTDIRITEMS:
                            targetgrouplunpath = os.path.join(targetgrouplunspath,item)
                            targetgrouplundevicepath = os.path.join(targetgrouplunpath,'device')
                            if os.path.islink(targetgrouplundevicepath):
                                retcode,proc = utils.cust_popen2([CAT,os.path.join(targetgrouplundevicepath,'filename')])
                                devicepath = proc.stdout.readlines()[0].strip()
                                targetdevices.append(devicepath)
    return targetdevices
#---------------------------------
# list all target name
#---------------------------------
def list_all_target():
    targetnames = []
    if os.path.exists(TARGETPATH):
        diritems = os.listdir(TARGETPATH)
        for item in diritems:
            if item.startswith(TARGETNAMEPRE):
                targetnames.append(item)
    return targetnames
#---------------------------------
# get hostname
#---------------------------------
def get_hostname():
    hostname = ''
    try:
        retcode,proc = utils.cust_popen2([HOSTNAME])
        hostname = proc.stdout.read().strip()
    except:
        print >> sys.stderr,traceback.print_exc()
    return hostname
#---------------------------------
# get iscsi target
#---------------------------------
def get_iscsi_target():
    targetinfos = []
    targetnames = list_all_target()
    #get target devices and groups
    for targetname in targetnames:
        targetinfo = {
            'target':targetname,
            'devices':[],
            'groups':[]
        }
        targetdevices = []
        targetlunspath = os.path.join(TARGETPATH,targetname,'luns')
        if os.path.exists(targetlunspath):
            diritems = os.listdir(targetlunspath)
            for item in diritems:
                if item not in DEFAULTDIRITEMS:
                    targetlunpath = os.path.join(targetlunspath,item)
                    targetlundevicepath = os.path.join(targetlunpath,'device')
                    if os.path.islink(targetlundevicepath):
                        targetlundeviceresult = os.readlink(targetlundevicepath)
                        devicename = os.path.split(targetlundeviceresult)[1]
                        retcode,proc = utils.cust_popen2([CAT,os.path.join(targetlundevicepath,'filename')])
                        devicepath = proc.stdout.readlines()[0].strip()
                        retcode,proc = utils.cust_popen2([CAT,os.path.join(targetlundevicepath,'size_mb')])
                        devicesize = proc.stdout.read().strip()
                        targetdevice = {
                            'lun':item,
                            'devicename':devicename,
                            'devicepath':devicepath,
                            'devicesize':devicesize
                        }
                        targetdevices.append(targetdevice)
        targetinfo['devices'] = targetdevices
        #groups
        targetgroups = []
        targetgroupspath = os.path.join(TARGETPATH,targetname,'ini_groups')
        if os.path.exists(targetgroupspath):
            diritems = os.listdir(targetgroupspath)
            for item in diritems:                
                if item not in DEFAULTDIRITEMS:
                    targetgroup = {
                        'group':item,
                        'devices':[],
                        'initiators':[]
                    }
                    targetgrouppath = os.path.join(targetgroupspath,item)
                    #group device
                    targetgrouplunspath = os.path.join(targetgrouppath,'luns')
                    targetgroupdevices = []
                    if os.path.exists(targetgrouplunspath):
                        diritems = os.listdir(targetgrouplunspath)
                        for item in diritems:
                            if item not in DEFAULTDIRITEMS:
                                targetgrouplunpath = os.path.join(targetgrouplunspath,item)
                                targetgrouplundevicepath = os.path.join(targetgrouplunpath,'device')
                                if os.path.islink(targetgrouplundevicepath):
                                    targetgrouplundeviceresult = os.readlink(targetgrouplundevicepath)
                                    devicename = os.path.split(targetgrouplundeviceresult)[1]
                                    retcode,proc = utils.cust_popen2([CAT,os.path.join(targetgrouplundevicepath,'filename')])
                                    devicepath = proc.stdout.readlines()[0].strip()
                                    retcode,proc = utils.cust_popen2([CAT,os.path.join(targetgrouplundevicepath,'size_mb')])
                                    devicesize = proc.stdout.read().strip()
                                    targetgroupdevice = {
                                        'lun':item,
                                        'devicename':devicename,
                                        'devicepath':devicepath,
                                        'devicesize':devicesize
                                    }
                                    targetgroupdevices.append(targetgroupdevice)
                    targetgroup['devices'] = targetgroupdevices
                    #group initiator
                    targetgroupinitiatorspath = os.path.join(targetgrouppath,'initiators')
                    targetgroupinitiators = []
                    if os.path.exists(targetgroupinitiatorspath):
                        diritems = os.listdir(targetgroupinitiatorspath)
                        for item in diritems:
                            if item not in DEFAULTDIRITEMS:
                                targetgroupinitiators.append(item)
                    targetgroup['initiators'] = targetgroupinitiators
                    targetgroups.append(targetgroup)
        targetinfo['groups'] = targetgroups
        targetinfos.append(targetinfo)
    return targetinfos
#---------------------------------
# get iscsi target info
#---------------------------------
def get_target_info(targetname):
    targetinfo = {
        'target':targetname,
        'devices':[],
        'groups':[]
    }
    #get target devices and groups
    targetdevices = []
    targetlunspath = os.path.join(TARGETPATH,targetname,'luns')
    if os.path.exists(targetlunspath):
        diritems = os.listdir(targetlunspath)
        for item in diritems:
            if item not in DEFAULTDIRITEMS:
                targetlunpath = os.path.join(targetlunspath,item)
                targetlundevicepath = os.path.join(targetlunpath,'device')
                if os.path.islink(targetlundevicepath):
                    targetlundeviceresult = os.readlink(targetlundevicepath)
                    devicename = os.path.split(targetlundeviceresult)[1]
                    retcode,proc = utils.cust_popen2([CAT,os.path.join(targetlundevicepath,'filename')])
                    devicepath = proc.stdout.readlines()[0].strip()
                    retcode,proc = utils.cust_popen2([CAT,os.path.join(targetlundevicepath,'size_mb')])
                    devicesize = proc.stdout.read().strip()
                    targetdevice = {
                        'lun':item,
                        'devicename':devicename,
                        'devicepath':devicepath,
                        'devicesize':devicesize
                    }
                    targetdevices.append(targetdevice)
    targetinfo['devices'] = targetdevices
    #groups
    targetgroups = []
    targetgroupspath = os.path.join(TARGETPATH,targetname,'ini_groups')
    if os.path.exists(targetgroupspath):
        diritems = os.listdir(targetgroupspath)
        for item in diritems:                
            if item not in DEFAULTDIRITEMS:
                targetgroup = {
                    'group':item,
                    'devices':[],
                    'initiators':[]
                }
                targetgrouppath = os.path.join(targetgroupspath,item)
                #group device
                targetgrouplunspath = os.path.join(targetgrouppath,'luns')
                targetgroupdevices = []
                if os.path.exists(targetgrouplunspath):
                    diritems = os.listdir(targetgrouplunspath)
                    for item in diritems:
                        if item not in DEFAULTDIRITEMS:
                            targetgrouplunpath = os.path.join(targetgrouplunspath,item)
                            targetgrouplundevicepath = os.path.join(targetgrouplunpath,'device')
                            if os.path.islink(targetgrouplundevicepath):
                                targetgrouplundeviceresult = os.readlink(targetgrouplundevicepath)
                                devicename = os.path.split(targetgrouplundeviceresult)[1]
                                retcode,proc = utils.cust_popen2([CAT,os.path.join(targetgrouplundevicepath,'filename')])
                                devicepath = proc.stdout.readlines()[0].strip()
                                retcode,proc = utils.cust_popen2([CAT,os.path.join(targetgrouplundevicepath,'size_mb')])
                                devicesize = proc.stdout.read().strip()
                                targetgroupdevice = {
                                    'lun':item,
                                    'devicename':devicename,
                                    'devicepath':devicepath,
                                    'devicesize':devicesize
                                }
                                targetgroupdevices.append(targetgroupdevice)
                targetgroup['devices'] = targetgroupdevices
                #group initiator
                targetgroupinitiatorspath = os.path.join(targetgrouppath,'initiators')
                targetgroupinitiators = []
                if os.path.exists(targetgroupinitiatorspath):
                    diritems = os.listdir(targetgroupinitiatorspath)
                    for item in diritems:
                        if item not in DEFAULTDIRITEMS:
                            targetgroupinitiators.append(item)
                targetgroup['initiators'] = targetgroupinitiators
                targetgroups.append(targetgroup)
    targetinfo['groups'] = targetgroups
    return targetinfo  
#------------------------------------------
# get target chap info
#------------------------------------------
def get_target_chap_info(targetname):
    targetchapinfo = {}
    targetincominguserpath = os.path.join(TARGETPATH,targetname,'IncomingUser')
    targetoutgoinguserpath = os.path.join(TARGETPATH,targetname,'OutgoingUser')
    if os.path.exists(targetincominguserpath):
        retcode,proc = utils.cust_popen2([CAT,targetincominguserpath])
        username,password = proc.stdout.readlines()[0].strip().split()
        if username and password:
            targetchapinfo['incominguser'] = {
                'username':username,
                'password':password
            }
    if os.path.exists(targetoutgoinguserpath):
        retcode,proc = utils.cust_popen2([CAT,targetoutgoinguserpath])
        username,password = proc.stdout.readlines()[0].strip().split()
        if username and password:
            targetchapinfo['outgoinguser'] = {
                'username':username,
                'password':password
            }
    return targetchapinfo
if __name__ == '__main__':
    targetinfos = get_iscsi_target()
    print targetinfos
