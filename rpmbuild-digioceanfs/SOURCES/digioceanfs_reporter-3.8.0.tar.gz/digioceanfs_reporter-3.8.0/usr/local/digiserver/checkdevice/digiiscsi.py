#-*- coding: utf-8 -*-

import os
import sys
import re
import traceback

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
homepath = currpath[:currpath.find('checkdevice')]
if not homepath in sys.path:
    sys.path.append(homepath)
import utils
#---------------------------------
#global
#---------------------------------
#---------------------------------
# system config
#---------------------------------
ISCSITARGET = '/proc/scsi_target/rbc_backend'
#ITARGET = '/usr/local/admin/iscsi/source/itarget'      ###########
ITARGET = '/usr/local/digitools/admin/source/itarget'
ISCSITARGETINFO = '/proc/scsi_target/iscsi_target/0'
#ISCSISOURCE = '/usr/local/admin/iscsi/source/'     ################
ISCSISOURCE = '/usr/local/digitools/admin/source/'
ISCSICONF = '/etc/admin/iscsi/conf'
#---------------------------------
# system command
#---------------------------------
NETSTAT = '/bin/netstat'
#-----------------------------------------
# get target num
#-----------------------------------------
def get_target_num():
    targetnum = 0
    try:
        result = []
        if os.path.exists(ITARGET):
            f,fstat = utils.cust_fopen(ITARGET,'r')
            result = f.readlines()
            utils.cust_fclose(f,fstat)
        for line in result:
            m = re.match("^/sbin/insmod.*targets=(\d+)",line)
            if m:
                targetnum = int(m.group(1))
                break
    except:
        print >> sys.stderr,traceback.print_exc()
    return targetnum
#-----------------------------------------
# get all iscsi target
#-----------------------------------------
def get_iscsi_target():
    """
    return {0:'/dev/nasvg/nas1',1:'/dev/nasvg/nas2'}
    """
    targetdev = {}
    result = []
    if os.path.exists(ITARGET):
        f = open(ITARGET,'r')
        result = f.readlines()
        f.close()
    rlen = len(result)
    i = 0
    while i < rlen:
        m = re.match("devname=(.*)",result[i])
        if m:
            dev = m.group(1)
            i += 1
            while i < rlen:
                sm = re.match(".*\s+>/proc/scsi_target/rbc_backend/(\d+)",result[i])
                if sm:
                    sn = int(sm.group(1))
                    targetdev[sn] = dev
                    break
                i += 1
        i += 1
    return targetdev
#-----------------------------------------
# get target info
#-----------------------------------------
def get_target_info(targetsn):
    targetinfo = []
    target = os.path.join(ISCSITARGET,str(targetsn))
    if os.path.exists(target):
        devname = 'null'
        capacity = 0
        capac = '0G'
        f,fstat = utils.cust_fopen(target,'r')
        lines = f.readlines()
        utils.cust_fclose(f,fstat)
        for line in lines:
            m = re.match("LUN 0 device.*(/dev/.*)",line)
            if m:
                devname = m.group(1)
            m = re.match("LUN 0 Capacity 0*(\w+)",line)
            if m:
                capacitystr = m.group(1)
                moapacity = 0
                alen = len(capacitystr)
                l10 = alen - 1
                while l10 >= 0:
                    if capacitystr[l10] == 'a':
                        capacity = capacity + 10 * 16 ** (alen - l10 - 1)
                    elif capacitystr[l10] == 'b':
                        capacity = capacity + 11 * 16 ** (alen - l10 - 1)
                    elif capacitystr[l10] == 'c':
                        capacity = capacity + 12 * 16 ** (alen - l10 - 1)
                    elif capacitystr[l10] == 'd':
                        capacity = capacity + 13 * 16 ** (alen - l10 - 1)
                    elif capacitystr[l10] == 'e':
                        capacity = capacity + 14 * 16 ** (alen - l10 - 1)
                    elif capacitystr[l10] == 'f':
                        capacity = capacity + 15 * 16 ** (alen - l10 - 1)
                    else:
                        capacity = capacity + int(capacitystr[l10]) * 16 ** (alen - l10 - 1)
                    l10 -= 1
            capac = capacity / 2
            m = re.match(".*BLOCKSIZE\s(\w+)",line)
            if m:
                blocksize = int(m.group(1)) / 512
            #TODO:default blocksize
            capac = '%sG' % str(round(float(capac * blocksize) / 1024 / 1024, 2))
        targetinfo = [str(targetsn),devname,capac]
    return targetinfo
#-----------------------------------------
# get all iscsi target running info
#-----------------------------------------
def get_iscsi_target_running_info():
    """
    get all target information
    """
    targetinfos = []
    iscsinum = 0
    if os.path.exists(ISCSITARGET):
        iscsinum = len(os.listdir(ISCSITARGET))
    for i in range(iscsinum):
        devname = 'null'
        capacity = 0
        filename = os.path.join(ISCSITARGET,str(i))
        if os.path.exists(filename):
            f,fstat = utils.cust_fopen(filename,'r')
            lines = f.readlines()
            utils.cust_fclose(f,fstat)
            for line in lines:
                m = re.match("LUN 0 device.*(/dev/.*)",line)
                if m:
                    devname = m.group(1)
                m = re.match("LUN 0 Capacity 0*(\w+)",line)
                if m:
                    capacitystr = m.group(1)
                    moapacity = 0
                    alen = len(capacitystr)
                    l10 = alen - 1
                    while l10 >= 0:
                        if capacitystr[l10] == 'a':
                            capacity = capacity + 10 * 16 ** (alen - l10 - 1)
                        elif capacitystr[l10] == 'b':
                            capacity = capacity + 11 * 16 ** (alen - l10 - 1)
                        elif capacitystr[l10] == 'c':
                            capacity = capacity + 12 * 16 ** (alen - l10 - 1)
                        elif capacitystr[l10] == 'd':
                            capacity = capacity + 13 * 16 ** (alen - l10 - 1)
                        elif capacitystr[l10] == 'e':
                            capacity = capacity + 14 * 16 ** (alen - l10 - 1)
                        elif capacitystr[l10] == 'f':
                            capacity = capacity + 15 * 16 ** (alen - l10 - 1)
                        else:
                            capacity = capacity + int(capacitystr[l10]) * 16 ** (alen - l10 - 1)
                        l10 -= 1
                capac = capacity / 2
                m = re.match(".*BLOCKSIZE\s(\w+)",line)
                if m:
                    blocksize = int(m.group(1)) / 512
        #TODO:default blocksize
        capac = '%sG' % str(round(float(capac * blocksize) / 1024 / 1024, 2))
        targetinfos.append([devname,capac,str(i)])
    return targetinfos
#-----------------------------------------
# get iscsi link info
#-----------------------------------------
def get_iscsi_link_info():
    iscsilinkinfos = {}
    if os.path.exists(ISCSITARGETINFO):
        retcode,proc = utils.cust_popen2(['cat',ISCSITARGETINFO])
        result = proc.stdout.readlines()
        reslen = len(result)
        i = 0
        targetmatch = '.*session\s+for\s+target\s+(\d)\s+.*'
        initmatch = '.*Initiator\s+Address\s*(\S+)\s*'
        localmatch = '.*Local\s+Address\s*(\S+)\s*'
        targetid = ''
        initiatoraddr = ''
        localaddr = ''
        while i < reslen:
            tm = re.match(targetmatch,result[i])
            if tm:
                targetid = int(tm.group(1))
                while True:
                    i += 1
                    if i < reslen:
                        im = re.match(initmatch,result[i])
                        lm = re.match(localmatch,result[i])
                        tm = re.match(targetmatch,result[i])
                        if im:
                            initiatoraddr = im.group(1)
                        elif lm:
                            localaddr = lm.group(1)
                        elif tm:
                            if targetid in iscsilinkinfos:
                                iscsilinkinfos[targetid].append([localaddr,initiatoraddr])
                            else:
                                iscsilinkinfos[targetid] = [[localaddr,initiatoraddr]]
                            i -= 1
                            targetid = ''
                            initiatoraddr = ''
                            localaddr = ''
                            break
                    else:
                        break
            i += 1
        if (targetid != '' and targetid >= 0) and initiatoraddr and localaddr:
            if targetid in iscsilinkinfos:
                iscsilinkinfos[targetid].append([localaddr,initiatoraddr])
            else:
                iscsilinkinfos[targetid] = [[localaddr,initiatoraddr]]
    return iscsilinkinfos
#----------------------------------
# get iscsi status
#----------------------------------
def get_iscsi_status():
    iscsistatus = False
    if os.path.exists(ISCSITARGET):
        iscsistatus = True
    return iscsistatus
#----------------------------------
# get iscsi net status
#----------------------------------
def get_iscsi_net_status():
    iscsinetstatus = True
    retcode,proc = utils.cust_popen2([NETSTAT,'-antp'])
    result = proc.stdout.readlines()
    for line in result:
        if line.find('3260') >= 0:
            checklist = line.split()
            if 'TIME_WAIT' in checklist or 'FIN_WAIT1' in checklist:
                iscsinetstatus = False
                break
    return iscsinetstatus
#----------------------------------
# get connect target
#----------------------------------
def get_echo_on():
    devices = []
    result = []
    try:
        f,fstat = utils.cust_fopen(ISCSITARGETINFO,'r')
        result = f.readlines()
        utils.cust_fclose(f,fstat)
        for line in result:
            m = re.match("\s+TargetName\s+.*:(\d+)",line)
            if m:
                devices.append(m.group(1))
    except:
        devices = None
    return devices
#-----------------------------------
# get thread
#-----------------------------------
def get_thread():
    thread = 0
    try:
        f,fstat = utils.cust_fopen(ISCSICONF,'r')
        result = f.readlines()
        utils.cust_fclose(f,fstat)
        for line in result:
            m = re.match("thread=(\d+)",line)
            if m:
                thread = int(m.group(1))
                break
    except:
        print >> sys.stderr,traceback.print_exc()
    return thread
#-------------------------------------
# get max connection
#-------------------------------------
def get_max_con():
    maxcon = 0
    try:
        f,fstat = utils.cust_fopen(ITARGET,'r')
        result = f.readlines()
        utils.cust_fclose(f,fstat)
        for line in result:
            m = re.match('./iscsi_manage target set MaxConnections=(\d+)',line)
            if m:
                maxcon = int(m.group(1))
                break
    except:
        print >> sys.stderr,traceback.print_exc()
    return maxcon
#-------------------------------------
# get authir password
#   if user need the chap,get the author password
#-------------------------------------
def get_author_pwd():
    authorpwd = ''
    try:
        f,fstat = utils.cust_fopen(ITARGET,'r')
        result = f.readlines()
        utils.cust_fclose(f,fstat)
        for line in result:
            m = re.match('^./iscsi_manage target force b cl=256 lx="(.*)".*',line)
            if m:
                authorpwd = m.group(1)
                break
    except:
        print >> sys.stderr,traceback.print_exc()
    return authorpwd
#--------------------------------------
# get author user
#   if user need the chap,get the author user
#--------------------------------------
def get_author_user():
    username = ''
    try:
        f,fstat = utils.cust_fopen(ITARGET,'r')
        result = f.readlines()
        utils.cust_fclose(f,fstat)
        for line in result:
            m = re.match('^./iscsi_manage target force b cl=256 lx="(.*)" ln=(.*)\s+host=.*',line)
            if m:
                username = m.group(2)
                break
    except:
        print >> sys.stderr,traceback.print_exc()
    return username
#----------------------------------------
# get iscsi type
#----------------------------------------
def get_target_type():
    targettype = 1
    try:
        f,fstat = utils.cust_fopen(ITARGET,'r')
        line = f.readline()
        while line:
            if line.find('offset') >= 0:
                targettype = 2 #yNo
                break
            elif line.find('shift') >= 0:
                targettype = 0 #no
                break
            elif line.find('targets') >= 0:
                targettype = 1 #yes
                break
            line = f.readline()
        utils.cust_fclose(f,fstat)
    except:
        utils.cust_fclose(f,fstat)
        print >> sys.stderr,traceback.print_exc()
    return targettype
