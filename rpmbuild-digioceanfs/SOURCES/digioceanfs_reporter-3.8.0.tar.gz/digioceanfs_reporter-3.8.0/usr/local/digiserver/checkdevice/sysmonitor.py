#!/usr/bin/python
#-*- coding: UTF-8 -*-

import os
import sys
import re
import time
import copy
import pickle

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
homepath = currpath[:currpath.find('checkdevice')]
if not homepath in sys.path:
    sys.path.append(homepath)
#from zbh import digimail
from daemon import Daemon
import utils
import digiraid4 as digiraid
from iniFile import IniFile
#---------------------------
#   paramter to be config
#---------------------------
logtimeinterval = 0 #10 second
mailtimeinterval = 0 #300 second
LOGMONITORDISK = MAILMONITORDISK = False
LOGMONITORRAID = MAILMONITORRAID = True
LOGMONITORLINK = MAILMONITORLINK = False
#---------------------------
# globals
#---------------------------
#command
miitool = '/sbin/mii-tool'
ethtool = '/usr/sbin/ethtool'
if utils.check_if_debian6():
    ethtool = '/sbin/ethtool'
monitorstopflag = '/tmp/digitools/monitorstop'
#sysfile
netdevicepath = '/sys/class/net/'
#deamon
pidfile = os.path.join(currpath,'tmp/digimonitor.pid')
stdin = '/dev/null'
stdout = os.path.join(currpath,'log/app.log')
stderr = os.path.join(currpath,'log/err.log')
#setting
digioceanlogfile = os.path.join(currpath,'log','monitor.log')
monitorsettingfile = os.path.join(currpath,'conf','monitor.conf')
#other
logstarttime = mailstarttime = time.time()
digistow = digiraid.get_diskmap()
cdisknamemap = digistow.digidisk.disknamemap
cdiskset = digistow.digidisk.disknameset
monitorflag = False

diskchangeeventlist = []
ifaceeventlist = []
raideventlist = []
maileventlist = []
#---------------------------
#---------------------------
# 
#---------------------------
def get_ifaces():
    retcode,proc = utils.cust_popen2(['ls',netdevicepath])
    result = ''.join(proc.stdout.readlines())
    me_eth = '(eth\d+)'
    me_bond = '(bond(\d+))'
    eths = re.findall(me_eth, result)
    return eths
#---------------------------
# 
#---------------------------   
def get_settings():
    global logtimeinterval,mailtimeinterval
    global LOGMONITORDISK,LOGMONITORRAID,LOGMONITORLINK,MAILMONITORDISK,MAILMONITORRAID,MAILMONITORLINK
    if os.path.isfile(monitorsettingfile):
        config = IniFile()
        config.read(monitorsettingfile)
        #log
        if config.has_section('logmonitor'):
            if config.has_option('logmonitor','loginterval'):
                logtimeinterval = config.getint('logmonitor','loginterval')
            if logtimeinterval == 0:
                LOGMONITORDISK = LOGMONITORRAID = LOGMONITORLINK = False
            else:
                if config.has_option('logmonitor','monitordisk'):
                    LOGMONITORDISK = config.getboolean('logmonitor','monitordisk')
                if config.has_option('logmonitor','monitorraid'):
                    LOGMONITORRAID = config.getboolean('logmonitor','monitorraid')
                if config.has_option('logmonitor','monitorlink'):
                    LOGMONITORLINK = config.getboolean('logmonitor','monitorlink')
        #mail
        if config.has_section('mailmonitor'):
            if config.has_option('mailmonitor','mailinterval'):
                mailtimeinterval = config.getint('mailmonitor','mailinterval')
            if mailtimeinterval <= 0:
                MAILMONITORDISK = MAILMONITORRAID = MAILMONITORLINK = False
            else:
                if config.has_option('mailmonitor','monitordisk'):
                    MAILMONITORDISK = config.getboolean('mailmonitor','monitordisk')
                if config.has_option('mailmonitor','monitorraid'):
                    MAILMONITORRAID = config.getboolean('mailmonitor','monitorraid')
                if config.has_option('mailmonitor','monitorlink'):
                    MAILMONITORLINK = config.getboolean('mailmonitor','monitorlink')
#---------------------------
# 
#---------------------------    
class SystemMonitor(Daemon):
    def run(self):
        global logtimeinterval,mailtimeinterval,LOGMONITORDISK,LOGMONITORRAID,LOGMONITORLINK,MAILMONITORDISK,MAILMONITORRAID,MAILMONITORLINK,monitorflag
        global logstarttime,mailstarttime,cdiskset,cdisknamemap,diskchangeeventlist,ifaceeventlist,raideventlist,maileventlist
        try:
            while True:
                time.sleep(30)
                if not monitorflag:
                    monitorflag = True
                    currtime = time.time()
                    get_settings()
                    if LOGMONITORDISK or MAILMONITORDISK or LOGMONITORRAID or MAILMONITORRAID or LOGMONITORLINK or MAILMONITORLINK:
                        #monitor disk
                        if LOGMONITORDISK or MAILMONITORDISK:
                            if currtime - logstarttime >= logtimeinterval or currtime - mailstarttime >= mailtimeinterval:
                                digistow = digiraid.get_diskmap()
                                ndisknamemap = digistow.digidisk.disknamemap
                                ndiskset = digistow.digidisk.disknameset
                                if ndiskset != cdiskset:
                                    ldiskset = cdiskset - ndiskset
                                    adiskset = ndiskset - cdiskset
                                    for disk in ldiskset:
                                        diskchangeeventlist.append([time.strftime('%Y-%m-%d %X'),'the disk number %s (%s) is droped' % (cdisknamemap[disk],disk)])
                                    for disk in adiskset:
                                        diskchangeeventlist.append([time.strftime('%Y-%m-%d %X'),'the disk number %s (%s) is added' % (ndisknamemap[disk],disk)])
                                diskstate = digiraid.get_all_disk_state()
                                diskidmap = digiraid.get_diskmap().digidisk.diskidmap
                                for diskid,diskstatus in diskstate.iteritems():
                                    if diskstatus == -2:
                                        diskdev = '/dev/%s' % diskidmap[diskid]
                                        diskchangeeventlist.append([time.strftime('%Y-%m-%d %X'),'the disk number %s (%s) is broken' % (diskid,diskdev)])
                                if diskchangeeventlist:
                                    if LOGMONITORDISK and currtime - logstarttime >= logtimeinterval:
                                        f,fstat = utils.cust_fopen(digioceanlogfile,'a+')
                                        for diskevent in diskchangeeventlist:
                                            f.write('%s %s\n' % (diskevent[0],diskevent[1]))
                                        utils.cust_fclose(f,fstat)
                                    if MAILMONITORDISK and currtime - mailstarttime >= mailtimeinterval:
                                        for diskevent in diskchangeeventlist:
                                            maileventlist.append('%s %s' % (diskevent[0],diskevent[1]))
                                cdiskset = ndiskset
                                cdisknamemap = ndisknamemap
                                diskchangeeventlist = []
                        #monitor raid
                        if LOGMONITORRAID or MAILMONITORRAID:
                            if currtime - logstarttime >= logtimeinterval or currtime - mailstarttime >= mailtimeinterval:
                                raiddevs = digiraid.get_raid_info()
                                for raidid,raidinfo in raiddevs.iteritems():
                                    if raidinfo['state'] in ['error','alert']:
                                        raideventlist.append([time.strftime('%Y-%m-%d %X'),'the RAID %s (%s) is %s' % (raidinfo['showname'],raidinfo['raiddev'],raidinfo['state'])])
                                if raideventlist:
                                    if LOGMONITORRAID and currtime - logstarttime >= logtimeinterval:
                                        f,fstat = utils.cust_fopen(digioceanlogfile,'a+')
                                        for raidevent in raideventlist:
                                            f.write('%s %s\n' % (raidevent[0],raidevent[1]))
                                        utils.cust_fclose(f,fstat)
                                    if MAILMONITORRAID and currtime - mailstarttime >= mailtimeinterval:
                                        for raidevent in raideventlist:
                                            maileventlist.append('%s %s' % (raidevent[0],raidevent[1]))
                                raideventlist = []
                        #monitor link
                        if LOGMONITORLINK or MAILMONITORLINK:
                            if currtime - logstarttime >= logtimeinterval or currtime - mailstarttime >= mailtimeinterval:
                                ifacelist = get_ifaces()
                                for iface in ifacelist:
                                    ifacelink = False
                                    retcode,proc = utils.cust_popen("%s %s | grep 'Link detected' | awk -F\: '{print $2}'" % (ethtool,iface))
                                    result = proc.stdout.read().strip()
                                    if retcode == 0 and result and result == 'yes':
                                        ifacelink = True
                                    if not ifacelink:
                                        ifaceeventlist.append([time.strftime('%Y-%m-%d %X'),'%s NIC Link is Down' % iface])
                                if ifaceeventlist:
                                    if LOGMONITORLINK and currtime - logstarttime >= logtimeinterval:
                                        f,fstat = utils.cust_fopen(digioceanlogfile,'a+')
                                        for ifaceevent in ifaceeventlist:
                                            f.write('%s %s\n' % (ifaceevent[0],ifaceevent[1]))
                                        utils.cust_fclose(f,fstat)
                                    if MAILMONITORLINK and currtime - mailstarttime >= mailtimeinterval:
                                        for ifaceevent in ifaceeventlist:
                                            maileventlist.append('%s %s' % (ifaceevent[0],ifaceevent[1]))
                            ifaceeventlist = []
                        if currtime - mailstarttime >= mailtimeinterval:
                            if maileventlist:
                                mathineip = ''
                                retcode,proc = utils.cust_popen("ifconfig  | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk '{ print $1}'")
                                alertmathineips = proc.stdout.readlines()
                                if alertmathineips:
                                    mathineip = alertmathineips[0]
                                maileventlist.insert(0,'Mathine: %s' % mathineip)
                                msg = '<br />'.join(maileventlist)
                                print msg
                                #retcode = digimail.send_alert_mail(msg)
                                maileventlist = []
                        if currtime - logstarttime >= logtimeinterval:
                            logstarttime = currtime
                        if currtime - mailstarttime >= mailtimeinterval:
                            mailstarttime = currtime
                    else:
                        print >> sys.stderr,'no item to be monitor!'
                        sys.exit(2)
                    monitorflag = False
        except Exception,e:
            print e
            sys.exit(2)
def main():
    isstop = os.path.isfile(monitorstopflag)
    daemon = SystemMonitor(pidfile,currpath,stdin,stdout,stderr)
    if len(sys.argv) == 2:
        if 'start' == sys.argv[1] and not isstop:
            daemon.start()
        elif 'stop' == sys.argv[1]:
            daemon.stop()
        elif 'restart' == sys.argv[1] and not isstop:
            daemon.restart()
        else:
            print 'Unknown command'
            sys.exit(2)
        sys.exit(0)
    else:
        print "Usage: python %s start|stop|restart" % sys.argv[0]
        print "Example: python %s start" % sys.argv[0]
        sys.exit(2)
        
if __name__ == '__main__':
    main()
