#-*- coding: utf-8 -*-

import os
import sys
import re
import copy
import traceback
import time
import pickle

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
homepath = currpath[:currpath.find('checkdevice')]
if not homepath in sys.path:
    sys.path.append(homepath)

basepath = '/etc/storage/'
if not basepath in sys.path:
    sys.path.append(basepath)

import utils
import digiiscsi
import digisan
from diskbitmap import baseboard
sas_sn = None
sata_sn = None
#-----------------------
#   globals
#-----------------------
targetinfo = None
stow = utils.Storage
RAIDSTARTID = 9
#DIGISTOWFILE = os.path.join(homepath,'digistow')
DIGISTOWFILE = '/usr/local/digitools/digistow'
DIGIRAIDSTOWFILE = '/usr/local/digitools/digiraidstow'
digistow = stow({})
digiraidstow = stow({})
sysdisk = None
DISKCACHEFILE = '/DISKMAPCACHE'
SYSDISKCACHE = '/tmp/digitools/sysdisk'
#-----------------------
#   system command
#-----------------------
MDADM = '/sbin/mdadm'
PVSCAN = '/sbin/pvscan'
#BLOCKDEV = '/sbin/blockdev'
#HDPARM = '/sbin/hdparm'
#LVDISPLAY = '/sbin/lvdisplay'
RM = '/bin/rm'
CAT = '/bin/cat'
DMIDECODE = '/usr/sbin/dmidecode'
#-----------------------
#   system config file path
#-----------------------
MDSTAT = '/proc/mdstat'
SCSIDEVICE = '/sys/class/scsi_device/'
SASDEVICE = '/sys/class/sas_device/'
DISKDEVICE = '/sys/block/%s/device'
DISKDEV = '/sys/class/scsi_device/%s/device/block'
#JOBD = '/usr/local/admin/softraid/jobd' ################
JOBD = '/usr/local/digitools/libcommon/raidlib/jobd'
PARTITIONS = '/proc/partitions'
DISKSERIAL = '/dev/disk/by-id/'
SYSBLOCK = '/sys/block/'
#-----------------------
#   variables
#-----------------------
RAIDSTATE = {
    0:'ok',
    1:'build',
    2:'recovery',
    3:'alert',
    4:'error',
    5:'reshape'
}
RAIDSHOWPRE = 'RAID'
EXPIRAINTERVAL = 60
EXPIRETIMEOUT = 180
#-----------------------
#   Exceptions
#-----------------------
class ExecCommandError(Exception):
    pass
    
class RaidError(Exception):
    pass
#-----------------------
#   functions
#-----------------------
cust_popen2 = utils.cust_popen2
cust_popen = utils.cust_popen

def check_sata_or_sas():
    disktype = 'sas'
    if not os.path.exists(SASDEVICE) or len(os.listdir(SASDEVICE)) == 0:
        disktype = 'sata'
    else:
        disktype = 'sas'
    return disktype

def importdata ():
    if not baseboard.check_device():
        aa = check_sata_or_sas()
        if aa == 'sas':
            import sas_sn
        else:
            import sata_sn
importdata()
#-----------------------
# init globals
#-----------------------
def init_global_diskmap():
    if baseboard.check_device():
        init_diskmap2()
    else:
        init_diskmap()
#---------------------------------
# get JOBD status,count
#---------------------------------
'''
def get_jobd_status():
    status = 0 #satadisk
    count = None
    if os.path.exists(JOBD):
        info,infostat = utils.cust_fopen(JOBD,'r')
        try:
            count = int(info.read().strip())
        except:
            count = 0
        utils.cust_fclose(info,infostat)
        if count == 0:
            status = 1 #16 disk
        elif count == 24:
            status = 3 #24 disk
        elif count == 8:
            status = 0 #8 disk
        elif count < 0:
            count = 0 - count
            status = 4 # (0 - count) * 4 disk
        else:
            status = 2 #dusk
    return status,count
'''
#-----------------------------------------
# new get JOBD status
#-----------------------------------------
def get_jobd_status():
    status = 0 #satadisk
    count = None
    cabinetcount = 1
    diskcounttype = 8
    if os.path.exists(JOBD):
        info,infostat = utils.cust_fopen(JOBD,'r')
        try:
            count = int(info.read().strip())
        except:
            count = 0
        utils.cust_fclose(info,infostat)
        if count == 0:
            diskcounttype = 16
            status = 1 #16 disk
        elif count == 24:
            diskcounttype = 24
            status = 3 #24 disk
        elif count == 8:
            status = 0 #8 disk
        elif count < 0:
            count = 0 - count
            diskcounttype = 4 * count
            status = 4 # (0 - count) * 4 disk
        elif count == 48:
            cabinetcount = 2
            diskcounttype = 24
            status = 5 #48 disk
        else:
            cabinetcount = count
            diskcounttype = 16
            status = 2 #dusk
    return status,cabinetcount,diskcounttype
#-----------------------------------------
# conver disk dev to disk slot
# dev   : /dev/sdq
# return: 6:0:0:0
#-----------------------------------------
def get_disk_slot_from_dev(diskdev):
    diskslot = None
    diskname = diskdev.replace('/dev/','')
    diskslotmatch = ".*\/(\d+:\d+:\d+:\d+)"
    if os.path.exists(DISKDEVICE % diskname):
        if os.path.islink(DISKDEVICE % diskname):
            result = os.readlink(DISKDEVICE % diskname)
            m = re.match(diskslotmatch,result)
            if m:
                diskslot = m.group(1)
    return diskslot

#-----------------------------------------
# split diskslot
# slot   : 6:0:0:0
# return : 2:0:0:0
#-----------------------------------------
def analysisslot1(diskslot):
    slot = diskslot
    if re.match('\d+:\d+:\d+:\d+',diskslot):
        tmp = [int(item) for item in diskslot.split(':')]
        maxid = max(tmp)
        maxpos = tmp.index(maxid)
        if maxid >= 6:
            maxid = maxid - 6
        else:
            maxid = maxid + 4
        tmp[maxpos] = maxid
        slot = ':'.join([str(item) for item in tmp])
    return slot
    
def analysisslot2(diskslot):
    slot = diskslot
    if re.match('\d+:\d+:\d+:\d+',diskslot):
        tmp = [int(item) for item in diskslot.split(':')]
        maxid = max(tmp)
        maxpos = tmp.index(maxid)
        if maxid >= 5:
            maxid = maxid - 4
        else:
            maxid = maxid + 5
        tmp[maxpos] = maxid
        slot = ':'.join([str(item) for item in tmp])
    return slot
    
def analysissysslot(diskslot):
    maxid = 0
    if re.match('\d+:\d+:\d+:\d+',diskslot):
        tmp = [int(item) for item in diskslot.split(':')]
        maxid = max(tmp)
    return maxid

#-----------------------------------------
# conver slot to disk id
# slot   : 6:0:0:0
# return: 13
#-----------------------------------------
def convert_disk_slot_to_disk_id(diskslot):
    diskid = None
    retcode,proc = utils.cust_popen('ls -al %s%s' % (SASDEVICE,'end*'))
    reslen = len(proc.stdout.readlines())
    if reslen > 0:
        #if os.path.exists(SASDEVICE):
        portaddr = convert_disk_slot_to_port_addr(diskslot)
        #24 disk
        '''
        m = re.match('^end\S+-\d+:(\d+)$',portaddr)
        n = re.match('^end\S+-\d+:(\d+:\d+)$',portaddr)
        portaddrkey = None
        if m:
            portaddrkey = m.group(1)
        elif n:
            portaddrkey = n.group(1)
        if portaddrkey:
            for key in sas_sn.DISKNUM.keys():
                if re.match('^end\S+-\d+:%s$' % portaddrkey,key):
                    diskid = sas_sn.DISKNUM[key]
                    break
        '''
        #other
        if portaddr and portaddr in sas_sn.DISKNUM:
            diskid = sas_sn.DISKNUM[portaddr]
    else:
        sysdisk = just_sys_disk()
        sysdiskslot = get_disk_slot_from_dev(sysdisk)
        if sysdiskslot in sata_sn.DISKNUM:
            maxid = analysissysslot(sysdiskslot)
            if maxid < 4:
                diskslot = analysisslot1(diskslot)
                if diskslot in sata_sn.DISKNUM:
                    diskid = sata_sn.DISKNUM[diskslot]
            else:
                diskslot = analysisslot2(diskslot)
                if diskslot in sata_sn.DISKNUM:
                    diskid = sata_sn.DISKNUM[diskslot]
        else:
            if diskslot in sata_sn.DISKNUM:
                diskid = sata_sn.DISKNUM[diskslot]
        """
        if diskslot in sata_sn.DISKNUM:
            diskid = sata_sn.DISKNUM[diskslot]
        else:
            sysdisk = just_sys_disk()
            sysdiskslot = get_disk_slot_from_dev(sysdisk)
            if sysdiskslot in sata_sn.DISKNUM:
                diskid = sata_sn.DISKNUM[sysdiskslot]
        """
    return diskid
#-----------------------------------------
# covert slot to portaddr
# slot      : 6:0:2:0
# portAddr  : end_device-7:6
#-----------------------------------------
def convert_disk_slot_to_port_addr(diskslot):
    portaddr = None
    pciaddr = ''
    find = False
    portfile = None
    
    portfilestr = 'phy_identifier'
    retcode,proc = utils.cust_popen("%s -t2 | sed -n '/Product Name/,1p' | awk -F\: '{print $2}'" % DMIDECODE)
    result = proc.stdout.read().strip()
    if result in ["X8SIE","X8DTL","X9DR7/E-LN4F"]:
        portfilestr = "sas_address"
    #getportfilescript = '/usr/local/admin/just_SN.py'
    #try:
    #    retcode,proc = utils.cust_popen2(['python',getportfilescript])
    #    result = proc.stdout.read().strip()
    #    if result:
    #        portfilestr = result
    #except:
    #    pass
    devicelist = os.listdir(SASDEVICE)
    for eachdev in devicelist:
        devsubdir = "%s%s/device" %(SASDEVICE,eachdev)
        targetlist = os.listdir(devsubdir)
        for eachtarget in targetlist:
            if re.match("target\d+\:\d+\:\d+",eachtarget):
                targetsubdir = '%s/%s' % (devsubdir,eachtarget)
                slotlist = os.listdir(targetsubdir)
                for eachslot in slotlist:
                    if eachslot == diskslot:
                        pciaddr = eachdev[:eachdev.rindex(':')]
                        portfile = '%s%s/%s' % (SASDEVICE,eachdev,portfilestr)
                        find = True
                        #break
                #if find:
                #    break
        #if find:
        #    break
    #-----------------------------------
    # new 
    #-----------------------------------
    if find:
        f = open(portfile,'r')
        result = f.read().strip()
        f.close()
        if result:
            if portfilestr == 'phy_identifier':
                portaddr = '%s:%s' %(pciaddr,result)
            else:
                portaddr = result
    #-----------------------------------
    # old
    #------------------------------------
    '''
    if find:
        f = open(portfile,'r')
        result = f.read().strip()
        f.close()
        if result:
            portaddr = '%s:%s' %(pciaddr,result)
    '''
    return portaddr
#-----------------------------------------
# check the system disk
#-----------------------------------------    
def just_sys_disk():
    global sysdisk
    if os.path.isfile(SYSDISKCACHE):
        retcode,proc = utils.cust_popen2([CAT,SYSDISKCACHE])
        sysdisk = proc.stdout.read().strip()
    else:
        sysdiskmatch = '\s+/dev/([s,h]d[a-z])\d+'
        retcode,proc = cust_popen2([PVSCAN,'-s'])
        if retcode == 0:
            result = proc.stdout.readlines()
            for line in result:
                m = re.search(sysdiskmatch,line)
                if m:
                    sysdisk = '/dev/%s' % m.group(1)
                    f,fstat = utils.cust_fopen(SYSDISKCACHE,'w')
                    f.write(sysdisk)
                    utils.cust_fclose(f,fstat)
                    break
        else:
            raise ExecCommandError,proc.stderr.read()
    return sysdisk
#----------------------------------------
# clear cache,force reload
#----------------------------------------
def clear_digistow():
    global digistow
    if os.path.isfile(DIGISTOWFILE):
        retcode,proc = utils.cust_popen2([RM,'-rf',DIGISTOWFILE])
        digistow = stow({})
#----------------------------------------
# clear cache,force reload
#----------------------------------------
def clear_digiraidstow():
    global digiraidstow
    if os.path.isfile(DIGIRAIDSTOWFILE):
        retcode,proc = utils.cust_popen2([RM,'-rf',DIGIRAIDSTOWFILE])
        digiraidstow = stow({})
#----------------------------------------
# get_diskmap
#----------------------------------------
def get_diskmap():
    global digistow
    init_global_diskmap()
    return copy.deepcopy(digistow)
#----------------------------------------
# get diskname set
#----------------------------------------
def get_disknameset():
    diskmatch = "sd\D+"
    disknameset = set([])
    disks = []
    sysdisk = just_sys_disk()
    sysdiskname = ''
    if sysdisk:
        sysdiskname = sysdisk.replace('/dev/','')
    sysblocks = os.listdir(SYSBLOCK)
    for sysblock in sysblocks:
        if re.match(diskmatch,sysblock) and sysblock != sysdiskname:
            disks.append(sysblock)
            disknameset.add(sysblock)
    return disks,disknameset
#-----------------------
# diskidmap
#    {'1':'sdb','2':'sdc','3':'sdd',...}
# disknamemap
#    {'sdb':'1','sdc':'2','sdd':'3',...}
#-----------------------
def init_diskmap():
    global digistow,sas_sn,sata_sn
    diskidmap = {}
    disknamemap = {}
    try:
        disks,disknameset = get_disknameset()
        aa = check_sata_or_sas()
        if aa == 'sata':
            try:
                reload(sata_sn)
            except:
                import sata_sn
        else:
            try:
                reload(sas_sn)
            except:
                import sas_sn
        for disk in disks: 
            diskslot = get_disk_slot_from_dev(disk)
            if diskslot:
                diskid = convert_disk_slot_to_disk_id(diskslot)
                if diskid:
                    diskid = str(diskid)
                    diskidmap[diskid] = disk
                    disknamemap[disk] = diskid
        digistow.digidisk = stow({})
        digistow.digidisk.diskidmap = copy.deepcopy(diskidmap)
        digistow.digidisk.disknamemap = copy.deepcopy(disknamemap)
        digistow.digidisk.disknameset = copy.deepcopy(disknameset)
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
#------------------------
# 
#------------------------    
def get_disk_info():
    global diskdevinfo
    global digistow
    diskdevinfo = stow({})
    diskidmap = {}
    disknamemap = {}
    try:
        disks,disknameset = get_disknameset()
        aa = check_sata_or_sas()
        if aa == 'sata':
            try:
                reload(sata_sn)
            except:
                import sata_sn
        else:
            try:
                reload(sas_sn)
            except:
                import sas_sn
        for disk in disks: 
            diskslot = get_disk_slot_from_dev(disk)
            if diskslot:
                diskid = convert_disk_slot_to_disk_id(diskslot)
                if diskid:
                    diskid = str(diskid)
                    diskidmap[diskid] = disk
                    disknamemap[disk] = diskid
        digistow.digidisk = stow({})
        digistow.digidisk.diskidmap = copy.deepcopy(diskidmap)
        digistow.digidisk.disknamemap = copy.deepcopy(disknamemap)
        digistow.digidisk.disknameset = copy.deepcopy(disknameset)
        if diskidmap:
            for diskid,diskname in diskidmap.iteritems():
                diskdevinfo[diskid] = {}
            thread_get_all_disk_state(diskidmap)
            thread_get_all_disk_size(diskidmap)
            thread_get_all_disk_serial(diskidmap)
        digistow.diskdevinfo = copy.deepcopy(diskdevinfo)
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        #utils.release_lock('disk')
    return diskdevinfo
    """
    try:
        if True:
            disks,disknameset = get_disknameset()
            if 'diskdevinfo' not in digistow or ( 'diskdevinfo' in digistow and digistow.diskdevinfo and currtime - digistow.diskdevinfo.digitime > EXPIRAINTERVAL) or ('digidisk' in digistow and 'disknameset' in digistow.digidisk and digistow.digidisk.disknameset != disknameset):
                clear_digistow()
                diskidmap = {}
                disknamemap = {}
                #disks,disknameset = get_disknameset()
                if 'digidisk' not in digistow or ( 'digidisk' in digistow and digistow.digidisk and 'diskidmap' in digistow.digidisk and digistow.digidisk.diskidmap and currtime - digistow.digidisk.digitime > EXPIRAINTERVAL) or ('digidisk' in digistow and 'disknameset' in digistow.digidisk and digistow.digidisk.disknameset != disknameset):
                    try:
                        reload(sata_sn)
                    except:
                        import sata_sn
                    try:
                        reload(sas_sn)
                    except:
                        import sas_sn
                    for disk in disks: 
                        diskslot = get_disk_slot_from_dev(disk)
                        if diskslot:
                            diskid = convert_disk_slot_to_disk_id(diskslot)
                            if diskid:
                                diskid = str(diskid)
                                diskidmap[diskid] = disk
                                disknamemap[disk] = diskid
                    digistow.digidisk = stow({})
                    digistow.digidisk.diskidmap = copy.deepcopy(diskidmap)
                    digistow.digidisk.disknamemap = copy.deepcopy(disknamemap)
                    digistow.digidisk.disknameset = copy.deepcopy(disknameset)
                    digistow.digidisk.digitime = time.time()
                    f,fstat = utils.cust_fopen(DIGISTOWFILE,'w')
                    pickle.dump(digistow,f)
                    utils.cust_fclose(f,fstat)
                    #wirite to cache
                    f,fstat = utils.cust_fopen(DISKCACHEFILE,'w')
                    pickle.dump(disknamemap,f)
                    utils.cust_fclose(f,fstat)
                diskidmap = copy.deepcopy(digistow.digidisk.diskidmap)
                if diskidmap:
                    for diskid,diskname in diskidmap.iteritems():
                        diskdevinfo[diskid] = {}
                    thread_get_all_disk_state(diskidmap)
                    thread_get_all_disk_size(diskidmap)
                    thread_get_all_disk_serial(diskidmap)
                digistow.diskdevinfo = copy.deepcopy(diskdevinfo)
                digistow.diskdevinfo.digitime = time.time()
                f,fstat = utils.cust_fopen(DIGISTOWFILE,'w')
                pickle.dump(digistow,f)
                utils.cust_fclose(f,fstat)
            #utils.release_lock('disk')
        else:
            while True:
                time.sleep(0.1)
                if os.path.exists(utils.DISKLOCK) and time.time() - os.stat(utils.DISKLOCK).st_mtime > EXPIRETIMEOUT:
                    utils.release_lock('disk')
                if 'diskdevinfo' in digistow and digistow.diskdevinfo:
                    break
                if not utils.is_lock('disk'):
                    return get_disk_info()
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        #utils.release_lock('disk')
    return copy.deepcopy(digistow.diskdevinfo)
    """
#-----------------------
# diskidmap
#    {'1':'sdb','2':'sdc','3':'sdd',...}
# disknamemap
#    {'sdb':'1','sdc':'2','sdd':'3',...}
#-----------------------
def init_diskmap2():
    global digistow
    try:
        disks,disknameset,diskidmap,disknamemap,expanderidmap = baseboard.get_diskmap()
        digistow.digidisk = stow({})
        digistow.digidisk.diskidmap = copy.deepcopy(diskidmap)
        digistow.digidisk.disknamemap = copy.deepcopy(disknamemap)
        digistow.digidisk.disknameset = copy.deepcopy(disknameset)
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
#------------------------
# 
#------------------------    
def get_disk_info2():
    global diskdevinfo
    global digistow
    diskdevinfo = stow({})
    try:
        disks,disknameset,diskidmap,disknamemap,expanderidmap = baseboard.get_diskmap()
        digistow.digidisk = stow({})
        digistow.digidisk.diskidmap = copy.deepcopy(diskidmap)
        digistow.digidisk.disknamemap = copy.deepcopy(disknamemap)
        digistow.digidisk.disknameset = copy.deepcopy(disknameset)
        if diskidmap:
            for diskid,diskname in diskidmap.iteritems():
                diskdevinfo[diskid] = {}
            thread_get_all_disk_state(diskidmap)
            thread_get_all_disk_size(diskidmap)
            thread_get_all_disk_serial(diskidmap)
        digistow.diskdevinfo = copy.deepcopy(diskdevinfo)
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
    return diskdevinfo
#------------------------
# 
#------------------------
def thread_get_all_disk_size(diskidmap):
    global diskdevinfo
    for diskid,diskname in diskidmap.iteritems():
        diskdevinfo[diskid]['size'] = get_disk_size(diskname)
#------------------------
# 
#------------------------
def get_disk_size(diskname):
    disksize = '0G'
    try:
        disksizefile = os.path.join(SYSBLOCK,diskname,'size')
        retcode,proc = utils.cust_popen2([CAT,disksizefile])
        disksize = proc.stdout.read().strip()
        #f = open(disksizefile,'r')
        #disksize = f.read().strip()
        #f.close()
        disksize = '%sG' % str(int(int(disksize) * 0.512 / 1000 / 10000) * 10)
    except:
        pass
    return disksize
#-------------------------------------------
#disk state
#-------------------------------------------    
def thread_get_all_disk_state(diskidmap):
    global diskdevinfo
    global targetdevices
    global targetinfo
    get_raid_disks()
    targetdevices = digisan.get_all_target_devices()
    targetinfo = digiiscsi.get_iscsi_target()
    for diskid,diskname in diskidmap.iteritems():
        diskdevinfo[diskid]['state'] = get_disk_state(diskname)
#------------------------
# 1:inuse
# 2:unuse
# 3:spare
# -1:inactive
# -2:broken
#------------------------
def get_disk_state(diskname):
    global asortraiddisks
    global targetinfo
    global targetdevices
    global hasraid
    if diskname in asortraiddisks['faildisks']:
        return -2
    elif diskname in asortraiddisks['sparedisks']:
        return 3
    elif diskname in asortraiddisks['workingdisks']:
        return 1
    else:
        try:
            diskdev = '/dev/%s' % diskname
            for targetsn,targetdev in targetinfo.iteritems():
                if diskdev == targetdev:
                    return 1
            if diskdev in targetdevices:
                return 1
            retcode,proc = cust_popen2([MDADM,'-E',diskdev])
            result = '%s%s' % (proc.stdout.read(),proc.stderr.read())
            if re.search("No md superblock detected on",result):
                return 2
            elif hasraid:
                return -2
            else:
                return -1
        except Exception,e:
            print >> sys.stderr,traceback.print_exc()
            return -2
#-------------------------------------------
#
#------------------------------------------- 
def get_raid_disks():
    global asortraiddisks
    global hasraid
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    diskstates = {'F':'faildisks','S':'sparedisks'}
    hasraid = False
    raiddiskmathch = '^md\d+\s+:\s+.*raid\d+\s+(.*)\n'
    diskstatematch = '(\S+)\((\S+)\)'
    asortraiddisks = {
        'faildisks':[],
        'sparedisks':[],
        'workingdisks':[]
    }
    i = 0
    reslen = len(result)
    while i < reslen:
        rdm = re.match(raiddiskmathch,result[i])
        if rdm:
            hasraid = True
            raiddiskstr = re.sub('\[\d+\]','',rdm.group(1))
            raiddisks = raiddiskstr.split()
            for raiddisk in raiddisks:
                dm = re.match(diskstatematch,raiddisk)
                if not dm is None:
                    asortraiddisks[diskstates[dm.group(2)]].append(dm.group(1))
                else:
                    asortraiddisks['workingdisks'].append(raiddisk)
            i += 2
            continue
        i += 1
#-------------------------------------------
#disk serial
#-------------------------------------------
def thread_get_all_disk_serial(diskidmap):
    global diskdevinfo
    get_disk_serials()
    for diskid,diskname in diskidmap.iteritems():
        diskdevinfo[diskid]['serial'],diskdevinfo[diskid]['model'] = get_disk_serial(diskname)
#-------------------------------------------
# 
#-------------------------------------------
def get_disk_serial(diskname):
    diskserial = None
    diskmodel = None
    global diskserials
    if diskname in diskserials:
        return (diskserials[diskname]['serial'],diskserials[diskname]['model'])
    return (diskserial,diskmodel)
#---------------------------
# diskserials
#    {'sda':{'model':'####','serial':'##########'},'sdb':{...}}
#---------------------------
def get_disk_serials():
    global diskserials
    diskserials = {}
    diskseriallinks = []
    if os.path.exists(DISKSERIAL):
        diskseriallinks = os.listdir(DISKSERIAL)
    for diskseriallink in diskseriallinks:
        if not diskseriallink.startswith('scsi-SATA'):
            continue
        diskseriallinkfullpath = os.path.join(DISKSERIAL,diskseriallink)
        if os.path.islink(diskseriallinkfullpath):
            diskmodel = ''
            diskserial = ''
            diskdevfile = os.readlink(diskseriallinkfullpath)
            diskdevname = os.path.split(diskdevfile)[1]
            diskmodel,diskserial = diskseriallink.rsplit('_',1)
            if diskserial.find('part') >= 0:
                diskserial = diskserial.rsplit('-')[0]
            diskmodel = diskmodel.split('_',1)[1]
            if diskmodel.endswith('-'):
                diskmodel = diskmodel[:-1]
            diskserials[diskdevname] = {
                'model':diskmodel,
                'serial':diskserial
            }
#-------------------------------------------
# get all disk size
#-------------------------------------------    
def get_all_disk_size():
    global digistow
    init_global_diskmap()
    diskidmap = copy.deepcopy(digistow.digidisk.diskidmap)
    disksizemap = {}
    for diskid,diskname in diskidmap.iteritems():
        disksizemap[diskid] = get_disk_size(diskname)
    return disksizemap
#-------------------------
# get all disk serial
#-------------------------
def get_all_disk_serial():
    global digistow
    init_global_diskmap()
    diskidmap = copy.deepcopy(digistow.digidisk.diskidmap)
    get_disk_serials()
    diskserialmap = {}
    for diskid,diskname in diskidmap.iteritems():
        diskserialmap[diskid] = get_disk_serial(diskname) #return a tuple (serial,model)
    return diskserialmap
#-------------------------------------------
# get all disk state
#-------------------------------------------    
def get_all_disk_state():
    global digistow
    global targetinfo
    global targetdevices
    
    init_global_diskmap()
    diskidmap = copy.deepcopy(digistow.digidisk.diskidmap)
    get_raid_disks()
    targetdevices = digisan.get_all_target_devices()
    targetinfo = digiiscsi.get_iscsi_target()
    diskstatemap = {}
    for diskid,diskname in diskidmap.iteritems():
        diskstatemap[diskid] = get_disk_state(diskname)
    return diskstatemap
#-------------------------
# get all disk id in raid
#-------------------------
def get_raid_disk_id(raiddev):
    global digistow
    raiddiskids = []
    init_global_diskmap()
    disknamemap = copy.deepcopy(digistow.digidisk.disknamemap)
    raidname = raiddev.replace('/dev/','')
    #raiddevmatch = '^%s\s+:\s+(active\s+raid(\d+)|inactive)\s+(.*)\n' % raidname
    raiddevmatch = '^%s\s+:\s+(active(\s+\(\S+\)\s+|\s+)raid(\d+)|inactive)\s+(.*)\n' % raidname
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    reslen = len(result)
    i = 0
    while i < reslen:
        rdm = re.match(raiddevmatch,result[i])
        if rdm:
            raiddiskstr = re.sub('\[\d+\]','',rdm.group(4))
            raiddiskstr = re.sub('\([F|S]\)','',raiddiskstr)
            raiddisks = raiddiskstr.split()
            for raiddisk in raiddisks:
                if raiddisk in disknamemap:
                    raiddiskids.append(disknamemap[raiddisk])
            break
        i += 1
    return raiddiskids
#------------------------
# get disk which state is unused
#------------------------
def get_unused_disk():
    unuseddisks = []
    diskstates = get_all_disk_state()
    for diskid,diskstate in diskstates.iteritems():
        if diskstate == 2:
            unuseddisks.append(diskid)
    unuseddisks = utils.sort_strings(unuseddisks)
    return unuseddisks
#------------------------
# get disk which state is inactive
#------------------------
def get_inactive_disk():
    inactivedisks = []
    diskstates = get_all_disk_state()
    for diskid,diskstate in diskstates.iteritems():
        if diskstate in [-1,-2]:
            inactivedisks.append(diskid)
    inactivedisks = utils.sort_strings(inactivedisks)
    return inactivedisks
#--------------------------
# get disk uuid, raiddev
#--------------------------
def get_disk_uuid(diskdev):
    uuid = ''
    raiddev = None
    retcode,proc = utils.cust_popen2([MDADM,'-E',diskdev])
    result = proc.stdout.readlines()
    for line in result:
        uuidmatch = re.match("\s+UUID\s+:\s+(\S+)\s+\(",line)
        if utils.check_if_debian6():
            uuidmatch = re.match("\s+Array\s+UUID\s+:\s+(\S+)\s+\(*",line)
        if uuidmatch:
            uuid = uuidmatch.group(1)
        raidmatch = re.match("Preferred Minor\s+:\s+(\d+)\n",line)
        if utils.check_if_debian6():
            raidmatch = re.match("\s*Name\s+:\s+Storage:(\d+)\s+",line)
        if raidmatch:
            raiddev = "/dev/md%s" % raidmatch.group(1)
        if uuid and raiddev:
            break
    return (uuid,raiddev)
#--------------------------
# get all disk health
#--------------------------
def get_all_disk_health():
    global digistow
    init_global_diskmap()
    diskidmap = copy.deepcopy(digistow.digidisk.diskidmap)
    diskhealthmap = {}
    smartinstalled = utils.check_installed('smartmontools')
    if smartinstalled: 
        for diskid,diskname in diskidmap.iteritems():
            diskhealthmap[diskid] = get_disk_health(diskname)
    return diskhealthmap
#--------------------------
# get disk health
#-------------------------- 
def get_disk_health(diskname):
    diskdev = '/dev/%s' % diskname
    smartsupport = False
    smartenable = False
    diskhealth = False
    retresult = []
    try:
        retcode,proc = utils.cust_popen2(['smartctl','-iH',diskdev])
        result = proc.stdout.readlines()
        reslen = len(result)
        for i in range(reslen):
            if re.search('.*:\s+Available.*',result[i]):
                smartsupport = True
            if re.search('.*:\s+Enabled.*',result[i]):
                smartenable = True
            if re.search('.*result:\s+PASSED.*',result[i]):
                diskhealth = True
            if re.search('.*result:\s+FAILED.*',result[i]):
                diskhealth = False
            if re.search('Failed Attributes:',result[i]):
                lastresult = result[i + 2:]
                for line in lastresult:
                    if line.strip():
                        failinfo = re.compile(r"\S+").findall(line)
                        retresult.append(failinfo)
                    else:
                        break
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        pass
    return [diskhealth,retresult]
#########################################################################################################
#----------------------------
# raidinfos
#     'showname':RAID组1,
#     'raidname':'md10',
#     'raiddev':'/dev/md10'
#----------------------------
def get_raid_base_info():
    raiddevsinfo = {}
    #raiddevmatch = '^(md(\d+))\s+:\s+(active\s+raid(\d+)|inactive)\s+(.*)\n'
    raiddevmatch = '^(md(\d+))\s+:\s+(active(\s+\(\S+\)\s+|\s+)raid(\d+)|inactive)\s+(.*)\n'
    try:
        if True:
            f = open(MDSTAT,'r')
            result = f.readlines()
            f.close()
            reslen = len(result)
            i = 0
            while i < reslen:
                rdm = re.match(raiddevmatch,result[i])
                if rdm:
                    raidname = rdm.group(1)
                    raidid = int(rdm.group(2))
                    raidlevel = rdm.group(5)
                    raidshowname = u'%s%d' % (RAIDSHOWPRE,((raidid - 10) / 10) * 10 + raidid % 10 + 1)
                    raiddevsinfo[raidid] = {
                        'raidname':raidname,
                        'raiddev':'/dev/%s' % raidname,
                        'raidlevel':raidlevel,
                        'showname':raidshowname
                    }
                    i += 2
                    continue
                i += 1
            #utils.release_lock('raid')
        else:
            while True:
                time.sleep(0.1)
                if not utils.is_lock('raid'):
                    return get_raid_base_info()
                elif time.time() - os.stat(utils.RAIDLOCK).st_mtime > EXPIRETIMEOUT:
                    utils.release_lock('raid')
    except Exception,e:
        pass
        #utils.release_lock('raid')
    return raiddevsinfo
#---------------------------------------
# raidinfos
#     'showname':RAID组1,
#     'raidname':'md10',
#     'raiddev':'/dev/md10',
#     'raidlevel':'5',
#     'raidsize':'1.76T',
#     'raiddisks':{'workingdisks':['sdb','sdc','sdd'],'faildisks':['sde'],'sparedisks':['sdf','sdg']},
#     'raiddiskids':['1','2','3','4','5','6'],
#     'raiddiskgids':{'workingdisks':['1','2','3'],'faildisks':['4'],'sparedisks':['5','6']},
#     'state':0
#---------------------------------------
def get_raid_info():
    raiddevsinfo = stow({})
    raiddevmatch = '^(md(\d+))\s+:\s+(active(\s+\(\S+\)\s+|\s+)raid(\d+)|inactive)\s+(.*)\n'
    try:
        f = open(MDSTAT,'r')
        result = f.readlines()
        f.close()
        reslen = len(result)
        diskstates = {'F':'faildisks','S':'sparedisks'}
        diskstatematch = '(\S+)\((\S+)\)'
        raidprocessmatch = '(recovery|resync)'
        raidbitmapmatch = 'bitmap:'
        i = 0
        while i < reslen:
            rdm = re.match(raiddevmatch,result[i])
            if rdm:
                raidname = rdm.group(1)
                raiddev = '/dev/%s' % raidname
                raidid = int(rdm.group(2))
                raidstatu = rdm.group(3)
                raidlevel = rdm.group(5)
                raiddiskstr = re.sub('\[\d+\]','',rdm.group(6))
                raidbitmap = False
                raiddisknames = {
                    'faildisks':[],
                    'sparedisks':[],
                    'workingdisks':[]
                }
                raiddisks = raiddiskstr.split()
                for raiddisk in raiddisks:
                    dm = re.match(diskstatematch,raiddisk)
                    if not dm is None:
                        raiddisknames[diskstates[dm.group(2)]].append(dm.group(1))
                    else:
                        raiddisknames['workingdisks'].append(raiddisk)
                raiddiskgids,raiddiskids = raiddisknametoid(raiddisknames)
                raidsize = '0G'
                raidsizematch = '\s+(\d+)\s+blocks'
                sm = re.match(raidsizematch,result[i + 1])
                if sm:
                    raidsize = '%sG' % str(round(float(sm.group(1)) / 1024 / 1024 ,2))
                rpm = re.search(raidprocessmatch,result[i + 2])
                rbm = None
                if rpm:
                    rbm = re.search(raidbitmapmatch,result[i + 3])
                else:
                    rbm = re.search(raidbitmapmatch,result[i + 2])
                if rbm:
                    raidbitmap = True
                
                raiddevsinfo[raidid] = {
                    'showname':'%s%d' % (RAIDSHOWPRE,((raidid - 10) / 10) * 10 + raidid % 10 + 1),
                    'raidname':raidname,
                    'raiddev':raiddev,
                    'raidlevel':raidlevel,
                    'raidsize':raidsize,
                    'raiddisks':raiddisknames,
                    'raiddiskids':raiddiskids,
                    'raiddiskgids':raiddiskgids,
                    'raidbitmap':raidbitmap,
                    'state':raidlevel and get_raid_state(raiddev,raidlevel) or 'error'
                }
                i += 2
                continue
            i += 1
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
    return raiddevsinfo
#----------------------------
# change raiddisks to raiddiskids
#     'raiddisks':{'workingdisks':['sdb','sdc','sdd'],'faildisks':['sde'],'sparedisks':['sdf','sdg']},
#     'raiddiskids':['1','2','3','4','5','6'],
#----------------------------
def raiddisknametoid(raiddisks):
    global digistow
    init_global_diskmap()
    disknamemap = copy.deepcopy(digistow.digidisk.disknamemap)
    raiddiskids = []
    raiddiskgids = {
        'faildisks':[],
        'sparedisks':[],
        'workingdisks':[]
    }
    for diskstate in ['faildisks','sparedisks','workingdisks']:
        for disk in raiddisks[diskstate]:
            if disk in disknamemap:
                raiddiskids.append(disknamemap[disk])
                raiddiskgids[diskstate].append(disknamemap[disk])
    return raiddiskgids,raiddiskids
#----------------------------
#   raid state
#       0:ok
#       1:build
#       2:recovery
#       3:alert
#       4:error
#----------------------------
def get_raid_state(raiddev,raidlevel):
    raidstate = 4
    if raidlevel != -1:
        raidstate = eval("get_raid_state%s('%s')" % (raidlevel,raiddev))
    return RAIDSTATE[raidstate]
#------------------------------------
#   check raid0 state
#   check failed disk from /proc/mdstat
#   command 'pvs' return result contain '/dev/md10: read failed ...Input/output error'
#   command 'mdadm -D /dev/md10' return result contain 'SCSI error' or 'does not appear to be active'
#------------------------------------
def get_raid_state0(raiddev):
    raidstate = 0
    raidname = raiddev.replace('/dev/','')
    raiddevmatch = '^%s\s+:\s+.*raid(\d+)\s+(.*)\n' % raidname
    faildiskmatch = '\(F\)'
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    reslen = len(result)
    i = 0
    while i < reslen:
        rdm = re.match(raiddevmatch,result[i])
        if rdm:
            faildisknum = len(re.findall(faildiskmatch,result[i]))
            if faildisknum > 0:
                raidstate = 4
                break
            break
        i += 1
    if raidstate > 0:
        return raidstate
    #check SCSI error
    retcode,proc = cust_popen2([MDADM,'-D',raiddev])
    if retcode == 0:
        result = proc.stdout.readlines()
        for line in result:
            if re.search('SCSI error',line) or re.search('does not appear to be active',line):
                raidstate = 4
                break
    else:
        raise ExecCommandError,proc.stderr.read()
    if raidstate > 0:
        return raidstate
    #check pvs error
    retcode,proc = cust_popen2([PVSCAN,'-s'])
    if retcode == 0:
        result = proc.stdout.readlines()
        for line in result:
            if re.search(raiddev,line) and re.search('Input/output error',line):
                raidstate = 4
                break
    else:
        raise ExecCommandError,proc.stderr.read()
    return raidstate
#--------------------------
# raid1 state
#--------------------------    
def get_raid_state1(raiddev):
    global digistow
    init_global_diskmap()
    diskidmap = copy.deepcopy(digistow.digidisk.diskidmap)
    disknamemap = copy.deepcopy(digistow.digidisk.disknamemap)
    raidstate = 4
    raidname = raiddev.replace('/dev/','')
    raiddevmatch = '^%s\s+:\s+.*raid(\d+)\s+(.*)\n' % raidname
    diskstatematch = '(\S+)\((\S+)\)'
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    reslen = len(result)
    i = 0
    while i < reslen:
        rdm = re.match(raiddevmatch,result[i])
        if rdm:
            faildisknum = result[i + 1].count('_')
            raiddiskstr = re.sub('\[\d+\]','',rdm.group(2))
            raiddisks = raiddiskstr.split()
            for raiddisk in raiddisks:
                dm = re.match(diskstatematch,raiddisk)
                if not dm is None:
                    if dm.group(2) == 'F':
                        faildiskdev = '/dev/%s' % dm.group(1)
                        retcode,proc = utils.cust_popen2([MDADM,raiddev,'--remove',faildiskdev])
            if faildisknum == 0:
                if re.search("resync",result[i + 2]):
                    raidstate = 1
                    break
                elif re.search("reshape",result[i + 2]):
                    raidstate = 5
                    break
                else:
                    raidstate = 0
                    break
            elif faildisknum == 1:
                if re.search('recovery',result[i + 2]):
                    raidstate = 2
                    break
                else:
                    unuseddiskids = get_unused_disk()
                    if unuseddiskids:
                        diskpre = None;
                        diskid = None
                        for raiddisk in raiddisks:
                            if raiddisk in disknamemap:
                                diskid = disknamemap[raiddisk]
                                break
                        if diskid and diskid.find('-') >= 0:
                            diskpre = diskid.split('-')[0]
                        if diskpre:
                            for diskid in unuseddiskids:
                                if diskid.startswith('%s-' % diskpre):
                                    retcode,proc = utils.cust_popen2([MDADM,raiddev,'--add','/dev/%s' % diskidmap[diskid]])
                                    break
                        else:
                            retcode,proc = utils.cust_popen2([MDADM,raiddev,'--add','/dev/%s' % diskidmap[unuseddiskids[0]]])
                    raidstate = 3
                    break
            else:
                raidstate = 4
                break
            break
        i += 1
    #TODO:remove the fault disk
    return raidstate
#---------------------------
# raid5 state
#---------------------------    
def get_raid_state5(raiddev):
    global digistow
    init_global_diskmap()
    diskidmap = copy.deepcopy(digistow.digidisk.diskidmap)
    disknamemap = copy.deepcopy(digistow.digidisk.disknamemap)
    raidstate = 4
    raidname = raiddev.replace('/dev/','')
    raiddevmatch = '^%s\s+:\s+.*raid(\d+)\s+(.*)\n' % raidname
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    reslen = len(result)
    i = 0
    while i < reslen:
        rdm = re.match(raiddevmatch,result[i])
        if rdm:
            faildisknum = result[i + 1].count('_')
            raiddiskmathch = '^md\d+\s+:\s+.*raid\d+\s+(.*)\n'
            diskstatematch = '(\S+)\((\S+)\)'
            rdm = re.match(raiddiskmathch,result[i])
            if rdm:
                raiddiskstr = re.sub('\[\d+\]','',rdm.group(1))
                raiddisks = raiddiskstr.split()
                for raiddisk in raiddisks:
                    dm = re.match(diskstatematch,raiddisk)
                    if not dm is None:
                        if dm.group(2) == 'F':
                            faildiskdev = '/dev/%s' % dm.group(1)
                            retcode,proc = utils.cust_popen2([MDADM,raiddev,'--remove',faildiskdev])
            if faildisknum == 0:
                if re.search("resync",result[i + 2]):
                    raidstate = 1
                    break
                elif re.search("reshape",result[i + 2]):
                    raidstate = 5
                    break
                else:
                    raidstate = 0
                    break
            elif faildisknum > 1:
                raidstate = 4
                break
            else:
                if re.search('recovery',result[i + 2]):
                    raidstate = 2
                    break
                else:
                    unuseddiskids = get_unused_disk()
                    if unuseddiskids:
                        diskpre = None;
                        diskid = None
                        for raiddisk in raiddisks:
                            if raiddisk in disknamemap:
                                diskid = disknamemap[raiddisk]
                                break
                        if diskid and diskid.find('-') >= 0:
                            diskpre = diskid.split('-')[0]
                        if diskpre:
                            for diskid in unuseddiskids:
                                if diskid.startswith('%s-' % diskpre):
                                    retcode,proc = utils.cust_popen2([MDADM,raiddev,'--add','/dev/%s' % diskidmap[diskid]])
                                    break
                        else:
                            retcode,proc = utils.cust_popen2([MDADM,raiddev,'--add','/dev/%s' % diskidmap[unuseddiskids[0]]])
                    raidstate = 3
                    break
            break
        i += 1
    #TODO:remove the fault disk
    return raidstate
#-----------------------------
# raid6 state
#-----------------------------        
def get_raid_state6(raiddev):
    global digistow
    init_global_diskmap()
    diskidmap = copy.deepcopy(digistow.digidisk.diskidmap)
    disknamemap = copy.deepcopy(digistow.digidisk.disknamemap)
    raidstate = 4
    raidname = raiddev.replace('/dev/','')
    raiddevmatch = '^%s\s+:\s+.*raid(\d+)\s+(.*)\n' % raidname
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    reslen = len(result)
    i = 0
    while i < reslen:
        rdm = re.match(raiddevmatch,result[i])
        if rdm:
            faildisknum = result[i + 1].count('_')
            sparedisknum = 0
            raiddiskmathch = '^md\d+\s+:\s+.*raid\d+\s+(.*)\n'
            diskstatematch = '(\S+)\((\S+)\)'
            rdm = re.match(raiddiskmathch,result[i])
            if rdm:
                raiddiskstr = re.sub('\[\d+\]','',rdm.group(1))
                raiddisks = raiddiskstr.split()
                for raiddisk in raiddisks:
                    dm = re.match(diskstatematch,raiddisk)
                    if not dm is None:
                        if dm.group(2) == 'F':
                            faildiskdev = '/dev/%s' % dm.group(1)
                            retcode,proc = utils.cust_popen2([MDADM,raiddev,'--remove',faildiskdev])
                        if dm.group(2) == 'S':
                            sparedisknum += 1
            if faildisknum == 0:
                if re.search("resync",result[i + 2]):
                    raidstate = 1
                    break
                elif re.search("reshape",result[i + 2]):
                    raidstate = 5
                    break
                else:
                    raidstate = 0
                    break
            elif faildisknum > 2:
                raidstate = 4
                break
            else:
                #raiddiskmathch = '^md\d+\s+:\s+.*raid\d+\s+(.*)\n'
                #diskstatematch = '(\S+)\((\S+)\)'
                #rdm = re.match(raiddiskmathch,result[i])
                adddisknum = 0
                if re.search('recovery',result[i + 2]):
                    raidstate = 2
                    if faildisknum == 2 and sparedisknum < 1:
                        adddisknum = 1
                elif re.search("resync",result[i + 2]):
                    raidstate = 1
                    if faildisknum == 1 and sparedisknum < 1:
                        adddisknum = 1
                else:
                    raidstate = 3
                    if faildisknum == 1 and sparedisknum < 1:
                        adddisknum = 1
                    if faildisknum == 2 and sparedisknum < 2:
                        adddisknum = 2
                if adddisknum > 0:
                    diskpre = None
                    unuseddiskids = get_unused_disk()
                    if unuseddiskids:
                        diskid = None
                        for raiddisk in raiddisks:
                            if raiddisk in disknamemap:
                                diskid = disknamemap[raiddisk]
                                break
                        if diskid and diskid.find('-') >= 0:
                            diskpre = diskid.split('-')[0]
                    if diskpre:
                        i = 0
                        for diskid in unuseddiskids:
                            if diskid.startswith('%s-' % diskpre):
                                retcode,proc = utils.cust_popen2([MDADM,raiddev,'--add','/dev/%s' % diskidmap[diskid]])
                                i += 1
                                if i == adddisknum:
                                    break
                    else:
                        i = 0
                        for diskid in unuseddiskids:
                            retcode,proc = utils.cust_popen2([MDADM,raiddev,'--add','/dev/%s' % diskidmap[diskid]])
                            i += 1
                            if i == adddisknum:
                                break
            break
        i += 1
    #TODO:remove the fault disk
    return raidstate
#------------------------
# raid10 state
#------------------------
def get_raid_state10(raiddev):
    raidstate = get_raid_state1(raiddev)
    return raidstate
#-------------------------
# get raid process
#-------------------------
def get_raid_process():
    raidprocess = {}
    #raiddevmatch = '^(md(\d+))\s+:\s+(active\s+raid(\d+)|inactive)\s+(.*)\n'
    raiddevmatch = '^(md(\d+))\s+:\s+(active(\s+\(\S+\)\s+|\s+)raid(\d+)|inactive)\s+(.*)\n'
    raidprocessmatch = '(recovery|resync)'
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    reslen = len(result)
    i = 0
    while i < reslen:
        rdm = rpm = None
        rdm = re.match(raiddevmatch,result[i])
        if rdm:
            rpm = re.search(raidprocessmatch,result[i + 2])
            if rpm:
                raidname = rdm.group(1)
                raidid = int(rdm.group(2))
                raidstatu = rdm.group(3)
                raidlevel = rdm.group(5)
                showname = '%s%d' % (RAIDSHOWPRE,((raidid - 10) / 10) * 10 + raidid % 10 + 1)
                if result[i + 2].find('%') >= 0:
                    tmp1,tmp2 = result[i + 2].split("%")
                    tmp1 = tmp1.split("=")
                    rprate = tmp1[-1].strip()
                    tmp2,tmp3 = tmp2.split("min")
                    tmp2 = tmp2.split("=")
                    rptime = tmp2[-1].strip()
                    raidprocess[raidid] = {
                        'rprate':rprate,
                        'rptime':rptime,
                        'raidname':raidname,
                        'raidshowname':showname
                    }
            i += 2
            continue
        else:
            i += 1
    return raidprocess
#------------------------
# get raid level
#------------------------
def get_raid_level(raiddev):
    raidlevel = '-1'
    raidname = raiddev.replace('/dev/','')
    #raidlevlematch = '^%s\s+:\s+(active\s+raid(\d+)|inactive)\s+.*\n' % raidname
    raidlevlematch = '^%s\s+:\s+(active(\s+\(\S+\)\s+|\s+)raid(\d+)|inactive)\s+.*\n' % raidname
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    for line in result:
        m = re.match(raidlevlematch,line)
        if m:
            raidlevel = m.group(3)
            break
    return raidlevel
#------------------------
# get raid level
#------------------------
def get_new_raid_dev():
    bigestnum = 9 #TODO:this should be a constant
    raiddevs = get_raid_base_info()
    bigestnum = max(raiddevs.keys() or [9])
    newraidnum = bigestnum + 1
    return "/dev/md%s" % newraidnum
#------------------------
# get raid show name
#------------------------
def get_raid_showname(raiddev):
    raidshownum = 1
    raidname = raiddev.replace('/dev/','')
    raidmatch = 'md(\d+)'
    rdm = re.match(raidmatch,raidname)
    if rdm:
        raidid = int(rdm.group(1))
        raidshownum = ((raidid - 10) / 10) * 10 + raidid % 10 + 1
    raidshowname = '%s%s' % (RAIDSHOWPRE,raidshownum)
    return raidshowname
#------------------------
# get raid detail
#------------------------
def get_raid_detail(sraiddev):
    raidinfo = None
    #raiddevmatch = '^(md(\d+))\s+:\s+(active\s+raid(\d+)|inactive)\s+(.*)\n'
    raiddevmatch = '^(md(\d+))\s+:\s+(active(\s+\(\S+\)\s+|\s+)raid(\d+)|inactive)\s+(.*)\n'
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    reslen = len(result)
    diskstates = {'F':'faildisks','S':'sparedisks'}
    diskstatematch = '(\S+)\((\S+)\)'
    raidprocessmatch = '(recovery|resync)'
    raidbitmapmatch = 'bitmap:'
    i = 0
    while i < reslen:
        rdm = re.match(raiddevmatch,result[i])
        if rdm:
            raidname = rdm.group(1)
            raiddev = '/dev/%s' % raidname
            if raiddev == sraiddev:
                raidid = int(rdm.group(2))
                raidstatu = rdm.group(3)
                raidlevel = rdm.group(5)
                raiddiskstr = re.sub('\[\d+\]','',rdm.group(6))
                raidbitmap = False
                raiddisknames = {
                    'faildisks':[],
                    'sparedisks':[],
                    'workingdisks':[]
                }
                raiddisks = raiddiskstr.split()
                for raiddisk in raiddisks:
                    dm = re.match(diskstatematch,raiddisk)
                    if not dm is None:
                        raiddisknames[diskstates[dm.group(2)]].append(dm.group(1))
                    else:
                        raiddisknames['workingdisks'].append(raiddisk)
                raiddiskgids,raiddiskids = raiddisknametoid(raiddisknames)
                raidsize = '0G'
                raidsizematch = '\s+(\d+)\s+blocks'
                sm = re.match(raidsizematch,result[i + 1])
                if sm:
                    raidsize = '%sG' % str(round(float(sm.group(1)) / 1024 / 1024 ,2))
                rpm = re.search(raidprocessmatch,result[i + 2])
                rbm = None
                if rpm:
                    rbm = re.search(raidbitmapmatch,result[i + 3])
                else:
                    rbm = re.search(raidbitmapmatch,result[i + 2])
                if rbm:
                    raidbitmap = True
                raidinfo = {
                    'showname':'%s%d' % (RAIDSHOWPRE,((raidid - 10) / 10) * 10 + raidid % 10 + 1),
                    'raidname':raidname,
                    'raiddev':raiddev,
                    'raidlevel':raidlevel,
                    'raidsize':raidsize,
                    'raiddisks':raiddisknames,
                    'raiddiskids':raiddiskids,
                    'raiddiskgids':raiddiskgids,
                    'raidbitmap':raidbitmap,
                    'state':raidlevel and get_raid_state(raiddev,raidlevel) or 'error'
                }
                break
            else:
                i += 2
                continue
        i += 1
    if raidinfo:
        retcode,proc = utils.cust_popen2([MDADM,'-QD',raiddev])
        result = proc.stdout.readlines()
        for line in result:
            if (line.find("Creation Time") >= 0):
                raidinfo['createtime'] = line.strip()[16:]

            elif (line.find("Raid Level") >= 0):
                raidinfo['raidlevel'] = line.strip()[13:]

            elif (line.find("Array Size") >= 0):
                raidinfo['arraysize'] = line.strip()[13:]

            elif (line.find("Device Size") >= 0):
                raidinfo['devicesize'] = line.strip()[14:]

            elif (line.find("Raid Devices") >= 0):
                raidinfo['raiddevices'] = line.strip()[15:]

            elif (line.find("Total Devices") >= 0):
                raidinfo['totaldevices'] = line.strip()[16:]

            elif (line.find("Preferred Minor") >= 0):
                raidinfo['minor'] = line.strip()[18:]

            elif (line.find("Persistence") >= 0):
                raidinfo['persistence'] = line.strip()[14:]

            elif (line.find("Update Time") >= 0):
                raidinfo['updatetime'] = line.strip()[14:]

            #elif (line.find("State :") >= 0):
            #    raidinfo['state'] = line.strip()[8:]

            elif (line.find("Active Devices") >= 0):
                raidinfo['activedev'] = line.strip()[17:]

            elif (line.find("Working Devices") >= 0):
                raidinfo['workingdev'] = line.strip()[18:]

            elif (line.find("Failed Devices") >= 0):
                raidinfo['faileddev'] = line.strip()[17:]

            elif (line.find("Spare Devices") >= 0):
                raidinfo['sparedev'] = line.strip()[16:]

            elif (line.find("Layout") >= 0):
                raidinfo['layout'] = line.strip()[9:]

            elif (line.find("Chunk Size") >= 0):
                raidinfo['chunksize'] = line.strip()[13:]
    return raidinfo
#------------------------
# get raid disk
#------------------------
def get_disk_in_raid(raidname):
    raiddisks = []
    #raiddevmatch = '^%s\s+:\s+(active\s+raid(\d+)|inactive)\s+(.*)\n' % raidname
    raiddevmatch = '^%s\s+:\s+(active(\s+\(\S+\)\s+|\s+)raid(\d+)|inactive)\s+(.*)\n' % raidname
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    reslen = len(result)
    i = 0
    while i < reslen:
        rdm = re.match(raiddevmatch,result[i])
        if rdm:
            raiddiskstr = re.sub('\[\d+\]','',rdm.group(4))
            raiddiskstr = re.sub('\([F|S]\)','',raiddiskstr)
            raiddisks.extend(raiddiskstr.split())
        i += 1
    return raiddisks
if __name__ == '__main__':
    digistow = get_diskmap()
    print '**********digistow*********************'
    print digistow.digidisk.disknamemap
    print '**********diskinfo*********************'
    diskinfo = None
    if baseboard.check_device():
        diskinfo = get_disk_info2()
    else:
        diskinfo = get_disk_info()
    print diskinfo
    print '**********raidinfo*********************'
    raidinfo = get_raid_info()
    print raidinfo
