#-*-coding: utf-8 -*-
#Programmer: limodou
#E-mail:     chatme@263.net
#
#Copyleft 2004 limodou
#
#Distributed under the terms of the GPL (GNU Public License)
#
#NewEdit is free software; you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation; either version 2 of the License, or
#(at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#$Id: IniFile.py,v 1.2 2004/07/20 14:15:44 limodou Exp $

import os
import sys
import codecs
from ConfigParser import ConfigParser, NoOptionError, NoSectionError
import types

class IniFile(ConfigParser):
    def read(self, inifile):
        self.inifile=inifile
        if inifile:
            try:
                fp = file(self.inifile, 'r')
            except Exception,e:
                fp = None
            if fp:
                self.readfp(fp)
                fp.close()
         
    def write(self, fp):
        """Write an .ini-format representation of the configuration state."""
        if self._defaults:
            fp.write("[%s]\n" % DEFAULTSECT)
            for (key, value) in self._defaults.items():
                fp.write("%s = %s\n" % (key, self.strValue(value).replace('\n', '\n\t')))
            fp.write("\n")
        for section in self._sections:
            fp.write("[%s]\n" % section)
            for (key, value) in self._sections[section].items():
                if key != "__name__":
                    fp.write("%s = %s\n" % (key, self.strValue(value).replace('\n', '\n\t')))
            fp.write("\n")

    def strValue(self, value):
        if type(value) in [types.UnicodeType]:
            return value.encode('utf-8')
        else:
            return str(value)
