#coding: utf-8
import os
import re
import sys
import pickle
import traceback
import setting
import threadclass
import getdiskinfo
import utils
import diskbit
import gpioctl
import simplejson as json
from diskbitmap import baseboard
from checkdevice import digiraid4 as digiraid
from xml.dom.minidom import Document

lightstatus = ['missing','','fault','active','','locate']
#---------------------------
#decode command data
#---------------------------
def decodecmd (cmddata,checkqueue,diskqueue,snmpqueue):
    try:
        setting.errlogdata(setting.LINE(),'jobfun.py',cmddata)
        if cmddata['op'] == 'udev':
            udevcmdjob(cmddata,checkqueue,snmpqueue)
        if cmddata['op'] == 'scandisk':
            init_disk_state (checkqueue,diskqueue)
        if cmddata['op'] == 'filesystem':
            filecmdjob(cmddata,snmpqueue)
        #if cmddata['op'] == 'http':
        #    httpcmdjob(cmddata,checkqueue)
        if cmddata['op'] == 'mdmon':
            mdmoncmdjob(cmddata,checkqueue,diskqueue,snmpqueue)
    except:
        setting.errlogdata(setting.LINE(),'jobfun.py',traceback.print_exc())

def filecmdjob (cmddata,snmpqueue):
    try:
        errdatalist = []
        rtndata = {}
        errdisk = ''
        errdatalist = cmddata['param'].split(',')
        rtndata['op'] = cmddata['op']
        rtndata['node'] = errdatalist[0]
        rtndata['mountpoint'] = errdatalist[1]
        rtndata['event'] = errdatalist[2]
        #change_disk_state()
        cmd = '/bin/mount'
        retcode,proc = utils.cust_popen(cmd)
        filedatas = proc.stdout.readlines()
        for filedata in filedatas:
            if filedata.find(rtndata['mountpoint']) != -1:
                m = filedata.split(' ')
                errdisk = ((m[0].strip()).split('/'))[2]
        if errdisk != '':
            if errdisk.find('sd') != -1:
                if baseboard.check_device():
                    change_disk_state()
                    for expandersasaddress,expanderinfo in setting.NEWDISKBITMAP.iteritems():
                        for phyid,diskinfo in expanderinfo.disks.iteritems():
                            if diskinfo['diskdev'] == errdisk:
                                clear_light_state(phyid,expanderinfo.smpdevice)
                                set_light_state(lightstatus[2],phyid,expanderinfo.smpdevice)
                                rtndata['errdiskname'] = errdisk
                                rtndata['errdiskid'] = diskinfo['locateid']
                else:
                    rtndata['errdiskname'] = errdisk
                    diskid = digiraid.get_diskmap()
                    disks = diskid.digidisk.disknamemap
                    for disk in disks.keys():
                        if disk == rtndata['errdiskname']:
                            rtndata['errdiskid'] = disks[disk]
            else:
                rtndata['errdiskname'] = errdisk
        if not rtndata.has_key('errdiskname'):
            rtndata['errdiskname'] = 'None'
        if not rtndata.has_key('errdiskid'):
            rtndata['errdiskid'] = 'None'
        if setting.FILEERRLIST != {}:
            aaa = {}
            for erdiskkey in setting.FILEERRLIST:
                if erdiskkey != errdisk or setting.FILEERRLIST[erdiskkey] != rtndata['mountpoint']:
                    snmpqueue.put(rtndata)
                    aaa[errdisk] = rtndata['mountpoint']
            if aaa != {}:
                setting.FILEERRLIST.update(aaa)
        else:
            setting.FILEERRLIST[errdisk] = rtndata['mountpoint']
            snmpqueue.put(rtndata)
    except:
        setting.errlogdata(setting.LINE(),'jobfun.py',traceback.print_exc())


#---------------------------
#udev command job
#---------------------------
def udevcmdjob (cmddata,checkqueue,snmpqueue):
    try:
        disklist = []
        rtndata = {}
        if cmddata['event'] == 'add':
            if baseboard.check_device():
                change_disk_state()
                for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
                    for phyid,diskinfo in expanderinfo.disks.iteritems():
                        try:
                            if diskinfo['newdiskstate'] == 4:
                                rtndata['event'] = 'remove'
                                rtndata['param'] = diskinfo['diskdev']
                                rtndata['op'] = cmddata['op']
                            elif diskinfo['newdiskstate'] != 4:
                                rtndata['event'] = cmddata['event']
                                rtndata['param'] = diskinfo['diskdev']
                                rtndata['op'] = cmddata['op']
                            if rtndata['param'] == diskinfo['diskdev']:
                                rtndata['locateid'] = diskinfo['locateid']
                            if diskinfo['diskdev'] != None:
                                disklist.append('/dev/' + diskinfo['diskdev'])
                            if diskinfo['locate'] == True:
                                continue
                            if diskinfo['olddiskstate'] == 4 or (diskinfo['olddiskstate'] == '' and diskinfo['newdiskstate'] == 0):
                                set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
                            snmpqueue.put(rtndata)
                            rtndata = {}
                        except:
                            setting.errlogdata(setting.LINE(),'jobfun.py',traceback.print_exc())
            else:
                diskid = digiraid.get_diskmap()
                disks = diskid.digidisk.disknamemap
                setting.DISKID = {}
                setting.DISKID = disks.copy()
                for disk in disks.keys():
                    if disk == rtndata['param']:
                        rtndata['locateid'] = disks[disk]
                disklist.append('/dev/' + cmddata['param'])
            getdiskinfo.write_disk_raid_snmp_conf('add',disklist,setting.DISKCONF)
            checkqueue.put('check')
            #snmpqueue.put(rtndata)
        elif cmddata['event'] == 'remove':
            if baseboard.check_device():
                change_disk_state()
                for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
                    for phyid,diskinfo in expanderinfo.disks.iteritems():
                        try:
                            if diskinfo['newdiskstate'] == 4:
                                rtndata['event'] = cmddata['event']
                                rtndata['param'] = diskinfo['diskdev']
                                rtndata['op'] = cmddata['op']
                            elif diskinfo['newdiskstate'] == 0:
                                rtndata['event'] = 'add'
                                rtndata['param'] = diskinfo['diskdev']
                                rtndata['op'] = cmddata['op']
                            if rtndata['param'] == diskinfo['diskdev']:
                                rtndata['locateid'] = diskinfo['locateid']
                            if diskinfo['newdiskstate'] in [2,4]:
                                getdiskinfo.diskerrlog (diskinfo['oldraidname'],diskinfo['locateid'],diskinfo['diskdev'])
                            if diskinfo['diskdev'] != None:
                                disklist.append('/dev/' + diskinfo['diskdev'])
                            if diskinfo['oldraidname'] != None:
                                digiraid.get_raid_detail(diskinfo['oldraidname'])
                            if diskinfo['locate'] == True:
                                continue 
                            if diskinfo['newdiskstate'] == 4 and diskinfo['olddiskstate'] != 1:
                                clear_light_state(phyid,expanderinfo.smpdevice)
                            if diskinfo['olddiskstate'] == 4 or (diskinfo['olddiskstate'] == '' and diskinfo['newdiskstate'] == 0):
                                set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
                            snmpqueue.put(rtndata)
                            rtndata = {}
                        except:
                            setting.errlogdata(setting.LINE(),'jobfun.py',traceback.print_exc())
            else:
                for disk in setting.DISKID.keys():
                     if disk == rtndata['param']:
                         rtndata['locateid'] = setting.DISKID[disk]
                         diskid = digiraid.get_diskmap()
                         disks = diskid.digidisk.disknamemap
                         setting.DISKID = {}
                         setting.DISKID = disks.copy()
                disklist.append('/dev/' + cmddata['param'])
            getdiskinfo.write_disk_raid_snmp_conf('remove',disklist,setting.DISKCONF)
            checkqueue.put('check')
    except:
        setting.errlogdata(setting.LINE(),'jobfun.py',traceback.print_exc())


#---------------------------
#mdmon command job
#---------------------------
def mdmoncmdjob (cmddata,checkqueue,diskqueue,snmpqueue):
    try:
        rtndata = cmddata.copy()
        diskrtndata = {}
        if cmddata['event'] == 'Fail':
            change_disk_state()
            for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
                if baseboard.check_device():
                    for phyid,diskinfo in expanderinfo.disks.iteritems():
                        if diskinfo['newdiskstate'] == 4:
                            diskrtndata['event'] = 'remove'
                            diskrtndata['param'] = diskinfo['diskdev']
                            diskrtndata['op'] = 'udev'
                            diskrtndata['locateid'] = diskinfo['locateid']
                            snmpqueue.put(diskrtndata)
                        #if diskinfo['newdiskstate'] in [2,4]:
                            #getdiskinfo.diskerrlog (diskinfo['oldraidname'],diskinfo['locateid'],diskinfo['diskdev'])
                            #if diskinfo['newdiskstate'] == 2:
                                #record_err_raid(diskqueue,'raiderr',diskinfo['oldraidname'],diskinfo['diskdev'])
                            #if diskinfo['newdiskstate'] == 2:
                                #diskqueue.put(diskinfo['diskdev'])
                        if diskinfo['locate'] == True:
                            continue
                        if diskinfo['olddiskstate'] not in [1,4]:
                            clear_light_state(phyid,expanderinfo.smpdevice)
                        set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
                else:
                    for phyid,diskinfo in expanderinfo.disks.iteritems():
                        diskinfo['locateid'] = phyid
                        if diskinfo['newdiskstate'] in [-2]:
                            getdiskinfo.diskerrlog (diskinfo['oldraidname'],diskinfo['locateid'],diskinfo['diskdev'])
                            record_err_raid(diskqueue,'raiderr',diskinfo['oldraidname'],diskinfo['diskdev'])
            checkqueue.put('check')
            snmpqueue.put(rtndata)
        elif cmddata['event'] == 'FailSpare':
            change_disk_state()
            for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
                if baseboard.check_device():
                    for phyid,diskinfo in expanderinfo.disks.iteritems():
                        if diskinfo['newdiskstate'] == 4:
                            diskrtndata['event'] = 'remove'
                            diskrtndata['param'] = diskinfo['diskdev']
                            diskrtndata['op'] = 'udev'
                            diskrtndata['locateid'] = diskinfo['locateid']
                            snmpqueue.put(diskrtndata)
                        #if diskinfo['newdiskstate'] in [2,4]:
                            #getdiskinfo.diskerrlog (diskinfo['oldraidname'],diskinfo['locateid'],diskinfo['diskdev'])
                            #if diskinfo['newdiskstate'] == 2:
                                #record_err_raid(diskqueue,'raiderr',diskinfo['oldraidname'],diskinfo['diskdev'])
                                #diskqueue.put(diskinfo['diskdev'])
                        if diskinfo['oldraidname'] != None:
                            digiraid.get_raid_detail(diskinfo['oldraidname'])
                        if diskinfo['locate'] == True:
                            continue
                        if diskinfo['olddiskstate'] not in [1,4]:
                            clear_light_state(phyid,expanderinfo.smpdevice)
                        set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
                else:
                    for phyid,diskinfo in expanderinfo.disks.iteritems():
                        diskinfo['locateid'] = phyid
                        if diskinfo['newdiskstate'] in [-2]:
                            getdiskinfo.diskerrlog (diskinfo['oldraidname'],diskinfo['locateid'],diskinfo['diskdev'])
                            record_err_raid(diskqueue,'raiderr',diskinfo['oldraidname'],diskinfo['diskdev'])
            checkqueue.put('check')
            snmpqueue.put(rtndata)
        elif cmddata['event'] == 'RebuildStarted':
            change_disk_state()
            for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
                for phyid,diskinfo in expanderinfo.disks.iteritems():
                    if diskinfo['newdiskstate'] == 4:
                        diskrtndata['event'] = 'remove'
                        diskrtndata['param'] = diskinfo['diskdev']
                        diskrtndata['op'] = 'udev'
                        diskrtndata['locateid'] = diskinfo['locateid']
                        snmpqueue.put(diskrtndata)
                    if diskinfo['newdiskstate'] in [2,4]:
                        getdiskinfo.diskerrlog (diskinfo['oldraidname'],diskinfo['locateid'],diskinfo['diskdev'])
                        if diskinfo['newdiskstate'] == 2:
                            record_err_raid(diskqueue,'raiderr',diskinfo['oldraidname'],diskinfo['diskdev'])
                            #diskqueue.put(diskinfo['diskdev'])
                    if diskinfo['locate'] == True:
                        continue
                    clear_light_state(phyid,expanderinfo.smpdevice)
                    if diskinfo['newdiskstate'] not in [1,4]:
                        set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
            if raid_resync_or_recovery(rtndata['param']):
                rtndata['event'] = 'ResyncStarted'
            checkqueue.put('check')
            snmpqueue.put(rtndata)
        elif cmddata['event'] == 'RebuildFinished':
            #record_err_raid(diskqueue,'raidrebuild',cmddata['param'],None)
            checkqueue.put('check')
            snmpqueue.put(rtndata)
        elif cmddata['event'] == 'SpareActive':
            checkqueue.put('check')
            snmpqueue.put(rtndata)
        elif cmddata['event'] == 'NewArray':
            change_disk_state()
            for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
                for phyid,diskinfo in expanderinfo.disks.iteritems():
                    if diskinfo['newdiskstate'] == 4:
                        diskrtndata['event'] = 'remove'
                        diskrtndata['param'] = diskinfo['diskdev']
                        diskrtndata['op'] = 'udev'
                        diskrtndata['locateid'] = diskinfo['locateid']
                        snmpqueue.put(diskrtndata)
                    if diskinfo['locate'] == True:
                        continue
                    clear_light_state(phyid,expanderinfo.smpdevice)
                    if diskinfo['newdiskstate'] not in [1,4]:
                        set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
            checkqueue.put('check')
            snmpqueue.put(rtndata)
        elif cmddata['event'] == 'DeviceDisappeared':
            change_disk_state()
            for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
                for phyid,diskinfo in expanderinfo.disks.iteritems():
                    if diskinfo['newdiskstate'] == 4:
                        diskrtndata['event'] = 'remove'
                        diskrtndata['param'] = diskinfo['diskdev']
                        diskrtndata['op'] = 'udev'
                        diskrtndata['locateid'] = diskinfo['locateid']
                        snmpqueue.put(diskrtndata)
                    if diskinfo['locate'] == True:
                        continue
                    clear_light_state(phyid,expanderinfo.smpdevice)
                    if diskinfo['newdiskstate'] not in [1,4]:
                        set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
            checkqueue.put('check')
            snmpqueue.put(rtndata)
    except:
        setting.errlogdata(setting.LINE(),'jobfun.py',traceback.print_exc())

#---------------------------
#html command job
#---------------------------
def httpcmdjob (cmddata,checkqueue):
    raidlist = []
    if cmddata['action'] == 'createraid':
        change_disk_state()
        for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
            for phyid,diskinfo in expanderinfo.disks.iteritems():
                if diskinfo['locate'] == True:
                    continue
                if diskinfo['olddiskstate'] != 3:
                    clear_light_state(phyid,expanderinfo.smpdevice)
                else:
                    set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
        raidlist.append(cmddata['param']['raid'])
        getdiskinfo.write_disk_raid_snmp_conf('add',raidlist,setting.RAIDCONF)
        checkqueue.put('check')
        raidlist = []
    elif cmddata['action'] == 'delraid':
        raidlist.append(cmddata['param']['raid'])
        record_err_raid(None,'delraid',cmddata['param']['raid'],None)
        getdiskinfo.write_disk_raid_snmp_conf('remove',raidlist,setting.RAIDCONF)
        #checkqueue.put('check')
    elif cmddata['action'] == 'cleardisk':
        change_disk_state()
        for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
            if baseboard.check_device():
                for phyid,diskinfo in expanderinfo.disks.iteritems():
                    if diskinfo['locate'] == True:
                        continue
                    if diskinfo['olddiskstate'] not in [1,4]:
                        clear_light_state(phyid,expanderinfo.smpdevice)
                    set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
            else:
                if gpioctl.checkgpio() == True:
                    for phyid,diskinfo in expanderinfo.disks.iteritems():
                        if diskinfo['olddiskstate'] in [-2]:
                            gpioctl.setgpio(phyid,'high')
        checkqueue.put('check')
    elif cmddata['action'] == 'sethotspare':
        change_disk_state()
        for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
            for phyid,diskinfo in expanderinfo.disks.iteritems():
                if diskinfo['locate'] == True:
                    continue
                clear_light_state(phyid,expanderinfo.smpdevice)
        checkqueue.put('check')
    elif cmddata['action'] == 'extendraid':
        change_disk_state()
        for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
            for phyid,diskinfo in expanderinfo.disks.iteritems():
                if diskinfo['locate'] == True:
                    continue
                if diskinfo['olddiskstate'] not in [1,4]:
                    clear_light_state(phyid,expanderinfo.smpdevice)
                set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
        checkqueue.put('check')
    elif cmddata['action'] == 'del_hotspare':
        change_disk_state()
        for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
            for phyid,diskinfo in expanderinfo.disks.iteritems():
                if diskinfo['locate'] == True:
                    continue
                if diskinfo['olddiskstate'] not in [1,4]:
                    clear_light_state(phyid,expanderinfo.smpdevice)
                set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
        checkqueue.put('check')
    elif cmddata['action'] == 'activeraid':
        change_disk_state()
        for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
            for phyid,diskinfo in expanderinfo.disks.iteritems():
                if diskinfo['locate'] == True:
                    continue
                if diskinfo['newdiskstate'] in [1,4]:
                    clear_light_state(phyid,expanderinfo.smpdevice)
                else:
                    set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
        checkqueue.put('check')
    elif cmddata['action'] == 'remove_disk_from_raid':
        change_disk_state()
        for expandersasaddress,expanderinfo in setting.CHANGDISKBITMAP.iteritems():
            for phyid,diskinfo in expanderinfo.disks.iteritems():
                if diskinfo['locate'] == True:
                    continue
                if diskinfo['olddiskstate'] not in [1,4]:
                    clear_light_state(phyid,expanderinfo.smpdevice)
                set_light_state(lightstatus[diskinfo['newdiskstate']],phyid,expanderinfo.smpdevice)
        checkqueue.put('check')
    elif cmddata['action'] == 'locate':
        change_disk_state()
        for expandersasaddress,expanderinfo in setting.NEWDISKBITMAP.iteritems():
            for phyid,diskinfo in expanderinfo.disks.iteritems():
                if cmddata['param']['disk'] == diskinfo['diskdev']:
                    if diskinfo['diskstate'] not in [1,4]:
                        clear_light_state(phyid,expanderinfo.smpdevice)
                    set_light_state(lightstatus[5],phyid,expanderinfo.smpdevice)
                    setting.OLDDISKBITMAP['%s' % expandersasaddress]['disks']['%s' % phyid]['locate'] = True
                    break
    elif cmddata['action'] == 'unlocate':
        change_disk_state()
        for expandersasaddress,expanderinfo in setting.NEWDISKBITMAP.iteritems():
            for phyid,diskinfo in expanderinfo.disks.iteritems():
                if cmddata['param']['disk'] == diskinfo['diskdev']:
                    clear_light_state(phyid,expanderinfo.smpdevice)
                    if diskinfo['diskstate'] not in [1,4]:
                        set_light_state(lightstatus[diskinfo['diskstate']],phyid,expanderinfo.smpdevice)
                    setting.OLDDISKBITMAP['%s' % expandersasaddress]['disks']['%s' % phyid]['locate'] = False
                    break
    elif cmddata['action'] == 'beep':
        if cmddata['event'] == 'stop':
            if os.path.exists(setting.BEEP) == False:
                os.makedirs(setting.BEEP)
            cmd = setting.TOUCH + ' ' + setting.BEEPSTOP
            retcode,proc = utils.cust_popen(cmd)
            if retcode != 0:
                setting.errlogdata(setting.LINE(),'jobfun.py',proc.stdout.readlines())
        if cmddata['event'] == 'start':
            if os.path.exists(setting.BEEPSTOP) == True:
                cmd = setting.RM + ' ' + setting.BEEPSTOP
                retcode,proc = utils.cust_popen(cmd)
                if retcode != 0:
                    setting.errlogdata(setting.LINE(),'jobfun.py',proc.stdout.readlines())
#---------------------------
# init disk state
# --------------------------
def init_disk_state (checkqueue,diskqueue):
    disklist = []
    raidlist = []
    errdisk = []
    change_disk_state()
    for expandersasaddress,expanderinfo in setting.NEWDISKBITMAP.iteritems():
        if baseboard.check_device() == True:
            for phyid,diskinfo in expanderinfo.disks.iteritems():
                if diskinfo['diskstate'] in [2,4]:
                    errdisk.append(diskinfo)
                if diskinfo['diskdev'] != None:
                    disklist.append('/dev/' + diskinfo['diskdev'])
                if diskinfo['raidname'] != None and (diskinfo['raidname'] not in raidlist):
                    raidlist.append(diskinfo['raidname'])
                clear_light_state (phyid,expanderinfo.smpdevice)
                if diskinfo['diskstate'] in [1,4]:
                    continue
                else:
                    set_light_state(lightstatus[diskinfo['diskstate']],phyid,expanderinfo.smpdevice)
        else:
            diskid = digiraid.get_diskmap()
            disks = diskid.digidisk.disknamemap
            setting.DISKID = disks.copy()
            for phyid,diskinfo in expanderinfo.disks.iteritems():
                diskinfo['locateid'] = phyid
                if diskinfo['diskstate'] in [-2]:
                    errdisk.append(diskinfo)
                    #gpioctl.setgpio(phyid,'low')
                if diskinfo['diskdev'] != None:
                    disklist.append('/dev/' + diskinfo['diskdev'])
                if diskinfo['raidname'] != None and (diskinfo['raidname'] not in raidlist):
                    raidlist.append(diskinfo['raidname'])  
    getdiskinfo.write_disk_raid_snmp_conf('init',disklist,setting.DISKCONF)
    getdiskinfo.write_disk_raid_snmp_conf('init',raidlist,setting.RAIDCONF)
    getdiskinfo.update_disk_raid_snmp(setting.DISKCMD)
    getdiskinfo.update_disk_raid_snmp(setting.RAIDCMD)
    for data in errdisk:
        getdiskinfo.diskerrlog (data['raidname'],data['locateid'],data['diskdev'])
    checkqueue.put('check')
#---------------------------
# build xml data
# --------------------------
def build_xml (xmldata):
    dom = Document()
    message = dom.createElement('Message')
    message.setAttribute('Type','MSG_RAID_DISK_LINK_ERROR_NOTIFY')
    dom.appendChild(message)
    deverrlist = dom.createElement('DevErrList')
    message.appendChild(deverrlist)
    i = 0
    for data in xmldata:
        listdata = data.split('<br />')
        errlist = dom.createElement('Errlist%s' %i)
        deverrlist.appendChild(errlist)
        errlist.setAttribute('Mathine', listdata[0][:-1])
        errlist.setAttribute('Time', listdata[1])
        o = p = q = 0
        for j in range(2,len(listdata)):
            errcode = listdata[j].split(' ')
            if errcode[1] == 'RAID':
                raiderr = dom.createElement('Raid%s' %o)
                errlist.appendChild(raiderr)
                raiderr.setAttribute('Name',errcode[2])
                raiderr.setAttribute('Device',errcode[3][1:-1])
                raiderr.setAttribute('Stauts',errcode[5])
                raiderr.setAttribute('Desp','')
                o = o + 1
            elif errcode[1] == 'disk':
                diskerr = dom.createElement('Disk%s' %p)
                errlist.appendChild(diskerr)
                diskerr.setAttribute('DiskID',errcode[3])
                diskerr.setAttribute('DiskDevice',errcode[4][1:-1])
                diskerr.setAttribute('Stauts',errcode[6])
                if errcode[4][6:-1] == 'None':
                    diskerr.setAttribute('Desp','No Disk')
                elif errcode[4][1:-2] == 'sd':
                    if errcode[6] == 'droped':
                        diskerr.setAttribute('Desp','Disk droped')
                    else:
                        diskerr.setAttribute('Desp','Disk added')
                else:
                    diskerr.setAttribute('Desp','Disk broken')
                p = p + 1
            else:
                neterr = dom.createElement('Net%s' %q)
                errlist.appendChild(neterr)
                neterr.setAttribute('Name',errcode[0])
                neterr.setAttribute('Stauts',errcode[4])
                neterr.setAttribute('Desp','NIC Link is Down')
                q = q + 1 
        i = i + 1
    xml = dom.toprettyxml(encoding='utf-8')
    rtndata = "HTTP/1.1 200 OK\r\nContent-Type: applition/xml\r\nContent-Length: %d\r\n\r\n%s" %(len(xml), xml) 
    return rtndata

#---------------------------
# build raid xml data
#---------------------------
def build_raidxml(xmldata):
    raidflag=False
    dom = Document()
    message = dom.createElement('Message')
    message.setAttribute('Type','MSG_RAID_DAMAGE_NOTIFY')
    dom.appendChild(message)
    deverrlist = dom.createElement('RaidList')
    message.appendChild(deverrlist)
    for data in xmldata:
        listdata = data.split('<br />')
        for j in range(2,len(listdata)):
            errcode = listdata[j].split(' ')
            if errcode[1] == 'RAID':
                raidflag = True
                raiderr = dom.createElement('Raid')
                deverrlist.appendChild(raiderr)
                raiderr.setAttribute('Name',errcode[2])
                #raiderr.setAttribute('Device',errcode[3][1:-1])
                if(errcode[5]=="alert"):
                    raiderr.setAttribute('Stauts',"1")
                elif(errcode[5]=="error"):
                    raiderr.setAttribute('Stauts',"2")
                raiderr.setAttribute('Desp','')
    if raidflag == False:
        return "error"
    xml = dom.toprettyxml(encoding='utf-8')
    rtndata = "POST /messagequery HTTP/1.1\r\nHost: 0.0.0.0:80 Accept: */* Content-Type: text/xml Content-Length:%d\r\n\r\n%s" %(len(xml), xml)
    return rtndata

#---------------------------
#build disk xml data
#---------------------------
def build_diskxml (xmldata):
    dom = Document()
    message = dom.createElement('Message')
    message.setAttribute('Type','MSG_DISK_EXCEPTION')
    dom.appendChild(message)
    for key in xmldata:
        diskerrlist = dom.createElement('Disk')
        message.appendChild(diskerrlist)
        diskerrlist.setAttribute('Name',key)
        diskerrlist.setAttribute('Type',xmldata[key]['error'])
        diskerrlist.setAttribute('Path','/dev/'+ key)
        diskerrlist.setAttribute('Termperature',xmldata[key]['temp'])
        diskerrlist.setAttribute('Rotate',xmldata[key]['rate'])
    xml = dom.toprettyxml(encoding='utf-8')
    rtndata = "POST /messagequery HTTP/1.1\r\nHost: 0.0.0.0:80 Accept: */* Content-Type: text/xml Content-Length:%d\r\n\r\n%s" %(len(xml), xml)
    return rtndata

#---------------------------
# build disk state xml
#---------------------------
def build_diskstate_xml(xmldata):
    dom = Document()
    message = dom.createElement('Message')
    message.setAttribute('Type','MSG_DISK_PRE_FAIL')
    dom.appendChild(message)
    for key in xmldata:
        diskerrlist = dom.createElement('Disk')
        message.appendChild(diskerrlist)
        diskerrlist.setAttribute('Name',key)
        #diskerrlist.setAttribute('Type',xmldata[key]['error'])
        diskerrlist.setAttribute('Path','/dev/'+ key)
        #diskerrlist.setAttribute('State',xmldata[key]['state'])
        diskerrlist.setAttribute('RAW_VALUE',xmldata[key]['count'])
    xml = dom.toprettyxml(encoding='utf-8')
    rtndata = "POST /messagequery HTTP/1.1\r\nHost: 0.0.0.0:80 Accept: */* Content-Type: text/xml Content-Length:%d\r\n\r\n%s" %(len(xml), xml)
    return rtndata
    
#---------------------------
# clear light state
# --------------------------
def clear_light_state (phyid,smpdevice):
    if baseboard.check_device():
        for light in lightstatus:
            if light == '':
                continue 
            clearcmd = 'sg_ses --clear=%s --index %s /dev/%s' % (light,phyid,smpdevice)
            retcode,proc = utils.cust_popen(clearcmd)
            if retcode != 0:
                setting.errlogdata(setting.LINE(),'jobfun.py','command:"' + clearcmd + '" error')
#---------------------------
# set light state
# --------------------------
def set_light_state (light,phyid,smpdevice):
    if baseboard.check_device() and light == 'fault':
        setcmd = 'sg_ses --set=%s --index %s /dev/%s' % (light,phyid,smpdevice)
        retcode,proc = utils.cust_popen(setcmd)
        if retcode != 0:
            setting.errlogdata(setting.LINE(),'jobfun.py','command:"' + setcmd + '" error')
#---------------------------
#change diskmap state
#---------------------------
def change_disk_state ():
    setting.NEWDISKBITMAP,setting.CHANGDISKBITMAP = diskbit.get_disk_bitmap(olddiskbitmap=setting.OLDDISKBITMAP)
    setting.errlogdata(setting.LINE(),'jobfun.py','NEWDISKBITMAP:' + str(setting.NEWDISKBITMAP))
    setting.errlogdata(setting.LINE(),'jobfun.py','OLDDISKBITMAP:' + str(setting.OLDDISKBITMAP))
    setting.errlogdata(setting.LINE(),'jobfun.py','CHANGDISKBITMAP:' + str(setting.CHANGDISKBITMAP))
    setting.OLDDISKBITMAP = setting.NEWDISKBITMAP

'''
    print '****NEWDISKBITMAP****************'
    print setting.NEWDISKBITMAP
    print '*********************************'


    print '****CHANGDISKBITMAP**************'
    print setting.CHANGDISKBITMAP
    print '*********************************'


    print '****OLDDISKBITMAP****************'
    print setting.OLDDISKBITMAP
    print '*********************************'
'''


#----------------------------
#read udp,xml configure
#----------------------------
def read_udp_xml_conf ():
    udpalertmathines = []
    xmlalertmathines = []
    if os.path.isfile(setting.udpserver):
        try:
            f = open(setting.udpserver,'r')
            udpalert = pickle.load(f)
            f.close()
            for udpalertdata in udpalert:
                if udpalertdata['inuse'] == True:
                    udpalertmathines.append(udpalertdata)
        except:
            print >> sys.stderr,traceback.print_exc()
    if os.path.isfile(setting.xmlserver):
        try:
            f=open(setting.xmlserver,'r')
            xmlalert = pickle.load(f)
            f.close()
            for xmlalertdata in xmlalert:
                if xmlalertdata['inuse'] == True:
                    xmlalertmathines.append(xmlalertdata)
        except:
            print >> sys.stderr,traceback.print_exc()
    return udpalertmathines,xmlalertmathines

#----------------------------
#read snmp conf
#----------------------------
def read_snmp_conf():
    snmpalertmathines = []
    if os.path.isfile(setting.snmpserver):
        try:
            f = open(setting.snmpserver,'r')
            snmpalert = pickle.load(f)
            f.close()
            for snmpalertdata in snmpalert:
                if snmpalertdata['inuse'] == True:
                    snmpalertmathines.append(snmpalertdata)
        except:
            print >> sys.stderr,traceback.print_exc()
    return snmpalertmathines


#----------------------------
#check raid list
#----------------------------
def raid_list ():
    raiddata = {}
    digistow = digiraid.get_diskmap()
    diskidmap = digistow.digidisk.diskidmap
    if baseboard.check_device():
        diskdevs = digiraid.get_disk_info2()
        cabinetcount,expanderidmap,expanderdisks = baseboard.get_cabinet_info()
    else:
        diskdevs = digiraid.get_disk_info()
        cabinetcount,expanderidmap,expanderdisks = (0,{},{})
    raiddevs = digiraid.get_raid_info()
    #cabinetcount,expanderidmap,expanderdisks = baseboard.get_cabinet_info()
    #raidids = raiddevs.keys()
    #raidids.sort()
    disresult = digiraid.get_raid_process()
    raiddata['diskidmap'] = diskidmap
    raiddata['diskdevs'] = diskdevs
    raiddata['raiddevs'] = raiddevs
    raiddata['cabinetcount'] = cabinetcount
    raiddata['expanderidmap'] = expanderidmap
    raiddata['expanderdisks'] = expanderdisks
    raiddata['disresult'] = disresult
    return digistow,raiddata

def write_digistow (digistow):
    try:
        if os.path.isfile(setting.DIGISTOWFILE) == False:
            os.mknod(setting.DIGISTOWFILE)
        f = open(setting.DIGISTOWFILE,'w')
        f.write(digistow)
        f.flush()
        f.close()
        return 1
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        return 0


def record_err_raid (diskqueue,flag,raidname,diskname):
    try:
        '''
        if raidname.find('/dev/') == -1:
            raidname = '/dev/' + raidname
        if flag == 'raiderr':
            if setting.REBUILDRAID == {}:
                setting.REBUILDRAID[raidname] = [diskname]
            else:
                if raidname in setting.REBUILDRAID.keys():
                    setting.REBUILDRAID[raidname].append(diskname)
                else:
                    setting.REBUILDRAID[raidname] = [diskname]
        elif flag == 'raidrebuild':
            if raidname in setting.REBUILDRAID.keys():
                getdiskinfo.update_disk_raid_snmp(setting.RAIDCMD)
                raidstate = getdiskinfo.get_raid_state (raidname)
                if raidstate == 'active':
                    for disk in setting.REBUILDRAID[raidname]:
                        diskqueue.put(disk)
                    del setting.REBUILDRAID[raidname]
        elif flag == 'delraid':
            if raidname in setting.REBUILDRAID.keys():
                del setting.REBUILDRAID[raidname]
        '''
        pass
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        return 0

def judge_sms_conf_empty():
    if os.path.isfile(setting.alertsms):
        try:
            f = open(setting.alertsms,'r')
            smsalertinfos = pickle.load(f)
            f.close()
            if 'inuse' in smsalertinfos and not smsalertinfos['inuse'] and 'mobp' in smsalertinfos and not smsalertinfos['mobp'] and 'smsp' in smsalertinfos and smsalertinfos['smsp']:
                return False
            else:
                return True
        except:
            print >> sys.stderr,traceback.print_exc()
            return False
    else:
        return False

def judge_mail_conf_empty():
    if os.path.isfile(setting.alertmail):
        try:
            f = open(setting.alertmail,'r')
            mailinfos = pickle.load(f)
            f.close()
            if not mailinfos:
                return False
            else:
                return True
        except:
            print >> sys.stderr,traceback.print_exc()
            return False
    else:
        return False

def judge_snmptrap_conf_empty():
    if os.path.isfile(setting.snmpserver):
        try:
            f = open(setting.snmpserver,'r')
            snmptrapinfos = pickle.load(f)
            f.close()
            if not snmptrapinfos:
                return False
            else:
                return True
        except:
            print >> sys.stderr,traceback.print_exc()
            return False
    else:
        return False

def raid_resync_or_recovery(raidname):
    try:
        f = open('/root/mdstat','r')
        result = f.readlines()
        for i in range(len(result)):
            if re.search(raidname,result[i]):
                j = 1
                while 1:
                    if result[i+j].find('md') >= 0:
                        break
                    if result[i+j].find('resync') >= 0:
                        return True
                    j = j+1
        return False
    except:
        print >> sys.stderr,traceback.print_exc()
        return False
