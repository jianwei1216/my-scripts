#!/usr/bin/python
import os
import sys
import time
import json
import traceback
import logging
from log import Log
import logging.config

filepath = "/etc/digioceanfs_manager/reports/"

def digi_logger(msgStr, lvl=7):
    Log()
    logger = logging.getLogger("digiServer")
    if lvl == 2:
        logger.critical(msgStr)
    elif lvl == 3:
        logger.error(msgStr)
    elif lvl == 4:
        logger.warn(msgStr)
    elif lvl == 5:
        logger.info(msgStr)
    elif lvl == 6 or lvl == 7:
        logger.debug(msgStr)
    else:
        logger.error(msgStr)


def getdata ():
    rtndata = {}
    datas = sys.stdin.readlines()
    digi_logger("DigiServer: receive from snmptrapd: %s" % datas,7)
    if datas == []:
        return rtndata
    rtndata['SourceNode'] = datas[0].strip()
    m = datas[1].split(':')
    rtndata['SourceIp'] = (m[1].strip())[1:-1]
    if datas[3].find('DiskDropEntry') != -1:
        rtndata['OP'] = 'DiskEvent'
        rtndata['CTime'] = ''
        rtndata['ErrNode'] = rtndata['SourceNode']
        rtndata['DiskName'] = ''
        rtndata['DiskID'] = ''
        rtndata['DiskEvent'] = ''
        for data in datas:
            if data.find('DiskDropDevName') != -1:
                del rtndata['DiskName']
                a = data.find(' ')
                rtndata['DiskName'] = data[a:].strip()
            if data.find('DiskDropCTime') != -1:
                del rtndata['CTime']
                a = data.find(' ')
                rtndata['CTime'] = data[a:].strip()
            if data.find('DiskDropDevID') != -1:
                del rtndata['DiskID']
                a = data.find(' ')
                rtndata['DiskID'] = data[a:].strip()
            if data.find('DiskDropEvent') != -1:
                del rtndata['DiskEvent']
                a = data.find(' ')
                rtndata['DiskEvent'] = data[a:].strip()
    elif datas[3].find('RaidFailEntry') != -1:
        rtndata['OP'] = 'RaidEvent'
        rtndata['CTime'] = ''
        rtndata['ErrNode'] = rtndata['SourceNode']
        rtndata['RaidName'] = ''
        rtndata['RaidDisk'] = ''
        rtndata['RaidEvent'] = ''
        for data in datas:
            if data.find('RaidFailRaidName') != -1:
                del rtndata['RaidName']
                a = data.find(' ')
                rtndata['RaidName'] = data[a:].strip()
            if data.find('RaidFailCTime') != -1:
                del rtndata['CTime']
                a = data.find(' ')
                rtndata['CTime'] = data[a:].strip()
            if data.find('RaidFailDiskName') != -1:
                del rtndata['RaidDisk']
                a = data.find(' ')
                rtndata['RaidDisk'] = data[a:].strip()
            if data.find('RaidFailEvent') != -1:
                del rtndata['RaidEvent']
                a = data.find(' ')
                rtndata['RaidEvent'] = data[a:].strip()
    elif datas[3].find('FileWarningEntry') != -1:
        rtndata['OP'] = 'FileSystemEvent'
        rtndata['CTime'] = ''
        rtndata['ErrNode'] = ''
        rtndata['FileMountPoint'] = ''
        rtndata['ErrDiskName'] = ''
        rtndata['ErrDiskID'] = ''
        rtndata['FileEvent'] = ''
        for data in datas:
            if data.find('FileWarningNode') != -1:
                del rtndata['ErrNode']
                a = data.find(' ')
                rtndata['ErrNode'] = data[a:].strip()
            if data.find('FileWarningCTime') != -1:
                del rtndata['CTime']
                a = data.find(' ')
                rtndata['CTime'] = data[a:].strip()
            if data.find('FileWarningMountPoint') != -1:
                del rtndata['FileMountPoint']
                a = data.find(' ')
                rtndata['FileMountPoint'] = data[a:].strip()
            if data.find('FileWarningDiskName') != -1:
                del rtndata['ErrDiskName']
                a = data.find(' ')
                rtndata['ErrDiskName'] = data[a:].strip()
            if data.find('FileWarningDiskID') != -1:
                del rtndata['ErrDiskID']
                a = data.find(' ')
                rtndata['ErrDiskID'] = data[a:].strip()
            if data.find('FileWarningEvent') != -1:
                del rtndata['FileEvent']
                a = data.find(' ')
                rtndata['FileEvent'] = data[a:].strip()
    elif datas[3].find('PingEntry') != -1:
        rtndata['OP'] = 'Ping'
        rtndata['CTime'] = ''
        rtndata['ErrNode'] = ''
        rtndata['PingIP'] = ''
        rtndata['Event'] = ''
        for data in datas:
            if data.find('PingNode') != -1:
                del rtndata['ErrNode']
                a = data.find(' ')
                rtndata['ErrNode'] = data[a:].strip()
            if data.find('PingCTime') != -1:
                del rtndata['CTime']
                a = data.find(' ')
                rtndata['CTime'] = data[a:].strip()
            if data.find('PingIP') != -1:
                del rtndata['PingIP']
                a = data.find(' ')
                rtndata['PingIP'] = data[a:].strip()
            if data.find('PingEvent') != -1:
                del rtndata['Event']
                a = data.find(' ')
                rtndata['Event'] = data[a:].strip()
    elif datas[3].find('SystemdiskEntry') != -1:
        rtndata['OP'] = 'Systemdisk'
        rtndata['ErrNode'] = rtndata['SourceNode']
        rtndata['CTime'] = ''
        rtndata['DirName'] = ''
        rtndata['Falg'] = ''
        rtndata['Used'] = ''
        for data in datas:
            if data.find('SystemdiskDir') != -1:
                del rtndata['DirName']
                a = data.find(' ')
                rtndata['DirName'] = data[a:].strip()
            if data.find('SystemdiskCTime') != -1:
                del rtndata['CTime']
                a = data.find(' ')
                rtndata['CTime'] = data[a:].strip()
            if data.find('SystemdiskFlag') != -1:
                del rtndata['Falg']
                a = data.find(' ')
                rtndata['Falg'] = data[a:].strip()
            if data.find('SystemdiskUsed') != -1:
                del rtndata['Used']
                a = data.find(' ')
                rtndata['Used'] = data[a:].strip()
    elif datas[3].find('NetLinkEntry') != -1:
        rtndata['OP'] = 'NetLink'
        rtndata['CTime'] = ''
        rtndata['ErrNode'] = rtndata['SourceNode']
        rtndata['Eth'] = ''
        rtndata['Event'] = ''
        for data in datas:
            if data.find('NetLinkCTime') != -1:
                del rtndata['CTime']
                a = data.find(' ')
                rtndata['CTime'] = data[a:].strip()
            if data.find('NetLinkEth') != -1:
                del rtndata['Eth']
                a = data.find(' ')
                rtndata['Eth'] = data[a:].strip()
            if data.find('NetLinkEvent') != -1:
                del rtndata['Event']
                a = data.find(' ')
                rtndata['Event'] = data[a:].strip()
    elif datas[3].find('DiskTempEntry') != -1:
        rtndata['OP'] = 'DiskTemp'
        rtndata['ErrNode'] = rtndata['SourceNode']
        rtndata['CTime'] = ''
        rtndata['DiskName'] = ''
        rtndata['Falg'] = ''
        rtndata['Temp'] = ''
        for data in datas:
            if data.find('DiskTempDevName') != -1:
                del rtndata['DiskName']
                a = data.find(' ')
                rtndata['DiskName'] = data[a:].strip()
            if data.find('DiskTempCTime') != -1:
                del rtndata['CTime']
                a = data.find(' ')
                rtndata['CTime'] = data[a:].strip()
            if data.find('DiskTempEvent') != -1:
                del rtndata['Falg']
                a = data.find(' ')
                rtndata['Falg'] = data[a:].strip()
            if data.find('DiskTempDevTemp') != -1:
                del rtndata['Temp']
                a = data.find(' ')
                rtndata['Temp'] = data[a:].strip()
    elif datas[3].find('SysMsgEntry') != -1:
        rtndata['OP'] = 'SysMsg'
        rtndata['ErrNode'] = rtndata['SourceNode']
        rtndata['CTime'] = ''
        rtndata['MsgName'] = ''
        rtndata['Falg'] = ''
        rtndata['Value'] = ''
        for data in datas:
            if data.find('SysMsgDevName') != -1:
                del rtndata['MsgName']
                a = data.find(' ')
                rtndata['MsgName'] = data[a:].strip()
            if data.find('SysMsgCTime') != -1:
                del rtndata['CTime']
                a = data.find(' ')
                rtndata['CTime'] = data[a:].strip()
            if data.find('SysMsgEvent') != -1:
                del rtndata['Falg']
                a = data.find(' ')
                rtndata['Falg'] = data[a:].strip()
            if data.find('SysMsgDevMsg') != -1:
                del rtndata['Value']
                a = data.find(' ')
                rtndata['Value'] = data[a:].strip()
    
    #For digiserver test
    elif datas[3].find('TestStateEntry') != -1:
        pass
    return rtndata

def writefile ():
    if os.path.exists(filepath) == False:
        os.mkdir(filepath)
    try:
        data = getdata()
    except Exception,e:
        digi_logger("DigiServer: %s" % traceback.print_exc(), 3)
    if data == {}:
        return
    writedata = json.dumps(data)
    if data['SourceNode'].find('UNKNOWN') != -1:
        return
    filename = filepath + data['SourceNode'] + '_' + str(time.time())
    f = open(filename,'w')
    f.write(writedata)
    f.flush()
    f.close()

if __name__ == '__main__':
    writefile()



