#coding: utf-8
import os
import sys
import time
import platform
import traceback
import subprocess
import re
from ConfigParser import ConfigParser
currpath = '/usr/local/digitools'
#logpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
logpath = '/usr/local/digiserver'
if logpath not in sys.path:
    sys.path.append(logpath)
if not os.path.exists(os.path.join(logpath,'log')):
    os.mkdir(os.path.join(logpath,'log'))
stdout = os.path.join(logpath,'log/app.log')
errlog = os.path.join(logpath,'log/err.log')
monitorlog = '/var/log/monitor.log'
chmonitorlog = '/var/log/chmonitor.log'
confpath = os.path.join(currpath,'conf')
alertmail = os.path.join(confpath,'alertmail')
alertsms = os.path.join(confpath,'alertsms')
alertsmtp = os.path.join(confpath,'alertsmtp')
xmlserver = os.path.join(confpath,'xmlalertmathine')
udpserver = os.path.join(confpath,'udpalertmathine')
snmpserver = os.path.join(confpath,'snmptrapip')
sysdiskconf = os.path.join(confpath,'sysdiskstate')
mailswaparea = []
oldmaileventlist = []
oldnetmaileventlist = []
OLDERRDISK = []
HTTPCHANGEFLAG = []
IFACEDATA = []
SPEEDDATA = []
PINGDATA = []
MANAGENODEIP = {}
NEWDISKBITMAP = {}
OLDDISKBITMAP = {}
CHANGDISKBITMAP = {}
DISKID = {}
FILEERRLIST = {}
DIGISTOW = {}
RAIDLISTDATA = ''
NODEMANGEFLAG = True
NODERESTARTFLAG = True
CHECKNETTIME = 3600 #second
BEEPFLAG = False
SYSBEEPFLAG = False
DIGISTOWFILE = '/tmp/digistow'
IPFILEADDR = '/etc/hosts'
DISKCONF = '/etc/snmpd-smartctl-connector'
RAIDCONF = '/etc/snmpd-mdraid-connector'
DISKCMD = '/usr/sbin/update-smartctl-cache' 
RAIDCMD = '/usr/sbin/update-mdraid-cache'
NODEMANAGE = '/usr/bin/node-manager'
MDADM = '/sbin/mdadm'
BEEPFLAGCONF = '/usr/local/digiserver/conf/beepflag.conf'
BEEPSTOP = '/tmp/beepflag/beepstop'
BEEPING = '/tmp/beepflag/beeping'
REBUILDRAID = {}
BEEP = '/tmp/beepflag'
DD = '/bin/dd'
DF = '/bin/df'
RM = '/bin/rm'
TOUCH = '/bin/touch'
LSMOD = '/bin/lsmod'
CAT = '/bin/cat'
PING = '/bin/ping'
TOP = '/usr/bin/top'
EVENTRAIDNAME = ''
RAIDSTATE = []
DEBUG = False

def LINE ():
    return traceback.extract_stack()[-2][1]

def errlogdata (line,module,errdata = None):
    if DEBUG == True:
        if os.path.isfile(errlog) == False:
            os.mknod(errlog)
        nowtime = time.strftime("%Y-%m-%d %X")
        if errdata is None:
            err_data = '%s %s [line:%s]: ' %(nowtime,module,line)
            f = open(errlog,'a')
            f.write(err_data)
            traceback.print_exc(file = f)
            f.flush()
            f.close()
        else:
            #print >> sys.stderr,'%s %s [line:%s]: %s' %(nowtime,module,line,errdata)
            err_data = '%s %s [line:%s]: %s\n' %(nowtime,module,line,errdata)
            f = open(errlog,'a')
            f.write(err_data)
            #traceback.print_exc(file = f)
            f.flush()
            f.close()

def diskerrdata(raidname,diskid,diskname,model,serial):
    nowtime = time.strftime("%Y-%m-%d %X")
    if diskname != None:
        err_data = '%s DiskID:%s,Raid:%s,Disk:%s,Model:%s,Serial:%s\n' %(nowtime,diskid,raidname,diskname,model,serial)
        cherr_data = '%s ���̺�:%s,Raid:%s,��������:%s,�����ͺ�:%s,�������к�:%s\n' %(nowtime,diskid,raidname,diskname,model,serial)
    else:
        err_data = '%s DiskID:%s,Raid:%s,Disk:%s,Disk Lost!\n' %(nowtime,diskid,raidname,diskname)
        cherr_data = '%s ���̺�:%s,Raid:%s,��������:%s,���̶�ʧ!\n' %(nowtime,diskid,raidname,diskname)
    if os.path.isfile(monitorlog) == False:
        os.mknod(monitorlog)
    f = open(monitorlog,'a+')
    f.write(err_data)
    f.flush()
    f.close()
    if os.path.isfile(chmonitorlog) == False:
        os.mknod(chmonitorlog)
    f = open(chmonitorlog,'a+')
    f.write(cherr_data)
    f.flush()
    f.close()

def iperrdata (errdata,flag):
    nowtime = time.strftime("%Y-%m-%d %X")
    err_data = '%s %s\n' %(nowtime,errdata)
    if flag == 'en':
        if os.path.isfile(monitorlog) == False:
            os.mknod(monitorlog)
        f = open(monitorlog,'a+')
        f.write(err_data)
        f.flush()
        f.close()
    else:
        if os.path.isfile(chmonitorlog) == False:
            os.mknod(chmonitorlog)
        f = open(chmonitorlog,'a+')
        f.write(err_data)
        f.flush()
        f.close()
