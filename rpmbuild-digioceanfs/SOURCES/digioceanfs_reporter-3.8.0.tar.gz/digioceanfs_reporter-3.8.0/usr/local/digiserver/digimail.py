#!/usr/bin/python
#-*- coding: UTF-8 -*-

import os
import sys
import pickle
import smtplib
import mimetypes
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.mime.audio import MIMEAudio
from email.mime.image import MIMEImage
from email.Utils import COMMASPACE, formatdate
from email import Encoders

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if currpath not in sys.path:
    sys.path.append(currpath)
import setting
import utils
#-----------------------------
# globals
#-----------------------------
def send_mail(
        send_to=['to@test.com'],
        subject='test',
        text='this is a test mail',
        files=[],
        smtpsetting={
            'send_from':'noreply@perabytes.com',
            'host':'mail.perabytes.com',
            'port':25,
            'starttls':False,
            'auth_required':False,
            'name':'',
            'passwrod':''
        }
    ):
    msg = MIMEMultipart()
    msg['From'] = smtpsetting['send_from']
    msg['To'] = COMMASPACE.join(send_to)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject
    msg.attach(MIMEText(text,'html'))
    if files:
        for file in files:
            try:
                ctype, encoding = mimetypes.guess_type(file)
                if ctype is None or encoding is not None:
                    # No guess could be made, or the file is encoded (compressed), so
                    # use a generic bag-of-bits type.
                    ctype = 'application/octet-stream'
                maintype, subtype = ctype.split('/', 1)
                if maintype == 'text':
                    fp = open(file)
                    # Note: we should handle calculating the charset
                    part = MIMEText(fp.read(), _subtype=subtype)
                    fp.close()
                elif maintype == 'image':
                    fp = open(file, 'rb')
                    part = MIMEImage(fp.read(), _subtype=subtype)
                    fp.close()
                elif maintype == 'audio':
                    fp = open(file, 'rb')
                    part = MIMEAudio(fp.read(), _subtype=subtype)
                    fp.close()
                else:
                    fp = open(file, 'rb')
                    part = MIMEBase(maintype, subtype)
                    part.set_payload(fp.read())
                    fp.close()
                    # Encode the payload using Base64
                    Encoders.encode_base64(part)
                # Set the filename parameter
                part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(file))
                msg.attach(part)
            except Exception,e:
                errmsg = "%s" % e.__str__ + ' : ' + ','.join([str(arg) for arg in e.args])
                errmsg = errmsg.replace('<','').replace('>','').replace('.__str__','')
    try:
        if int(smtpsetting['port']) == 25:
            smtp = smtplib.SMTP(str(smtpsetting['host']))
        else:
            smtp = smtplib.SMTP(str(smtpsetting['host']),str(smtpsetting['port']))
        if smtpsetting['starttls']:
            smtp.ehlo()
            smtp.starttls()
            smtp.ehlo()
        if smtpsetting['auth_required']:
            result = smtp.login(smtpsetting['name'], smtpsetting['password'])
        smtp.sendmail(smtpsetting['send_from'], send_to, msg.as_string())
        smtp.quit()
        return 0
    except Exception,e:
        errmsg = "%s" % e.__str__ + ' : ' + ','.join([str(arg) for arg in e.args])
        errmsg = errmsg.replace('<','').replace('>','').replace('.__str__','')
        if errmsg.find('Network is unreachable') >= 0:
            return "checknetwork"
        return errmsg

def get_smtp_settings():
    default_smtp = None
    if os.path.isfile(setting.alertsmtp):
        f = open(setting.alertsmtp,'r')
        allsmtps = pickle.load(f)
        f.close()
        for smtp in allsmtps:
            if smtp['default']:
                default_smtp = smtp
                break
    return default_smtp

def get_send_to_mails():
    sendtomails =[]
    if os.path.isfile(setting.alertmail):
        f,fstat = utils.cust_fopen(setting.alertmail,'r')
        allmails = pickle.load(f)
        utils.cust_fclose(f,fstat)
        for mail in allmails:
            if mail['inuse']:
                sendtomails.append(mail['email'])
    return sendtomails
        
def send_alert_mail(msg):
    smtpsetting = get_smtp_settings()
    sendtomails = get_send_to_mails()
    if not smtpsetting or not sendtomails:
        return -1
    retcode = send_mail(send_to=sendtomails,subject='DigiOcean alert mail',text=msg,files=[],smtpsetting=smtpsetting)
    return retcode
