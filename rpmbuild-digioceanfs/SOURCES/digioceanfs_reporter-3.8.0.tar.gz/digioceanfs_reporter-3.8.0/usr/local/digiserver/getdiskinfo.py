#coding: utf-8

import os
import sys
import re
import string
import utils
import setting
import traceback
#----------------------------
# update disk snmp confgure
#----------------------------
def write_disk_raid_snmp_conf(event,devdata,confpath):
    #get_disk_attr('sdd')
    #get_disk_state('sdd')
    try:
        f,fstat = utils.cust_fopen(confpath,'r+')
        line = f.readline()
        while line:
            a=string.find(line,'DEVICES')
            if a==0:
                addpoint = f.tell() - len(line)
                temp = f.read()
                datalist =line[9:-2].split(" ")
                if event == 'add':
                    for dev in devdata:
                        if not dev in datalist:
                            datalist.append(dev)
                elif event == 'remove':
                     for dev in devdata:
                        if dev in datalist:
                            datalist.remove(dev)
                else:
                    datalist = devdata
                writedata = 'DEVICES=(' + " ".join(datalist) +')\n'
                f.seek(addpoint)
                f.truncate()
                f.write(writedata)
                f.write(temp)  
                break
            line = f.readline() 
        utils.cust_fclose(f,fstat)
        return 0
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        raise ExecCommandError,e

def update_disk_raid_snmp(command):
    try:
        retcode,proc = utils.cust_popen2([command])
        retcode,proc = utils.cust_popen2(["/etc/init.d/snmpd","reload"])
    except Exception,e:
        print >> sys.stderr,traceback.print_exc()
        raise ExecCommandError,e
    
def get_disk_info(disk):
    diskmsg = {}
    filename = '/var/cache/snmp/dev_' + disk + '_info'
    if not os.path.exists(filename):
        return diskmsg
    f,fstat = utils.cust_fopen(filename,'r')
    lines = f.readlines()
    utils.cust_fclose(f,fstat)
    for data in lines:
        if data.find('Device Model') != -1:
            i = data.find(":")
            diskmsg["Model"] = data[i+1:].strip()
        if data.find('Serial Number') != -1:
            i = data.find(":")
            diskmsg["Serial"] = data[i+1:].strip()
    return diskmsg
            

def get_disk_attr(disk):
    diskmsg = {}
    #diskmsg['name'] = disk
    filename = '/var/cache/snmp/dev_' + disk + '_attr'
    if not os.path.exists(filename):
        return diskmsg
    f,fstat = utils.cust_fopen(filename,'r')
    lines = f.readlines()
    utils.cust_fclose(f,fstat)
    for data in lines:
        if data.find("Temperature_Celsius") != -1:
            a = data.split(' ')
            b = []
            for m in a:
                if m != '':
                    b.append(m) 
            diskmsg['temp'] = b[9]
        elif data.find("Current Drive Temperature") != -1:
            i = data.find(":")
            j = data.find(" C")
            diskmsg["temp"] = data[i+1:j].strip()
        '''
        elif data.find("Reallocated_Sector_Ct") != -1:
            sector = data.split(" ")
            diskmsg["RAW_VALUE"] = sector[-1].strip()
        elif data.find("Elements in grown defect list") != -1:
            i = data.find(":")
            diskmsg["RAW_VALUE"] = data[i+1:].strip()
        '''
    return diskmsg

def get_disk_state(disk):
    diskstatemsg = {}
    filename = '/var/cache/snmp/dev_' + disk + '_state'
    if not os.path.exists(filename):
        return diskstatemsg
    f,fstat = utils.cust_fopen(filename,'r')
    lines = f.readlines()
    utils.cust_fclose(f,fstat)
    for data in lines:
        if data.find("SMART overall-health self-assessment test result") != -1:
            i = data.find(":")
            diskstatemsg["state"] = data[i+1:].strip()
        elif data.find("SMART Health Status") != -1:
            i = data.find(":")
            diskstatemsg["state"] = data[i+1:].strip()  
    return diskstatemsg

def readrate (disk):
    retcode,proc = utils.cust_popen2(["hdparm","-I",'/dev/'+disk])
    rtndata = proc.stdout.readlines()
    for data in rtndata:
        if data.find("Nominal Media Rotation Rate:") != -1:
            rateflag = True
            i = data.find(":")
            rate = data[i+1:-1].strip()
            try:
                rate = int(rate)
                return str(rate)
            except:
                return "1"
    return "0"    

def diskerrlog (raidname,diskid,diskname):
    try:
        diskinfo = {}
        if diskname != None:
            diskinfo = get_disk_info(diskname)
            setting.diskerrdata(raidname,diskid,diskname,diskinfo['Model'],diskinfo['Serial'])
        else:
            setting.diskerrdata(raidname,diskid,diskname,None,None)
    except Exception,e:
        setting.errlogdata(setting.LINE(),'getdiskinfo.py','Write disk error log error!')


def checkerrdisk (diskname):
    errflag = False
    command = 'smartctl -A /dev/%s' %(diskname)
    retcode,proc = utils.cust_popen(command)
    smartdata = proc.stdout.readlines()
    for data in smartdata:
        if data.find('Reallocated_Sector_Ct') != -1:
            msg = data.split(" ")
            value = msg[-1].strip()
            if int(value) > 0:
                errflag = True
                break
        if data.find('Reallocated_Event_Count') != -1:
            msg = data.split(" ")
            value = msg[-1].strip()
            if int(value) > 0:
                errflag = True
                break
        if data.find('Current_Pending_Sector') != -1:
            msg = data.split(" ")
            value = msg[-1].strip()
            if int(value) > 0:
                errflag = True
                break
        if data.find('Offline_Uncorrectable') != -1:
            msg = data.split(" ")
            value = msg[-1].strip()
            if int(value) > 0:
                errflag = True
                break
        if data.find('UDMA_CRC_Error_Count') != -1:
            msg = data.split(" ")
            value = msg[-1].strip()
            if int(value) > 0:
                errflag = True
                break
    return errflag

def cleardisk (diskname):
    diskdev = '/dev/%s' %(diskname)
    retcode,proc = utils.cust_popen2([setting.MDADM,"--zero-super",diskdev])
    retcode,proc = utils.cust_popen2([setting.DD,'if=/dev/zero','of=%s' % diskdev,'bs=1024K','count=1'])

def get_raid_state (raidname):
    data = ''
    raidname = raidname[5:]
    filename = '/var/cache/snmp/dev_' + raidname + '_mdinfo'
    if not os.path.exists(filename):
        return data
    f,fstat = utils.cust_fopen(filename,'r')
    lines = f.readlines()
    utils.cust_fclose(f,fstat)
    for line in lines:
        if line.find('State') != -1:
            i = line.find(":")
            data = line[i+1:].strip()
            break
    return data

