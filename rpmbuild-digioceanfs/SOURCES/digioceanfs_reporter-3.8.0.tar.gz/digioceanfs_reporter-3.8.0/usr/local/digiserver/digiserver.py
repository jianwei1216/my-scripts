#!/usr/bin/python
#import signal
import os
import sys
import re
import time
import copy
import pickle
import threading
import setting
from daemon import Daemon
import socketclass
import threadclass
import jobfun
import diskbit
import utils
from Queue import Queue
currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if currpath not in sys.path:
    sys.path.append(currpath)
pidfile= os.path.join(currpath,'tmp/main.pid')
stdin = '/dev/null'
stdout = setting.stdout
stderr = setting.errlog

class SystemServer(Daemon):
    def run (self):
        threadlock = threading.Lock()
        queue = Queue(100)
        mailqueue = Queue(100)
        smsqueue = Queue(100)
        xmlqueue = Queue(100)
        checkqueue = Queue(100)
        diskqueue = Queue(100)
        snmpqueue = Queue(100)
        beepqueue = Queue(100)
        socks = socketclass.Socket()
        httpsocks = socketclass.HttpSocket()
        netthread = threadclass.NetThread('NetThread',queue,socks,threadlock,checkqueue)
        workthread = threadclass.WorkThread('WorkThread',queue,checkqueue,diskqueue,snmpqueue)
        diskthread = threadclass.DiskThread('DiskThread',diskqueue,checkqueue)
        checkthread = threadclass.CheckDevice('CheckDevice',checkqueue,mailqueue,snmpqueue,threadlock)
        mailthread = threadclass.MailThread('MailThread',mailqueue)
        #smsthread = threadclass.SmsThread('SmsThread',smsqueue)
        #xmlthread = threadclass.XmlThread('XmlThread',xmlqueue)
        checknetthread = threadclass.CheckNetThread('CheckNetThread',checkqueue,mailqueue)
        snmpthread = threadclass.SnmpThread('SnmpThread',snmpqueue)
        beepthread = threadclass.BeepThread('BeepThread',beepqueue)
        #httpthread = threadclass.HttpSocketThread('HttpSocketThread',httpsocks,threadlock)
        checkip = threadclass.CheckIP('CheckIP',snmpqueue)
        getsysmsg = threadclass.Getsysmsg('Getsysmsg',snmpqueue)
        #checksysdisk = threadclass.CheckSysDisk('CheckSysDisk',mailqueue)
        netthread.start()
        workthread.start()
        diskthread.start()
        checkthread.start()
        mailthread.start()
        #smsthread.start()
        #xmlthread.start()
        snmpthread.start()
        checknetthread.start()
        beepthread.start()
        #httpthread.start()
        checkip.start()
        getsysmsg.start()
        #checksysdisk.start()
        jobfun.init_disk_state(checkqueue,diskqueue)
        netthread.join()
        workthread.join()
        diskthread.join()
        checkthread.join()
        mailthread.join()
        #smsthread.join()
        #xmlthread.join()
        snmpthread.join()
        checknetthread.join()
        beepthread.join()
        #httpthread.join()
        checkip.join()
        getsysmsg.join()
        #checksysdisk.join()

def main2 ():
    threadlock = threading.Lock()
    queue = Queue(100)
    mailqueue = Queue(100)
    smsqueue = Queue(100)
    xmlqueue = Queue(100)
    checkqueue = Queue(100)
    diskqueue = Queue(100)
    snmpqueue = Queue(100)
    beepqueue = Queue(100)
    socks = socketclass.Socket()
    httpsocks = socketclass.HttpSocket()
    netthread = threadclass.NetThread('NetThread',queue,socks,threadlock,checkqueue)
    workthread = threadclass.WorkThread('WorkThread',queue,checkqueue,diskqueue,snmpqueue)
    diskthread = threadclass.DiskThread('DiskThread',diskqueue,checkqueue)
    checkthread = threadclass.CheckDevice('CheckDevice',checkqueue,mailqueue,snmpqueue,threadlock)
    mailthread = threadclass.MailThread('MailThread',mailqueue)
    #smsthread = threadclass.SmsThread('SmsThread',smsqueue)
    #xmlthread = threadclass.XmlThread('XmlThread',xmlqueue)
    snmpthread = threadclass.SnmpThread('SnmpThread',snmpqueue)
    checknetthread = threadclass.CheckNetThread('CheckNetThread',checkqueue,mailqueue)
    beepthread = threadclass.BeepThread('BeepThread',beepqueue)
    #httpthread = threadclass.HttpSocketThread('HttpSocketThread',httpsocks,threadlock)
    checkip = threadclass.CheckIP('CheckIP',snmpqueue)
    #checksysdisk = threadclass.CheckSysDisk('CheckSysDisk',mailqueue)
    netthread.start()
    workthread.start()
    diskthread.start()
    checkthread.start()
    mailthread.start()
    #smsthread.start()
    #xmlthread.start()
    snmpthread.start()
    checknetthread.start()
    beepthread.start()
    #httpthread.start()
    checkip.start()
    #checksysdisk.start()
    jobfun.init_disk_state(checkqueue,diskqueue)
    netthread.join()
    workthread.join()
    diskthread.join()
    checkthread.join()
    mailthread.join()
    #smsthread.join()
    #xmlthread.join()
    snmpthread.join()
    checknetthread.join()
    beepthread.join()
    #httpthread.join()
    checkip.join()
    #checksysdisk.join()
    
def CheckServerStart ():
    checkstart = 'ps aux |grep /usr/local/digiserver/digiserver.py'
    retcode,proc = utils.cust_popen(checkstart)
    result = proc.stdout.readlines()
    if len(result) > 3:
        return False
    else:
        return True


def main ():
    isstop = CheckServerStart()
    daemon = SystemServer(pidfile,currpath,stdin,stdout,stderr)
    if len(sys.argv) >= 2:
        if len(sys.argv) == 3:
            if sys.argv[2] == '-D':
                setting.DEBUG = True
        if 'start' == sys.argv[1]:
            if isstop == True:
                daemon.start()
            else:
                print 'python %s is already start' % sys.argv[0]
        elif 'stop' == sys.argv[1]:
            daemon.stop()
        elif 'restart' == sys.argv[1]:
            daemon.restart()
        elif 'test' == sys.argv[1]:
            main2()
        else:
            print 'Unknown command'
            sys.exit(2)
        sys.exit(0)
    else:
        print "Usage: python %s start|stop|restart" % sys.argv[0]
        print "Example: python %s start" % sys.argv[0]
        sys.exit(2)

if __name__ == '__main__':
    main()
