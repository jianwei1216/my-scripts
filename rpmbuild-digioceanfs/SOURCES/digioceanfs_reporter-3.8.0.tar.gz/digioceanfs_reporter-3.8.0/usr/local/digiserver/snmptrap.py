#-*- coding: UTF-8 -*-

import os
import sys
import re
import utils
import setting
import jobfun
import traceback
import time
import checkip

def SendFileTrap (data):
    setting.errlogdata(setting.LINE(),'snmptrap.py','snmpdata = ' + str(data))
    try:
        ip = []
        c = []
        snmpdata = ''
        a = {}
        retcode,proc = utils.cust_popen2([setting.CAT,setting.IPFILEADDR])
        hosts_lines = proc.stdout.read()
        hostip = checkip.CentOs7_readipaddr()
        for host in hostip:
            if re.match('eth\d+|br\d+|bond\d+|enp\w+',host['eth']):
                if host['addr'] != '' and hosts_lines.find(host['addr']) >= 0:
                    a['ip'] = host['addr']
                    a['port'] = '162'
                    c.append(a)
                    a = {}
        if data['op'] in ['cputemp','usedcpu','usedmem','Fan']:
            sendflag = '.1.3.6.1.4.1.38696.2.14.2.1'
            snmpdata = snmpdata + 'SysMsgIndex' + ' i ' + '1' + ' '
            snmpdata = snmpdata + 'SysMsgCTime' + ' s ' + str(time.time()) + ' '
            snmpdata = snmpdata + 'SysMsgDevName' + ' s ' + data['name'] + ' '
            snmpdata = snmpdata + 'SysMsgDevMsg' + ' s ' + data['used'] + ' '
            snmpdata = snmpdata + 'SysMsgEvent' + ' s ' + data['flag']
            #setting.errlogdata(setting.LINE(),'snmptrap.py',snmpdata)
            if snmpdata != '':
                b = readconf()
                ip = b + c
                sendsnmptrap(snmpdata,sendflag,ip)
                snmpdata = ''
        if data['op'] == 'disktemp':
            sendflag = '.1.3.6.1.4.1.38696.2.13.2.1'
            snmpdata = snmpdata + 'DiskTempIndex' + ' i ' + '1' + ' '
            snmpdata = snmpdata + 'DiskTempCTime' + ' s ' + str(time.time()) + ' '
            snmpdata = snmpdata + 'DiskTempDevName' + ' s ' + data['name'] + ' '
            snmpdata = snmpdata + 'DiskTempDevTemp' + ' s ' + data['temp'] + ' '
            snmpdata = snmpdata + 'DiskTempEvent' + ' s ' + data['flag']
            #setting.errlogdata(setting.LINE(),'snmptrap.py',snmpdata)
            if snmpdata != '':
                b = readconf()
                ip = b + c
                sendsnmptrap(snmpdata,sendflag,ip)
                snmpdata = ''
        if data['op'] == 'filesystem':
            sendflag = '.1.3.6.1.4.1.38696.2.7.2.1'
            snmpdata = snmpdata + 'FileWarningIndex' + ' i ' + '1' + ' '
            snmpdata = snmpdata + 'FileWarningCTime' + ' s ' + str(time.time()) + ' '
            snmpdata = snmpdata + 'FileWarningNode' + ' s ' + data['node'] + ' '
            snmpdata = snmpdata + 'FileWarningMountPoint' + ' s ' + data['mountpoint'] + ' '
            snmpdata = snmpdata + 'FileWarningDiskName' + ' s ' + data['errdiskname'] + ' '
            snmpdata = snmpdata + 'FileWarningDiskID' + ' s ' + data['errdiskid'] + ' '
            snmpdata = snmpdata + 'FileWarningEvent' + ' s ' + data['event']
            if snmpdata != '':
                b = readconf()
                ip = b + c
                sendsnmptrap(snmpdata,sendflag,ip)
                snmpdata = ''
        elif data['op'] == 'systemdisk':
            sendflag = '.1.3.6.1.4.1.38696.2.12.2.1'
            snmpdata = snmpdata + 'SystemdiskIndex' + ' i ' + '1' + ' '
            snmpdata = snmpdata + 'SystemdiskCTime' + ' s ' + str(time.time()) + ' '
            snmpdata = snmpdata + 'SystemdiskDir' + ' s ' + data['dirname'] + ' '
            snmpdata = snmpdata + 'SystemdiskFlag' + ' s ' + data['flag'] + ' '
            snmpdata = snmpdata + 'SystemdiskUsed' + ' s ' + data['used']
            if snmpdata != '':
                b = readconf()
                ip = b + c
                sendsnmptrap(snmpdata,sendflag,ip)
                snmpdata = ''
        elif data['op'] == 'udev':
            sendflag = '.1.3.6.1.4.1.38696.2.8.2.1'
            snmpdata = snmpdata + 'DiskDropIndex' + ' i ' + '1' + ' '
            snmpdata = snmpdata + 'DiskDropCTime' + ' s ' + str(time.time()) + ' '
            snmpdata = snmpdata + 'DiskDropDevName' + ' s ' + data['param'] + ' '
            if data.has_key('locateid'):
                snmpdata = snmpdata + 'DiskDropDevID' + ' s ' + data['locateid'] + ' '
            snmpdata = snmpdata + 'DiskDropEvent' + ' s ' + data['event']
            if snmpdata != '':
                b = readconf()
                ip = b + c
                sendsnmptrap(snmpdata,sendflag,ip)
                snmpdata = ''
        elif data['op'] == 'mdmon':
            sendflag = '.1.3.6.1.4.1.38696.2.9.2.1'
            snmpdata = snmpdata + 'RaidFailIndex' + ' i ' + '1' + ' '
            snmpdata = snmpdata + 'RaidFailCTime' + ' s ' + str(time.time()) + ' '
            a = data['param'].find('->')
            if a != -1:
                snmpdata = snmpdata + 'RaidFailRaidName' + ' s ' + data['param'][:a] + ' '
                snmpdata = snmpdata + 'RaidFailDiskName' + ' s ' + data['param'][a+2:] + ' '
            else:
                snmpdata = snmpdata + 'RaidFailRaidName' + ' s ' + data['param'] + ' '
            snmpdata = snmpdata + 'RaidFailEvent' + ' s ' + data['event']
            if snmpdata != '':
                b = readconf()
                ip = b + c
                sendsnmptrap(snmpdata,sendflag,ip)
                snmpdata = ''
        elif data['op'] in ['NetLink','NetSpeed'] :
            sendflag = '.1.3.6.1.4.1.38696.2.11.2.1'
            snmpdata = snmpdata + 'NetLinkIndex' + ' i ' + '1' + ' '
            snmpdata = snmpdata + 'NetLinkCTime' + ' s ' + str(time.time()) + ' '
            snmpdata = snmpdata + 'NetLinkEth' + ' s ' + data['Net'] + ' '
            snmpdata = snmpdata + 'NetLinkEvent' + ' s ' + data['Link']
            if snmpdata != '':
                b = readconf()
                ip = b + c
                sendsnmptrap(snmpdata,sendflag,ip)
                snmpdata = ''
        elif data['op'] == 'Ping':
            sendflag = '.1.3.6.1.4.1.38696.2.10.2.1'
            snmpdata = snmpdata + 'PingIndex' + ' i ' + '1' + ' '
            snmpdata = snmpdata + 'PingCTime' + ' s ' + str(time.time()) + ' '
            snmpdata = snmpdata + 'PingNode' + ' s ' + data['Node'] + ' '
            snmpdata = snmpdata + 'PingIP' + ' s ' + data['Ip'] + ' '
            snmpdata = snmpdata + 'PingEvent' + ' s ' + data['Event']
            if snmpdata != '':
                b=[]
                ip = b + c
                sendsnmptrap(snmpdata,sendflag,ip)
                snmpdata = ''
    except:
        print >> sys.stderr,traceback.print_exc()




def SendTrap(data):
    if type(data) == type('1'):
        decodestr(data)
    else:
        decodedict(data)

def decodestr(data):
    snmpdata = ''
    raidsendflag = 'RaidWarningTable'
    disksendflag = 'DiskWarningTable'
    #ip = '10.10.30.88'
    datalist = data.split('<br />')
    i = 1
    for errdata in datalist:
        if errdata.find("is") != -1 and errdata.find("RAID") != -1:
            errtype = errdata.split(' ')
            snmpdata = snmpdata + 'RaidWarningRaidIndex.' + str(i) + ' i ' + str(i) + ' ' + 'RaidWarningRaidName.' + str(i) + ' s ' + '"' + errtype[2] + '"' + ' ' + 'RaidWarningRaidPath.' + str(i) + ' s ' + '"' + errtype[3][2:-1] + '"' + ' ' + 'RaidWarningRaidErrType.' + str(i) + ' s ' + '"' +errtype[5] + '"' + ' '
            i = i + 1
    if snmpdata != '':
        sendsnmptrap(snmpdata,raidsendflag)
        snmpdata = ''
    i = 1
    for errdata in datalist:
        if errdata.find("is") != -1 and errdata.find("disk") != -1:
            errtype = errdata.split(' ')
            snmpdata = snmpdata + 'DiskWarningDiskIndex.' + str(i) + ' i ' + str(i) + ' '
            snmpdata = snmpdata + 'DiskWarningDiskId.' + str(i) + ' s ' + errtype[3] + ' '
            snmpdata = snmpdata + 'DiskWarningDiskPath.' + str(i) + ' s ' + errtype[4][2:-1] + ' '
            snmpdata = snmpdata + 'DiskWarningDiskState.' + str(i) + ' s ' + errtype[6] + ' '
            i = i + 1
    if snmpdata != '':
        sendsnmptrap(snmpdata,disksendflag)
        snmpdata = ''

def decodedict(data):
    snmpdata = ''
    senddict = {}
    #ip = 'localhost'
    sendflag = 'DiskWarningTable'
    for statekey in data['state'].keys():
        if statekey in data['temp'].keys():
            for tempkey in data['temp'].keys():
                if tempkey == statekey:
                    senddict[tempkey] = dict(data['state'][statekey],**data['temp'][tempkey])
        else:
            senddict[statekey] = data['state'][statekey]
    for tempkey in data['temp'].keys():
        if tempkey in data['state'].keys() and not tempkey in senddict.keys():
            senddict[tempkey] = data['temp'][tempkey]
    i = 1
    if senddict != {}:
        for key in senddict.keys():
            snmpdata = snmpdata + 'DiskWarningDiskIndex.' + str(i) + ' i ' + str(i) + ' '
            snmpdata = snmpdata + 'DiskWarningDiskName.' + str(i) + ' s ' + key + ' '
            if senddict[key].has_key('count'):
                snmpdata = snmpdata + 'DiskWarningDiskCount.' + str(i) + ' s ' + senddict[key]['count'] + ' '
            if senddict[key].has_key('state'):
                snmpdata = snmpdata + 'DiskWarningDiskState.' + str(i) + ' s ' + senddict[key]['state'] + ' '
            if senddict[key].has_key('rate'):
                snmpdata = snmpdata + 'DiskWarningDiskRate.' + str(i) + ' s ' + senddict[key]['rate'] + ' '
            if senddict[key].has_key('temp'):
                snmpdata = snmpdata + 'DiskWarningDiskTemp.' + str(i) + ' s ' + filter(str.isdigit,senddict[key]['temp']) + ' '
            if senddict[key].has_key('error'):
                snmpdata = snmpdata + 'DiskWarningDiskErrCode.' + str(i) + ' s ' + senddict[key]['error'] + ' '
            i = i + 1
    if snmpdata != '':
        sendsnmptrap(snmpdata,sendflag)
        snmpdata = ''

def sendsnmptrap(senddata,sendflag,ip=[]):
    if ip != []:
        for addr in ip:
            snmpcmd = '/usr/bin/snmptrap -v 2c -c hacking %s:%s "" %s %s' % (addr['ip'],addr['port'],sendflag,senddata)
            setting.errlogdata(setting.LINE(),'snmptrap.py',snmpcmd)
            retcode,proc = utils.cust_popen(snmpcmd)
            if retcode != 0:
                setting.errlogdata(setting.LINE(),'snmptrap.py',proc.stderr.readlines())

def readconf ():
    ip = []
    gluster_cmd = '/usr/sbin/digiocean peer status'
    retcode,proc = utils.cust_popen(gluster_cmd)
    lines = proc.stdout.readlines()
    for line in lines:
        b = {}
        if line.find("Hostname:") != -1:
            i = line.find(":")
            addr = line[i+2:-1]
            b['ip'] = addr
            b['port'] = '162'
            ip.append(b)
    return ip



