import sys,socket
import json

class Client:
        def sendmsg(self,argv1,argv2,argv3):
                s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
                s.connect("/tmp/pipe.d")
                b=json.dumps({"op":"mdmon","event":argv1,"param":argv2[argv2.find("m"):]})
                if argv3!=None:
                        b=json.dumps({"op":"mdmon","event":argv1,"param":argv2[argv2.find("m"):]+"->"+argv3[argv3.find("s"):]})
                s.send(b)
                #print s.recv(1000)
                s.close()
argv1=sys.argv[1]
argv2=sys.argv[2] 
client=Client()
if len(sys.argv)==4:
        argv3=sys.argv[3]
        client.sendmsg(argv1,argv2,argv3)
else:
        client.sendmsg(argv1,argv2,None)
