#-*- coding: utf-8 -*-

import time
import serial
import re
import sys
import os
import setting
import utils
import pickle

#---------------------------------
#  get sms alert settings
#---------------------------------
def get_sms_settings():
    CTRADDR = None
    MOBADDR = []
    SMSALERTSTATUS = False
    try:
        ser = serial.Serial("/dev/ttyGSM",9600)
        ser.write("AT\r")
        time.sleep(0.1)
        line = ser.read(ser.inWaiting())
        ser.close()
        m = re.search('\+86\d+',line)
        if m:
            CTRADDR = m.group()
    except Exception,e:
        pass
    if os.path.isfile(setting.alertsms):
        f,fstat = utils.cust_fopen(setting.alertsms,'r')
        smsinfos = pickle.load(f)
        if smsinfos:
            if not CTRADDR and smsinfos['smsp']:
                CTRADDR = str(smsinfos['smsp'])
            if smsinfos['mobp']:
                MOBADDR = smsinfos['mobp']
            SMSALERTSTATUS = smsinfos['inuse']
    return CTRADDR,MOBADDR,SMSALERTSTATUS
#---------------------------------
#   mobile addr and SMSC init
#---------------------------------
def addr_init(destaddr):
    dest_addr_list = []
    dest_addr = destaddr.replace('+','')
    if len(dest_addr)%2 == 1:
        dest_addr = dest_addr + 'F'
    tmp_list = list(dest_addr)
    for i in range(0,len(tmp_list),2):
        dest_addr_list.append(tmp_list[i+1])
        dest_addr_list.append(tmp_list[i])
    dest_addr = ''.join(dest_addr_list) 
    return dest_addr

#---------------------------------
#   message init
#---------------------------------
def mesg_init(addr,MESG):
    if type(MESG) == unicode:
        mesg = MESG
    else:
        mesg = MESG.decode('utf-8')
    mesg = str([mesg])
    m = re.search("\[u'(.*)'\]",mesg)
    if m:
        mesg = m.group(1)
    mesglist = list(mesg)
    i = 0
    while i < len(mesglist):
        if not mesglist[i] == '\\':
            mesglist[i] = "%04x" % ord(mesglist[i])
            i += 1
        else:
            i += 6
    mesg = ''.join(mesglist).replace("\u",'')
    hex_len = '%02x' % (len(mesg)/2)
    mesg = hex_len + mesg
    return mesg

#---------------------------------
#   send chinese message
#---------------------------------
def send_chinese_mesg(ser,mobaddr,mesgi,ctraddr):
    #---------- mesg init ---------#
    ctr_addr = '0891' + addr_init(ctraddr)
    mob_addr = addr_init(mobaddr)
    addr = '11000D91' + mob_addr + '000800'
    mesgstr = mesg_init(addr,mesg)
    size = len(addr + mesgstr)/2
    #---------- send mesg ---------#
    ser.write("AT+CMGF=0\r")
    time.sleep(0.1)
    line = ser.read(ser.inWaiting())
    print line
    ser.write("AT+CMGS=%s\r" % size)
    time.sleep(0.1)
    line = ser.read(ser.inWaiting())
    print line
    message = ctr_addr + addr + mesgstr + '\032\r'
    ser.write(message)
    time.sleep(0.1)
    while ser.inWaiting():
        line = ser.readline()
        print line
		
#---------------------------------
#   send english message
#---------------------------------
def send_english_mesg(ser,mobaddr,mesg):
    mobaddr = mobaddr.replace('+86','')
    ser.write("AT+CMGF=1\r")
    time.sleep(0.1)
    line = ser.read(ser.inWaiting())
    print line
    ser.write("AT+CMGS=%s\r" % mobaddr)
    time.sleep(0.1)
    line = ser.read(ser.inWaiting())
    print line
    message = mesg + '\032\r'
    ser.write(message)
    time.sleep(0.1)
    while ser.inWaiting():
        line = ser.readline()
        print line
    
#------------------------------------
#    flag = 0 : english message
#    flag = 1 : chinese message   
#------------------------------------
def send_alert_sms(mesg,flag):
    mesg = mesg.replace('<br />',' ')
    errmesg = []
    CTRADDR,MOBADDR,SMSALERTSTATUS = get_sms_settings()
    if SMSALERTSTATUS and CTRADDR:
        for mobaddr in MOBADDR:
            if flag == 0:
                tmp = len(mesg) / 140
            else:
                tmp = len(mesg) / 70
            for i in range(tmp+1):
                try:
                    ser = serial.Serial("/dev/ttyGSM",9600)
                    ser.write("AT\r")
                    time.sleep(0.1)
                    if not ser.inWaiting() == 9:
                        ser.close() 
                        break
                    else:
                        line = ser.read(ser.inWaiting())
                        print line
                        if flag == 0:
                            send_english_mesg(ser,str(mobaddr),mesg[i*140:(i+1)*140])
                        else:
                            send_chinese_mesg(ser,str(mobaddr),mesg[i*70:(i+1)*70],str(CTRADDR))
                        ser.close()
                except Exception,e:
                    errmsg = "%s" % e.__str__ + ' : ' + ','.join([str(arg) for arg in e.args])
                    if errmsg.find("SerialException") >= 0 and errmsg.find("could not open port") >= 0:
                        errmsg = "GSM Modem not connected."
                    errmesg.append(errmsg) 
    elif not CTRADDR:
        errmsg = "The SMS center number not set."
        errmesg.append(errmsg)
    else:
        errmsg = "SMS alarm function is closed."
        errmesg.append(errmsg)
    if errmesg:
        return '<br />'.join(errmesg)
    else:
        return 0

if __name__ == "__main__":
    smsmesg = "This is a test string."
    send_alert_sms(smsmesg,0)
