#!/usr/bin/python

import os
import sys
import time
import utils
import setting

filepath = '/usr/local/digitools/libcommon/raidlib/sata_jobd'
gpiopin = ['216','218','219','220','192','198','199','201']

def pins_export(i):
    try:
        pin1export = open("/sys/class/gpio/export","w")
        pin1export.write(i)
        pin1export.close()
        return 'OK'
    except IOError:
        setting.errlogdata(setting.LINE(),'gpioctl.py',"INFO: GPIO " + i + " already Exists, skipping export gpio")
        pin1export.close()
        return 'err'
def pins_unexport (i):
    try:
        pin1export = open("/sys/class/gpio/unexport","w")
        pin1export.write(i)
        pin1export.close()
        return 'OK'
    except IOError:
        setting.errlogdata(setting.LINE(),'gpioctl.py',"INFO: GPIO " + i + " already Unexport" ) 
        pin1export.close()
        return 'err'

def read_value(i):
    try:
        fp1 = open("/sys/class/gpio/gpio"+ i +"/value","r")
        value = fp1.read()
        fp1.close()
        return value
    except IOError:
        setting.errlogdata(setting.LINE(),'gpioctl.py',"INFO: Read GPIO " + i + " value Error")
        fp1.close()
        return 'err'
def write_value(pin,value):
    try:
        fp1 = open("/sys/class/gpio/gpio"+ pin +"/value","w")
        value = fp1.write(value)
        fp1.close()
        return 'OK'
    except IOError:
        setting.errlogdata(setting.LINE(),'gpioctl.py',"INFO: Write GPIO " + pin + " value Error")
        fp1.close()
        return 'err'

def read_direction(i):
    try:
        fp1 = open("/sys/class/gpio/gpio"+ i +"/direction","r")
        value = fp1.read()
        fp1.close()
        return value
    except IOError:
        setting.errlogdata(setting.LINE(),'gpioctl.py',"INFO: Read GPIO " + i + " direction Error")
        fp1.close()
        return 'err'

def write_direction(pin,value):
    try:
        fp1 = open("/sys/class/gpio/gpio"+ pin +"/direction","w")
        value = fp1.write(value)
        fp1.close()
        return 'OK'
    except IOError:
        setting.errlogdata(setting.LINE(),'gpioctl.py',"INFO: Write GPIO " + pin + " direction Error" )
        fp1.close()
        return 'err'

def init ():
    for i in range(8):
        pins_export(gpiopin[i])
        write_direction(gpiopin[i],'high')

def checkgpio ():
    if os.path.exists(filepath):
        retcode,proc = utils.cust_popen(setting.LSMOD)
        if retcode != 0:
            setting.errlogdata(setting.LINE(),'gpioctl.py',retcode)
        lsmoddata = proc.stdout.read()
        if lsmoddata.find('gpio_nm10') != -1:
            return True
        else:
            return False
    else:
        return False

def setgpio (pin,value):
    rtndata = write_direction(gpiopin[int(pin)-1],value)
    if rtndata == 'OK':
        gpiovalue = read_value(gpiopin[int(pin)-1])
        return gpiovalue
    else:
        return rtndata


