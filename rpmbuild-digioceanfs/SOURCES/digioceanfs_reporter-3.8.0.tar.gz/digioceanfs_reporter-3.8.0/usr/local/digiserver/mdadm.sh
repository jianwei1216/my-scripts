#!/bin/sh
/usr/bin/python /usr/local/digiserver/mdadmclient.pyc $1 $2 $3
