#coding: utf-8
import os
import sys
import time
import threading
import socketclass
import digimail
import digisms
import setting
import jobfun
import getdiskinfo
import simplejson as json
import sysmonitor
import snmptrap
import utils
import checkip
import readfan
import checksysdisk
from copy import deepcopy 
from Queue import Queue

class NetThread(threading.Thread):
    def __init__ (self, threadname, queue,socks,threadlock,checkqueue):
        threading.Thread.__init__(self, name = threadname)
        self.sharedata = queue
        self.netsock = socks 
        self._threadlock = threadlock
        self._checkqueue = checkqueue
        setting.errlogdata(setting.LINE(),'threadclass.py','NetThread Init')
    def run(self):
        setting.errlogdata(setting.LINE(),'threadclass.py','NetThread Run')
        i = 0
        while True:
            self.netsock.Listen()
            if self.netsock.connlist == []:
                continue
            for conn in self.netsock.connlist:
                rtn = self.netsock.Recvdata(conn,self.sharedata)
                if rtn == 0:
                    self.netsock.CloseConn(conn)
                    #self.netsock.Senddata(conn,'OK')
                elif rtn == 2:
                    self.netsock.CloseConn(conn)

class WorkThread(threading.Thread):
    def __init__ (self, threadname,queue,checkqueue,diskqueue,snmpqueue):
        threading.Thread.__init__(self, name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','WorkThread Init')
        self.sharedata = queue
        self._checkqueue = checkqueue
        self._diskqueue = diskqueue
        self._snmpqueue = snmpqueue
    def run (self):
        setting.errlogdata(setting.LINE(),'threadclass.py','WorkThread Run')
        queuedata = []
        while True: 
            while True:
                recvdata = self.sharedata.get()
                queuedata.append(recvdata)
                if self.sharedata.empty() == True:
                    break
            for data in queuedata:
                jobfun.decodecmd(data,self._checkqueue,self._diskqueue,self._snmpqueue)
            queuedata = []

class CheckDevice(threading.Thread):
    def __init__ (self,threadname,checkqueue,mailqueue,snmpqueue,threadlock):
        threading.Thread.__init__(self,name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','CheckDevice Init')
        self._checkqueue = checkqueue
        self._mailqueue = mailqueue
        #self._smsqueue = smsqueue
        #self._xmlqueue = xmlqueue
        self._snmpqueue = snmpqueue
        self._threadlock = threadlock
    def run (self):
        setting.errlogdata(setting.LINE(),'threadclass.py','CheckDevice Run')
        queuelist = []
        while True:
            while True:
                queuelist.append(self._checkqueue.get())
                if self._checkqueue.empty() == True:
                    break
            #digistow,raidlist = jobfun.raid_list()
            #setting.DIGISTOW = deepcopy(digistow)
            #cmd = '/bin/sync'
            #retcode,proc = utils.cust_popen2([cmd])
            for data in list(set(queuelist)):
                if data == 'check':
                    getdiskinfo.update_disk_raid_snmp(setting.DISKCMD)
                    getdiskinfo.update_disk_raid_snmp(setting.RAIDCMD)
                    snmpflag = False
                    m = setting.CAT + ' ' + '/proc/mdstat'
                    retcode,proc = utils.cust_popen(m)
                    raidmsg = proc.stdout.readlines()
                    raid = []
                    for z in raidmsg:
                        if z[:2] == 'md':
                            x = z.find(':')
                            raid.append(z[:x-1])
                    if raid != []:
                        if setting.RAIDSTATE != []:
                            raidstate = deepcopy(setting.RAIDSTATE)
                            for x in raidstate:
                                if x['param'] not in raid:
                                    setting.RAIDSTATE.remove(x)
                        for setting.EVENTRAIDNAME in raid:
                            if setting.EVENTRAIDNAME != '':
                                raiddata = {}
                                raiddata['op'] = 'mdmon'
                                raiddata['param'] = setting.EVENTRAIDNAME
                                cmd = setting.MDADM + ' --detail ' + '/dev/' + setting.EVENTRAIDNAME
                                retcode,proc = utils.cust_popen(cmd)
                                raidmsg = proc.stdout.readlines()
                                raiderr = proc.stderr.readlines()
                                if raiderr == []:
                                    for msg in raidmsg:
                                        if msg.find('State :') != -1:
                                            if msg.find('degraded') != -1:
                                                raiddata['event'] = 'degraded'
                                                if raiddata not in setting.RAIDSTATE:
                                                    snmpflag = True
                                                    setting.RAIDSTATE.append(raiddata)
                                            elif msg.find('FAILED') != -1:
                                                raiddata['event'] = 'FAILED'
                                                if raiddata not in setting.RAIDSTATE:
                                                    snmpflag = True
                                                    setting.RAIDSTATE.append(raiddata)   
                                            else:
                                                if setting.RAIDSTATE != []:
                                                     b = deepcopy(setting.RAIDSTATE)
                                                     for a in b:
                                                         if a['param'] == raiddata['param']:
                                                             setting.RAIDSTATE.remove(a)
                                else:
                                    if setting.RAIDSTATE != []:
                                        b = deepcopy(setting.RAIDSTATE)
                                        for a in b:
                                            if a['param'] == raiddata['param']:
                                                setting.RAIDSTATE.remove(a)
                                if snmpflag == True:
                                    self._snmpqueue.put(raiddata)
                                    snmpflag == False
                    else:
                        setting.RAIDSTATE = []
                        
                    '''
                    digistow,raidlist = jobfun.raid_list()
                    setting.DIGISTOW = deepcopy(digistow)
                    getdiskinfo.update_disk_raid_snmp(setting.DISKCMD)
                    getdiskinfo.update_disk_raid_snmp(setting.RAIDCMD)
                    #self._threadlock.acquire()
                    setting.RAIDLISTDATA = json.dumps(raidlist) + 'END'
                    #err = jobfun.write_digistow(setting.RAIDLISTDATA)
                    #setting.HTTPCHANGEFLAG = 1
                    
                    if setting.HTTPCHANGEFLAG != []:
                        for a in setting.HTTPCHANGEFLAG:
                            a.put('1')
                    
                    #self._threadlock.release()
                    devmsg = sysmonitor.CheckDevice(digistow,raidlist['raiddevs'])
                    if devmsg != None:
                        errdata = devmsg.split('<br />')
                        for err in errdata:
                            dataraid = ''
                            datadisk = ''
                            if err.find('disk') != -1:
                                i = err.find('(')
                                j = err.find(')')
                                datadisk = err[i+1:j]
                            if err.find('RAID') != -1:
                                i = err.find('(')
                                j = err.find(')')
                                dataraid = err[i+1:j]
                            if (datadisk != '' and datadisk.find('None') == -1) or dataraid != '':
                                setting.BEEPFLAG = True
                                break
                            else:
                                setting.BEEPFLAG = False
                    else:
                        setting.BEEPFLAG = False
                    if devmsg != None and len(devmsg) > 50:
						pass
                        #self._mailqueue.put(devmsg)
                        #self._smsqueue.put(devmsg)
                        #self._xmlqueue.put(devmsg)
                        #self._snmpqueue.put(devmsg)
                    '''
                elif data == 'netcheck':
                    linkflag = False
                    pingflag = False
                    rtn = []
                    rtndata = {}
                    netmsg = sysmonitor.CheckNet()
                    '''
                    if setting.NODEMANGEFLAG == True and setting.NODERESTARTFLAG == False:
                        retcode,proc = utils.cust_popen2([setting.NODEMANAGE,'restart'])
                        if retcode != 0:
							setting.errlogdata(setting.LINE(),'threadclass.py','restart node manage error!')
                        setting.NODERESTARTFLAG = True
                    '''
                    #netmsg = [{'Speed': '100', 'Net': 'eth0', 'MaxSpeed': '1000', 'Link': 'yes'},{'Net': 'eth1', 'Link': 'no'}]
                    for msg in netmsg:
                        if setting.IFACEDATA == []:
                            if msg['Link'] == 'no':
                                setting.IFACEDATA.append(msg['Net']+':'+msg['Link'])
                                rtndata = msg
                                rtndata['op'] = 'NetLink'
                                self._snmpqueue.put(rtndata)
                        else:    #setting.IFACEDATA = ['eth1:no']
                            for i in range(len(setting.IFACEDATA)):
                                if setting.IFACEDATA[i].find(msg['Net']) != -1:
                                    linkflag = True
                                    if setting.IFACEDATA[i].find(msg['Link']) == -1:
                                        setting.IFACEDATA[i] = msg['Net']+':'+msg['Link']
                                        rtndata = msg
                                        rtndata['op'] = 'NetLink'
                                        self._snmpqueue.put(rtndata)
                            if linkflag == False:
                                if msg['Link'] == 'no':
                                    setting.IFACEDATA.append(msg['Net']+':'+msg['Link'])
                                    rtndata = msg
                                    rtndata['op'] = 'NetLink'
                                    self._snmpqueue.put(rtndata)
                    time.sleep(0.1)
                    for speedmsg in netmsg:
                        if speedmsg['Link'] == 'yes':
                            if int(speedmsg['Speed']) < int(speedmsg['MaxSpeed']):
                                if setting.SPEEDDATA == []:
                                    rtndata['op'] = 'NetSpeed'
                                    rtndata['Net'] = speedmsg['Net']
                                    rtndata['Link'] = 'SpeedDown'
                                    setting.SPEEDDATA.append(speedmsg['Net'])
                                    self._snmpqueue.put(rtndata)
                                    sysmonitor.speedresume(speedmsg['Net'],speedmsg['MaxSpeed'])
                                else:
                                    if speedmsg['Net'] not in setting.SPEEDDATA:
                                        rtndata['op'] = 'NetSpeed'
                                        rtndata['Net'] = speedmsg['Net']
                                        rtndata['Link'] = 'SpeedDown'
                                        setting.SPEEDDATA.append(speedmsg['Net'])
                                        self._snmpqueue.put(rtndata)
                                        sysmonitor.speedresume(speedmsg['Net'],speedmsg['MaxSpeed'])
                                    else:
                                        sysmonitor.speedresume(speedmsg['Net'],speedmsg['MaxSpeed'])
                            else:
                                if speedmsg['Net'] in setting.SPEEDDATA:
                                    rtndata['op'] = 'NetSpeed'
                                    rtndata['Net'] = speedmsg['Net']
                                    rtndata['Link'] = 'SpeedResume'
                                    self._snmpqueue.put(rtndata)
                                    setting.SPEEDDATA.remove(speedmsg['Net'])
                    pingmsg = checkip.getpingmsg()
                    if pingmsg != []:
                        for msg in pingmsg:
                            if setting.PINGDATA == []:
                                if msg['Event'] == 'Off-line':
                                    setting.PINGDATA.append(msg['Node']+':'+msg['Ip']+':'+msg['Event'])
                                    self._snmpqueue.put(msg)
                            else:
                                for i in range(len(setting.PINGDATA)):
                                    if setting.PINGDATA[i].find(msg['Node']) != -1 or setting.PINGDATA[i].find(msg['Ip']) != -1:
                                        pingflag = True
                                        if setting.PINGDATA[i].find(msg['Event']) == -1:
                                            setting.PINGDATA[i] = msg['Node']+':'+msg['Ip']+':'+msg['Event']
                                            self._snmpqueue.put(msg)
                                if pingflag == False:
                                    if msg['Event'] == 'Off-line':
                                        setting.PINGDATA.append(msg['Node']+':'+msg['Ip']+':'+msg['Event'])
                                        self._snmpqueue.put(msg)
                else:
                    getdiskinfo.update_disk_raid_snmp(setting.DISKCMD)
                    getdiskinfo.update_disk_raid_snmp(setting.RAIDCMD)
                    #diskmsg = sysmonitor.checkdisk(setting.DIGISTOW)
                    #self._xmlqueue.put(diskmsg)
                    #self._snmpqueue.put(diskmsg)
            queuelist = []

class MailThread(threading.Thread):
    def __init__ (self,threadname,mailqueue):
        threading.Thread.__init__(self,name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','MailThread Init')
        self._mailqueue = mailqueue
    def run (self):
        setting.errlogdata(setting.LINE(),'threadclass.py','MailThread Run')
        maildata = []
        mailmsg = ''
        while True:
            while True: 
                maildata.append(self._mailqueue.get())
                if self._mailqueue.empty() == True:
                    break 
            for data in maildata:
                mailmsg = mailmsg + data
            eretval = jobfun.judge_mail_conf_empty()
            if eretval:
                rtn = digimail.send_alert_mail(mailmsg)
                if rtn != 0:
                    setting.errlogdata(setting.LINE(),'threadclass.py',rtn)
            mailmsg = ''
            maildata = []

class SmsThread(threading.Thread):
    def __init__ (self,threadname,smsqueue):
        threading.Thread.__init__(self,name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','SmsThread Init')
        self._smsqueue = smsqueue
    def run (self):
        setting.errlogdata(setting.LINE(),'threadclass.py','SmsThread Run')
        smsdata = []
        smsmsg = ''
        while True:
            while True: 
                smsdata.append(self._smsqueue.get())
                if self._smsqueue.empty() == True:
                    break 
            for data in smsdata:
                smsmsg = smsmsg + data
            eretval = jobfun.judge_sms_conf_empty()
            if eretval:
                rtn = digisms.send_alert_sms(smsmsg,0)
                if rtn != 0:
                    setting.errlogdata(setting.LINE(),'threadclass.py',rtn)
            smsmsg = ''
            smsdata = []
            
class XmlThread(threading.Thread):
    def __init__ (self,threadname,xmlqueue):
        threading.Thread.__init__(self,name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','XmlThread Init')
        self._xmlqueue = xmlqueue
    def run (self):
        setting.errlogdata(setting.LINE(),'threadclass.py','XmlThread Run')
        xmlsenddata = ''
        xmldata = []
        udpalertmathines = []
        xmlalertmathines = []
        xmlsenddiskdata = []
        while True:
            while True:
                xmldata.append(self._xmlqueue.get())
                if self._xmlqueue.empty() == True:
                    break
            #xmlsenddata = jobfun.build_xml(xmldata)
            xmlsenddiskdata = []
            for xml in xmldata:
                if type(xml) == type({}):
                    if xml['temp'] != {}:
                        diskdata = jobfun.build_diskxml(xml['temp'])
                        xmlsenddiskdata.append(diskdata)
                        diskdata = ''
                    if xml['state'] != {}:
                        diskdata = jobfun.build_diskstate_xml(xml['state'])
                        xmlsenddiskdata.append(diskdata)
                        diskdata = ''
                else:
                    a=[]
                    a.append(xml)
                    xmlsenddata = jobfun.build_raidxml(a)
                if xmlsenddata=="error" or (xmlsenddata == '' and xmlsenddiskdata == []):
                    xmldata=[]
                    continue
                udpalertmathines,xmlalertmathines = jobfun.read_udp_xml_conf()
                if udpalertmathines != []:
                    for udpalert in udpalertmathines:
                        udpsocket = socketclass.UdpSocket(udpalert['ip'],int(udpalert['port']))
                        udpsocketrtn = udpsocket.UdpSend(xmlsenddata)
                        udpsocket.UdpSocketClose()
                if xmlalertmathines != []:
                    for xmlalert in xmlalertmathines:
                        if xmlsenddiskdata != []:
                            for senddata in xmlsenddiskdata:
                                xmlsocket = socketclass.XmlSocket(xmlalert['ip'],int(xmlalert['port']))
                                xmlconnectrtn = xmlsocket.XmlConnect()
                                if xmlconnectrtn == -1:
                                    xmlsocket.XmlSocketClose()
                                    continue
                                xmlsocketrtn = xmlsocket.XmlSend(senddata)
                                xmlsocket.XmlSocketClose()
                                xmlsenddiskdata = []
                        if xmlsenddata != '':
                            xmlsocket = socketclass.XmlSocket(xmlalert['ip'],int(xmlalert['port']))
                            xmlconnectrtn = xmlsocket.XmlConnect()
                            if xmlconnectrtn == -1:
                                xmlsocket.XmlSocketClose()
                                continue
                            xmlsocketrtn = xmlsocket.XmlSend(xmlsenddata)
                            xmlsocket.XmlSocketClose()
                            xmlsenddata = ''
            xmldata = []

class CheckNetThread(threading.Thread):
    def __init__ (self,threadname,checkqueue,mailqueue):
        threading.Thread.__init__(self,name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','CheckNetThread Init')
        self._checkqueue = checkqueue
        self._mailqueue = mailqueue
    def run (self):
        setting.errlogdata(setting.LINE(),'threadclass.py','CheckNetThread Run')
        while True:
            self._checkqueue.put('netcheck')
            #self._checkqueue.put('diskcheck')
            #fandata = readfan.fanalarm()
            #if fandata != '':
                #self._mailqueue.put(fandata)
            time.sleep(10)

class SnmpThread(threading.Thread):
    def __init__(self,threadname,snmpqueue):
        threading.Thread.__init__(self,name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','SnmpThread Init')
        self._snmpqueue = snmpqueue
    def run (self):
        setting.errlogdata(setting.LINE(),'threadclass.py','SnmpThread Run')
        snmpdata = []
        while True:
            while True:
                snmpdata.append(self._snmpqueue.get())
                if self._snmpqueue.empty() == True:
                    break
            for data in snmpdata:
                snmptrap.SendFileTrap(data)
            snmpdata = []

class DiskThread(threading.Thread):
    def __init__ (self,threadname,diskqueue,checkqueue):
        threading.Thread.__init__(self,name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','DiskThread Init')
        self._diskqueue = diskqueue
        self._checkqueue = checkqueue
    def run (self):
        setting.errlogdata(setting.LINE(),'threadclass.py','DiskThread Run')
        alldiskname = []
        while True:
            while True:
                alldiskname.append(self._diskqueue.get())
                if self._diskqueue.empty() == True:
                    break
            for diskname in alldiskname:
                diskflag = getdiskinfo.checkerrdisk(diskname)
                if diskflag == False:
                    getdiskinfo.cleardisk(diskname)
            alldiskname = []
            self._checkqueue.put("check")


class BeepThread(threading.Thread):
    def  __init__ (self,threadname,beepqueue):
        threading.Thread.__init__(self,name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','BeepThread Init')
        self._beepqueue = beepqueue
    def run (self):
        setting.errlogdata(setting.LINE(),'threadclass.py','BeepThread Run')
        if os.path.isfile(setting.BEEPFLAGCONF) == False:
            os.mknod(setting.BEEPFLAGCONF)
        while True:
            time.sleep(5)
            if os.path.exists(setting.BEEPSTOP) == False:
                if setting.BEEPFLAG or setting.SYSBEEPFLAG:
                    retcode,proc = utils.cust_popen('beep -f 3030 -r 30 -d 0.01 -l 1000')
                    if os.path.exists(setting.BEEP) == False:
                        os.makedirs(setting.BEEP)
                    cmd = setting.TOUCH + ' ' + setting.BEEPING
                    retcode,proc = utils.cust_popen(cmd)
                    if retcode != 0:
                        setting.errlogdata(setting.LINE(),'threadclass.py',proc.stdout.readlines())
                elif setting.BEEPFLAG == False and setting.SYSBEEPFLAG == False:
                    if os.path.exists(setting.BEEPING) == True:
                        cmd = setting.RM + ' ' + setting.BEEPING
                        retcode,proc = utils.cust_popen(cmd)
                        if retcode != 0:
                            setting.errlogdata(setting.LINE(),'threadclass.py',proc.stdout.readlines())

class HttpSocketThread(threading.Thread):
    def __init__ (self, threadname,socks,threadlock):
        threading.Thread.__init__(self, name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','HttpSocketThread Init')
        self.netsock = socks
        self._threadlock = threadlock
    def run(self):
        setting.errlogdata(setting.LINE(),'threadclass.py','HttpSocketThread Run')
        while True:
            self.netsock.Listen()
            self._threadlock.acquire()
            subhttpthread = SubHttpThread(self.netsock.connection)
            subhttpthread.start()
            self._threadlock.release()
'''
            if self.netsock.connlist == []:
                continue
            if setting.HTTPCHANGEFLAG == 1:
                a = self.netsock.connlist
                for m in range(len(a)):
                    rtn = self.netsock.Senddata(self.netsock.connlist[m],str(setting.HTTPCHANGEFLAG))
                    if rtn == 0:
                        continue
                for conn in self.netsock.connlist:
                    self.netsock.CloseConn(conn)
                self.netsock.connlist = []
                setting.HTTPCHANGEFLAG = 0
            time.sleep(0.01)
'''
class SubHttpThread(threading.Thread):
    def __init__ (self,sockname):
        threading.Thread.__init__(self)
        setting.errlogdata(setting.LINE(),'threadclass.py','SubHttpThread Init')
        self._queue = Queue()
        self._sockname = sockname
    def run (self):
        setting.errlogdata(setting.LINE(),'threadclass.py','SubHttpThread Run')
        senddata = ''
        setting.HTTPCHANGEFLAG.append(self._queue)
        while True:
            try:
                senddata = self._queue.get(True,10)
                try:
                    rtn = self._sockname.send(senddata)
                except:
                    break
            except:
                try:
                    rtn = self._sockname.send('0')
                    revcdata = self._sockname.recv(512)
                    continue
                except:
                    break
        #self._queue.task_done()
        setting.HTTPCHANGEFLAG.remove(self._queue)

class CheckIP(threading.Thread):
    def __init__ (self, threadname,snmpqueue):
        threading.Thread.__init__(self, name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','CheckIP Init')
        self._snmpqueue = snmpqueue
    def run (self):
        setting.errlogdata(setting.LINE(),'threadclass.py','CheckIP Run')
        m = ['/','/home']
        nowdata1 = {}
        nowdatahome = {}
        while True:
            for n in m:
                snmpdata = {}
                cmd = setting.DF + ' -h ' + n
                retcode,proc = utils.cust_popen(cmd)
                datas = proc.stdout.read()
                snmpdata['op'] = 'systemdisk'
                snmpdata['dirname'] = n
                a = datas.split('\n')
                b = a[-2].split(' ')
                d =[]
                for c in b:
                    if c != '':
                        d.append(c)
                if d == []:
                    continue 
                snmpdata['used'] = d[-2]
                diruse = int(d[-2][:-1])
                if diruse >= 80 and diruse < 90:
                    snmpdata['flag'] = 'notice'
                elif diruse >= 90 and diruse < 95:
                    snmpdata['flag'] = 'warning'
                elif diruse >= 95:
                    snmpdata['flag'] = 'error'
                else:
                    snmpdata['flag'] = 'ok'
                if snmpdata['dirname'] == '/':
                    if nowdata1 == {}:
                        nowdata1 = deepcopy(snmpdata)
                        if snmpdata['flag'] != 'ok':
                            print 'send:',snmpdata
                            self._snmpqueue.put(snmpdata)
                    else:
                        if nowdata1['flag'] != snmpdata['flag']:
                            print 'send:',snmpdata
                            self._snmpqueue.put(snmpdata)
                            nowdata1 = deepcopy(snmpdata)
                if snmpdata['dirname'] == '/home':
                    if nowdatahome == {}:
                        nowdatahome = deepcopy(snmpdata)
                        if snmpdata['flag'] != 'ok':
                            print 'send:',snmpdata
                            self._snmpqueue.put(snmpdata)
                    else:
                        if nowdatahome['flag'] != snmpdata['flag']:
                            print 'send:',snmpdata
                            self._snmpqueue.put(snmpdata)
                            nowdatahome = deepcopy(snmpdata)
            time.sleep(60)
            '''
            allport = []
            errdata = checkip.checkip()
            if writeflag != []:
                for net in errdata:
                    allport.append(net['eth'])
                for net in writeflag:
                    if net not in allport:
                        delport.append(net)
                for portdata in delport:
                    m = '%s has been deleted.' %(portdata)
                    chm = '%s ��ɾ��' %(portdata) 
                    setting.iperrdata(m,'en')
                    setting.iperrdata(chm,'ch')
                    writeflag.remove(portdata)
            for data in errdata:
                if data['flag'] == 'error' and data['eth'] not in writeflag:
                    setting.iperrdata(data['data'],'en')
                    setting.iperrdata(data['chdata'],'ch')
                    writeflag.append(data['eth'])
                if data['flag'] == 'ok' and data['eth'] in writeflag:
                    setting.iperrdata(data['data'],'en')
                    setting.iperrdata(data['chdata'],'ch')
                    writeflag.remove(data['eth'])
            '''
            #time.sleep(300)

class CheckSysDisk(threading.Thread):
    def __init__ (self, threadname,mailqueue):
        threading.Thread.__init__(self, name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','CheckSysDisk Init')
        self._mailqueue = mailqueue
    def run (self):
        setting.errlogdata(setting.LINE(),'threadclass.py','CheckSysDisk Run')
        errdata = ''
        cherrdata = ''
        while True:
            errdisk = checksysdisk.writeconf()
            if errdisk != [] and errdisk[0] == 'single':
                time.sleep(3600)
                continue
            if errdisk != []:
                if setting.OLDERRDISK == []:
                    for data in errdisk:
                        errdata = errdata + ' System Disk Error,S/N:' + data['Serial_No'] + ',State:' + data['State'] + '\n'
                        cherrdata = cherrdata + 'ϵͳ�̴���,S/N:' + data['Serial_No'] + ',״̬:' + data['State'] + '\n'
                    setting.OLDERRDISK = errdisk
                    if errdata != '':
                        setting.iperrdata(errdata.strip(),'en')
                        setting.iperrdata(cherrdata.strip(),'ch')
                        errdata = time.strftime("%Y-%m-%d %X", time.localtime()) + ' ' + errdata
                        self._mailqueue.put(errdata)
                        errdata = ''
                else:
                    for data in errdisk:
                        if data not in setting.OLDERRDISK:
                            errdata = errdata + ' System Disk Error,S/N:' + data['Serial_No'] + ',State:' + data['State'] + '\n'
                            cherrdata = cherrdata + ' ϵͳ�̴���,S/N:' + data['Serial_No'] + ',״̬:' + data['State'] + '\n'
                    setting.OLDERRDISK = errdisk
                    if errdata != '':
                        setting.iperrdata(errdata.strip(),'en')
                        setting.iperrdata(cherrdata.strip(),'ch')
                        errdata = time.strftime("%Y-%m-%d %X", time.localtime()) + ' ' + errdata
                        self._mailqueue.put(errdata)
                        errdata = ''
                setting.SYSBEEPFLAG = True
            else:
                setting.SYSBEEPFLAG = False
            time.sleep(900)


class Getsysmsg(threading.Thread):
    def __init__ (self,threadname,snmpqueue):
        threading.Thread.__init__(self, name = threadname)
        setting.errlogdata(setting.LINE(),'threadclass.py','getsysmsg Init')
        self._snmpqueue = snmpqueue
    def run (self):
        diskmsg = []
        setting.errlogdata(setting.LINE(),'threadclass.py','getsysmsg Run')
        while True:
            getdiskinfo.update_disk_raid_snmp(setting.DISKCMD)
            #getdiskinfo.update_disk_raid_snmp(setting.RAIDCMD)
            diskmsg = sysmonitor.checkdisk()
            #setting.errlogdata(setting.LINE(),'threadclass.py',diskmsg)
            if diskmsg != []:
                for disk in diskmsg:
                    self._snmpqueue.put(disk)
            time.sleep(300)
            sysmsg = sysmonitor.CentOs7_check_cpu_mem()
            if sysmsg != []:
                for msg in sysmsg:
                    setting.errlogdata(setting.LINE(),'threadclass.py',msg)
                    self._snmpqueue.put(msg)
            time.sleep(300)
