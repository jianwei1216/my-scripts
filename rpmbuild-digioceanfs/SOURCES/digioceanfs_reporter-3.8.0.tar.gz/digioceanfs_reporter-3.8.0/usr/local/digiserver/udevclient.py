import os,sys,socket
import json
import traceback
import time
errlog = "/usr/local/digiserver/log/err.log"
DEBUG = True
def LINE ():
    return traceback.extract_stack()[-2][1]

def errlogdata (line,module,errdata = None):
    if DEBUG == True:
        if os.path.isfile(errlog) == False:
            os.mknod(errlog)
        nowtime = time.strftime("%Y-%m-%d %X")
        if errdata is None:
            err_data = '%s %s [line:%s]: ' %(nowtime,module,line)
            f = open(errlog,'a')
            f.write(err_data)
            traceback.print_exc(file = f)
            f.flush()
            f.close()
        else:
            #print >> sys.stderr,'%s %s [line:%s]: %s' %(nowtime,module,line,errdata)
            err_data = '%s %s [line:%s]: %s\n' %(nowtime,module,line,errdata)
            f = open(errlog,'a')
            f.write(err_data)
            #traceback.print_exc(file = f)
            f.flush()
            f.close()


class Client:
    def sendmsg(self,argv1):
        try:
            s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
            s.connect("/tmp/pipe.d")
            if argv1.find('add')!=-1:
                b=json.dumps({"op":"udev","event":"add","param":argv1[argv1.find('-')+1:]})
                s.send(b)
            if argv1.find('rm')!=-1:
                b=json.dumps({"op":"udev","event":"remove","param":argv1[argv1.find('-')+1:]})
                s.send(b)
                #print s.recv(1000)
            s.close()
        except:
            errlogdata(LINE(),'udevclient',traceback.print_exc())
argv1=sys.argv[1]
errlogdata(LINE(),'udevclient',argv1)
client=Client()
client.sendmsg(argv1)
