'''
Created on 2014-5-14

@author: ballma
'''
import datetime
import logging
import os
import logging.config

LOG_LEVEL = {2: logging.CRITICAL, 3: logging.ERROR, 4: logging.WARN, 5: logging.INFO, 7: logging.DEBUG}

class Log:
    
    def __init__(self):
        try:
            os.mkdir('/var/log/digiserver')
            os.system('touch /var/log/digiserver/digiserver.log')
        except:
            pass
        logging.config.fileConfig('/usr/local/digiserver/log.conf')

        # create logger
        logger = logging.getLogger('digiServer')
        #logging.basicConfig(filename=logfilepath,format='%(asctime)s [-] %(message)s')#,level=LOG_LEVEL[l])
        #ch.setLevel(logging.DEBUG)
        #logger = logging.getLogger()
        #logger.setLevel(logging.ERROR)
        
    def msg(self, msgStr, lvl):
        if lvl == 2:
            logging.critical(msgStr)
        elif lvl == 3:
            logging.error(msgStr)
        elif lvl == 4:
            logging.warn(msgStr)
        elif lvl == 5:
            logging.info(msgStr)
        elif lvl == 7:
            logging.debug(msgStr)
        else:
            logging.error(msgStr)
        
def test():
    log = Log()
    log.msg('log test')
    
if __name__ == "__main__":
    test()