#coding: utf-8
import os
import sys
import socket
import select
import setting
import time
import utils 
import simplejson as json
from Queue import Queue
stdout = setting.stdout
stderr = setting.errlog
class Socket():
    def __init__ (self):
        self.connection = ''
        self.address = ''
        self.connlist = []
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        if os.path.exists('/tmp/pipe.d'):
            os.unlink('/tmp/pipe.d')
        self.sock.bind('/tmp/pipe.d')
        retcode,proc = utils.cust_popen('/bin/chmod 777 /tmp/pipe.d')
        if retcode != 0:
            print >> sys.stderr,proc.stderr.readlines()
    def Listen (self):
        try:
            self.sock.listen(100)
            if self.connlist != []:
                infds,outfds,errfds = select.select([self.sock,],[],[],0)
                if len(infds) != 0:
                    self.connection,self.address = self.sock.accept()
                    self.connlist.append(self.connection)
            else:
                self.connection,self.address = self.sock.accept()
                self.connlist.append(self.connection)
        except:
            setting.errlogdata(setting.LINE(),'socketclass.py','listen error')
    def Senddata (self,conn,senddata = 'ok'):
        try:
            sendbuf = conn.send(senddata)
        except:
            setting.errlogdata(setting.LINE(),'socketclass.py','send data error')
    def Recvdata (self,conn,queue):
        conn.setblocking(0)
        try:
            readbuf = conn.recv(512)
            if readbuf == '':
                return 2
            else:
                data = json.loads(readbuf)
                queue.put(data)
                return 0
        except:
            return 1 

    def CloseConn (self,conn):
        try:
            self.connlist.remove(conn)
            conn.close()
        except:
            setting.errlogdata(setting.LINE(),'socketclass.py','close connect error')

class XmlSocket():
    def __init__ (self,host,port):
        if host == None or port == None:
            setting.errlogdata(setting.LINE(),'socketclass.py','Host or Port error')
            return None
        self.host = host
        self.port = port 
        self.bufsize = 1024 
        self.addr = (self.host,self.port)
        self.xmlsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    def XmlConnect (self):
        try:
            a = self.xmlsock.connect((self.host,self.port))
            return 1
        except:
            setting.errlogdata(setting.LINE(),'socketclass.py','xmlsocket connect error')
            return -1

    def XmlRecv (self):
        try:
            recvdata = self.xmlsock.recv(self.bufsize)
            print recvdata
        except:
           setting.errlogdata(setting.LINE(),'socketclass.py','xmlsocket recvdata error')

    def XmlSend (self,xmldata):
        try:
            xmlsenddatanum = self.xmlsock.send(xmldata)
            return xmlsenddatanum
        except:
            setting.errlogdata(setting.LINE(),'socketclass.py','xmlsocket senddata error')

    def XmlSocketClose (self):
        try:
            self.xmlsock.close()
        except:
            setting.errlogdata(setting.LINE(),'socketclass.py','xmlsocket close error')

class UdpSocket():
    def __init__ (self,host,port):
        if host == None or port == None:
            setting.errlogdata(setting.LINE(),'socketclass.py','Host or Port error')
            return None
        self.host = host
        self.port = port 
        self.bufsize = 1024 
        self.addr = (self.host,self.port)
        self.udpsock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

    def UdpRecv (self):
        try:
            recvdata = self.udpsock.recv(self.bufsize)
        except:
           setting.errlogdata(setting.LINE(),'socketclass.py','udpsock recvdata error')
    
    def UdpSend (self,xmldata):
        try:
            udpsenddatanum = self.udpsock.sendto(xmldata,(self.host,self.port))
            return udpsenddatanum
        except:
            setting.errlogdata(setting.LINE(),'socketclass.py','udpsocket senddata error')

    def UdpSocketClose (self):
        try:
            self.udpsock.close()
        except:
            setting.errlogdata(setting.LINE(),'socketclass.py','udpsocket close error')

class HttpSocket():
    def __init__ (self):
        self.connection = ''
        self.address = ''
        self.connlist = []
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        if os.path.exists('/tmp/httppipe.d'):
            os.unlink('/tmp/httppipe.d')
        self.sock.bind('/tmp/httppipe.d')
        retcode,proc = utils.cust_popen('/bin/chmod 777 /tmp/httppipe.d')
        if retcode != 0:
            print >> sys.stderr,proc.stderr.readlines()
    def Listen (self):
        try:
            self.sock.listen(100)
            self.connection,self.address = self.sock.accept()
            #self.connlist.append(self.connection)
            '''
            if self.connlist != []:
                infds,outfds,errfds = select.select([self.sock,],[],[],0)
                if len(infds) != 0:
                    self.connection,self.address = self.sock.accept()
                    self.connlist.append(self.connection)
            else:
            '''
        except:
            setting.errlogdata(setting.LINE(),'SocketClass.py','httpsocket listen error')
    def Senddata (self,conn,senddata):
        try:
            sendbuf = conn.send(senddata)
            return 1
        except:
            setting.errlogdata(setting.LINE(),'SocketClass.py','httpsocket send data error')
            return 0
    def Recvdata (self,conn):
        conn.setblocking(0)
        try:
            readbuf = conn.recv(512)
            if readbuf == '':
                return 2
            else:
                return 0
        except:
            return 1
    def CloseConn (self,conn):
        try:
            conn.close()
        except:
            setting.errlogdata(setting.LINE(),'socketclass.py','http socket close connect error')

