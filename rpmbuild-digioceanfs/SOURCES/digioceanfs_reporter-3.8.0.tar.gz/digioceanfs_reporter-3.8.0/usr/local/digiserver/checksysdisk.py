#!/usr/bin/python
#coding: utf-8

import os
import sys
import utils
import setting

sasircu = '/usr/sbin/sas2ircu'

def getdoublesys ():
    sysdiskstate = {}
    retcode,proc = utils.cust_popen2([sasircu,'0','status'])
    if retcode != 0:
        setting.errlogdata(setting.LINE(),'checksysdisk.py','sas2ircu status command error!')
        return sysdiskstate
    data = proc.stdout.read()
    if data.find('Command STATUS Completed Successfully') != -1 and data.find('Utility Completed Successfully') != -1:
        sysdiskstate['SysDisk']= 'double'
    else:
        sysdiskstate['SysDisk'] = 'single'
    if sysdiskstate['SysDisk'] == 'double':
        a = data.split('\n')
        for b in a:
            if b.find('Current operation') != -1:
                c = b.find(':')
                sysdiskstate['COP'] = b[c+1:].strip()
            if b.find('Volume state') != -1:
                c = b.find(':')
                sysdiskstate['VState'] = b[c+1:].strip()
            if b.find('Percentage complete') != -1:
                c = b.find(':')
                sysdiskstate['PComplete'] = b[c+1:].strip()
    return sysdiskstate

def getsysstate ():
    sysdiskinfo = []
    irinfo = {}
    diskinfo = []
    sysdiskstate = getdoublesys()
    if sysdiskstate != {}:
        retcode,proc = utils.cust_popen2([sasircu,'0','display'])
        i = 0
        aa = []
        for data in proc.stdout.readlines():
            if data != '\n':
                aa.append(data)
                continue
            sysdiskinfo.append(aa)
            aa = []
        sysdiskinfo.append(aa)
        for data in sysdiskinfo[1]:
            if data.find('Status of volume') != -1:
                i = data.find(':')
                irinfo['Status_volume'] = data[i+1:].strip()
            if data.find('RAID level') != -1:
                i = data.find(':')
                irinfo['RAID_level'] = data[i+1:].strip()
        for m in range(len(sysdiskinfo)):
            if m > 1 and m < len(sysdiskinfo)-1:
                disk = {}
                Enclosure = ''
                Slot = ''
                State = ''
                for data in sysdiskinfo[m]:
                    if data.find('State') != -1:
                        State = data[data.find(':')+1:].strip()
                    if State != '' and State in ['Optimal (OPT)','Missing (MIS)','Rebuilding (RBLD)']:
                        disk['State'] = State
                        if data.find('Model Number') != -1:
                            disk['Model_Number'] = data[data.find(':')+1:].strip()
                        if data.find('Serial No') != -1:
                            disk['Serial_No'] = data[data.find(':')+1:].strip()
                if disk != {}:
                    diskinfo.append(disk)
    return sysdiskstate,diskinfo,irinfo

        
def writeconf ():
    writedata = []
    diskstate,diskinfo,irinfo = getsysstate()
    if diskstate != {}:
        if diskstate['SysDisk'] == 'double':
            writedata.append('STATUS')
            for key in diskstate:
                writedata.append(key + '=' + diskstate[key])
            if irinfo != {}:
                writedata.append('IR')
                for key in irinfo:
                    writedata.append(key + '=' + irinfo[key])
            if diskinfo != []:
                writedata.append('SYSTEM DISK')
                i = 0
                for data in diskinfo:
                    writedata.append('DISK' + str(i))
                    for key in data:
                        writedata.append(key + '=' + data[key])
                    i = i + 1
        else:
            writedata.append('STATUS')
            for key in diskstate:
                writedata.append(key + '=' + diskstate[key])
    f = open(setting.sysdiskconf,'w')
    for data in writedata:
        f.write(data)
        f.write('\n')
        f.flush()
    f.close()
    errdisk = []
    if diskstate != {} and diskstate['SysDisk'] == 'double':
        if diskstate['VState'] != 'Optimal':
            for data in diskinfo:
                if data['State'] not in ['Optimal (OPT)','Rebuilding (RBLD)']:
                    errdisk.append(data)
    else:
        return ['single']
    return errdisk

