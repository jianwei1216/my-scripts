#!/usr/bin/python
#-*- coding: UTF-8 -*-

import os
import sys
import re
import time
import copy
import pickle
import setting
import digimail
import getdiskinfo
from daemon import Daemon
import utils
import checkip
from checkdevice import digiraid4 as digiraid
from checkdevice.iniFile import IniFile
#---------------------------
#   paramter to be config
#---------------------------
#logtimeinterval = 0 #10 second
#mailtimeinterval = 0 #300 second
LOGMONITORDISK = MAILMONITORDISK = False
LOGMONITORRAID = MAILMONITORRAID = True
LOGMONITORLINK = MAILMONITORLINK = False
#---------------------------
# globals
#---------------------------
#command
miitool = '/sbin/mii-tool'
ethtool = '/usr/sbin/ethtool'
if utils.check_if_debian6():
    ethtool = '/sbin/ethtool'
monitorstopflag = '/tmp/digitools/monitorstop'
#sysfile
netdevicepath = '/sys/class/net/'
#deamon
stdin = '/dev/null'
stdout = setting.stdout
stderr = setting.errlog
#setting
#digioceanlogfile = os.path.join(setting.logpath,'log','monitor.log')
digioceanlogfile = setting.monitorlog
chdigioceanlogfile = setting.chmonitorlog
monitorsettingfile = os.path.join(setting.currpath,'conf','monitor.conf')
#other
logstarttime = mailstarttime = time.time()
digistow = digiraid.get_diskmap()
cdisknamemap = digistow.digidisk.disknamemap
cdiskset = digistow.digidisk.disknameset
monitorflag = False

diskchangeeventlist = []
chdiskchangeeventlist = []
ifaceeventlist = []
chifaceeventlist = []
raideventlist = []
chraideventlist = []
maileventlist = []
#---------------------------
#---------------------------
# 
#---------------------------
def get_ifaces():
    retcode,proc = utils.cust_popen2(['ls',netdevicepath])
    result = ''.join(proc.stdout.readlines())
    me_eth = '(eth\d+)'
    me_bond = '(bond(\d+))'
    eths = re.findall(me_eth, result)
    return eths
#---------------------------
# 
#---------------------------   
def get_settings():
    #global logtimeinterval,mailtimeinterval
    global LOGMONITORDISK,LOGMONITORRAID,LOGMONITORLINK,MAILMONITORDISK,MAILMONITORRAID,MAILMONITORLINK
    if os.path.isfile(monitorsettingfile):
        config = IniFile()
        config.read(monitorsettingfile)
        #log
        if config.has_section('logmonitor'):
            if config.has_option('logmonitor','monitordisk'):
                LOGMONITORDISK = config.getboolean('logmonitor','monitordisk')
            if config.has_option('logmonitor','monitorraid'):
                LOGMONITORRAID = config.getboolean('logmonitor','monitorraid')
            if config.has_option('logmonitor','monitorlink'):
                LOGMONITORLINK = config.getboolean('logmonitor','monitorlink')
        #mail
        if config.has_section('mailmonitor'): 
            if config.has_option('mailmonitor','monitordisk'):
                MAILMONITORDISK = config.getboolean('mailmonitor','monitordisk')
            if config.has_option('mailmonitor','monitorraid'):
                MAILMONITORRAID = config.getboolean('mailmonitor','monitorraid')
            if config.has_option('mailmonitor','monitorlink'):
                MAILMONITORLINK = config.getboolean('mailmonitor','monitorlink')


def CheckDevice (digistow,raiddevs):
    global logtimeinterval,mailtimeinterval,LOGMONITORDISK,LOGMONITORRAID,LOGMONITORLINK,MAILMONITORDISK,MAILMONITORRAID,MAILMONITORLINK,monitorflag
    global logstarttime,mailstarttime,cdiskset,cdisknamemap,diskchangeeventlist,ifaceeventlist,raideventlist,maileventlist
    newmaileventlist = []
    msg = None
    try:
        if not monitorflag:
            monitorflag = True
            currtime = time.time()
            get_settings()
            if LOGMONITORDISK or MAILMONITORDISK or LOGMONITORRAID or MAILMONITORRAID or LOGMONITORLINK or MAILMONITORLINK:
                #monitor disk
                if LOGMONITORDISK or MAILMONITORDISK:
                    #if currtime - logstarttime >= logtimeinterval or currtime - mailstarttime >= mailtimeinterval:
                    #digistow = digiraid.get_diskmap()
                    ndisknamemap = digistow.digidisk.disknamemap
                    ndiskset = digistow.digidisk.disknameset
                    if ndiskset != cdiskset:
                        ldiskset = cdiskset - ndiskset
                        adiskset = ndiskset - cdiskset
                        for disk in ldiskset:
                            diskchangeeventlist.append([time.strftime('%Y-%m-%d %X'),'the disk number %s (%s) is droped' % (cdisknamemap[disk],disk)])
                            chdiskchangeeventlist.append([time.strftime('%Y-%m-%d %X'),'���̺� %s (%s) ���γ���' % (cdisknamemap[disk],disk)])
                        for disk in adiskset:
                            diskchangeeventlist.append([time.strftime('%Y-%m-%d %X'),'the disk number %s (%s) is added' % (ndisknamemap[disk],disk)])
                            chdiskchangeeventlist.append([time.strftime('%Y-%m-%d %X'),'���̺� %s (%s) ����ӡ�' % (cdisknamemap[disk],disk)])
                    diskstate = digiraid.get_all_disk_state()
                    diskidmap = digistow.digidisk.diskidmap
                    for diskid,diskstatus in diskstate.iteritems():
                        if diskstatus == -2:
                            diskdev = '/dev/%s' % diskidmap[diskid]
                            diskchangeeventlist.append([time.strftime('%Y-%m-%d %X'),'the disk number %s (%s) is broken' % (diskid,diskdev)])
                            chdiskchangeeventlist.append([time.strftime('%Y-%m-%d %X'),'���̺� %s (%s) �𻵡�' % (diskid,diskdev)])
                    if diskchangeeventlist:
                        if LOGMONITORDISK:
                            f,fstat = utils.cust_fopen(digioceanlogfile,'a+')
                            for diskevent in diskchangeeventlist:
                                f.write('%s %s\n' % (diskevent[0],diskevent[1]))
                            utils.cust_fclose(f,fstat)
                            f,fstat = utils.cust_fopen(chdigioceanlogfile,'a+')
                            for diskevent in chdiskchangeeventlist:
                                f.write('%s %s\n' % (diskevent[0],diskevent[1]))
                            utils.cust_fclose(f,fstat)
                        if MAILMONITORDISK:
                            for diskevent in diskchangeeventlist:
                                maileventlist.append('%s' % (diskevent[1]))
                    cdiskset = ndiskset
                    cdisknamemap = ndisknamemap
                    diskchangeeventlist = []
                #monitor raid
                if LOGMONITORRAID or MAILMONITORRAID:
                    #if currtime - logstarttime >= logtimeinterval or currtime - mailstarttime >= mailtimeinterval:
                    #raiddevs = digiraid.get_raid_info()
                    for raidid,raidinfo in raiddevs.iteritems():
                        if raidinfo['state'] in ['error','alert']:
                            raideventlist.append([time.strftime('%Y-%m-%d %X'),'the RAID %s (%s) is %s' % (raidinfo['showname'],raidinfo['raiddev'],raidinfo['state'])])
                            if raidinfo['state'] == 'error':
								chraideventlist.append([time.strftime('%Y-%m-%d %X'),'the RAID %s (%s) ��' % (raidinfo['showname'],raidinfo['raiddev'])])
                            else:
                                chraideventlist.append([time.strftime('%Y-%m-%d %X'),'the RAID %s (%s) ����' % (raidinfo['showname'],raidinfo['raiddev'])])
                    if raideventlist:
                        if LOGMONITORRAID:
                            f,fstat = utils.cust_fopen(digioceanlogfile,'a+')
                            for raidevent in raideventlist:
                                f.write('%s %s\n' % (raidevent[0],raidevent[1]))
                            utils.cust_fclose(f,fstat)
                            f,fstat = utils.cust_fopen(chdigioceanlogfile,'a+')
                            for raidevent in chraideventlist:
                                f.write('%s %s\n' % (raidevent[0],raidevent[1]))
                            utils.cust_fclose(f,fstat)
                        if MAILMONITORRAID:
                            for raidevent in raideventlist:
                                maileventlist.append('%s' % (raidevent[1]))
                    raideventlist = []
                #monitor link
                '''
                if LOGMONITORLINK or MAILMONITORLINK:
                    #if currtime - logstarttime >= logtimeinterval or currtime - mailstarttime >= mailtimeinterval:
                    ifacelist = get_ifaces()
                    for iface in ifacelist:
                        ifacelink = False
                        retcode,proc = utils.cust_popen("%s %s | grep 'Link detected' | awk -F\: '{print $2}'" % (ethtool,iface))
                        result = proc.stdout.read().strip()
                        if retcode == 0 and result and result == 'yes':
                            ifacelink = True
                        if not ifacelink:
                            ifaceeventlist.append([time.strftime('%Y-%m-%d %X'),'%s NIC Link is Down' % iface])
                    if ifaceeventlist:
                        if LOGMONITORLINK:
                            f,fstat = utils.cust_fopen(digioceanlogfile,'a+')
                            for ifaceevent in ifaceeventlist:
                                f.write('%s %s\n' % (ifaceevent[0],ifaceevent[1]))
                            utils.cust_fclose(f,fstat)
                        if MAILMONITORLINK:
                            for ifaceevent in ifaceeventlist:
                                maileventlist.append('%s' % (ifaceevent[1]))
                ifaceeventlist = []
                '''
                #if currtime - mailstarttime >= mailtimeinterval:
                if maileventlist:
                    mathineip = ''
                    retcode,proc = utils.cust_popen("ifconfig  | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk '{ print $1}'")
                    alertmathineips = proc.stdout.readlines()
                    if alertmathineips:
                        mathineip = alertmathineips[0]
                    for maildata in maileventlist:
                        if maildata not in setting.oldmaileventlist:
                            newmaileventlist.append(maildata)
                    setting.oldmaileventlist = maileventlist[:]
                    newmaileventlist.insert(0,'Mathine: %s' % mathineip)
                    newmaileventlist.insert(1,time.strftime('%Y-%m-%d %X'))
                    #maileventlist.insert(0,'Mathine: %s' % mathineip)
                    #maileventlist.insert(1,time.strftime('%Y-%m-%d %X'))
                    msg = '<br />'.join(newmaileventlist)
                    #msg = '<br />'.join(maileventlist)
                    maileventlist = []
                    newmaileventlist = []
            else:
                setting.errlogdata(setting.LINE(),'sysmonitor.py','no item to be monitor!')
            monitorflag = False
            if msg == None:
                setting.oldmaileventlist = []
            return msg
    except Exception,e:
        print e

def getconnectip ():
    iplist = []
    mymac = ''
    myeth = ''
    ipaddr = checkip.CentOs7_readipaddr()
    retcode,proc = utils.cust_popen2([setting.CAT,setting.IPFILEADDR])
    datas = proc.stdout.readlines()
    for data in datas:
        if data.find('####DigioceanfsNode####') != -1:
            c = {}
            ipmsg = data.split(' ')
            c['addr'] = ipmsg[0]
            c['node'] = ipmsg[1]
            iplist.append(c)
    for myip in ipaddr:
        for nodeip in iplist:
            if myip['addr'] == nodeip['addr']:
                mymac = myip['mac']
    if mymac != '':
        for myip in ipaddr:
            if myip['eth'].find('eth') != -1 and mymac == myip['mac']:
                myeth = myip['eth']
    return myeth


def CheckNet ():
    ifacedata = []
    nodemanageflag = False
    try:
        eth = getconnectip()
        ifacelist = get_ifaces()
        for iface in ifacelist:
            data = {}
            retcode,proc = utils.cust_popen("%s %s" % (ethtool,iface))
            result = proc.stdout.readlines()
            data['Net'] = iface
            for a in result:
                i = a.find('Link detected:')
                j = len('Link detected:')
                if i != -1:
                    data['Link'] = a[i+j:].strip()
            if data['Link'] == 'yes':
                for b in range(len(result)):
                    k = result[b].find('Speed:')
                    l = len('Speed:')
                    if k != -1:
                        data['Speed'] = result[b][k+l:].strip()[:-4]
                    if result[b].find('1000baseT/Full') != -1:
                        data['MaxSpeed'] = '1000'
                    elif result[b].find('100baseT/Full') != -1:
                        data['MaxSpeed'] = '100'
                    elif result[b].find('10baseT/Full') != -1:
                        data['MaxSpeed'] = '10'
            ifacedata.append(data)
        for mylink in ifacedata:
            if mylink['Net'] == eth:
                if mylink['Link'] == 'no':
                    setting.NODEMANGEFLAG = False
                else:
                    setting.NODEMANGEFLAG = True
        if setting.NODEMANGEFLAG == False:
            setting.NODERESTARTFLAG = False
        return ifacedata
    except Exception,e:
        print e

def speedresume (eth,speed):
    cmd = '%s -s %s speed %s duplex full' %(ethtool,eth,speed)
    retcode,proc = utils.cust_popen(cmd)
    return 0

'''
def CheckNet ():
    global LOGMONITORDISK,LOGMONITORRAID,LOGMONITORLINK,MAILMONITORDISK,MAILMONITORRAID,MAILMONITORLINK,monitorflag
    global logstarttime,mailstarttime,cdiskset,cdisknamemap,diskchangeeventlist,ifaceeventlist,raideventlist,maileventlist
    netmaileventlist = []
    newnetmaileventlist = []
    get_settings()
    msg = None
    try:
        if LOGMONITORLINK or MAILMONITORLINK:
            ifacelist = get_ifaces()
            for iface in ifacelist:
                ifacelink = False
                retcode,proc = utils.cust_popen("%s %s | grep 'Link detected' | awk -F\: '{print $2}'" % (ethtool,iface))
                result = proc.stdout.read().strip()
                if retcode == 0 and result and result == 'yes':
                    ifacelink = True
                if not ifacelink:
                    ifaceeventlist.append([time.strftime('%Y-%m-%d %X'),'%s NIC Link is Down' % iface])
                    chifaceeventlist.append([time.strftime('%Y-%m-%d %X'),'%s �������ӶϿ���' % iface])
            if ifaceeventlist:
                if LOGMONITORLINK:
                    f,fstat = utils.cust_fopen(digioceanlogfile,'a+')
                    for ifaceevent in ifaceeventlist:
                        f.write('%s %s\n' % (ifaceevent[0],ifaceevent[1]))
                    utils.cust_fclose(f,fstat)
                    f,fstat = utils.cust_fopen(chdigioceanlogfile,'a+')
                    for ifaceevent in chifaceeventlist:
                        f.write('%s %s\n' % (ifaceevent[0],ifaceevent[1]))
                    utils.cust_fclose(f,fstat)
                if MAILMONITORLINK:
                    for ifaceevent in ifaceeventlist:
                        netmaileventlist.append('%s' % (ifaceevent[1]))
        ifaceeventlist = []
        if netmaileventlist:
            mathineip = ''
            retcode,proc = utils.cust_popen("ifconfig  | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk '{ print $1}'")
            alertmathineips = proc.stdout.readlines()
            if alertmathineips:
                mathineip = alertmathineips[0]
            for maildata in netmaileventlist:
                if maildata not in setting.oldnetmaileventlist:
                    newnetmaileventlist.append(maildata)
            setting.oldnetmaileventlist = netmaileventlist[:]
            newnetmaileventlist.insert(0,'Mathine: %s' % mathineip)
            newnetmaileventlist.insert(1,time.strftime('%Y-%m-%d %X'))
            msg = '<br />'.join(newnetmaileventlist)
            netmaileventlist = []
            newnetmaileventlist = []
        if msg == None:
            setting.oldnetmaileventlist = []
        return msg
    except Exception,e:
        print e

'''
#-------------------------
#check disk temperature and rotate
#-------------------------
'''
def checkdisk(digistow):
    rtndata = {}
    rtndata_temp_rate = {}
    rtndata_state = {}
    ndisknamemap = digistow.digidisk.disknamemap
    for key in ndisknamemap:
        if key == None:
            continue
        diskmsg = getdiskinfo.get_disk_attr(key)
        try:
            if int(diskmsg["temp"]) > 68:
                rtndata_temp_rate[key] = {"temp":diskmsg["temp"],"rate":getdiskinfo.readrate(key),"error":"1"}
        except:
            rtndata_temp_rate[key] = {"temp":'UNKNOWN',"rate":getdiskinfo.readrate(key),"error":"1"}
        diskstate = getdiskinfo.get_disk_state(key)
        try:
            if not diskstate["state"] in ['PASSED','OK']:
                rtndata_state[key] = {'state':diskstate["state"],'count':diskmsg["RAW_VALUE"]}
        except:
            rtndata_state[key] = {'state':'UNKNOWN','count':'UNKNOWN'}
    rtndata["temp"] = rtndata_temp_rate
    rtndata["state"] = rtndata_state
    return rtndata
'''
def checkdisk ():
    rtn = []
    rtndata = {}
    disks = {}
    cmd = setting.CAT + ' ' + '/etc/snmpd-smartctl-connector'
    retcode,proc = utils.cust_popen(cmd)
    a = proc.stdout.readlines()
    for b in a:
        if b.find('#') == -1 and b.find('DEVICES=') != -1:
            i = b.find('(')
            j = b.find(')')
            c = b[i+1:j]
            disks = c.split(' ')
    if disks != {}:
        for disk in disks:
            diskmsg = getdiskinfo.get_disk_attr(disk[5:])
            if diskmsg and 'temp' in diskmsg:
                if int(diskmsg['temp']) > 60 and int(diskmsg['temp']) < 70:
                    rtndata['op'] = 'disktemp'
                    rtndata['name'] = disk[5:]
                    rtndata['temp'] = diskmsg['temp'].strip()
                    rtndata['flag'] = 'notice'
                elif int(diskmsg['temp']) >= 70:
                    rtndata['op'] = 'disktemp'
                    rtndata['name'] = disk[5:]
                    rtndata['temp'] = diskmsg['temp'].strip()
                    rtndata['flag'] = 'warning'
            if rtndata != {}:
                rtn.append(rtndata)
                rtndata = {}
    #setting.errlogdata(setting.LINE(),'sysmonitor.py',rtn)
    return rtn

def log_command_cpu_info(tmp_list):
    for i in range(len(tmp_list)):
        if tmp_list[i].find('PID USER      PR  NI  VIRT  RES  SHR S %CPU %MEM    TIME+  COMMAND') >= 0:
            j = 1
            line = tmp_list[i+j].split()
            while line:
                setting.errlogdata(setting.LINE(),'sysmonitor.py','PID : %s CPU : %s COMMAND : %s' % (line[0],line[8],line[11]))
                j = j+1
                line = tmp_list[i+j].split()

def check_cpu_mem ():
    rtndata = []
    data = {}
    cmd = setting.TOP + ' -bi -n 1'
    retcode,proc = utils.cust_popen(cmd)
    tmp_list = proc.stdout.readlines()
    #setting.errlogdata(setting.LINE(),'sysmonitor.py',tmp_list)
    spare_cpu = float(tmp_list[2].split()[4].split('%')[0])
    used_cpu = 100 - spare_cpu
    if used_cpu > 90.0 and used_cpu < 95.0:
        data['op'] = 'usedcpu'
        data['name'] = 'usedcpu'
        data['used'] = str(used_cpu)
        data['flag'] = 'notice'
    elif used_cpu >= 95.0:
        data['op'] = 'usedcpu'
        data['name'] = 'usedcpu'
        data['used'] = str(used_cpu)
        data['flag'] = 'warning'
    if data != {}:
        log_command_cpu_info(tmp_list)
        rtndata.append(data)
        data = {}
    setting.errlogdata(setting.LINE(),'sysmonitor.py',used_cpu)
    cmd = 'cat /proc/meminfo'
    retcode,proc = utils.cust_popen(cmd)
    tmp_list = proc.stdout.readlines()
    mem_total = tmp_list[0].split()[1]
    mem_free = tmp_list[1].split()[1]
    tmp_ret = 1- int(mem_free)/float(mem_total)   # ��ʽ 0.2054533303805729 �Ƿ�Ҫת��20.55%
    used_per = round(tmp_ret * 100, 2)
    if used_per > 95.0 and used_per <98.0:
        data['op'] = 'usedmem'
        data['name'] = 'usedmem'
        data['used'] = str(used_per)
        data['flag'] = 'notice'
    elif used_per >= 98.0:
        data['op'] = 'usedmem'
        data['name'] = 'usedmem'
        data['used'] = str(used_per)
        data['flag'] = 'warning'
    if data != {}:
        rtndata.append(data)
        data = {}

    temp = None
    cmd = 'ipmitool sdr'
    retcode,proc = utils.cust_popen(cmd)
    m = proc.stdout.readlines()
    for n in m:
        if n.find('CPU Temp') != -1:
            if n.find('degrees C') != -1:
                i = n.find('|')
                j = n.find('degrees C')
                temp = n[i+1:j].strip()
            if temp != None:
                if int(temp) >70 and int(temp) < 80:
                    data['op'] = 'cputemp'
                    data['name'] = 'cputemp'
                    data['used'] = temp
                    data['flag'] = 'notice'
                elif int(temp) >= 80:
                    data['op'] = 'cputemp'
                    data['name'] = 'cputemp'
                    data['used'] = temp
                    data['flag'] = 'warning'
            if data != {}:
                rtndata.append(data)
                data = {}
        fan = {}
        if n.find('FAN 1') != -1:
            i = n.find('|')
            j = n.find('RPM')
            fan['op'] = 'Fan'
            fan['name'] = 'cpufan'
            fan['used'] = n[i+1:j].strip()
            if int(fan['used']) < 100:
                fan['flag'] = 'warning'
                rtndata.append(fan)
            
        if n.find('FAN 2') != -1:
            i = n.find('|')
            j = n.find('RPM')
            fan['op'] = 'Fan'
            fan['name'] = 'fan1'
            fan['used'] = n[i+1:j].strip()
            if int(fan['used']) < 100:
                fan['flag'] = 'warning'
                rtndata.append(fan)
        if n.find('FAN 3') != -1:
            i = n.find('|')
            j = n.find('RPM')
            fan['op'] = 'Fan'
            fan['name'] = 'fan2'
            fan['used'] = n[i+1:j].strip()
            if int(fan['used']) < 100:
                fan['flag'] = 'warning'
                rtndata.append(fan)
    setting.errlogdata(setting.LINE(),'sysmonitor.py',rtndata)
    return rtndata

def CentOs7_check_cpu_mem ():
    rtndata = []
    data = {}
    cmd = setting.TOP + ' -bi -n 1'
    retcode,proc = utils.cust_popen(cmd)
    tmp_list = proc.stdout.readlines()
    #setting.errlogdata(setting.LINE(),'sysmonitor.py',tmp_list)
    spare_cpu = float(tmp_list[2].split()[7])
    used_cpu = 100 - spare_cpu
    if used_cpu > 90.0 and used_cpu < 95.0:
        data['op'] = 'usedcpu'
        data['name'] = 'usedcpu'
        data['used'] = str(used_cpu)
        data['flag'] = 'notice'
    elif used_cpu >= 95.0:
        data['op'] = 'usedcpu'
        data['name'] = 'usedcpu'
        data['used'] = str(used_cpu)
        data['flag'] = 'warning'
    if data != {}:
        log_command_cpu_info(tmp_list)
        rtndata.append(data)
        data = {}
    setting.errlogdata(setting.LINE(),'sysmonitor.py',used_cpu)
    cmd = 'cat /proc/meminfo'
    retcode,proc = utils.cust_popen(cmd)
    tmp_list = proc.stdout.readlines()
    mem_total = tmp_list[0].split()[1]
    mem_free = tmp_list[1].split()[1]
    tmp_ret = 1- int(mem_free)/float(mem_total)   # ��ʽ 0.2054533303805729 �Ƿ�Ҫת��20.55%
    used_per = round(tmp_ret * 100, 2)
    if used_per > 95.0 and used_per <98.0:
        data['op'] = 'usedmem'
        data['name'] = 'usedmem'
        data['used'] = str(used_per)
        data['flag'] = 'notice'
    elif used_per >= 98.0:
        data['op'] = 'usedmem'
        data['name'] = 'usedmem'
        data['used'] = str(used_per)
        data['flag'] = 'warning'
    if data != {}:
        rtndata.append(data)
        data = {}

    temp = None
    cmd = 'ipmitool sdr'
    retcode,proc = utils.cust_popen(cmd)
    m = proc.stdout.readlines()
    for n in m:
        if n.find('CPU Temp') != -1:
            if n.find('degrees C') != -1:
                i = n.find('|')
                j = n.find('degrees C')
                temp = n[i+1:j].strip()
            if temp != None:
                if int(temp) >70 and int(temp) < 80:
                    data['op'] = 'cputemp'
                    data['name'] = 'cputemp'
                    data['used'] = temp
                    data['flag'] = 'notice'
                elif int(temp) >= 80:
                    data['op'] = 'cputemp'
                    data['name'] = 'cputemp'
                    data['used'] = temp
                    data['flag'] = 'warning'
            if data != {}:
                rtndata.append(data)
                data = {}
        fan = {}
        if n.find('FAN 1') != -1:
            i = n.find('|')
            j = n.find('RPM')
            fan['op'] = 'Fan'
            fan['name'] = 'cpufan'
            fan['used'] = n[i+1:j].strip()
            if int(fan['used']) < 100:
                fan['flag'] = 'warning'
                rtndata.append(fan)

        if n.find('FAN 2') != -1:
            i = n.find('|')
            j = n.find('RPM')
            fan['op'] = 'Fan'
            fan['name'] = 'fan1'
            fan['used'] = n[i+1:j].strip()
            if int(fan['used']) < 100:
                fan['flag'] = 'warning'
                rtndata.append(fan)
        if n.find('FAN 3') != -1:
            i = n.find('|')
            j = n.find('RPM')
            fan['op'] = 'Fan'
            fan['name'] = 'fan2'
            fan['used'] = n[i+1:j].strip()
            if int(fan['used']) < 100:
                fan['flag'] = 'warning'
                rtndata.append(fan)
    setting.errlogdata(setting.LINE(),'sysmonitor.py',rtndata)
    return rtndata

if __name__ == '__main__':
    #CheckDevice()
    print CheckNet()
