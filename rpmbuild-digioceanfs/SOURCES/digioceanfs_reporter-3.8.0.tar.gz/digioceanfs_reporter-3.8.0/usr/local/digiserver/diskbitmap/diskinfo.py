#!/usr/bin/env python
#-*- coding: UTF-8 -*-

import os
import sys
import re
import traceback

currpath = os.path.join(os.getcwd(),os.path.dirname(__file__))
if not currpath in sys.path:
    sys.path.append(currpath)
homepath = currpath[:currpath.find('diskbitmap')]
if not homepath in sys.path:
    sys.path.append(homepath)
import utils
import baseboard
#-----------------------
#	globals
#-----------------------
MDSTAT = '/proc/mdstat'
#-----------------------
#	system command
#-----------------------
MDADM = '/sbin/mdadm'
#------------------------
# 0:unuse
# 1:inuse
# 2:broken
# 3:inactive
# 4:nodisk
#------------------------
def get_disk_state(diskname):
    global asortraiddisks
    global hasraid
    if diskname is None:
        return 4
    if diskname in asortraiddisks['faildisks']:
        return 2
    elif diskname in asortraiddisks['sparedisks']:
        return 1
    elif diskname in asortraiddisks['workingdisks']:
        return 1
    else:
        try:
            diskdev = '/dev/%s' % diskname
            retcode,proc = utils.cust_popen2([MDADM,'-E',diskdev])
            result = '%s%s' % (proc.stdout.read(),proc.stderr.read())
            if re.search("No md superblock detected on",result):
                return 0
            elif hasraid:
                return 2
            else:
                return 3
        except Exception,e:
            print >> sys.stderr,traceback.print_exc()
            return 2
#-------------------------------------------
#
#------------------------------------------- 
def get_sorted_raid_disks():
    global asortraiddisks
    global hasraid
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    diskstates = {'F':'faildisks','S':'sparedisks'}
    hasraid = False
    raiddiskmathch = '^md\d+\s+:\s+.*raid\d+\s+(.*)\n'
    diskstatematch = '(\S+)\((\S+)\)'
    asortraiddisks = {
        'faildisks':[],
        'sparedisks':[],
        'workingdisks':[]
    }
    i = 0
    reslen = len(result)
    while i < reslen:
        rdm = re.match(raiddiskmathch,result[i])
        if rdm:
            hasraid = True
            raiddiskstr = re.sub('\[\d+\]','',rdm.group(1))
            raiddisks = raiddiskstr.split()
            for raiddisk in raiddisks:
                dm = re.match(diskstatematch,raiddisk)
                if not dm is None:
                    asortraiddisks[diskstates[dm.group(2)]].append(dm.group(1))
                else:
                    asortraiddisks['workingdisks'].append(raiddisk)
            i += 2
            continue
        i += 1
#-------------------------------------------
#
#------------------------------------------- 
def get_disks_raid():
    diskraids = {}
    f = open(MDSTAT,'r')
    result = f.readlines()
    f.close()
    diskstates = {'F':'faildisks','S':'sparedisks'}
    raiddiskmathch = '^(md(\d+))\s+:\s+.*raid\d+\s+(.*)\n'
    diskstatematch = '(\S+)\((\S+)\)'
    i = 0
    reslen = len(result)
    while i < reslen:
        rdm = re.match(raiddiskmathch,result[i])
        if rdm:
            raidname = '/dev/%s' % (rdm.group(1))
            raidid = rdm.group(2)
            raiddiskstr = re.sub('\[\d+\]','',rdm.group(3))
            raiddisks = raiddiskstr.split()
            diskraids[raidid] = []
            for raiddisk in raiddisks:
                dm = re.match(diskstatematch,raiddisk)
                if not dm is None:
                    diskraids[dm.group(1)] = raidid
                else:
                    diskraids[raiddisk] = raidid
            i += 2
            continue
        i += 1
    return diskraids
#-------------------------------------------
# get all disk state
#-------------------------------------------    
def get_all_disk_state():
    diskstatemap = {}
    disks,disknameset,diskidmap,disknamemap,expanderidmap = baseboard.get_diskmap()
    if disks == [] or diskidmap == {} or disknamemap == {} or expanderidmap == {}:
        return diskstatemap
    get_sorted_raid_disks()
    for diskid,diskname in diskidmap.iteritems():
        diskstatemap[diskid] = get_disk_state(diskname)
    return diskstatemap

if __name__ == '__main__':
    diskstatemap = get_all_disk_state()
    print diskstatemap
    print '##################################'
